// ============================================================
// Sagitnote MD5 工具 — 与服务器 Md5Util.md5 完全一致
// 标准 RFC 1321 MD5：UTF-8 输入 → 32 位小写十六进制输出
// 仅用于 page/folder 同步的 URL_MD5 字段（_swMd5 是 SHA-256，用于 imageData，互不干扰）
// ============================================================

(function (global) {
  'use strict';

  // 32-bit 安全加法（JS 位运算返回有符号 32 位，但位模式正确）
  function _add(x, y) {
    var lsw = (x & 0xFFFF) + (y & 0xFFFF);
    var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
    return (msw << 16) | (lsw & 0xFFFF);
  }

  // 循环左移
  function _rotl(x, n) { return (x << n) | (x >>> (32 - n)); }

  // 通用混合：q = 非线性函数输出
  function _cmn(q, a, b, x, s, t) {
    return _add(_rotl(_add(_add(a, q), _add(x, t)), s), b);
  }
  function _F(a, b, c, d, x, s, t) { return _cmn((b & c) | ((~b) & d), a, b, x, s, t); }
  function _G(a, b, c, d, x, s, t) { return _cmn((b & d) | (c & (~d)), a, b, x, s, t); }
  function _H(a, b, c, d, x, s, t) { return _cmn(b ^ c ^ d, a, b, x, s, t); }
  function _I(a, b, c, d, x, s, t) { return _cmn(c ^ (b | (~d)), a, b, x, s, t); }

  function wpzl_md5(input) {
    if (input == null) return null;
    if (input === '') return 'd41d8cd98f00b204e9800998ecf8427e';

    // 1) UTF-8 编码 → 字节数组
    var bytes;
    if (typeof TextEncoder !== 'undefined') {
      bytes = new TextEncoder().encode(input);
    } else {
      var raw = unescape(encodeURIComponent(input));
      bytes = new Array(raw.length);
      for (var i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    }

    // 2) 字节 → little-endian 32-bit word 数组（含 padding 占位）
    var origLenBits = bytes.length * 8;
    var numWords = (((bytes.length + 8) >> 6) + 1) * 16; // padding 后 word 数（16 的倍数）
    var x = new Array(numWords);
    for (var i = 0; i < numWords; i++) x[i] = 0;
    for (var i = 0; i < bytes.length; i++) {
      x[i >> 2] |= bytes[i] << ((i % 4) * 8);
    }
    // padding：原始数据末尾加 0x80
    x[bytes.length >> 2] |= 0x80 << ((bytes.length % 4) * 8);
    // 末尾 word 存原始 bit 长度（低 32 位；URL 长度远小于 2^32）
    x[numWords - 2] = origLenBits;

    // 3) 64 轮压缩
    var a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
    for (var i = 0; i < numWords; i += 16) {
      var oa = a, ob = b, oc = c, od = d;

      a = _F(a, b, c, d, x[i + 0], 7, -680876936);
      d = _F(d, a, b, c, x[i + 1], 12, -389564586);
      c = _F(c, d, a, b, x[i + 2], 17, 606105819);
      b = _F(b, c, d, a, x[i + 3], 22, -1044525330);
      a = _F(a, b, c, d, x[i + 4], 7, -176418897);
      d = _F(d, a, b, c, x[i + 5], 12, 1200080426);
      c = _F(c, d, a, b, x[i + 6], 17, -1473231341);
      b = _F(b, c, d, a, x[i + 7], 22, -45705983);
      a = _F(a, b, c, d, x[i + 8], 7, 1770035416);
      d = _F(d, a, b, c, x[i + 9], 12, -1958414417);
      c = _F(c, d, a, b, x[i + 10], 17, -42063);
      b = _F(b, c, d, a, x[i + 11], 22, -1990404162);
      a = _F(a, b, c, d, x[i + 12], 7, 1804603682);
      d = _F(d, a, b, c, x[i + 13], 12, -40341101);
      c = _F(c, d, a, b, x[i + 14], 17, -1502002290);
      b = _F(b, c, d, a, x[i + 15], 22, 1236535329);

      a = _G(a, b, c, d, x[i + 1], 5, -165796510);
      d = _G(d, a, b, c, x[i + 6], 9, -1069501632);
      c = _G(c, d, a, b, x[i + 11], 14, 643717713);
      b = _G(b, c, d, a, x[i + 0], 20, -373897302);
      a = _G(a, b, c, d, x[i + 5], 5, -701558691);
      d = _G(d, a, b, c, x[i + 10], 9, 38016083);
      c = _G(c, d, a, b, x[i + 15], 14, -660478335);
      b = _G(b, c, d, a, x[i + 4], 20, -405537848);
      a = _G(a, b, c, d, x[i + 9], 5, 568446438);
      d = _G(d, a, b, c, x[i + 14], 9, -1019803690);
      c = _G(c, d, a, b, x[i + 3], 14, -187363961);
      b = _G(b, c, d, a, x[i + 8], 20, 1163531501);
      a = _G(a, b, c, d, x[i + 13], 5, -1444681467);
      d = _G(d, a, b, c, x[i + 2], 9, -51403784);
      c = _G(c, d, a, b, x[i + 7], 14, 1735328473);
      b = _G(b, c, d, a, x[i + 12], 20, -1926607734);

      a = _H(a, b, c, d, x[i + 5], 4, -378558);
      d = _H(d, a, b, c, x[i + 8], 11, -2022574463);
      c = _H(c, d, a, b, x[i + 11], 16, 1839030562);
      b = _H(b, c, d, a, x[i + 14], 23, -35309556);
      a = _H(a, b, c, d, x[i + 1], 4, -1530992060);
      d = _H(d, a, b, c, x[i + 4], 11, 1272893353);
      c = _H(c, d, a, b, x[i + 7], 16, -155497632);
      b = _H(b, c, d, a, x[i + 10], 23, -1094730640);
      a = _H(a, b, c, d, x[i + 13], 4, 681279174);
      d = _H(d, a, b, c, x[i + 0], 11, -358537222);
      c = _H(c, d, a, b, x[i + 3], 16, -722521979);
      b = _H(b, c, d, a, x[i + 6], 23, 76029189);
      a = _H(a, b, c, d, x[i + 9], 4, -640364487);
      d = _H(d, a, b, c, x[i + 12], 11, -421815835);
      c = _H(c, d, a, b, x[i + 15], 16, 530742520);
      b = _H(b, c, d, a, x[i + 2], 23, -995338651);

      a = _I(a, b, c, d, x[i + 0], 6, -198630844);
      d = _I(d, a, b, c, x[i + 7], 10, 1126891415);
      c = _I(c, d, a, b, x[i + 14], 15, -1416354905);
      b = _I(b, c, d, a, x[i + 5], 21, -57434055);
      a = _I(a, b, c, d, x[i + 12], 6, 1700485571);
      d = _I(d, a, b, c, x[i + 3], 10, -1894986606);
      c = _I(c, d, a, b, x[i + 10], 15, -1051523);
      b = _I(b, c, d, a, x[i + 1], 21, -2054922799);
      a = _I(a, b, c, d, x[i + 8], 6, 1873313359);
      d = _I(d, a, b, c, x[i + 15], 10, -30611744);
      c = _I(c, d, a, b, x[i + 6], 15, -1560198380);
      b = _I(b, c, d, a, x[i + 13], 21, 1309151649);
      a = _I(a, b, c, d, x[i + 4], 6, -145523070);
      d = _I(d, a, b, c, x[i + 11], 10, -1120210379);
      c = _I(c, d, a, b, x[i + 2], 15, 718787259);
      b = _I(b, c, d, a, x[i + 9], 21, -343485551);

      a = _add(a, oa);
      b = _add(b, ob);
      c = _add(c, oc);
      d = _add(d, od);
    }

    // 4) state words → little-endian bytes → 小写 hex
    function toHex(w) {
      var h = '';
      for (var i = 0; i < 4; i++) {
        var by = (w >>> (i * 8)) & 0xFF;
        h += (by < 16 ? '0' : '') + by.toString(16);
      }
      return h;
    }
    return toHex(a) + toHex(b) + toHex(c) + toHex(d);
  }

  global.wpzl_md5 = wpzl_md5;
})(typeof self !== 'undefined' ? self : (typeof globalThis !== 'undefined' ? globalThis : this));
