// ============================================================
// Sagitnote - Sync Engine
// Loaded via importScripts('sync-engine.js') by service-worker.js
// Provides: bidirectional annotation sync (push/pull), dirty tracking,
//           conflict resolution (LWW), offline queue, retry scheduling
// Gated by: gradeConfig.features.cloudSync (data-driven; no isPro identity check)
// ============================================================

// ---- Configuration ----

var SYNC_INTERVAL_MINUTES = 15;
var SYNC_BATCH_SIZE = 50;
var SYNC_MAX_RETRIES = 10; // 兜底默认（服务端 sys_sync_max_retries 值到达前；服务端默认 10）。不再作丢弃硬上限。
var PUSH_DEBOUNCE_MS_BASE = 10000; // 基础 10s，加上随机抖动 0-5s
var PULL_COOLDOWN_MS = 5 * 60 * 1000;
// P1-5：no_dirty_skip 的多设备可见性兜底——上次成功拉取距今超过此时长时，无脏也放行一次
// 轻量 pull（对端删除/变更在 ≤~35min 内到达，无需打开页面或手动同步）。
var PROBE_PULL_MAX_STALE_MS = 30 * 60 * 1000;
var _syncDownloadTotal = null; // 服务端回传的标注总数（首次全量同步首页），供进度展示
var _syncDownloadPulled = 0;   // 当前同步周期已下载的标注数，供 manager 主动查询进度

function _getPushDebounceMs() {
  return PUSH_DEBOUNCE_MS_BASE + Math.floor(Math.random() * 5000); // 10-15s
}

// 大同步断点续传（Bug 7）：MV3 SW 30s 回收导致首次全量同步无法一次完成，
// 用持久化 cursor + alarm 续传。sync-resume alarm 仅在大同步进行中活跃，完成后清除。
var SYNC_RESUME_ALARM = 'sync-resume';
var SYNC_RESUME_ALARM_MINUTES = 1; // MV3 alarm 最小周期；首次大同步约 30-50 分钟完成
// E-P2-4: init 末尾浪涌打散用 one-shot alarm（无 pending 时替代 setTimeout，SW 可被回收）
var SYNC_JITTER_ALARM = 'sync-init-jitter';

// ---- Server-Error Backoff / Circuit Breaker ----
// 二分法：kind='network'（探活也不通）不触碰本熔断器，行为与历史一致（探活驱动 + 退避矩阵升档）；
// 探活通但 /api/v1/sync 业务请求失败（5xx 等 'server' 错误）→ serverErrorCount 累加，
// 达阈值熔断：冷却期内自动同步（immediate/normal）与 flushOfflineQueue 全部短路，
// manual（用户点「立即同步」）永远直通，任何成功即全复位。
// 状态存 chrome.storage.local（wpzl_sync_backoff），SW 被杀重启不重置。
var WPZL_SERVER_ERR_PAUSE_THRESHOLD = 3;                // 连续 3 次服务端错误 → 熔断
var WPZL_SERVER_ERR_COOLDOWN_BASE_MS = 30 * 60 * 1000;  // 首次熔断冷却 30min
var WPZL_SERVER_ERR_COOLDOWN_MAX_MS = 120 * 60 * 1000;  // 冷却上限 2h（30→60→120min 升级封顶）

function _serverErrBackoffDefault() {
  return {
    serverErrorCount: 0,     // 连续"服务端错误"次数（kind==='server'）；network 错误不加不清
    pausedUntil: 0,          // epoch ms；> Date.now() 表示熔断冷却中（自动同步暂停）
    pauseLevel: 0,           // 熔断档位，冷却时长 30·2^(level-1) min 升级
    lastServerErrorAt: null, // 诊断用（ISO）
    lastServerErrorMsg: null // 诊断用（截断 500 字符）
  };
}

async function _getServerErrBackoff() {
  return new Promise(function (resolve) {
    try {
      chrome.storage.local.get(['wpzl_sync_backoff'], function (r) {
        var b = (r && r.wpzl_sync_backoff) || _serverErrBackoffDefault();
        // 容错：老/坏数据补齐字段
        if (typeof b.serverErrorCount !== 'number') b.serverErrorCount = 0;
        if (typeof b.pausedUntil !== 'number') b.pausedUntil = 0;
        if (typeof b.pauseLevel !== 'number') b.pauseLevel = 0;
        resolve(b);
      });
    } catch (e) { resolve(_serverErrBackoffDefault()); }
  });
}

async function _setServerErrBackoff(b) {
  return new Promise(function (resolve) {
    try { chrome.storage.local.set({ wpzl_sync_backoff: b }, resolve); }
    catch (e) { resolve(); }
  });
}

async function _isServerErrPaused() {
  var b = await _getServerErrBackoff();
  return b.pausedUntil > Date.now();
}

async function _recordServerError(errMsg) {
  var b = await _getServerErrBackoff();
  b.serverErrorCount = (b.serverErrorCount || 0) + 1;
  b.lastServerErrorAt = new Date().toISOString();
  b.lastServerErrorMsg = ((errMsg || '') + '').slice(0, 500) || null;
  // half-open 语义：仅在当前不在冷却期内时重置冷却并升级档位——冷却期内再失败
  // （只可能是 manual 直通触发）不重复升级；冷却到期后的下一次尝试失败才升级。
  if (b.serverErrorCount >= WPZL_SERVER_ERR_PAUSE_THRESHOLD && b.pausedUntil <= Date.now()) {
    b.pauseLevel = (b.pauseLevel || 0) + 1;
    var cooldown = Math.min(WPZL_SERVER_ERR_COOLDOWN_BASE_MS * Math.pow(2, b.pauseLevel - 1),
                            WPZL_SERVER_ERR_COOLDOWN_MAX_MS);
    b.pausedUntil = Date.now() + cooldown;
    console.warn('[Sync] Server-error circuit OPEN: count=' + b.serverErrorCount +
                 ' level=' + b.pauseLevel + ' cooldown=' + Math.round(cooldown / 60000) + 'min');
  }
  await _setServerErrBackoff(b);
}

async function _resetServerErrBackoff() {
  var b = await _getServerErrBackoff();
  if (b.serverErrorCount === 0 && b.pausedUntil === 0) return; // 免写
  await _setServerErrBackoff({
    serverErrorCount: 0,
    pausedUntil: 0,
    pauseLevel: 0,
    lastServerErrorAt: b.lastServerErrorAt,
    lastServerErrorMsg: b.lastServerErrorMsg
  });
}

// Dirty bit definitions
var DIRTY_BIT_CONTENT = 1 << 0;       // CONTEXT
var DIRTY_BIT_COMMENT = 1 << 1;      // COMMENT_TEXT
var DIRTY_BIT_TAGS = 1 << 2;         // TAGS
var DIRTY_BIT_STYLE = 1 << 3;        // MARK_COLOR, TITLE, MARK_WIDTH, ANNOTATION_MODE
var DIRTY_BIT_POSITION = 1 << 4;     // XPATH, OFFSET, ANCHOR, etc.
var DIRTY_BIT_DELETED = 1 << 5;      // local delete
var DIRTY_BIT_THUMBNAIL = 1 << 6;    // THUMBNAIL (pageRect screenshots)
// page-level dirty bits（user_pages 同步用）
var DIRTY_BIT_TITLE = 1 << 7;        // page title
var DIRTY_BIT_FAVORITE = 1 << 8;     // favorite
var DIRTY_BIT_FOLDER = 1 << 9;       // folder_id
var DIRTY_BIT_PAGE_NOTE = 1 << 10;   // page_note blocks
var DIRTY_BIT_VISITED = 1 << 11;     // last_visited
var DIRTY_BIT_CUSTOM_TITLE = 1 << 12; // user-defined custom_title (rename)
var DIRTY_BIT_SORT_ORDER = 1 << 13;  // sort_order (目录树拖拽手动排序)

var SYNC_STATUS_LOCAL = 'local';
var SYNC_STATUS_PENDING = 'pending';
var SYNC_STATUS_SYNCED = 'synced';
var SYNC_STATUS_CONFLICT = 'conflict';
var SYNC_STATUS_ERROR = 'error';
var SYNC_STATUS_PENDING_DELETED = 'pending_deleted';

// 服务端拒绝原因中属于「永久失败」的集合：立即标 EXHAUSTED 停止自动重发（用户编辑/删后可手动重试）。
// 其余（cloud_quota / storage_error / doc_limit / invalid / 未知）为瞬时（doc_limit/snap_limit/cloud_quota 等限额类已在各自 mark* 处理函数中立即耗尽，见 spec 2026-09-21）。
// 文档/快照 body 上云专用；标注/页面/文件夹/图片不产生这些原因。
var PERMANENT_REJECTION_REASONS = {
  'doc_size_limit': true,
  'doc_size_limit=0': true,
  'snap_size_limit': true,
  'snap_size_limit=0': true,
  'body_conflict': true,
  'decompress_limit': true  // P1-43: GZ: 解压超 64MB（gzip 炸弹）——重试无意义
};

// 统一 /sync 请求体字节预算：服务端 filter 硬上限 15MB，超限 413「请求体过大」**整批**拒绝
// （S3-14 实测；且该响应非 ApiResponse 包裹体）。历史缺陷：批切片只按条数（200）无字节预算，
// 单个 >15MB DTO（照片文档 bodyHtml 内联 GZ 后仍超）拖垮整批 → 批级失败处理器把「请求体过大」
// 覆盖到批内**所有**记录的 SYNC_LAST_ERROR（含 daily_mark_limit 等逐项业务原因）并陪烧重试计数。
// 批累计预算 12MB：留 3MB 余量给请求包裹/转义/headers。
var SYNC_BATCH_BYTES_BUDGET = 12 * 1024 * 1024;
// 单条 DTO 序列化后超此值 = 单独成批也装不下（物理不可同步）→ 不入队、就地终态化（精确原因
// doc_size_limit/snap_size_limit/payload_too_large + EXHAUSTED），失败查看器立即可见、不连坐。
// 14MB 对应"单条独占一个请求"场景：14MB + 请求包裹 < 15MB 服务端上限。
var SYNC_ITEM_BYTES_HARD_CAP = 14 * 1024 * 1024;
function _isPermanentRejectionReason(reason) {
  return !!(reason && PERMANENT_REJECTION_REASONS[reason]);
}

// P1-14/P1-33：EXHAUSTED 主动通知——任一记录置耗尽（false→true 跃迁）时调用，取代
// "依赖用户自己打开失败查看器"的被动发现。双通道：
// ① chrome.runtime.sendMessage（manager 等扩展页 onMessage 实时收 → toast+角标刷新）；
// ② chrome.storage.local['wpzl_exhausted_notify'] 标志（popup 为拉模式无 listener，打开时读；
//    用户打开 manager 失败查看器后清除）。
function _broadcastSyncExhausted(detail) {
  try {
    chrome.runtime.sendMessage({ type: 'wpzl-sync-exhausted', detail: detail || {} },
      function () { void chrome.runtime.lastError; });
  } catch (e) { /* ignore */ }
  try {
    chrome.storage.local.get(['wpzl_exhausted_notify'], function (r) {
      var cur = (r && r.wpzl_exhausted_notify) || {};
      chrome.storage.local.set({
        wpzl_exhausted_notify: { count: ((cur.count || 0) + 1), at: Date.now() }
      });
    });
  } catch (e) { /* ignore */ }
}

// ---- 云端存储配额阻断：标志 + 释放探测自动恢复 + 提示节流 ----
// 配额满导致的拒绝（图片 40001 / docs/snaps cloud_quota）置 wpzl_quota_blocked；每轮 sync 成功后
// （及 onProChanged 升级时）探测 GET /assets/quota（读端点不受配额影响）：used < total（清理/升级已
// 释放空间）→ 仅复位"配额原因"的耗尽项并自动重传；仍满则保持耗尽不空转。此前耗尽项的唯一自动
// 复位入口是重新登录，用户按 toast 提示"清理或升级"后还得手动重试——本机制补上自动恢复路径。
var QUOTA_BLOCKED_KEY = 'wpzl_quota_blocked';
var QUOTA_TOAST_KEY = 'wpzl_quota_toast_time';
var QUOTA_TOAST_COOLDOWN_MS = 30 * 60 * 1000;

// ---- 云同步标注总量限额（markLimit）：阻断标志 + 专用提示 + 释放探测自动恢复 ----
// 与上方 assets 云存储配额互相独立：mark_limit 是标注条数限额、cloud_quota 是存储字节限额，
// 恢复条件（markCount<markLimit vs used<total）与探测端点都不同，不共享标志/提示。
var MARK_LIMIT_BLOCKED_KEY = 'wpzl_mark_limit_blocked';
var MARK_LIMIT_TOAST_KEY = 'wpzl_mark_limit_toast_time';
var MARK_LIMIT_TOAST_COOLDOWN_MS = 30 * 60 * 1000;

// 标注总量限额的服务端软拒原因：稳定 token mark_limit（不含数字，上限从 limits.markLimit 读）。
// 不入 PERMANENT_REJECTION_REASONS——否则被 _resetExhaustedState 的永久分支排除，升级/调额后无法自动复位。
function _isMarkLimitRejectionReason(reason) {
  return !!reason && String(reason) === 'mark_limit';
}

// V69: UTC-naive 'yyyy-MM-dd HH:mm:ss'（CREATE_TIME 入库格式）→ Date（按 UTC 构造），
// 配合本地 getter 得到本地日；及本地日字符串。
function _wpzlSyncParseStoredDate(s) {
  if (!s || typeof s !== 'string') return null;
  var m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})/);
  if (!m) return null;
  return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]));
}

function _wpzlSyncLocalDateStr(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

async function _setMarkLimitBlocked(v) {
  try {
    var obj = {};
    obj[MARK_LIMIT_BLOCKED_KEY] = !!v;
    await new Promise(function (r) { chrome.storage.local.set(obj, r); });
  } catch (e) { /* ignore */ }
}

// 配额类拒绝原因：docs/snaps 的稳定 token cloud_quota，及图片路径记录的中文 lastError「配额超限…」。
// 只管存储配额——标注总量（mark_limit）走上方独立链路，不在此命中。
function _isQuotaRejectionReason(reason) {
  if (!reason) return false;
  var s = String(reason);
  return s === 'cloud_quota' || s.indexOf('配额超限') >= 0;
}

async function _setQuotaBlocked(v) {
  try {
    var obj = {};
    obj[QUOTA_BLOCKED_KEY] = !!v;
    await new Promise(function (r) { chrome.storage.local.set(obj, r); });
  } catch (e) { /* ignore */ }
}

// 配额满提示（30 分钟冷却）：图片直传失败（service-worker 路径）与 docs/snaps 软拒路径共用，
// 避免批量截图/连续保存文档时每次失败都弹「云端存储已满」。
async function _maybeShowQuotaToast() {
  try {
    var stored = await new Promise(function (r) { chrome.storage.local.get([QUOTA_TOAST_KEY], r); });
    if (Date.now() - ((stored && stored[QUOTA_TOAST_KEY]) || 0) <= QUOTA_TOAST_COOLDOWN_MS) return;
    await new Promise(function (r) {
      var obj = {};
      obj[QUOTA_TOAST_KEY] = Date.now();
      chrome.storage.local.set(obj, r);
    });
    if (typeof _notifyToastToActiveTab === 'function' && typeof chrome.i18n !== 'undefined' && chrome.i18n.getMessage) {
      _notifyToastToActiveTab(chrome.i18n.getMessage('cloudQuotaFullToast'), { clickable: true, duration: 4000 });
    }
  } catch (e) { /* ignore */ }
}

// 标注总量达限提示（30 分钟冷却）：服务端 mark_limit 软拒与上传收集预拦截两路共用。
// 文案由 SW 侧 chrome.i18n 取好纯文本经 toast 链下发（$1=limits.markLimit，读不到走无数字版本）；
// 点击走通用升级弹窗（control-panel 既有 clickable toast 行为，无需 feature 参数）。
async function _maybeShowMarkLimitToast(limit) {
  try {
    var stored = await new Promise(function (r) { chrome.storage.local.get([MARK_LIMIT_TOAST_KEY], r); });
    if (Date.now() - ((stored && stored[MARK_LIMIT_TOAST_KEY]) || 0) <= MARK_LIMIT_TOAST_COOLDOWN_MS) return;
    await new Promise(function (r) {
      var obj = {};
      obj[MARK_LIMIT_TOAST_KEY] = Date.now();
      chrome.storage.local.set(obj, r);
    });
    if (typeof _notifyToastToActiveTab === 'function' && typeof chrome.i18n !== 'undefined' && chrome.i18n.getMessage) {
      var msg = (typeof limit === 'number' && limit >= 0)
        ? chrome.i18n.getMessage('markLimitToast', [String(limit)])
        : chrome.i18n.getMessage('markLimitToastNoLimit');
      if (msg) _notifyToastToActiveTab(msg, { clickable: true, duration: 4000 });
    }
  } catch (e) { /* ignore */ }
}

// 配额释放探测：标志为真才发请求。/assets/* 端点无 ApiResponse envelope（裸 DTO，见
// asset-uploader.js 同款），兼容两种形态。探测失败（网络等）与冷却未到期一样静默留下轮再查（冷却门 30 分钟）。
async function _maybeResumeQuotaExhausted(force) {
  try {
    var stored = await new Promise(function (r) { chrome.storage.local.get([QUOTA_BLOCKED_KEY], r); });
    if (!(stored && stored[QUOTA_BLOCKED_KEY])) return;
    if (!(await _limitProbeGatePassed('probe_quota', force))) return;
    if (typeof wpzl_assetQuota !== 'function') return;
    var q = await wpzl_assetQuota();
    var payload = (q && q.data && typeof q.data.used === 'number') ? q.data : q;
    var used = (payload && typeof payload.used === 'number') ? payload.used : null;
    var total = (payload && typeof payload.total === 'number') ? payload.total : null;
    if (used == null || total == null) return;
    if (!(used < total)) return;   // 仍满（含 total=0 停用）：保持耗尽，不空转重推
    var resumed = await _resetExhaustedState({ imagesOnly: false, reasonFilter: _isQuotaRejectionReason });
    await _setQuotaBlocked(false);
    if (resumed > 0) {
      console.log('[Sync] cloud quota freed (used=' + used + ' < total=' + total +
        ') — resumed ' + resumed + ' quota-exhausted records');
      try { requestSync('normal'); } catch (e2) { /* ignore */ }
      try { await _uploadPendingImages(); } catch (e2) { /* ignore */ }
    }
  } catch (e) { /* 探测失败：留下轮再查 */ }
}

// 标注总量限额释放探测：标志为真才发请求。markLimit>0 时以 /users/me/usage 的服务端权威
// markCount 判断（本地计数只是近似——不含他端/协作批注）；-1/0（升级/放开）直接恢复。
// 探测失败（网络等）静默留下轮再查（冷却门 30 分钟）；不触碰 assets 存储配额链路（wpzl_quota_blocked）。
async function _maybeResumeMarkLimitExhausted(force) {
  try {
    var stored = await new Promise(function (r) { chrome.storage.local.get([MARK_LIMIT_BLOCKED_KEY], r); });
    if (!(stored && stored[MARK_LIMIT_BLOCKED_KEY])) return;
    if (!(await _limitProbeGatePassed('probe_mark', force))) return;
    var pro = (typeof wpzl_getProStatus === 'function') ? await wpzl_getProStatus() : null;
    var limit = pro && pro.limits && pro.limits.markLimit;
    if (typeof limit !== 'number') return;   // limits 不可读（脱机兜底）：留下轮再查
    if (limit > 0) {
      if (typeof wpzl_getUsage !== 'function') return;
      var usage = await wpzl_getUsage();
      // /users/me/usage 走 ApiResponse envelope（server-api 可能已解包），两种形态都兼容
      var payload = (usage && usage.data && typeof usage.data.markCount === 'number') ? usage.data : usage;
      var markCount = (payload && typeof payload.markCount === 'number') ? payload.markCount : null;
      if (markCount == null) return;
      if (!(markCount < limit)) return;      // 仍满：保持耗尽，不空转重推
    }
    var resumed = await _resetExhaustedState({ imagesOnly: false, reasonFilter: _isMarkLimitRejectionReason });
    await _setMarkLimitBlocked(false);
    if (resumed > 0) {
      console.log('[Sync] mark limit freed (limit=' + limit + ') — resumed ' + resumed + ' mark-exhausted records');
      try { requestSync('normal'); } catch (e2) { /* ignore */ }
    }
  } catch (e) { /* 探测失败：留下轮再查 */ }
}

// ---- V69: 每日标注创建限额（dailyMarkLimit）：阻断标志 + 专用提示 + 跨天释放探测 ----
// 与 markLimit（总量）/cloud_quota（存储字节）互相独立：daily_mark_limit 是每日新建数限额，
// 恢复条件是"服务端日计数归零（跨天）或调额"，探测端点 /users/me/usage 的 dailyMarkCount。
var DAILY_MARK_LIMIT_BLOCKED_KEY = 'wpzl_daily_mark_limit_blocked';
var DAILY_MARK_LIMIT_TOAST_KEY = 'wpzl_daily_mark_limit_toast_time';
var DAILY_MARK_LIMIT_TOAST_COOLDOWN_MS = 30 * 60 * 1000;

// 服务端软拒 token daily_mark_limit。不入 PERMANENT_REJECTION_REASONS——否则被
// _resetExhaustedState 的永久分支排除，跨天/调额后无法自动复位。
function _isDailyMarkLimitRejectionReason(reason) {
  return !!reason && String(reason) === 'daily_mark_limit';
}

// ---- V70: 每日导入额度（dailyImportLimit）：阻断标志 + 专用提示 + 跨天释放探测 ----
// 备份导入/游客认领的历史数据豁免 daily_mark_limit/doc_limit/snap_limit 后的共享防刷量上限。
// 服务端稳定 token import_limit；恢复条件：跨天服务端导入计数归零或调额，探测 /users/me/usage
// 的 importCountToday。与每日类限额互相独立。
var IMPORT_LIMIT_BLOCKED_KEY = 'wpzl_import_limit_blocked';
var IMPORT_LIMIT_TOAST_KEY = 'wpzl_import_limit_toast_time';
var IMPORT_LIMIT_TOAST_COOLDOWN_MS = 30 * 60 * 1000;

// 服务端软拒 token import_limit。不入 PERMANENT_REJECTION_REASONS——跨天/调额后须能自动复位。
function _isImportLimitRejectionReason(reason) {
  return !!reason && String(reason) === 'import_limit';
}

async function _setImportLimitBlocked(v) {
  try {
    var obj = {};
    obj[IMPORT_LIMIT_BLOCKED_KEY] = !!v;
    await new Promise(function (r) { chrome.storage.local.set(obj, r); });
  } catch (e) { /* ignore */ }
}

// 导入额度达限提示（30 分钟冷却，镜像 _maybeShowDailyMarkLimitToast）：导入大文件被拦时
// 用户需要知道"这是导入上限、明天恢复"，而非每日新建上限。
async function _maybeShowImportLimitToast(limit) {
  try {
    var stored = await new Promise(function (r) { chrome.storage.local.get([IMPORT_LIMIT_TOAST_KEY], r); });
    if (Date.now() - ((stored && stored[IMPORT_LIMIT_TOAST_KEY]) || 0) <= IMPORT_LIMIT_TOAST_COOLDOWN_MS) return;
    await new Promise(function (r) {
      var obj = {};
      obj[IMPORT_LIMIT_TOAST_KEY] = Date.now();
      chrome.storage.local.set(obj, r);
    });
    if (typeof _notifyToastToActiveTab === 'function' && typeof chrome.i18n !== 'undefined' && chrome.i18n.getMessage) {
      var msg = (typeof limit === 'number' && limit >= 0)
        ? chrome.i18n.getMessage('importLimitToast', [String(limit)])
        : chrome.i18n.getMessage('importLimitToastNoLimit');
      if (msg) _notifyToastToActiveTab(msg, { clickable: true, duration: 4000 });
    }
  } catch (e) { /* ignore */ }
}

// 导入额度释放探测（镜像 _maybeResumeDailyMarkLimitExhausted）：标志为真才发请求；
// dailyImportLimit>0 时以 /users/me/usage 的服务端 importCountToday 判断（跨天归零）；
// -1（调额放开）直接恢复；0=导入停用（服务端 importAllowed=0 必拒）保持耗尽不放行——
// 与 dailyMarkLimit 的 0 语义不同（那边服务端 limit<=0 直接跳过检查），PDS 探测同款 0 守卫。
// 失败静默留下轮再查（冷却门 60 分钟）。
async function _maybeResumeImportLimitExhausted(force) {
  try {
    var stored = await new Promise(function (r) { chrome.storage.local.get([IMPORT_LIMIT_BLOCKED_KEY], r); });
    if (!(stored && stored[IMPORT_LIMIT_BLOCKED_KEY])) return;
    if (!(await _limitProbeGatePassed('probe_daily_import', force))) return;
    var pro = (typeof wpzl_getProStatus === 'function') ? await wpzl_getProStatus() : null;
    var limit = pro && pro.limits && pro.limits.dailyImportLimit;
    if (typeof limit !== 'number') return;   // limits 不可读（脱机兜底）：留下轮再查
    if (limit === 0) return;                 // 0=导入停用（服务端必拒）：保持耗尽不放行，防整批重推死循环
    if (limit > 0) {
      if (typeof wpzl_getUsage !== 'function') return;
      var usage = await wpzl_getUsage();
      var payload = (usage && usage.data && typeof usage.data.importCountToday === 'number') ? usage.data : usage;
      var importedCount = (payload && typeof payload.importCountToday === 'number') ? payload.importCountToday : null;
      if (importedCount == null) return;     // 旧 server 无该字段：视为未知留下轮
      if (!(importedCount < limit)) return;  // 仍满（同一天）：保持耗尽，不空转重推
    }
    var resumed = await _resetExhaustedState({ imagesOnly: false, reasonFilter: _isImportLimitRejectionReason });
    await _setImportLimitBlocked(false);
    if (resumed > 0) {
      console.log('[Sync] import limit freed (limit=' + limit + ') — resumed ' + resumed + ' import-exhausted records');
      try { requestSync('normal'); } catch (e2) { /* ignore */ }
    }
  } catch (e) { /* 探测失败：留下轮再查 */ }
}

async function _setDailyMarkBlocked(v) {
  try {
    var obj = {};
    obj[DAILY_MARK_LIMIT_BLOCKED_KEY] = !!v;
    await new Promise(function (r) { chrome.storage.local.set(obj, r); });
  } catch (e) { /* ignore */ }
}

// ---- 限额类拒绝原因总谓词（spec 2026-09-21）----
// 6 个服务端稳定 token + 图片路径中文 lastError「配额超限」（仅精确匹配——sync-engine 唯一
// 写入点 _uploadPendingImagesInner 的 quota catch；注解路径服务端业务文本『配额超限：…』
// （单页/类型限额 quotaMessage）不属限额体系，不匹配，保持可手动重试恢复）。
// 返回 'daily'（每日周期限额）/ 'total'（总量/存储限额）/ null（非限额）。UI 分类与手动重试防御共用。
// ⚠️ 不得用它替换各探测的 reasonFilter——_isQuotaRejectionReason 与 wpzl_quota_blocked
// 配对、_isMarkLimitRejectionReason 与 wpzl_mark_limit_blocked 配对，扩语义会跨类型复位。
function _isLimitRejectionReason(reason) {
  if (!reason) return null;
  var s = String(reason);
  if (s === 'daily_mark_limit' || s === 'doc_limit' || s === 'snap_limit' || s === 'import_limit') return 'daily';
  if (s === 'mark_limit' || s === 'page_limit' || s === 'cloud_quota' || s === '配额超限') return 'total';
  return null;
}

// ---- page/doc/snap 限额阻断标志：每种限额独立键（平铺）——mark* 处理函数与释放探测
// 可能并发写不同 kind，共享对象读改写会互相覆盖。值即布尔。
// 这三种限额在 V69 时无探测恢复路径（snap_limit 甚至属 PERMANENT 连登录复位都不碰），
// 本标志是新合并探测 _maybeResumePageDocSnapLimitExhausted 的触发器。
var PDS_LIMIT_REASONS = ['page_limit', 'doc_limit', 'snap_limit'];

function _pdsLimitKey(kind) { return 'wpzl_pds_limit_blocked_' + kind; }

async function _getPdsLimitBlocked() {
  try {
    var keys = PDS_LIMIT_REASONS.map(function (k) { return _pdsLimitKey(k); });
    var stored = await new Promise(function (r) { chrome.storage.local.get(keys, r); });
    var out = {};
    for (var i = 0; i < PDS_LIMIT_REASONS.length; i++) {
      out[PDS_LIMIT_REASONS[i]] = !!(stored && stored[_pdsLimitKey(PDS_LIMIT_REASONS[i])]);
    }
    return out;
  } catch (e) {
    var empty = {};
    for (var j = 0; j < PDS_LIMIT_REASONS.length; j++) empty[PDS_LIMIT_REASONS[j]] = false;
    return empty;
  }
}

async function _setPdsLimitBlocked(kind, v) {
  try {
    var obj = {};
    obj[_pdsLimitKey(kind)] = !!v;
    await new Promise(function (r) { chrome.storage.local.set(obj, r); });
  } catch (e) { /* ignore */ }
}

// ---- 限额释放探测冷却门：每类探测独立键（平铺，避免并发读改写互相覆盖）。
// force=true 跳过冷却读取但照写时间戳（升级路径的立即探测消耗本次冷却，防止下一轮重复）。
// 存储异常放行（等价于无门）。
var LIMIT_PROBE_GATE_PREFIX = 'wpzl_limit_probe_gate_';
var LIMIT_PROBE_COOLDOWN_MS = {
  probe_quota: 30 * 60 * 1000,       // 存储/总量：清理空间后随时可释放，30 分钟足够
  probe_mark: 30 * 60 * 1000,        // 标注总量：删除标注后随时可释放
  probe_daily_mark: 60 * 60 * 1000,  // 每日周期：跨天才可能恢复，探测再勤也无意义
  probe_pds: 60 * 60 * 1000,         // 含两类每日限额（docCountToday/dailySnapCount），同上
  probe_daily_import: 60 * 60 * 1000  // 每日周期：跨天才可能恢复（镜像 probe_daily_mark）
};

async function _limitProbeGatePassed(key, force) {
  var storageKey = LIMIT_PROBE_GATE_PREFIX + key;
  try {
    var stored = await new Promise(function (r) { chrome.storage.local.get([storageKey], r); });
    var last = stored && stored[storageKey];
    var now = Date.now();
    if (!force && last && (now - last) < LIMIT_PROBE_COOLDOWN_MS[key]) return false;
    var obj = {};
    obj[storageKey] = now;
    await new Promise(function (r) { chrome.storage.local.set(obj, r); });
    return true;
  } catch (e) { return true; }
}

// 每日限额达限提示（30 分钟冷却）：软拒与上传收集预拦截两路共用（mark_limit 同款）。
// 文案强调"明天自动恢复、新标注仅保存在本设备"（中性话术，不出现档位名）。
async function _maybeShowDailyMarkLimitToast(limit) {
  try {
    var stored = await new Promise(function (r) { chrome.storage.local.get([DAILY_MARK_LIMIT_TOAST_KEY], r); });
    if (Date.now() - ((stored && stored[DAILY_MARK_LIMIT_TOAST_KEY]) || 0) <= DAILY_MARK_LIMIT_TOAST_COOLDOWN_MS) return;
    await new Promise(function (r) {
      var obj = {};
      obj[DAILY_MARK_LIMIT_TOAST_KEY] = Date.now();
      chrome.storage.local.set(obj, r);
    });
    if (typeof _notifyToastToActiveTab === 'function' && typeof chrome.i18n !== 'undefined' && chrome.i18n.getMessage) {
      var msg = (typeof limit === 'number' && limit >= 0)
        ? chrome.i18n.getMessage('dailyMarkLimitToast', [String(limit)])
        : chrome.i18n.getMessage('dailyMarkLimitToastNoLimit');
      if (msg) _notifyToastToActiveTab(msg, { clickable: true, duration: 4000 });
    }
  } catch (e) { /* ignore */ }
}

// 每日限额释放探测：标志为真才发请求。服务端按 server_created_at 计数、跨天自动归零——
// dailyMarkLimit>0 时以 /users/me/usage 的服务端 dailyMarkCount 判断（本地计数器不反映
// 服务端日界）；-1/0（调额放开）直接恢复。探测失败静默留下轮再查（冷却门 60 分钟）。
async function _maybeResumeDailyMarkLimitExhausted(force) {
  try {
    var stored = await new Promise(function (r) { chrome.storage.local.get([DAILY_MARK_LIMIT_BLOCKED_KEY], r); });
    if (!(stored && stored[DAILY_MARK_LIMIT_BLOCKED_KEY])) return;
    if (!(await _limitProbeGatePassed('probe_daily_mark', force))) return;
    var pro = (typeof wpzl_getProStatus === 'function') ? await wpzl_getProStatus() : null;
    var limit = pro && pro.limits && pro.limits.dailyMarkLimit;
    if (typeof limit !== 'number') return;   // limits 不可读（脱机兜底）：留下轮再查
    if (limit > 0) {
      if (typeof wpzl_getUsage !== 'function') return;
      var usage = await wpzl_getUsage();
      var payload = (usage && usage.data && typeof usage.data.dailyMarkCount === 'number') ? usage.data : usage;
      var dailyCount = (payload && typeof payload.dailyMarkCount === 'number') ? payload.dailyMarkCount : null;
      if (dailyCount == null) return;
      if (!(dailyCount < limit)) return;     // 仍满（同一天）：保持耗尽，不空转重推
    }
    var resumed = await _resetExhaustedState({ imagesOnly: false, reasonFilter: _isDailyMarkLimitRejectionReason });
    await _setDailyMarkBlocked(false);
    if (resumed > 0) {
      console.log('[Sync] daily mark limit freed (limit=' + limit + ') — resumed ' + resumed + ' daily-exhausted records');
      try { requestSync('normal'); } catch (e2) { /* ignore */ }
    }
  } catch (e) { /* 探测失败：留下轮再查 */ }
}

// page/doc/snap 限额释放探测（合并一条，spec 2026-09-21）：三种限额的释放信号都在
// GET /users/me/usage（pageCount/docCountToday/dailySnapCount，需 server 同步增补两字段）。
// 释放判定：limit=-1（无限）直接放行；limit=0（功能停用，服务端必拒）保持耗尽不放行；
// limit>0 时 count<limit 才放行。usage 信封解析沿用现有容忍写法（wpzl_getUsage 已解包一层，
// usage.data||usage 双形态兼容）；字段缺失（旧 server / 脱机）视为未知留下轮——设计内降级，不报错。
// 本地实扫兜底：切号时 resetSyncState 会清掉 wpzl_pds_limit_blocked_* 标志，标志一没探测就
// 永远不跑，限额耗尽的记录再无自动恢复路径（用户只看到"已达上限"、又没有重试按钮）。
// kinds 因此取「标志 ∪ 本地实扫」。
// ⚠️ 扫描范围必须与 _resetExhaustedState 的 dirtyStatuses 一致（4 个脏状态全扫）：
// 耗尽记录**不一定**是 error 态——属主变更/导入路径会把 SYNC_STATUS 改写成 pending 却保留
// SYNC_EXHAUSTED，正是本文档要修的那种 pending+exhausted 死状态；只扫 error 会漏掉它
//（实测复现：真实卡死记录 status=pending，error 索引命中 0 条）。
// 三个 store × 4 个状态都是 syncStatus 索引上的小集合查询，只在同步成功收尾触发，开销可忽略。
async function _collectLocalPdsExhaustedKinds() {
  var STORE_KIND = [['documents', 'doc_limit'], ['snapshots', 'snap_limit'], ['pages', 'page_limit']];
  var STATUSES = [SYNC_STATUS_PENDING, SYNC_STATUS_LOCAL, SYNC_STATUS_ERROR, SYNC_STATUS_PENDING_DELETED];
  var out = {};
  for (var si = 0; si < STORE_KIND.length; si++) {
    var kind = STORE_KIND[si][1];
    try {
      var idx = db._tx(STORE_KIND[si][0], 'readonly').index('syncStatus');
      // 同一事务内并发派发 4 个 getAll（顺序 await 会让事务失活）
      var groups = await Promise.all(STATUSES.map(function (s) {
        return _getAllFromIndex(idx, s);
      }));
      for (var gi = 0; gi < groups.length && !out[kind]; gi++) {
        var rows = groups[gi];
        for (var ri = 0; ri < rows.length; ri++) {
          var rec = rows[ri];
          if (rec && rec.SYNC_EXHAUSTED &&
              PDS_LIMIT_REASONS.indexOf(String(rec.SYNC_LAST_ERROR)) >= 0) {
            out[kind] = true;
            break;
          }
        }
      }
    } catch (e) { /* 该 store 不可扫：跳过，不影响其他 kind */ }
  }
  return out;
}

async function _maybeResumePageDocSnapLimitExhausted(force) {
  try {
    var blocked = await _getPdsLimitBlocked();
    var localKinds = await _collectLocalPdsExhaustedKinds();
    var kinds = [];
    for (var pi = 0; pi < PDS_LIMIT_REASONS.length; pi++) {
      var kindI = PDS_LIMIT_REASONS[pi];
      if (blocked[kindI] || localKinds[kindI]) kinds.push(kindI);
    }
    if (kinds.length === 0) return;
    if (!(await _limitProbeGatePassed('probe_pds', force))) return;
    var pro = (typeof wpzl_getProStatus === 'function') ? await wpzl_getProStatus() : null;
    var limits = pro && pro.limits;
    if (!limits) return;                     // limits 不可读（脱机兜底）：留下轮再查
    if (typeof wpzl_getUsage !== 'function') return;
    var usage = await wpzl_getUsage();
    var payload = (usage && usage.data && typeof usage.data.pageCount === 'number') ? usage.data : usage;
    if (!payload) return;
    // 三种限额的 [limits 字段名, usage 字段名]
    var FIELDS = {
      page_limit: ['pageLimit', 'pageCount'],
      doc_limit: ['docLimit', 'docCountToday'],
      snap_limit: ['snapLimit', 'dailySnapCount']
    };
    var released = {};                       // token -> true（本轮已释放的 kind）
    for (var ki = 0; ki < kinds.length; ki++) {
      var kind = kinds[ki];
      var limit = limits[FIELDS[kind][0]];
      var count = (payload && typeof payload[FIELDS[kind][1]] === 'number') ? payload[FIELDS[kind][1]] : null;
      if (typeof limit !== 'number' || count == null) continue;   // 信号缺失：该 kind 留下轮
      if (limit === 0) continue;   // 0=功能停用（服务端必拒）：保持耗尽，不放行（-1=无限照常放行）
      if (limit > 0 && !(count < limit)) continue;                // 仍满：保持耗尽
      released[kind] = true;
    }
    if (!(released.page_limit || released.doc_limit || released.snap_limit)) return;
    // 单次扫描复位：filter 只放行「token ∈ 本轮已释放集合」的记录（page 释放而 doc 未释放时不可跨类复位）
    var resumed = await _resetExhaustedState({
      imagesOnly: false,
      reasonFilter: function (reason) {
        return (reason === 'page_limit' && !!released.page_limit) ||
               (reason === 'doc_limit' && !!released.doc_limit) ||
               (reason === 'snap_limit' && !!released.snap_limit);
      }
    });
    for (var ri = 0; ri < PDS_LIMIT_REASONS.length; ri++) {
      if (released[PDS_LIMIT_REASONS[ri]]) await _setPdsLimitBlocked(PDS_LIMIT_REASONS[ri], false);
    }
    if (resumed > 0) {
      console.log('[Sync] page/doc/snap limit freed — resumed ' + resumed + ' limit-exhausted records');
      try { requestSync('normal'); } catch (e2) { /* ignore */ }
    }
  } catch (e) { /* 探测失败：留下轮再查 */ }
}

// ---- State ----

var _syncLock = false;
// 防御：onLogout / clearAllLocalData 期间置 true，通知在飞的 sync 周期不要再写 syncMeta / IDB。
// 避免切账号时 in-flight 周期收尾把上一个账号的 sync_token 写回已被清空的 syncMeta。
var _syncAbandoned = false;
var _debounceTimer = null;
var _syncEnabled = false;
var _recentPulls = {}; // url -> timestamp

// 当前登录用户 ID（字符串）。服务端 sync 响应不返回 userId 字段（历史设计：基于 token 私有），
// 但浏览器侧按 USER_ID 隔离读取（决策 4），所以 pull 下来的记录必须有 USER_ID。
// 在每次 sync 前 refresh，作为 serverXxxDtoToLocal 的 fallback。
var _currentUid = '';
async function _refreshCurrentUid() {
  try {
    var auth = await new Promise(function (resolve) {
      chrome.storage.local.get(['wpzl_auth'], function (r) { resolve(r.wpzl_auth || null); });
    });
    if (auth && auth.user && auth.user.id != null) {
      _currentUid = String(auth.user.id);
      return _currentUid;
    }
  } catch (e) { /* ignore */ }
  _currentUid = '';
  return _currentUid;
}

// ---- init-pending 同步请求队列 ----
// MV3 SW 30s 空闲被杀，重启后 init() 异步进行；此期间用户操作目录（putFolder 等）会
// 触发 requestSync，但 _syncEnabled=false → 静默跳过 → 操作停在 PENDING 直到下次手动 syncNow。
// 通过 _pendingSyncRequest 把此类请求暂存，init() 完成后若启用了同步则 flush。
// 取较高优先级（immediate > normal），多次请求合并为一次。
var _pendingSyncRequest = null;

// ---- Init lifecycle tracking (用于诊断「立即同步按钮偶尔消失」) ----
// _syncEnabled 是模块级变量，默认 false；只有 init() 异步跑完才可能变 true。
// MV3 SW 30s 空闲会被杀，重启后 onMessage 同步注册、init() 异步进行，
// 此时 sync-status 查询可能命中 _syncEnabled=false 的窗口 → 按钮消失。
//
// 通过 _initPromise 让 sync-status handler 可以「等 init 完成」再响应，
// 从而消除按钮闪烁。promise 在 init() 末尾（成功或失败都）resolve。
var _initState = 'pending';   // 'pending' | 'running' | 'completed' | 'failed'
var _initStartedAt = null;
var _initCompletedAt = null;
var _initError = null;
var _initResolve = null;
var _initPromise = new Promise(function (resolve) { _initResolve = resolve; });

function getInitState() {
  return {
    state: _initState,
    startedAt: _initStartedAt,
    completedAt: _initCompletedAt,
    elapsedMs: _initStartedAt ? ((_initCompletedAt || Date.now()) - _initStartedAt) : 0,
    error: _initError,
    syncEnabled: _syncEnabled
  };
}

// 等待 init() 完成，最多 timeoutMs 毫秒；超时也 resolve（不让调用方死等）。
// 返回最终的 init 快照。
async function waitForInit(timeoutMs) {
  timeoutMs = timeoutMs || 3000;
  var startWait = Date.now();
  await Promise.race([
    _initPromise,
    new Promise(function (resolve) { setTimeout(resolve, timeoutMs); })
  ]);
  var snap = getInitState();
  console.log('[Sync] waitForInit: waited ' + (Date.now() - startWait) +
    'ms, finalState=' + snap.state + ', syncEnabled=' + snap.syncEnabled);
  return snap;
}

// 将 DIRTY_BITS 位掩码解码为可读字段名（用于同步报告）
function decodeDirtyBits(bits, kind) {
  bits = bits || 0;
  var fields = [];
  if (kind === 'page') {
    if (bits & DIRTY_BIT_TITLE) fields.push(chrome.i18n.getMessage('dirtyTitle'));
    if (bits & DIRTY_BIT_FAVORITE) fields.push(chrome.i18n.getMessage('dirtyFavorite'));
    if (bits & DIRTY_BIT_FOLDER) fields.push(chrome.i18n.getMessage('dirtyFolder'));
    if (bits & DIRTY_BIT_PAGE_NOTE) fields.push(chrome.i18n.getMessage('dirtyPageNote'));
    if (bits & DIRTY_BIT_VISITED) fields.push(chrome.i18n.getMessage('dirtyVisitTime'));
    if (bits & DIRTY_BIT_CUSTOM_TITLE) fields.push(chrome.i18n.getMessage('dirtyCustomTitle'));
    if (fields.length === 0 && bits !== 0) fields.push('bit=' + bits);
  } else if (kind === 'annotation') {
    if (bits & DIRTY_BIT_CONTENT) fields.push(chrome.i18n.getMessage('dirtyContent'));
    if (bits & DIRTY_BIT_COMMENT) fields.push(chrome.i18n.getMessage('dirtyComment'));
    if (bits & DIRTY_BIT_TAGS) fields.push(chrome.i18n.getMessage('dirtyTags'));
    if (bits & DIRTY_BIT_STYLE) fields.push(chrome.i18n.getMessage('dirtyStyle'));
    if (bits & DIRTY_BIT_POSITION) fields.push(chrome.i18n.getMessage('dirtyPosition'));
    if (bits & DIRTY_BIT_THUMBNAIL) fields.push(chrome.i18n.getMessage('dirtyThumb'));
    if (bits === 0xFF) fields.push(chrome.i18n.getMessage('dirtyAllFields'));
    else if (fields.length === 0 && bits !== 0) fields.push('bit=' + bits);
  }
  return fields;
}

// ---- SyncMeta Store Access ----
// Uses the global `db` (AnnotationDB instance) from service-worker.js

function _syncGetStore(mode) {
  if (!db || !db.db) throw new Error('IndexedDB not initialized');
  var tx = db.db.transaction('syncMeta', mode);
  return tx.objectStore('syncMeta');
}

function _syncGetMeta(key) {
  return new Promise(function (resolve, reject) {
    var store = _syncGetStore('readonly');
    var req = store.get(key);
    req.onsuccess = function () { resolve(req.result ? req.result.value : null); };
    req.onerror = function () { reject(req.error); };
  });
}

function _syncSetMeta(key, value) {
  return new Promise(function (resolve, reject) {
    var store = _syncGetStore('readwrite');
    var req = store.put({ SYNC_KEY: key, value: value });
    req.onsuccess = function () { resolve(); };
    req.onerror = function () { reject(req.error); };
  });
}

// 防御检查：当前 sync 周期是否已被放弃（onLogout / clearAllLocalData 触发）。
// 在写 syncMeta / 健康度的关键点调用，true = 跳过本次写入。
function _syncAborted() {
  if (_syncAbandoned) {
    console.log('[Sync] cycle abandoned (logout/switch-user), skipping meta write');
    return true;
  }
  return false;
}

// P1 修复（登出×在途竞争，2026-10-07）：本地清空守卫。置位时 ①连带置 _syncAbandoned——
// 在飞周期按哨兵丢弃一切结果应用（上传侧此前无保护：在途批的成功应用/失败回写/offline
// 入队都会把旧账号行种回已清空的库，实测登出后残留 pending 标注）；②sync() 入口拒绝
// 新周期（含 manual——库正在被清，任何同步都无意义）。清空完成后由调用方复位；
// 复位不动 _syncAbandoned（迟到的旧周期保持缴械，新周期入口自会重置该标志）。
var _localClearGuard = false;
function setClearGuard(on) {
  _localClearGuard = !!on;
  if (on) _syncAbandoned = true;
}

// P2 修复（导入期推送并发坍塌，2026-10-07）：导入会话标志。restoreChunk/restoreBackup
// 写库期间置位，非 manual 的 sync 请求（connectivity-tick / 防抖 immediate 等）一律跳过——
// 导入 chunk 的长 IDB 写事务与 sync 的读/写事务同 store 互斥，并发实测批延迟 1.7s → 18-104s。
// finalize 后由 restoreChunk 收尾先清标志再 requestSync('normal') 续上。
var _importSessionActive = false;
function setImportSession(active) { _importSessionActive = !!active; }

// P1-7：登出与在飞 pull 竞争——_applyDownloaded* 各分块写事务前检查，已放弃则抛哨兵终止本轮。
// 哨兵沿调用链 rethrow（各 _applyFail catch 识别放行），最终由 sync() 的 withSyncLock().catch
// 静默收尾（不计失败、不烧重试计数、不发 token_expired 噪声——登出流程自身管理状态）。
var WPZL_SYNC_ABORTED_ERR = 'WPZL_SYNC_ABORTED';
function _throwIfSyncAborted() {
  if (_syncAbandoned) throw new Error(WPZL_SYNC_ABORTED_ERR);
}

// ---- 大同步断点续传（Bug 7）----
// 持久化"未完成的下载 cursor"到 syncMeta['pull_cursor']。SW 30s 回收中断后，
// 下次 sync() 入口或 init()/alarm 唤醒时读出续传，避免每次从头拉全量。
async function _getPullCursor() {
  return _syncGetMeta('pull_cursor');
}
async function _savePullCursor(cursor, pageCursor, folderCursor, imageAssetCursor, documentCursor, snapshotCursor) {
  // P1-7：登出中不写游标——clearAllLocalData 后写入会把旧账号的分页进度留在已清空的 syncMeta 里
  if (_syncAbandoned) return;
  await _syncSetMeta('pull_cursor', {
    cursor: cursor,
    pageCursor: pageCursor,
    folderCursor: folderCursor,
    imageAssetCursor: imageAssetCursor || null,
    documentCursor: documentCursor || null,
    snapshotCursor: snapshotCursor || null
  });
}
async function _clearPullCursor() {
  await _syncSetMeta('pull_cursor', null);
  try { chrome.alarms.clear(SYNC_RESUME_ALARM); } catch (e) { /* ignore */ }
}
function _ensureResumeAlarm() {
  try { chrome.alarms.create(SYNC_RESUME_ALARM, { periodInMinutes: SYNC_RESUME_ALARM_MINUTES }); } catch (e) { /* ignore */ }
}

// ---- Device ID Management ----

function _syncGenerateUUID() {
  // UUID v4
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0;
    var v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

var _cachedDeviceId = null;

async function getDeviceId() {
  if (_cachedDeviceId) return _cachedDeviceId;
  // Check chrome.storage.local first (fast path)
  var stored = await new Promise(function (resolve) {
    chrome.storage.local.get(['wpzl_device_id'], function (r) {
      resolve(r.wpzl_device_id || null);
    });
  });
  if (stored) {
    _cachedDeviceId = stored;
    return stored;
  }
  // Check syncMeta store
  var fromDb = await _syncGetMeta('device_id');
  if (fromDb) {
    _cachedDeviceId = fromDb;
    await new Promise(function (resolve) {
      chrome.storage.local.set({ wpzl_device_id: fromDb }, resolve);
    });
    return fromDb;
  }
  // Generate new
  var newId = _syncGenerateUUID();
  _cachedDeviceId = newId;
  await _syncSetMeta('device_id', newId);
  await new Promise(function (resolve) {
    chrome.storage.local.set({ wpzl_device_id: newId }, resolve);
  });
  return newId;
}

// ---- Field Mapping ----

/**
 * Sanitize a value for a server-side Long field.
 * Converts NaN / undefined / null to null so Jackson can deserialize it.
 */
function _safeLong(v) {
  if (v == null) return null;
  if (typeof v === 'number' && isNaN(v)) return null;
  if (typeof v === 'string' && (v === 'NaN' || v === 'null' || v === 'undefined')) return null;
  var n = Number(v);
  if (isNaN(n)) return null;
  return n;
}

function localToServerDto(ann) {
  return {
    markInfoId: ann.MARK_INFO_ID,
    domain: ann.DOMAIN,
    webUri: ann.WEB_URI,
    startXpath: ann.START_XPATH,
    endXpath: ann.END_XPATH,
    startOffset: _safeLong(ann.START_OFFSET),
    endOffset: _safeLong(ann.END_OFFSET),
    startMd5: ann.START_MD5,
    endMd5: ann.END_MD5,
    startTagName: ann.START_TAG_NAME,
    endTagName: ann.END_TAG_NAME,
    context: ann.CONTEXT,
    textSnapshot: ann.TEXT_SNAPSHOT || null,
    thumbnail: ann.THUMBNAIL || null,
    commentText: ann.COMMENT_TEXT,
    markColor: ann.MARK_COLOR,
    markWidth: ann.MARK_WIDTH,
    annotationMode: ann.ANNOTATION_MODE || null,
    markStyle: ann.MARK_STYLE || null,
    title: ann.TITLE,
    authorId: ann.AUTHOR_ID,
    authorName: ann.AUTHOR_NAME,
    userId: ann.USER_ID,
    xOffset: ann.X_OFFSET,
    yOffset: ann.Y_OFFSET,
    tags: ann.TAGS,
    anchorWidth: ann.ANCHOR_WIDTH,
    anchorHeight: ann.ANCHOR_HEIGHT,
    anchorYRatio: ann.ANCHOR_Y_RATIO != null ? Number(ann.ANCHOR_Y_RATIO) : null,
    startParentDepth: ann.START_PARENT_DEPTH,
    startChildIndex: ann.START_CHILD_INDEX,
    startChildTag: ann.START_CHILD_TAG,
    startDate: ann.CREATE_TIME,
    updateDate: ann.UPDATE_TIME
  };
}

function serverDtoToLocal(dto) {
  // Backward compat: old server may still have pageRect screenshots in context
  var thumbnail = dto.thumbnail || null;
  if (!thumbnail && dto.endXpath === '$pageRect' && dto.context) {
    if (dto.context.indexOf('data:') === 0 || dto.context.indexOf('img:') === 0) {
      thumbnail = dto.context;
    }
  }

  return {
    MARK_INFO_ID: dto.markInfoId,
    DOMAIN: dto.domain,
    WEB_URI: dto.webUri,
    START_XPATH: dto.startXpath,
    END_XPATH: dto.endXpath,
    START_OFFSET: dto.startOffset,
    END_OFFSET: dto.endOffset,
    START_MD5: dto.startMd5,
    END_MD5: dto.endMd5,
    START_TAG_NAME: dto.startTagName,
    END_TAG_NAME: dto.endTagName,
    CONTEXT: dto.context,
    TEXT_SNAPSHOT: dto.textSnapshot || null,
    COMMENT_TEXT: dto.commentText,
    MARK_COLOR: dto.markColor,
    MARK_WIDTH: dto.markWidth,
    ANNOTATION_MODE: dto.annotationMode || null,
    MARK_STYLE: dto.markStyle || null,
    TITLE: dto.title,
    AUTHOR_ID: dto.authorId,
    AUTHOR_NAME: dto.authorName,
    USER_ID: String((dto.userId != null && dto.userId !== '') ? dto.userId : (_currentUid || '')),
    // 协作来源标记（服务端 D-33 透出）：'collab'=查看者在分享页创建（不占属主限额，总量/每日门与
    // feature-gate 计数均排除）。属主自有行 dto.source='owner'，保守存原值、判定统一 ==='collab'。
    // sync-engine 独有元数据：commitData fieldMap 不收，页面桥写入被 SYNC_OWNED_KEYS 剥除。
    SOURCE: dto.source || null,
    X_OFFSET: dto.xOffset,
    Y_OFFSET: dto.yOffset,
    TAGS: dto.tags,
    ANCHOR_WIDTH: dto.anchorWidth,
    ANCHOR_HEIGHT: dto.anchorHeight,
    ANCHOR_Y_RATIO: dto.anchorYRatio != null ? Number(dto.anchorYRatio) : null,
    START_PARENT_DEPTH: dto.startParentDepth,
    START_CHILD_INDEX: dto.startChildIndex,
    START_CHILD_TAG: dto.startChildTag,
    CREATE_TIME: dto.startDate,
    UPDATE_TIME: dto.updateDate,
    SYNC_STATUS: SYNC_STATUS_SYNCED,
    SYNC_VERSION: 0,
    SERVER_UPDATE_TIME: dto.updateDate,
    DIRTY_BITS: 0,
    THUMBNAIL: thumbnail,
    SYNCED_AT: dto.syncedAt || null
  };
}

// serverDtoToLocal 是**整条替换**（putMany/put 全量覆盖），而 DTO 里根本没有本地独有字段——
// 不显式搬运就会被抹掉。两个 server-wins 覆盖点（拉取主循环、LWW 冲突）都必须走本函数，
// 否则两处会各自漏字段、行为漂移。
//
// ⚠️ THUMB_* 家族 + _pageKey 必须在内：它们是 pageRect 截图「补传中/已耗尽/本地缺失」的**全部**
// 状态。被抹掉 = 本地 localThumbnails 里那张截图再也没人上传，且用户看不到任何失败项
//（既不在 thumb_pending_ids 清单里、也不带 THUMB_LOCAL_MISSING 终态）—— 静默放弃。
// 只搬「工作状态」不搬 THUMBNAIL 值：值以服务端为准；而 PENDING 被保留后，若服务端的 null
// 确实覆盖了未推送的 objectKey，下一轮 flush 会用本地字节重传并回写，自然自愈。
function _preserveLocalOnlyFields(localAnn, existing) {
  if (!existing) return localAnn;
  if (!localAnn.AUTHOR_ID && existing.AUTHOR_ID) localAnn.AUTHOR_ID = existing.AUTHOR_ID;
  if (!localAnn.AUTHOR_NAME && existing.AUTHOR_NAME) localAnn.AUTHOR_NAME = existing.AUTHOR_NAME;
  // 旧服务端 DTO 无 textSnapshot 时勿用 null 覆盖本地已有值（$picLine 区域文本）
  if (!localAnn.TEXT_SNAPSHOT && existing.TEXT_SNAPSHOT) localAnn.TEXT_SNAPSHOT = existing.TEXT_SNAPSHOT;
  localAnn.SELECT_STATE = existing.SELECT_STATE;
  localAnn.MARK_TYPE_ID = existing.MARK_TYPE_ID;
  localAnn.OWNER_ID = existing.OWNER_ID;
  // 截图补传/终态状态（本地独有，DTO 无这些键）
  if (existing.THUMBNAIL_PENDING) localAnn.THUMBNAIL_PENDING = existing.THUMBNAIL_PENDING;
  if (existing.THUMB_LOCAL_MISSING) localAnn.THUMB_LOCAL_MISSING = existing.THUMB_LOCAL_MISSING;
  if (existing.THUMB_EXHAUSTED) localAnn.THUMB_EXHAUSTED = existing.THUMB_EXHAUSTED;
  if (typeof existing.THUMB_RETRY_COUNT === 'number') localAnn.THUMB_RETRY_COUNT = existing.THUMB_RETRY_COUNT;
  if (existing.THUMB_LAST_ERROR) localAnn.THUMB_LAST_ERROR = existing.THUMB_LAST_ERROR;
  if (existing._pageKey) localAnn._pageKey = existing._pageKey;
  return localAnn;
}

function buildDiffUploadDto(ann) {
  var bits = ann.DIRTY_BITS || 0xFF;
  var dto = {
    markInfoId: ann.MARK_INFO_ID,
    domain: ann.DOMAIN,
    webUri: ann.WEB_URI,
    startDate: ann.CREATE_TIME,
    updateDate: ann.UPDATE_TIME,
    authorId: ann.AUTHOR_ID,
    authorName: ann.AUTHOR_NAME,
    userId: ann.USER_ID,
    // V70 导入豁免（spec §6.2）：导入/游客认领记录的首次创建同步豁免每日限额。
    // 记录级元数据（非 dirty-bit 字段），无条件随基座携带（服务端仅在"新建"时消费）。
    imported: ann.IS_IMPORTED === 1 ? true : undefined
  };

  if (bits & DIRTY_BIT_CONTENT) {
    dto.context = ann.CONTEXT;
    // TEXT_SNAPSHOT（$picLine 区域文本）与 CONTEXT 同属内容位；为空不写键，服务端保留原值
    if (ann.TEXT_SNAPSHOT) dto.textSnapshot = ann.TEXT_SNAPSHOT;
  }
  if (bits & DIRTY_BIT_THUMBNAIL) {
    // 决策 B（P2-5 语义，见 docs/同步机制重构方案-合并push和pull为单次请求.md 第十节）：
    // 无图片上云权限的用户 THUMBNAIL 恒为空（缩略图只在本地 IDB）；有权限时为 objectKey 字符串（已上云）。
    // 上传守门：D2 起该字段语义为 R2 objectKey（服务端 AnnotationDto @Size 512）；旧模型/导入
    // 数据可能是 base64 data: 截图（实测单条 1.4MB，2026-09-21 导入踩雷），超限会让整批 /sync
    // 40002「参数校验失败」。超 512 不写键（同下方空值语义：服务端保留原值或 NULL），本地记录
    // 原样保留（pageRect 缩略图本地 4 分支仍走 dataUrl 显示）；新数据 objectKey 均 ≤512 不受影响。
    if (ann.THUMBNAIL && ann.THUMBNAIL.length <= 512) dto.thumbnail = ann.THUMBNAIL;
    // THUMBNAIL 为 null/undefined/超长 时不写 dto.thumbnail（服务端保留原值或 NULL，不被空值覆盖）
  }
  if (bits & DIRTY_BIT_COMMENT) dto.commentText = ann.COMMENT_TEXT;
  if (bits & DIRTY_BIT_TAGS) dto.tags = ann.TAGS;
  if (bits & DIRTY_BIT_STYLE) {
    dto.markColor = ann.MARK_COLOR;
    dto.title = ann.TITLE;
    dto.markWidth = ann.MARK_WIDTH;
    // ANNOTATION_MODE（implicit 悬停 / explicit 始终可见）服务端已存储，随 STYLE 位上传。
    // 此前被当作"仅本地字段"遗漏，导致"始终可见"批注分享/跨端后回落为悬停提示。
    dto.annotationMode = ann.ANNOTATION_MODE;
    // MARK_STYLE（高亮样式 underline/background/wavy…）服务端已存储，随 STYLE 位上传。
    dto.markStyle = ann.MARK_STYLE;
  }
  if (bits & DIRTY_BIT_POSITION) {
    dto.startXpath = ann.START_XPATH;
    dto.endXpath = ann.END_XPATH;
    dto.startOffset = _safeLong(ann.START_OFFSET);
    dto.endOffset = _safeLong(ann.END_OFFSET);
    dto.startMd5 = ann.START_MD5;
    dto.endMd5 = ann.END_MD5;
    dto.startTagName = ann.START_TAG_NAME;
    dto.endTagName = ann.END_TAG_NAME;
    dto.xOffset = _safeLong(ann.X_OFFSET);
    dto.yOffset = _safeLong(ann.Y_OFFSET);
    dto.anchorWidth = _safeLong(ann.ANCHOR_WIDTH);
    dto.anchorHeight = _safeLong(ann.ANCHOR_HEIGHT);
    // ANCHOR_Y_RATIO（万分数，锚点 Y 比率）服务端已存储，随 POSITION 位上传。
    dto.anchorYRatio = ann.ANCHOR_Y_RATIO != null ? Number(ann.ANCHOR_Y_RATIO) : null;
    dto.startParentDepth = _safeLong(ann.START_PARENT_DEPTH);
    dto.startChildIndex = _safeLong(ann.START_CHILD_INDEX);
    dto.startChildTag = ann.START_CHILD_TAG;
  }

  return dto;
}

function computeDirtyBits(updates) {
  var bits = 0;
  var keys = Object.keys(updates);
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    if (k === 'CONTEXT' || k === 'TEXT_SNAPSHOT') bits |= DIRTY_BIT_CONTENT;
    else if (k === 'THUMBNAIL') bits |= DIRTY_BIT_THUMBNAIL;
    else if (k === 'COMMENT_TEXT') bits |= DIRTY_BIT_COMMENT;
    else if (k === 'TAGS') bits |= DIRTY_BIT_TAGS;
    else if (k === 'MARK_COLOR' || k === 'TITLE' || k === 'MARK_WIDTH' || k === 'ANNOTATION_MODE' || k === 'MARK_STYLE') bits |= DIRTY_BIT_STYLE;
    else if (k === 'START_XPATH' || k === 'END_XPATH' || k === 'START_OFFSET' || k === 'END_OFFSET' ||
             k === 'START_MD5' || k === 'END_MD5' || k === 'START_TAG_NAME' || k === 'END_TAG_NAME' ||
             k === 'ANCHOR_Y_RATIO' || k === 'ANCHOR_WIDTH' || k === 'ANCHOR_HEIGHT' ||
             k === 'START_PARENT_DEPTH' || k === 'START_CHILD_INDEX' || k === 'START_CHILD_TAG' ||
             k === 'X_OFFSET' || k === 'Y_OFFSET') bits |= DIRTY_BIT_POSITION;
  }
  return bits;
}

// ---- Page / Folder DTO Mapping ----

function serverPageDtoToLocal(dto) {
  return {
    url: dto.webUri,
    URL_MD5: dto.urlMd5,
    domain: dto.domain || '',
    scheme: dto.scheme || '',
    title: dto.title || '',
    FAVICON: dto.favicon || null,
    FAVORITE: !!dto.favorite,
    FOLDER_ID: dto.folderId || null,
    SORT_ORDER: (dto.sortOrder != null && typeof dto.sortOrder === 'number') ? dto.sortOrder : null,
    CUSTOM_TITLE: dto.customTitle || null,
    USER_ID: String((dto.userId != null && dto.userId !== '') ? dto.userId : (_currentUid || '')),
    annotationCount: dto.annotationCount || 0,
    createdAt: dto.firstVisited || null,
    lastVisited: dto.lastVisited || null,
    PAGE_NOTE: dto.pageNote || null,
    PAGE_NOTE_UPDATED_AT: dto.pageNoteUpdatedAt || null,
    SYNC_STATUS: SYNC_STATUS_SYNCED,
    SYNC_VERSION: 0,
    SERVER_UPDATE_TIME: dto.updatedAt || null,
    DIRTY_BITS: 0,
    SYNCED_AT: dto.syncedAt || null
  };
}

function buildPageDiffUploadDto(page) {
  var bits = page.DIRTY_BITS || 0xFF;
  var dto = {
    urlMd5: page.URL_MD5,
    webUri: page.url,
    domain: page.domain,
    scheme: page.scheme || '',
    userId: page.USER_ID || '',
    annotationCount: page.annotationCount || 0,
    updatedAt: page.lastVisited || page.createdAt || null,
    // 始终上传 lastVisited 字段，与服务端 updatedAt 保持一致。
    // 否则页面级变更（pageNote/favorite/folder，无 VISITED 位）上传不含 lastVisited，
    // 服务端保留旧值，下载合并时回退本地 lastVisited（页面在侧栏跳到旧位置）。
    lastVisited: page.lastVisited || null
  };
  if (bits & DIRTY_BIT_TITLE) {
    dto.title = page.title;
    dto.favicon = page.FAVICON || null;
  }
  if (bits & DIRTY_BIT_FAVORITE) dto.favorite = !!page.FAVORITE;
  if (bits & DIRTY_BIT_FOLDER) dto.folderId = page.FOLDER_ID || ''; // 空串表示移出目录
  if (bits & DIRTY_BIT_SORT_ORDER) dto.sortOrder = (page.SORT_ORDER != null && typeof page.SORT_ORDER === 'number') ? page.SORT_ORDER : 0;
  if (bits & DIRTY_BIT_CUSTOM_TITLE) dto.customTitle = page.CUSTOM_TITLE || ''; // 空串表示清除自定义标题
  if (bits & DIRTY_BIT_PAGE_NOTE) {
    dto.pageNote = page.PAGE_NOTE || null;
    dto.pageNoteUpdatedAt = page.PAGE_NOTE_UPDATED_AT || null;
  }
  return dto;
}

function serverFolderDtoToLocal(dto) {
  return {
    folderId: dto.folderId,
    name: dto.name || '',
    parentFolderId: dto.parentFolderId || null,
    orderSeq: dto.orderSeq || 0,
    USER_ID: String((dto.userId != null && dto.userId !== '') ? dto.userId : (_currentUid || '')),
    SYNC_STATUS: SYNC_STATUS_SYNCED,
    SYNC_VERSION: 0,
    SERVER_UPDATE_TIME: dto.updatedAt || null,
    DIRTY_BITS: 0,
    updatedAt: dto.updatedAt || null,
    SYNCED_AT: dto.syncedAt || null
  };
}

function buildFolderDiffUploadDto(folder) {
  // folder 字段统一上传（记录小，不做字段级 diff）
  return {
    folderId: folder.folderId,
    name: folder.name,
    parentFolderId: folder.parentFolderId || '',
    orderSeq: folder.orderSeq || 0,
    userId: folder.USER_ID || '',
    updatedAt: folder.updatedAt || wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss')
  };
}

// ---- Image Asset DTO Mapping（第4类：imageData 指针同步，base64 走 R2 不入 sync）----
// biz_key = pageKey + '_' + imageKey，与客户端 imageData.id、服务端 ImageAsset.bizKey 对齐

function serverImageAssetDtoToLocal(dto) {
  // data 留空：跨设备 pull 拿到 cloudUrl(=objectKey) 元数据后，由 image-sync-downloader 后台拉 blob 回填
  // D2：wire 字段 cloudUrl 承载 objectKey；contentHash 已从协议移除。
  return {
    id: dto.pageKey + '_' + dto.imageKey,
    pageKey: dto.pageKey,
    imageKey: dto.imageKey,
    imageUrl: dto.imageUrl || null,
    data: null,
    cloudUrl: dto.cloudUrl || null,
    SYNC_STATUS: SYNC_STATUS_SYNCED,
    SYNC_VERSION: 0,
    SERVER_UPDATE_TIME: dto.updatedAt || null,
    DIRTY_BITS: 0,
    timestamp: dto.updatedAt || new Date().toISOString(),
    SYNCED_AT: dto.syncedAt || null
  };
}

function buildImageAssetDiffUploadDto(rec) {
  // 必须剥离 data 字段（base64 走 R2，不走 sync 通道）。cloudUrl 承载 objectKey。
  return {
    pageKey: rec.pageKey,
    imageKey: rec.imageKey,
    cloudUrl: rec.cloudUrl || null,
    imageUrl: rec.imageUrl || null,
    updatedAt: rec.timestamp || rec.SERVER_UPDATE_TIME || new Date().toISOString()
  };
}

function imageAssetBizKey(rec) {
  return rec.pageKey + '_' + rec.imageKey;
}

// ---- 收集脏 page / folder ----

async function _collectDirtyPages() {
  var store = db._tx('pages', 'readonly');
  var index = store.index('syncStatus');
  // 并发派发 4 个 getAll（同一事务活跃期内全部派发），避免顺序 await 导致事务失活
  var results = await Promise.all([
    _getAllFromIndex(index, SYNC_STATUS_PENDING),
    _getAllFromIndex(index, SYNC_STATUS_LOCAL),
    _getAllFromIndex(index, SYNC_STATUS_ERROR),
    _getAllFromIndex(index, SYNC_STATUS_PENDING_DELETED)
  ]);
  var dirty = results[0].concat(results[1]).concat(results[2]);
  var pendingDeleted = results[3];
  var deleted = pendingDeleted.map(function (p) { return p.URL_MD5; }).filter(Boolean);
  return { dirty: dirty, deleted: deleted };
}

async function _collectDirtyFolders() {
  var store = db._tx('folders', 'readonly');
  var index = store.index('syncStatus');
  // 并发派发 4 个 getAll（同一事务活跃期内全部派发），避免顺序 await 导致事务失活
  var results = await Promise.all([
    _getAllFromIndex(index, SYNC_STATUS_PENDING),
    _getAllFromIndex(index, SYNC_STATUS_LOCAL),
    _getAllFromIndex(index, SYNC_STATUS_ERROR),
    _getAllFromIndex(index, SYNC_STATUS_PENDING_DELETED)
  ]);
  var dirty = results[0].concat(results[1]).concat(results[2]);
  var pendingDeleted = results[3];
  var deleted = pendingDeleted.map(function (f) { return f.folderId; });
  return { dirty: dirty, deleted: deleted };
}

// ---- Document DTO Mapping（第5类：自建文档，docId 为业务键）----
// 文档作为真实 https 页面由服务端在 <manager_domain>/d/<docId> 渲染，批注按 webUri 绑定。
// MVP 沿用 folder 模式整记录上传（DIRTY_BITS=0xFF），bodyHtml 体积受服务端 doc_size_limit 约束。

function serverDocumentDtoToLocal(dto) {
  // P1-8（dbVersion 25）：bodyHtml 不进记录（分仓在 docBodies）；若服务端 DTO 带 body
  //（防御 legacy 通道），由 _applyDownloadedDocumentsChunk 落 docBodies。
  return {
    docId: dto.docId,
    webUri: dto.webUri || '',
    domain: dto.domain || '',
    urlMd5: dto.urlMd5 || '',
    title: dto.title || '',
    bodyObjectKey: dto.bodyObjectKey || null,
    bodyContentHash: dto.bodyContentHash || null,
    folderId: dto.folderId || null,
    tags: dto.tags || '',
    pageWidth: dto.pageWidth || '820px',
    isReadOnly: !!dto.isReadOnly,
    sortOrder: (dto.sortOrder != null && typeof dto.sortOrder === 'number') ? dto.sortOrder : null,
    kind: 'document',
    USER_ID: String((dto.userId != null && dto.userId !== '') ? dto.userId : (_currentUid || '')),
    SYNC_STATUS: SYNC_STATUS_SYNCED,
    SYNC_VERSION: 0,
    SERVER_UPDATE_TIME: dto.updatedAt || null,
    DIRTY_BITS: 0,
    updatedAt: dto.updatedAt || null,
    SYNCED_AT: dto.syncedAt || null
  };
}

// bodyObjectKey 命名空间归属校验：合法 key 应属当前登录账号（u/{uid}/doc|snap/...）。
// 跨账号残留（换号/备份导入把他人命名空间的 key 带进本地记录）时必须视为无 key 重传 body——
// 否则上传恒发 bodyHtml=null，服务端 persistXxxBody 见 null 即跳过，新建行永不落 body
// （表现：usage 计数有文档、存储视图/管理页文档恒空、缩略图签名 403「无权操作他人对象」）。
function _isForeignBodyKey(key) {
  return !!(key && _currentUid && String(key).indexOf('u/' + _currentUid + '/') !== 0);
}

function buildDocumentDiffUploadDto(doc) {
  // doc 整记录上传（docId 为业务键；userId 由服务端从鉴权上下文取，DTO 不带）
  // body 上云（覆盖策略）：首次无 key、本地标记 bodyDirty（编辑保存过）、或 key 非当前账号命名空间
  // → 带 bodyHtml 上传；否则 null（服务端 persistDocumentBody 见 null 即保留既有 R2 对象，不重传、不覆盖）。
  // P1-8 分仓：记录不再内联 bodyHtml——此处先按条件给出 ''（需上传）或 null（跳过）哨兵，
  // 实际 body 由 sync() 的异步 join（db.getDocBodyHtml）回填。
  return {
    docId: doc.docId,
    webUri: doc.webUri,
    domain: doc.domain || '',
    urlMd5: doc.urlMd5 || '',
    title: doc.title || '',
    bodyHtml: (doc.bodyDirty || !doc.bodyObjectKey || _isForeignBodyKey(doc.bodyObjectKey)) ? '' : null,
    folderId: doc.folderId || '',
    tags: doc.tags != null ? doc.tags : '',
    pageWidth: doc.pageWidth || '820px',
    isReadOnly: !!doc.isReadOnly,
    sortOrder: (doc.sortOrder != null && typeof doc.sortOrder === 'number') ? doc.sortOrder : null,
    updatedAt: doc.updatedAt || wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss'),
    // V70 导入豁免（spec §6.2）：同 buildDiffUploadDto
    imported: doc.IS_IMPORTED === 1 ? true : undefined
  };
}

async function _collectDirtyDocuments(skipR2Degraded) {
  var store = db._tx('documents', 'readonly');
  var index = store.index('syncStatus');
  var results = await Promise.all([
    _getAllFromIndex(index, SYNC_STATUS_PENDING),
    _getAllFromIndex(index, SYNC_STATUS_LOCAL),
    _getAllFromIndex(index, SYNC_STATUS_ERROR),
    _getAllFromIndex(index, SYNC_STATUS_PENDING_DELETED)
  ]);
  // 永久/瞬时耗尽项不再自动重发（手动重试复位）。
  // P1-41: R2 降级退避窗内跳过 dirty 收集（tombstone 仍收集——删除不写 R2 put，
  // 服务端 tombstone 处理失败会自然重试）；manual（用户强制）不受退避限制。
  var dirty = skipR2Degraded ? [] : results[0].concat(results[1]).concat(results[2])
    .filter(function (d) { return !d.SYNC_EXHAUSTED; });
  var pendingDeleted = results[3];
  var deleted = pendingDeleted.map(function (d) { return d.docId; });
  return { dirty: dirty, deleted: deleted };
}

// ---- snapshot（第6类，镜像 document 模式；bodyHtml 为纯原始网页快照）----
// 记录形态：{ snapId, webUri, domain, urlMd5, title, bodyHtml, sourceWebUri, sourceUrlMd5,
//   folderId, kind:'snapshot', USER_ID, updatedAt, SYNC_STATUS, SYNC_VERSION, SERVER_UPDATE_TIME,
//   DIRTY_BITS, SYNC_RETRY_COUNT, SYNC_EXHAUSTED, SYNC_LAST_ERROR, SYNC_LAST_ATTEMPT_AT }
// webUri = <manager_domain>/snap/<snapId>，批注按 webUri 绑定；sourceWebUri/sourceUrlMd5 回链源网页。

function serverSnapshotDtoToLocal(dto) {
  // P1-8（dbVersion 25）：bodyHtml 不进记录（分仓在 snapBodies）；若服务端 DTO 带 body
  //（防御 legacy 通道，_applyDownloadedSnapshotsChunk 有 GZ 解压），由 apply 落 snapBodies。
  return {
    snapId: dto.snapId,
    webUri: dto.webUri || '',
    domain: dto.domain || '',
    urlMd5: dto.urlMd5 || '',
    title: dto.title || '',
    bodyObjectKey: dto.bodyObjectKey || null,
    bodyContentHash: dto.bodyContentHash || null,
    sourceWebUri: dto.sourceWebUri || '',
    sourceUrlMd5: dto.sourceUrlMd5 || '',
    folderId: dto.folderId || null,
    snapType: dto.snapType || 'full',
    sortOrder: (dto.sortOrder != null && typeof dto.sortOrder === 'number') ? dto.sortOrder : null,
    kind: 'snapshot',
    USER_ID: String((dto.userId != null && dto.userId !== '') ? dto.userId : (_currentUid || '')),
    SYNC_STATUS: SYNC_STATUS_SYNCED,
    SYNC_VERSION: 0,
    SERVER_UPDATE_TIME: dto.updatedAt || null,
    DIRTY_BITS: 0,
    updatedAt: dto.updatedAt || null,
    SYNCED_AT: dto.syncedAt || null
  };
}

function buildSnapshotDiffUploadDto(snap) {
  // snap 整记录上传（snapId 为业务键；userId 由服务端从鉴权上下文取，DTO 不带）
  // P1-8 分仓：同 buildDocumentDiffUploadDto——'' / null 哨兵，实际 body 由异步 join 回填。
  return {
    snapId: snap.snapId,
    webUri: snap.webUri,
    domain: snap.domain || '',
    urlMd5: snap.urlMd5 || '',
    title: snap.title || '',
    // body 已上云（bodyObjectKey 在且属当前账号）→ 不重传 body（服务端 persistSnapshotBody 见 null 即保留既有对象）；
    // 首次采集无 key、或 key 非当前账号命名空间（跨账号残留）→ 正常传 bodyHtml。避免 key-bearing 快照每次元数据编辑都重发 MB 级 body。
    bodyHtml: (!snap.bodyObjectKey || _isForeignBodyKey(snap.bodyObjectKey)) ? '' : null,
    sourceWebUri: snap.sourceWebUri || '',
    sourceUrlMd5: snap.sourceUrlMd5 || '',
    folderId: snap.folderId || '',
    snapType: snap.snapType || 'full',
    sortOrder: (snap.sortOrder != null && typeof snap.sortOrder === 'number') ? snap.sortOrder : null,
    updatedAt: snap.updatedAt || wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss'),
    // V70 导入豁免（spec §6.2）：同 buildDiffUploadDto
    imported: snap.IS_IMPORTED === 1 ? true : undefined
  };
}

// ---- bodyHtml gzip 压缩/解压（减少上传体积，绕过 docSizeLimit 限额）----

// Uint8Array → Base64（SW 环境无 compression.js，用原生 btoa）
function _uint8ToBase64(bytes) {
  var bin = '';
  for (var i = 0; i < bytes.length; i += 8192) {
    var end = Math.min(i + 8192, bytes.length);
    bin += String.fromCharCode.apply(null, bytes.subarray(i, end));
  }
  return btoa(bin);
}

// Base64 → Uint8Array
function _base64ToUint8(b64) {
  var bin = atob(b64);
  var bytes = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

// gzip 压缩 bodyHtml，返回 "GZ:" + base64(gzip(bodyHtml))。HTML 压缩比通常 3-5x。
// 服务端 processSnapshotUploads 识别 "GZ:" 前缀后解压。
async function _compressBodyHtml(raw) {
  if (!raw || raw.length < 2048) return raw;  // 小于 2KB 不压缩
  try {
    var bytes = new TextEncoder().encode(raw);
    // P1-30: ⚠️ 不得用 CompressionStream.writable.getWriter().write()——Chrome 150 等版本下
    // 永不 resolve（静默挂起）。必须 Response(...).body.pipeThrough(...) 全量读出
    // （与 manager.js gzipBytes 同款已验证写法）。
    var buf = await new Response(new Response(bytes).body.pipeThrough(new CompressionStream('gzip'))).arrayBuffer();
    return 'GZ:' + _uint8ToBase64(new Uint8Array(buf));
  } catch (e) {
    console.warn('[Sync] bodyHtml compression failed, sending raw:', e.message);
    return raw;
  }
}

function _decompressBodyHtml(raw) {
  if (!raw || typeof raw !== 'string' || raw.indexOf('GZ:') !== 0) {
    return Promise.resolve(raw);
  }
  // P1-30: 原实现两个缺陷——① 只 reader.read() 一次，>64KB 的 body 静默截断（DecompressionStream
  // 分块产出，首个 chunk 通常 ~64KB）；② getWriter().write() 有 Chrome-150 挂起风险。
  // 改 pipeThrough + Response 全量读（与 manager.js gunzipBytes 同款），调用方均 await，签名兼容。
  return (async function () {
    try {
      var bytes = _base64ToUint8(raw.substring(3));
      var buf = await new Response(new Response(bytes).body.pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
      return new TextDecoder().decode(buf);
    } catch (e) {
      console.warn('[Sync] bodyHtml decompression failed:', e.message);
      return raw;
    }
  })();
}

async function _collectDirtySnapshots(skipR2Degraded) {
  var store = db._tx('snapshots', 'readonly');
  var index = store.index('syncStatus');
  var results = await Promise.all([
    _getAllFromIndex(index, SYNC_STATUS_PENDING),
    _getAllFromIndex(index, SYNC_STATUS_LOCAL),
    _getAllFromIndex(index, SYNC_STATUS_ERROR),
    _getAllFromIndex(index, SYNC_STATUS_PENDING_DELETED)
  ]);
  // P1-41: 同 _collectDirtyDocuments——R2 降级退避窗内跳过 dirty，tombstone 照常。
  var dirty = skipR2Degraded ? [] : results[0].concat(results[1]).concat(results[2])
    .filter(function (s) { return !s.SYNC_EXHAUSTED; }); // 永久/瞬时耗尽项不再自动重发（手动重试复位）
  var pendingDeleted = results[3];
  var deleted = pendingDeleted.map(function (s) { return s.snapId; });
  return { dirty: dirty, deleted: deleted };
}

// ---- 收集脏 imageData（第4类，镜像 page 但简化）----
// 语义：push 只发 cloudUrl 元数据（剥离 data/base64）。
// 待推判定：SYNC_STATUS 非 synced（local/pending/error），或 SYNC_STATUS='synced' 但 DIRTY_BITS≠0
//   （saveImageFromUrl/Base64 上传 R2 成功后写 SYNCED+DIRTY_BITS=1，表示 cloudUrl 已变更待 sync push 元数据）。
// 仅收集 cloudUrl 非空的（无 cloudUrl 的纯本地记录无服务端语义）。
// deleted 暂不实现：imageData deleteImageData 是物理删除无 tombstone；跨设备删除同步留 TODO。
// P1-18b: "SYNCED+DIRTY_BITS≠0 且有 cloudUrl"（图片 R2 上传成功、元数据待推）的记录不在
// syncStatus 索引的脏值里，此前靠 _collectDirtyImageData 全表 getAll 兜住（每 push 周期整表扫，
// 携带 base64 的读放大）。改为 syncMeta 有界清单 img_meta_dirty 追踪这部分记录：
// R2 上传成功时记入（SW _doUploadWithRetry → _noteImageMetaDirty），服务端确认后移除。
// 兜底：init 时 _reconcilePendingWorkLists 全表重建一次（见 init），防 restoreBackup 等路径漏记。
var IMG_META_DIRTY_MAX = 200;

// P1-18c: thumb_pending_ids 清单——THUMBNAIL_PENDING 标注的 annId 有界列表（≤THUMB_PENDING_MAX），
// _flushPendingThumbnails 此前每 tick/启动 db.getAll('annotations') 全表扫（含 CONTEXT 大字段）。
// 写入：saveLocalThumbnail 置标记时；清除：上云成功/标记清除/标注删除时 + flush 对账式自清理
//（读出的记录已无 THUMBNAIL_PENDING 即从清单移除）。init 时 _reconcilePendingWorkLists 全表重建兜底。
var THUMB_PENDING_MAX = 50;

async function _getThumbPendingIds() {
  try {
    return await _syncGetMeta('thumb_pending_ids') || [];
  } catch (e) { return []; }
}

// thumb_pending_ids 的所有变更**必须**走这里串行化。它是读-改-写（get → 增删 → set），
// 并发调用会互相覆盖丢 id —— 实测：连续保存两张页面截图时，两个 _noteThumbPending 竞态丢过一个，
// 那张截图要等清单见底触发补货或 24h 对账才被捡回来。
// 串行链 + **链内重读**：每个变更在自己的回合里重新取清单，没有过期快照覆盖的窗口。
var _thumbListChain = Promise.resolve();
function _serializeThumbList(fn) {
  var run = function () {
    return (async function () {
      var list = await _syncGetMeta('thumb_pending_ids') || [];
      await fn(list);
      await _syncSetMeta('thumb_pending_ids', list);
    })();
  };
  // 前一环无论成败都要继续排队；链条自身吞掉异常，一个失败不能让后续全部跳过
  var p = _thumbListChain.then(run, run);
  _thumbListChain = p.then(function () { }, function () { });
  return p;
}

// 头部淘汰公共段：被挤出的 id 在 DB 里仍是 PENDING 但已进不了清单 → 置截断标志交补传器补货
async function _capThumbList(list) {
  if (list.length > THUMB_PENDING_MAX) {
    list.splice(0, list.length - THUMB_PENDING_MAX);
    await _setThumbPendingTruncated(true);
  }
}

async function _noteThumbPending(id) {
  if (!id) return;
  try {
    await _serializeThumbList(async function (list) {
      if (list.indexOf(id) >= 0) return;
      list.push(id);
      await _capThumbList(list);
    });
  } catch (e) {
    // P1-9：入队失败=缩略图永久孤儿（补传器只认清单），不可静默——至少留下可观测痕迹
    console.warn('[thumb] note pending failed:', e && e.message);
  }
}

async function _removeThumbPending(id) {
  if (!id) return;
  try {
    await _serializeThumbList(function (list) {
      var i = list.indexOf(id);
      if (i >= 0) list.splice(i, 1);
    });
  } catch (e) { /* ignore */ }
}

// 原子并入（链内重读）：_wpzlMergeThumbPendingIds / 导入收尾用。
// 此前在调用方 get→union→set，与并发的 _noteThumbPending 互相覆盖。
function _mergeThumbPendingIds(ids) {
  if (!ids || ids.length === 0) return Promise.resolve(0);
  return _serializeThumbList(async function (list) {
    var added = 0;
    for (var i = 0; i < ids.length; i++) {
      if (ids[i] && list.indexOf(ids[i]) < 0) { list.push(ids[i]); added++; }
    }
    if (added) await _capThumbList(list);
    return added;
  }).catch(function () { return 0; });
}

// 原子剔除（链内重读）：补传器对账自清理用——只删"确认已不再是 PENDING"的 id，
// 并发新增的一律保留。取代原先在 SW 侧 get→union→set 的写回（那有丢更新窗口）。
function _dropThumbPendingIds(deadIds) {
  if (!deadIds || deadIds.length === 0) return Promise.resolve(0);
  return _serializeThumbList(function (list) {
    var dead = {};
    for (var i = 0; i < deadIds.length; i++) dead[deadIds[i]] = 1;
    var removed = 0;
    for (var j = list.length - 1; j >= 0; j--) {
      if (dead[list[j]]) { list.splice(j, 1); removed++; }
    }
    return removed;
  }).catch(function () { return 0; });
}

async function _setThumbPendingIds(ids) {
  try {
    await _serializeThumbList(function (list) {
      var next = ids || [];
      list.length = 0;
      for (var i = 0; i < next.length; i++) list.push(next[i]);
    });
  } catch (e) { /* ignore */ }
}

// C 修复：thumb_pending_ids 是有界工作清单（≤THUMB_PENDING_MAX），而 DB 里 THUMBNAIL_PENDING 的
// 记录可能更多。_reconcilePendingWorkLists 每 24h 才重建一次，被上限截掉的尾部在节流期内永远进不了
// 清单；补传器读清单、manager 视图却是全表扫，两边不同源 → 用户看到一批"永远不动的待传项"。
// thumb_pending_truncated 记「确实有记录没能进清单」，补传器在清单里再无可补传项时据此即时补货。
// ⚠️ 每个截断点都必须写 true（含 _noteThumbPending / _wpzlMergeThumbPendingIds 的头部淘汰），
// 否则标志会停在过期的 false 上（例：昨天对账写 false，今天导入被截到 50 → 尾部全部饿死）。
async function _getThumbPendingTruncated() {
  try {
    var v = await _syncGetMeta('thumb_pending_truncated');
    return v === undefined ? undefined : !!v;
  } catch (e) { return undefined; }
}
async function _setThumbPendingTruncated(flag) {
  try { await _syncSetMeta('thumb_pending_truncated', !!flag); } catch (e) { /* ignore */ }
}

// 清单准入（live-first）：未耗尽项优先占位，耗尽项补位。若不优先，一批已耗尽项会一直占满上限、
// 把真正待传的尾部挡在门外 —— 补货反复触发却寸步不进（活锁）。
// truncated = 存在没能进入清单的「未耗尽」待传项（耗尽项被挤出不影响它是否算工作）。
function _admitThumbPending(allAnns) {
  var live = [], dead = [];
  for (var i = 0; i < allAnns.length; i++) {
    var a = allAnns[i];
    if (!a || !a.THUMBNAIL_PENDING || !a.MARK_INFO_ID) continue;
    (a.THUMB_EXHAUSTED ? dead : live).push(a.MARK_INFO_ID);
  }
  var ids = live.slice(0, THUMB_PENDING_MAX);
  if (ids.length < THUMB_PENDING_MAX) ids = ids.concat(dead.slice(0, THUMB_PENDING_MAX - ids.length));
  return { ids: ids, truncated: live.length > THUMB_PENDING_MAX };
}

// C 修复：仅重建 thumb_pending_ids 清单。流式投影扫描；不碰孤儿缩略图对各种，也不写
// pending_lists_reconciled_at —— 它有意绕开 _reconcilePendingWorkLists 的 24h 节流，
// 供补传器在清单见底时即时补货。勿给它加节流：加了就退回「尾部干等 24h」的原缺陷。
async function _refreshThumbPendingIds() {
  try {
    var allAnns = await _streamCollectAnnotations();
    var r = _admitThumbPending(allAnns);
    await _setThumbPendingIds(r.ids);
    await _setThumbPendingTruncated(r.truncated);
    return r.truncated;
  } catch (e) { return false; }
}

// P2-6: init 对账孤儿缩略图清扫上限——每轮最多清 N 条，剩余下轮 init 再清
// （防几万孤儿一次性卡 SW 启动；老库 dbVersion<8 无 localThumbnails store 时
//  _tx 抛错被内层 catch 跳过，天然兼容）。
var ORPHAN_THUMB_CLEAN_MAX = 500;

// F-4: 流式迭代 store 记录（openCursor）。visit(record) 返回 true 可提前终止。
// 与 getAll 的差别：任一时刻只持有一条记录（base64/CONTEXT 大字段用后即释放），
// 不把全表反序列化进内存——300MB 水位的 imageData 库下避免整表驻留的内存峰值。
function _streamStoreRecords(storeName, visit) {
  return new Promise(function (resolve, reject) {
    var req;
    try { req = db._tx(storeName, 'readonly').openCursor(); } catch (e) { reject(e); return; }
    req.onsuccess = function (ev) {
      var cursor = ev.target.result;
      if (!cursor) { resolve(); return; }
      var stop = false;
      try { stop = visit(cursor.value) === true; } catch (e) { reject(e); return; }
      if (stop) { resolve(); return; }
      cursor.continue();
    };
    req.onerror = function () { reject(req.error); };
  });
}

// P1-18 兜底：全表对账重建 img_meta_dirty / thumb_pending_ids。
// F-4/E-P2-8 改造：此前每次 SW 冷启动都执行（annotations/imageData 全表 getAll，
// 含 CONTEXT/base64 大字段整体进内存，是 300MB 水位库下冷启动的最大性能杀手）——
// 改为 24h 节流 + openCursor 流式。restoreBackup 导入后需要立即重建：该路径会清
// pending_lists_reconciled_at 强制下次 init 重跑（见 service-worker.js restoreBackup case）。
var PENDING_LISTS_RECONCILE_INTERVAL_MS = 24 * 60 * 60 * 1000;
// F-4: 流式收集 annotations 对账所需字段（仅 MARK_INFO_ID/THUMBNAIL_PENDING 投影），
// 不把 CONTEXT/THUMBNAIL 大字段驻留内存。
async function _streamCollectAnnotations() {
  var out = [];
  await _streamStoreRecords('annotations', function (a) {
    // THUMB_EXHAUSTED 供 _admitThumbPending 做 live-first 准入；仍不投影 CONTEXT/THUMBNAIL 大字段。
    // THUMBNAIL_PENDING 必须取真实字段值——终态（THUMB_LOCAL_MISSING，PENDING 已清）绝不能进工作清单，
    // 否则会退回"排一个永远传不上去的任务"。终态由 manager 侧的 collectThumbPending 单独呈现。
    if (a) out.push({
      MARK_INFO_ID: a.MARK_INFO_ID,
      THUMBNAIL_PENDING: !!a.THUMBNAIL_PENDING,
      THUMB_EXHAUSTED: !!a.THUMB_EXHAUSTED
    });
  });
  return out;
}

async function _reconcilePendingWorkLists() {
  try {
    var lastRun = 0;
    try { lastRun = await _syncGetMeta('pending_lists_reconciled_at') || 0; } catch (e) { /* ignore */ }
    if (lastRun && (Date.now() - lastRun) < PENDING_LISTS_RECONCILE_INTERVAL_MS) return;
    var allAnns = await _streamCollectAnnotations();
    var annKeySet = new Set();   // P2-6: 复用本轮全量读建 key 集合，不重查
    for (var i = 0; i < allAnns.length; i++) {
      var a = allAnns[i];
      if (a && a.MARK_INFO_ID) annKeySet.add(a.MARK_INFO_ID);
    }
    // 与 _refreshThumbPendingIds 共用同一套 live-first 准入与截断标志计算，避免两条路径口径分叉
    var _thumbAdmit = _admitThumbPending(allAnns);
    await _setThumbPendingIds(_thumbAdmit.ids);
    await _setThumbPendingTruncated(_thumbAdmit.truncated);

    // P2-6 第三步：localThumbnails 孤儿对账（annId 不在 annotations 全集 → 删）。
    // 只按物理存在性判定——软删（pending_deleted）行仍在 annotations store，其缩略图
    // 由删除路径的级联清（本批另加），此处不误伤。key-only 读（getAllKeys）不拉
    // dataURL 大字段；删除走 db.deleteByKeys（自带新事务同步派发）。
    var orphanCleaned = 0;
    var orphanCapped = false;
    try {
      var tKeys = await new Promise(function (resolve, reject) {
        var req = db._tx('localThumbnails', 'readonly').getAllKeys();
        req.onsuccess = function () { resolve(req.result || []); };
        req.onerror = function () { reject(req.error); };
      });
      var orphans = [];
      for (var k = 0; k < tKeys.length; k++) {
        if (!annKeySet.has(tKeys[k])) {
          if (orphans.length < ORPHAN_THUMB_CLEAN_MAX) orphans.push(tKeys[k]);
          else { orphanCapped = true; break; }
        }
      }
      if (orphans.length > 0) {
        await db.deleteByKeys('localThumbnails', orphans);
        orphanCleaned = orphans.length;
      }
    } catch (e2) {
      // 老库无 localThumbnails store（dbVersion<8）等：跳过清扫不阻断对账
      console.warn('[Sync] orphan thumbnail sweep failed:', e2 && e2.message);
    }

    // F-4: imageData 流式扫描（只收集 id，凑满 IMG_META_DIRTY_MAX 即停，不整表驻留 base64）
    var metaIds = [];
    try {
      await _streamStoreRecords('imageData', function (r) {
        if (r && r.SYNC_STATUS === SYNC_STATUS_SYNCED && (r.DIRTY_BITS || 0) && r.cloudUrl) {
          metaIds.push(r.id);
          if (metaIds.length >= IMG_META_DIRTY_MAX) return true;
        }
      });
    } catch (e3) {
      console.warn('[Sync] reconcile img_meta_dirty scan failed:', e3 && e3.message);
    }
    try { await _syncSetMeta('img_meta_dirty', metaIds); } catch (e) { /* ignore */ }
    // 成功后才落节流时间戳（失败保持未跑状态，下次 init 重试）
    try { await _syncSetMeta('pending_lists_reconciled_at', Date.now()); } catch (e) { /* ignore */ }
    console.log('[Sync] reconcile pending work lists: thumb=' + _thumbAdmit.ids.length + ', imgMeta=' + metaIds.length
      + (orphanCleaned ? (', orphanThumbs=' + orphanCleaned + (orphanCapped ? ' (capped)' : '')) : ''));
  } catch (e) {
    console.warn('[Sync] reconcile pending work lists failed:', e && e.message);
  }
}

// F-4/E-P2-8: 清对账/自愈节流时间戳（restoreBackup 导入后强制下次 init 全量重建清单；
// 导入数据不经常规写点，持久化清单不会自然收录）
async function _syncClearReconcileGates() {
  try {
    await _syncSetMeta('pending_lists_reconciled_at', 0);
    await _syncSetMeta('img_dl_scan_last_run', 0);
    await _syncSetMeta('doc_dl_scan_last_run', 0);   // P1-7：restore 后强制重建文档待下清单
  } catch (e) { /* ignore */ }
}

async function _noteImageMetaDirty(id) {
  if (!id) return;
  try {
    var list = await _syncGetMeta('img_meta_dirty') || [];
    if (list.indexOf(id) < 0) {
      list.push(id);
      if (list.length > IMG_META_DIRTY_MAX) list = list.slice(list.length - IMG_META_DIRTY_MAX);
      await _syncSetMeta('img_meta_dirty', list);
    }
  } catch (e) { /* ignore */ }
}

async function _clearImageMetaDirty(id) {
  if (!id) return;
  try {
    var list = await _syncGetMeta('img_meta_dirty') || [];
    var i = list.indexOf(id);
    if (i >= 0) {
      list.splice(i, 1);
      await _syncSetMeta('img_meta_dirty', list);
    }
  } catch (e) { /* ignore */ }
}

// ---- P1-23: R2 清理补偿队列（有界） ----
// deleteAnnotation（pageRect 缩略图单对象）/ deletePage（按 pageKey 批删）的 R2 删除
// 原为 fire-and-forget（失败仅 warn）→ 对象+配额永久泄漏（服务端 StorageQuotaReconciler
// 只对账计数，不删孤儿对象）。失败入队，connectivity-tick online 分支重试。
var R2_DELETE_PENDING_MAX = 200;
var R2_DELETE_FLUSH_BATCH = 10;
var R2_DELETE_MAX_RETRIES = 10;

async function _getR2DeletePending() {
  try { return await _syncGetMeta('r2_delete_pending') || []; } catch (e) { return []; }
}

async function _noteR2DeletePending(key, by) {
  try {
    if (!key) return;
    var list = await _getR2DeletePending();
    for (var i = 0; i < list.length; i++) {
      if (list[i].k === key && list[i].by === (by || 'key')) return; // 已在队列
    }
    list.push({ k: key, by: by || 'key', rc: 0, ts: 0 });
    if (list.length > R2_DELETE_PENDING_MAX) list = list.slice(list.length - R2_DELETE_PENDING_MAX);
    await _syncSetMeta('r2_delete_pending', list);
  } catch (e) { /* ignore */ }
}

// 每次最多重试 R2_DELETE_FLUSH_BATCH 条；成功 / HTTP 404（对象已不在，目的达成）出队；
// 其余失败 retryCount++ 留队；≥R2_DELETE_MAX_RETRIES 放弃（console.error，配额泄漏兜底靠
// 服务端 StorageQuotaReconciler 每日对账数字）。
async function _flushR2DeleteQueue() {
  if (typeof wpzl_assetDelete !== 'function' && typeof wpzl_assetDeleteByPage !== 'function') return 0;
  var list = await _getR2DeletePending();
  if (!list.length) return 0;
  var remaining = [];
  var flushed = 0;
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    if (flushed >= R2_DELETE_FLUSH_BATCH) { remaining.push(item); continue; }
    try {
      if (item.by === 'page') await wpzl_assetDeleteByPage(item.k);
      else await wpzl_assetDelete(item.k);
      flushed++;
      continue; // 成功 → 出队
    } catch (e) {
      if (e && e.status === 404) { flushed++; continue; } // 对象不存在 → 目的已达成，出队
    }
    item.rc = (item.rc || 0) + 1;
    item.ts = Date.now();
    if (item.rc >= R2_DELETE_MAX_RETRIES) {
      console.error('[Sync] R2 delete retry exhausted, giving up: ' + item.by + ':' + item.k);
      continue; // 放弃 → 出队
    }
    remaining.push(item);
  }
  try { await _syncSetMeta('r2_delete_pending', remaining); } catch (e) { /* ignore */ }
  if (flushed > 0) console.log('[Sync] r2_delete_pending flushed ' + flushed + ', remaining ' + remaining.length);
  return flushed;
}

// ---- P1-17: imageData 容量治理 ----
// base64 上传成功后不清（离线可用设计），无 LRU/TTL → IDB 无界增长（实测 118 图即 46MB）。
// 策略：本地 data 总量超水位（300MB）时，对"已上云(SYNCED+cloudUrl) 且上云超 90 天"的
// 冷数据清 data 留 cloudUrl 指针（dataEvicted 标记防 ISD 自动回灌；manager 手动回填仍可用），
// 从最老开始清到水位以下。7 天节流；全表扫为低频路径（P1-18 已消灭高频全表扫）。
var IMG_DATA_EVICT_THRESHOLD_BYTES = 300 * 1024 * 1024;
var IMG_DATA_EVICT_MIN_AGE_MS = 90 * 24 * 60 * 60 * 1000;
var IMG_EVICT_RUN_INTERVAL_MS = 7 * 24 * 60 * 60 * 1000;

// P1-2 Step A：时间值归一化（FMT "yyyy-MM-dd HH:mm:ss" / ISO / epoch ms → ms 数字）。
// 所有 LWW/新旧比较的唯一入口——消灭 FMT 与 ISO 混存时的字典序脆弱性（ISO 含 T/Z 与
// FMT 字符串直接比较结果无意义）与本地钟慢误判。解析失败返回 0（调用方视作"无时间信息"，
// 保守跳过/触发合并修正）。存储格式不变（Step B 另行评估）。
function _tsMs(v) {
  if (!v) return 0;
  if (typeof v === 'number') return v;
  var s = String(v).trim();
  // 无时区 naive（FMT "yyyy-MM-dd HH:mm:ss"）= UTC 轴（2026-11 起服务端也统一 UTC）→ 必须按 UTC 构造。
  // 不得走 Date.parse：Chrome 对无时区串按本地时区解释，与 ISO-Z 侧（imageData timestamp）互比差一个时区。
  var m = s.replace('T', ' ').match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?$/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
  var n = Date.parse(s); // ISO（含 imageData timestamp）/ 其他
  return isNaN(n) ? 0 : n;
}

async function _maybeEvictImageData() {
  try {
    var lastRun = await _syncGetMeta('img_evict_last_run') || 0;
    var now = Date.now();
    if (typeof lastRun === 'number' && now - lastRun < IMG_EVICT_RUN_INTERVAL_MS) return 0;
    await _syncSetMeta('img_evict_last_run', now);
    var store = db._tx('imageData', 'readonly');
    var all = await _getAllFromStore(store);
    var total = 0;
    for (var i = 0; i < all.length; i++) {
      var r = all[i];
      if (r && r.data) total += r.data.length;
    }
    if (total < IMG_DATA_EVICT_THRESHOLD_BYTES) return 0;
    // 候选：已上云且上云超 90 天且有 data（按上云时间 SYNCED_AT 最老优先）
    var candidates = [];
    for (var j = 0; j < all.length; j++) {
      var rec = all[j];
      if (!rec || !rec.data || !rec.cloudUrl) continue;
      if (rec.SYNC_STATUS !== SYNC_STATUS_SYNCED) continue;
      if (rec.dataEvicted) continue;
      var syncedMs = _tsMs(rec.SYNCED_AT) || _tsMs(rec.timestamp);
      if (!syncedMs || now - syncedMs < IMG_DATA_EVICT_MIN_AGE_MS) continue;
      candidates.push({ rec: rec, syncedMs: syncedMs });
    }
    candidates.sort(function (a, b) { return a.syncedMs - b.syncedMs; });
    var evicted = 0;
    var toPut = [];
    for (var c = 0; c < candidates.length && total >= IMG_DATA_EVICT_THRESHOLD_BYTES; c++) {
      var er = candidates[c].rec;
      total -= (er.data ? er.data.length : 0);
      er.data = null;
      er.dataEvicted = true;
      toPut.push(er);
      evicted++;
    }
    if (toPut.length > 0) {
      var wstore = db._tx('imageData', 'readwrite');
      for (var p = 0; p < toPut.length; p++) wstore.put(toPut[p]); // 循环内不 await（事务失活）
      console.log('[Sync] imageData evict: cleared data for ' + evicted + ' cold synced images (threshold ' +
        Math.round(IMG_DATA_EVICT_THRESHOLD_BYTES / 1024 / 1024) + 'MB)');
    }
    return evicted;
  } catch (e) {
    console.warn('[Sync] _maybeEvictImageData failed:', e && e.message);
    return 0;
  }
}

// ---- P1-44: 长离线(>墓碑保留期)全量对账 ----
// 服务端 janitor 定期物理删 >90 天墓碑；离线超 90 天的设备恢复后，增量查询学不到这些删除
// → 本地残留已删数据、上传"重建"→ 已删数据复活并传播。对策：token 年龄逼近保留期时做一次
// 全量对账（丢 token 走 since=null 全量分页拉服务端 active 全集，本地 SYNCED 且不在全集 → 硬删）。
// 服务端每响应带 serverNow + tombstoneRetentionDays（SyncResponse 新增字段）。

// 解析 syncToken（Base64url "userId:epochMs:shortId"）内嵌的签发时间，失败返回 0
function _syncTokenEpochMs(token) {
  try {
    var raw = atob(String(token).replace(/-/g, '+').replace(/_/g, '/'));
    var ms = parseInt(raw.split(':')[1], 10);
    return isNaN(ms) ? 0 : ms;
  } catch (e) { return 0; }
}

// 对账 diff：collected = 全量拉取期间累计的服务端 active 集（各类型 Set）。
// 判定：本地 SYNC_STATUS==='synced'（已同步、服务端权威）且 id 不在服务端全集 → 硬删。
// 保留：PENDING/LOCAL/PENDING_DELETED（未上行意图）与 error/exhausted（服务端无行，非删除证据）。
// 安全阀：某类服务端返回空集 && 本地该类有 SYNCED 记录 → 跳过该类（疑似拉取异常/换号，防误删）。
// USER_ID 过滤：仅处理当前账号记录（_currentUid，与 serverPageDtoToLocal 同源）。
async function _runFullReconcileDiff(collected) {
  var uid = String(_currentUid || '');
  var summary = [];
  try {
    // annotations
    var annAll = await _getAllFromStore(db._tx('annotations', 'readonly'));
    var annDel = [];
    var annSynced = 0;
    for (var i = 0; i < annAll.length; i++) {
      var a = annAll[i];
      if (!a || a.SYNC_STATUS !== SYNC_STATUS_SYNCED) continue;
      if (uid && a.USER_ID && String(a.USER_ID) !== uid) continue;
      annSynced++;
      if (!collected.ann.has(a.MARK_INFO_ID)) annDel.push(a.MARK_INFO_ID);
    }
    if (collected.ann.size > 0 && annDel.length > 0) {
      await db.deleteByKeys('annotations', annDel);
      // P2-6: 级联清 localThumbnails（对账确认服务端无此标注 → 本地行清除）
      try { await db.deleteByKeys('localThumbnails', annDel); } catch (e2) { /* ignore */ }
      summary.push('annotations:' + annDel.length + '/' + annSynced);
    } else if (collected.ann.size === 0 && annSynced > 0) {
      summary.push('annotations:SKIPPED(server empty)');
    }
  } catch (e) { summary.push('annotations:ERROR'); console.warn('[Sync] reconcile annotations failed:', e && e.message); }
  try {
    // pages（_hardDeletePagesByUrlMd5 级联清 imageData）
    var pageAll = await _getAllFromStore(db._tx('pages', 'readonly'));
    var pageDel = [];
    var pageSynced = 0;
    for (var p = 0; p < pageAll.length; p++) {
      var pg = pageAll[p];
      if (!pg || pg.SYNC_STATUS !== SYNC_STATUS_SYNCED) continue;
      if (uid && pg.USER_ID && String(pg.USER_ID) !== uid) continue;
      pageSynced++;
      if (pg.URL_MD5 && !collected.page.has(pg.URL_MD5)) pageDel.push(pg.URL_MD5);
    }
    if (collected.page.size > 0 && pageDel.length > 0) {
      await _hardDeletePagesByUrlMd5(pageDel);
      summary.push('pages:' + pageDel.length + '/' + pageSynced);
    } else if (collected.page.size === 0 && pageSynced > 0) {
      summary.push('pages:SKIPPED(server empty)');
    }
  } catch (e) { summary.push('pages:ERROR'); console.warn('[Sync] reconcile pages failed:', e && e.message); }
  try {
    var folderAll = await _getAllFromStore(db._tx('folders', 'readonly'));
    var folderDel = [];
    var folderSynced = 0;
    for (var f = 0; f < folderAll.length; f++) {
      var fo = folderAll[f];
      if (!fo || fo.SYNC_STATUS !== SYNC_STATUS_SYNCED) continue;
      if (uid && fo.USER_ID && String(fo.USER_ID) !== uid) continue;
      folderSynced++;
      if (fo.folderId && !collected.folder.has(fo.folderId)) folderDel.push(fo.folderId);
    }
    if (collected.folder.size > 0 && folderDel.length > 0) {
      await _hardDeleteFoldersById(folderDel);
      summary.push('folders:' + folderDel.length + '/' + folderSynced);
    } else if (collected.folder.size === 0 && folderSynced > 0) {
      summary.push('folders:SKIPPED(server empty)');
    }
  } catch (e) { summary.push('folders:ERROR'); console.warn('[Sync] reconcile folders failed:', e && e.message); }
  try {
    var imgAll = await _getAllFromStore(db._tx('imageData', 'readonly'));
    var imgDel = [];
    var imgSynced = 0;
    for (var m = 0; m < imgAll.length; m++) {
      var im = imgAll[m];
      if (!im || im.SYNC_STATUS !== SYNC_STATUS_SYNCED) continue;
      if (uid && im.USER_ID && String(im.USER_ID) !== uid) continue;
      imgSynced++;
      if (im.id && !collected.image.has(im.id)) imgDel.push(im.id);
    }
    if (collected.image.size > 0 && imgDel.length > 0) {
      await _hardDeleteImageAssetsByBizKey(imgDel);
      summary.push('imageData:' + imgDel.length + '/' + imgSynced);
    } else if (collected.image.size === 0 && imgSynced > 0) {
      summary.push('imageData:SKIPPED(server empty)');
    }
  } catch (e) { summary.push('imageData:ERROR'); console.warn('[Sync] reconcile imageData failed:', e && e.message); }
  try {
    var docAll = await _getAllFromStore(db._tx('documents', 'readonly'));
    var docDel = [];
    var docSynced = 0;
    for (var d = 0; d < docAll.length; d++) {
      var dc = docAll[d];
      if (!dc || dc.SYNC_STATUS !== SYNC_STATUS_SYNCED) continue;
      if (uid && dc.USER_ID && String(dc.USER_ID) !== uid) continue;
      docSynced++;
      if (dc.docId && !collected.doc.has(dc.docId)) docDel.push(dc.docId);
    }
    if (collected.doc.size > 0 && docDel.length > 0) {
      await _hardDeleteDocumentsById(docDel);
      summary.push('documents:' + docDel.length + '/' + docSynced);
    } else if (collected.doc.size === 0 && docSynced > 0) {
      summary.push('documents:SKIPPED(server empty)');
    }
  } catch (e) { summary.push('documents:ERROR'); console.warn('[Sync] reconcile documents failed:', e && e.message); }
  try {
    var snapAll = await _getAllFromStore(db._tx('snapshots', 'readonly'));
    var snapDel = [];
    var snapSynced = 0;
    for (var s = 0; s < snapAll.length; s++) {
      var sn = snapAll[s];
      if (!sn || sn.SYNC_STATUS !== SYNC_STATUS_SYNCED) continue;
      if (uid && sn.USER_ID && String(sn.USER_ID) !== uid) continue;
      snapSynced++;
      if (sn.snapId && !collected.snap.has(sn.snapId)) snapDel.push(sn.snapId);
    }
    if (collected.snap.size > 0 && snapDel.length > 0) {
      await _hardDeleteSnapshotsById(snapDel);
      summary.push('snapshots:' + snapDel.length + '/' + snapSynced);
    } else if (collected.snap.size === 0 && snapSynced > 0) {
      summary.push('snapshots:SKIPPED(server empty)');
    }
  } catch (e) { summary.push('snapshots:ERROR'); console.warn('[Sync] reconcile snapshots failed:', e && e.message); }
  console.log('[Sync] full reconcile diff done: ' + (summary.join(', ') || 'nothing to reconcile'));
}

async function _collectDirtyImageData() {
  // P1-18b: 索引查 pending/local/error（isPending 分支）+ img_meta_dirty 清单覆盖 isDirtySynced 分支
  // P1-13: pending_deleted（删除墓碑）第四态采集进 deleted——本机删图随统一批次上行传播。
  //   服务端 processImageAssetTombstone 已就绪；墓碑记录只保留 id/pageKey/imageKey/cloudUrl
  //   语义（data 在标墓碑时已清），rejected 外的已发 key 均视为删除已达成（见响应处理）。
  var idx = db._tx('imageData', 'readonly').index('syncStatus');
  var results = await Promise.all([
    _getAllFromIndex(idx, SYNC_STATUS_PENDING),
    _getAllFromIndex(idx, SYNC_STATUS_LOCAL),
    _getAllFromIndex(idx, SYNC_STATUS_ERROR),
    _getAllFromIndex(idx, SYNC_STATUS_PENDING_DELETED)
  ]);
  var candidates = results[0].concat(results[1]).concat(results[2]);
  var seen = {};
  var dirty = [];
  for (var i = 0; i < candidates.length; i++) {
    var rec = candidates[i];
    // P1-12：已耗尽（元数据被拒不计数时代终结后的新产物）不再自动采集——仅手动重传/重登复位
    if (rec.SYNC_EXHAUSTED) continue;
    seen[rec.id] = true;
    if (rec.cloudUrl) dirty.push(rec);
  }
  // P1-13: 墓碑采集（bizKey = pageKey_imageKey = id，与服务端 softDeleteByBizKeyIn 对齐）
  var deleted = [];
  var tombstones = results[3];
  for (var t = 0; t < tombstones.length; t++) {
    var tr = tombstones[t];
    if (tr.cloudUrl && !seen[tr.id]) deleted.push(imageAssetBizKey(tr));
  }
  // 清单部分：SYNCED + bits + cloudUrl（R2 已传、元数据待推）
  try {
    var metaIds = await _syncGetMeta('img_meta_dirty') || [];
    if (metaIds.length > 0) {
      var metaRecs = await db.getByKeys('imageData', metaIds);
      for (var m = 0; m < metaRecs.length; m++) {
        var mr = metaRecs[m];
        if (mr && !seen[mr.id] && mr.SYNC_STATUS === SYNC_STATUS_SYNCED && (mr.DIRTY_BITS || 0) && mr.cloudUrl) {
          dirty.push(mr);
        }
      }
    }
  } catch (e) { /* ignore */ }
  return { dirty: dirty, deleted: deleted };
}

// ---- 应用下载的 imageAsset（合并到本地，保留本地 data，仅更新 cloudUrl 元数据）----
// 分块批写（与 pages/folders 一致），避免 SW 30s 超时与大事务回滚。
// 拿到新 cloudUrl 且本地无 data 的记录，推入 image-sync-downloader 队列异步拉 blob。
async function _applyDownloadedImageAssets(serverList) {
  if (!serverList || serverList.length === 0) return 0;
  var total = 0;
  for (var i = 0; i < serverList.length; i += WPZL_IDB_WRITE_CHUNK) {
    var chunk = serverList.slice(i, i + WPZL_IDB_WRITE_CHUNK);
    total += await _applyDownloadedImageAssetsChunk(chunk);
  }
  return total;
}

async function _applyDownloadedImageAssetsChunk(serverList) {
  if (!serverList || serverList.length === 0) return 0;
  _throwIfSyncAborted(); // P1-7：分块写事务前检查——登出中则抛哨兵终止本轮
  var keys = serverList.map(function (d) { return d && (d.pageKey + '_' + d.imageKey); });
  var existingList = await db.getByKeys('imageData', keys);
  var toPut = [];
  var needDownload = []; // 本地无 data 且拿到 cloudUrl，待 image-sync-downloader 拉 blob
  var count = 0;
  for (var i = 0; i < serverList.length; i++) {
    var dto = serverList[i];
    if (!dto || !dto.pageKey || !dto.imageKey) continue;
    var existing = existingList[i];
    var serverLocal = serverImageAssetDtoToLocal(dto);
    if (!existing) {
      // 服务端有、本地无：写入（data=null，SYNC_STATUS='synced'，待后台拉 blob）
      toPut.push(serverLocal);
      if (serverLocal.cloudUrl) needDownload.push(serverLocal);
      count++;
      continue;
    }
    // 本地有未推（local/pending）→ 保留本地
    // P1-13: pending_deleted（删除墓碑）同样保留——并发窗口内对端仍在推此图时，
    // 不能把墓碑覆盖回 synced（否则墓碑丢失、删除永不上行）。
    if (existing.SYNC_STATUS === SYNC_STATUS_PENDING ||
        existing.SYNC_STATUS === SYNC_STATUS_LOCAL ||
        existing.SYNC_STATUS === SYNC_STATUS_PENDING_DELETED) {
      continue;
    }
    // Pull-loop guard：已应用过此服务端 revision 则跳过（P1-2 Step A：_tsMs 归一化比较）
    if (_syncGuardSkip(dto.syncedAt, existing.SYNCED_AT)) {
      continue;
    }
    // 本地已 synced 或无 cloudUrl：以服务端 cloudUrl 为准 upsert（保留本地 data）
    var merged = Object.assign({}, existing);
    merged.cloudUrl = serverLocal.cloudUrl || existing.cloudUrl;
    merged.imageUrl = serverLocal.imageUrl || existing.imageUrl;
    merged.SERVER_UPDATE_TIME = serverLocal.SERVER_UPDATE_TIME || existing.SERVER_UPDATE_TIME;
    merged.SYNCED_AT = serverLocal.SYNCED_AT || existing.SYNCED_AT;
    merged.SYNC_STATUS = SYNC_STATUS_SYNCED;
    merged.DIRTY_BITS = 0;
    toPut.push(merged);
    if (!merged.data && merged.cloudUrl && (merged.cloudUrl !== existing.cloudUrl)) {
      needDownload.push(merged);
    }
    count++;
  }
  if (toPut.length > 0) {
    var store = db._tx('imageData', 'readwrite');
    for (var p = 0; p < toPut.length; p++) {
      store.put(toPut[p]);
    }
  }
  // 通知 image-sync-downloader 拉 blob（任务3 实现；不存在时优雅降级）
  if (needDownload.length > 0 && typeof _enqueueImageSyncDownloads === 'function') {
    try { _enqueueImageSyncDownloads(needDownload); } catch (e) { /* ignore */ }
  }
  return count;
}

// ---- P1-13 连带：应用服务端下发的 imageAsset 删除墓碑（对端传播的下行侧）----
// 服务端 deletedImageAssetKeys 含 since 窗口内软删行——此前客户端只发上行/确认，从不消费
// 下行墓碑，对端设备的本地 imageData 永不删（cloudd 指针残留、容量虚占）。
// 保护：本地 PENDING/LOCAL（未上行意图）/PENDING_DELETED（本地墓碑待确认）不删，其余硬删。
async function _applyDeletedImageAssetKeys(bizKeys) {
  if (!bizKeys || bizKeys.length === 0) return 0;
  var existingList = await db.getByKeys('imageData', bizKeys);
  var toDelete = [];
  for (var i = 0; i < bizKeys.length; i++) {
    var existing = existingList[i];
    if (!existing) continue;
    if (existing.SYNC_STATUS === SYNC_STATUS_PENDING ||
        existing.SYNC_STATUS === SYNC_STATUS_LOCAL ||
        existing.SYNC_STATUS === SYNC_STATUS_PENDING_DELETED) continue;
    toDelete.push(bizKeys[i]);
  }
  if (toDelete.length > 0) await _hardDeleteImageAssetsByBizKey(toDelete);
  return toDelete.length;
}

// ---- 应用下载的 page / folder（合并到本地，保留本地 summary* 独有字段）----
// 大数据量分块写入：每块 100 条独立 readwrite 事务，避免 SW 30s 超时与 IDB 大事务回滚。
// 单块失败抛出，调用方（sync 主循环）记录已成功块数；下次同步 cursor 从断点续传。

var WPZL_IDB_WRITE_CHUNK = 100;

async function _applyDownloadedPages(serverPages) {
  if (!serverPages || serverPages.length === 0) return { count: 0, written: [] };
  var total = 0;
  var written = [];
  for (var i = 0; i < serverPages.length; i += WPZL_IDB_WRITE_CHUNK) {
    var chunk = serverPages.slice(i, i + WPZL_IDB_WRITE_CHUNK);
    var r = await _applyDownloadedPagesChunk(chunk);
    total += r.count;
    if (r.written && r.written.length) written = written.concat(r.written);
  }
  return { count: total, written: written };
}

async function _applyDownloadedPagesChunk(serverPages) {
  if (!serverPages || serverPages.length === 0) return 0;
  _throwIfSyncAborted(); // P1-7：分块写事务前检查——登出中则抛哨兵终止本轮
  // 批量读 existing：一个 readonly 事务并发 get，避免循环里跨 await 复用写事务导致 TransactionInactiveError
  var keys = serverPages.map(function (d) { return d && d.webUri; });
  var existingList = await db.getByKeys('pages', keys);
  var toPut = [];
  var count = 0;
  var written = []; // 实际写入（new/updated）的条目，供同步报告精确展示（去重 guard 跳过的不计）
  for (var i = 0; i < serverPages.length; i++) {
    var dto = serverPages[i];
    if (!dto || !dto.webUri) continue;
    var existing = existingList[i];
    var serverLocal = serverPageDtoToLocal(dto);
    if (!existing) {
      toPut.push(serverLocal);
      count++;
      written.push({ result: 'new', url: serverLocal.url || '', title: serverLocal.title || '' });
      continue;
    }
    if (existing.SYNC_STATUS === SYNC_STATUS_PENDING ||
        existing.SYNC_STATUS === SYNC_STATUS_LOCAL ||
        existing.SYNC_STATUS === SYNC_STATUS_PENDING_DELETED) {
      continue; // 本地有未推送改动（如本地真标题待推送），保留本地
    }
    // Pull-loop guard: 已应用过此服务端 revision 则跳过（P1-2 Step A：_tsMs 归一化比较）
    if (_syncGuardSkip(dto.syncedAt, existing.SYNCED_AT)) {
      continue;
    }
    // 标题合并独立于时间戳：服务端有真标题 且 本地无待推送真标题(DIRTY_BIT_TITLE) 且 标题不同 → 用服务端。
    // 避免"同秒时间戳导致 _isServerNewer=false、真标题合不进来、本地停留在 URL 派生串"。
    var useServerTitle = !!(serverLocal.title) && !(existing.DIRTY_BITS & DIRTY_BIT_TITLE) &&
                         existing.title !== serverLocal.title;
    var serverNewer = _isServerNewer(dto.updatedAt, existing.SERVER_UPDATE_TIME);
    if (useServerTitle || serverNewer) {
      var merged = Object.assign({}, existing); // 保留本地 summary* 等独有字段
      if (useServerTitle) merged.title = serverLocal.title;
      if (serverNewer) {
        merged.URL_MD5 = serverLocal.URL_MD5 || existing.URL_MD5;
        merged.domain = serverLocal.domain || existing.domain;
        merged.scheme = serverLocal.scheme || existing.scheme;
        merged.FAVICON = serverLocal.FAVICON || existing.FAVICON;
        // P1-4: FAVORITE 改标准 LWW——到达此处必为 SYNCED（上方 1133 已跳过 PENDING/LOCAL/
        // PENDING_DELETED），服务端值即权威（favorite 变更上行时 setFavorite 会置脏位并 bump
        // lastVisited，服务端 LWW 已裁决）。原并集语义导致取消收藏永不下传、双向永久分歧。
        merged.FAVORITE = !!(serverLocal.FAVORITE);
        if (serverLocal.FOLDER_ID !== null && serverLocal.FOLDER_ID !== undefined) merged.FOLDER_ID = serverLocal.FOLDER_ID;
        // customTitle：服务端有值（含空串=null）就覆盖；与 folderId 同语义
        if (serverLocal.CUSTOM_TITLE !== null && serverLocal.CUSTOM_TITLE !== undefined) merged.CUSTOM_TITLE = serverLocal.CUSTOM_TITLE;
        // sortOrder：服务端有值（null=从未手动排序）就覆盖；与 folderId 同语义
        if (serverLocal.SORT_ORDER !== null && serverLocal.SORT_ORDER !== undefined) merged.SORT_ORDER = serverLocal.SORT_ORDER;
        if (serverLocal.annotationCount != null) merged.annotationCount = serverLocal.annotationCount;
        merged.lastVisited = serverLocal.lastVisited || existing.lastVisited;
        merged.createdAt = existing.createdAt || serverLocal.createdAt;
        if (serverLocal.PAGE_NOTE) {
          merged.PAGE_NOTE = serverLocal.PAGE_NOTE;
          merged.PAGE_NOTE_UPDATED_AT = serverLocal.PAGE_NOTE_UPDATED_AT;
        }
      }
      merged.SYNC_STATUS = SYNC_STATUS_SYNCED;
      merged.SYNC_VERSION = serverLocal.SYNC_VERSION;
      merged.SERVER_UPDATE_TIME = serverLocal.SERVER_UPDATE_TIME || existing.SERVER_UPDATE_TIME;
      merged.SYNCED_AT = serverLocal.SYNCED_AT || existing.SYNCED_AT;
      merged.DIRTY_BITS = (existing.DIRTY_BITS || 0) & ~DIRTY_BIT_TITLE; // 已用服务端真标题，清掉本地 TITLE 脏位
      merged.DIRTY_BITS = (merged.DIRTY_BITS || 0) & ~DIRTY_BIT_CUSTOM_TITLE; // 已用服务端 customTitle，清掉本地 CUSTOM_TITLE 脏位
      merged.DIRTY_BITS = (merged.DIRTY_BITS || 0) & ~DIRTY_BIT_SORT_ORDER; // 已用服务端 sortOrder，清掉本地 SORT_ORDER 脏位
      toPut.push(merged);
      count++;
      written.push({ result: 'updated', url: merged.url || '', title: merged.title || '' });
    }
  }
  if (toPut.length > 0) await db.putMany('pages', toPut);
  return { count: count, written: written };
}

async function _applyDownloadedFolders(serverFolders) {
  if (!serverFolders || serverFolders.length === 0) return { count: 0, written: [] };
  var total = 0;
  var written = [];
  for (var i = 0; i < serverFolders.length; i += WPZL_IDB_WRITE_CHUNK) {
    var chunk = serverFolders.slice(i, i + WPZL_IDB_WRITE_CHUNK);
    var r = await _applyDownloadedFoldersChunk(chunk);
    total += r.count;
    if (r.written && r.written.length) written = written.concat(r.written);
  }
  return { count: total, written: written };
}

async function _applyDownloadedFoldersChunk(serverFolders) {
  if (!serverFolders || serverFolders.length === 0) return 0;
  _throwIfSyncAborted(); // P1-7：分块写事务前检查——登出中则抛哨兵终止本轮
  // 批量读 existing：一个 readonly 事务并发 get，避免循环里跨 await 复用写事务导致 TransactionInactiveError
  var keys = serverFolders.map(function (d) { return d && d.folderId; });
  var existingList = await db.getByKeys('folders', keys);
  var toPut = [];
  var count = 0;
  var written = []; // 实际写入（new/updated）的条目，供同步报告精确展示（去重 guard 跳过的不计）
  for (var i = 0; i < serverFolders.length; i++) {
    var dto = serverFolders[i];
    if (!dto || !dto.folderId) continue;
    var existing = existingList[i];
    var serverLocal = serverFolderDtoToLocal(dto);
    if (!existing) {
      toPut.push(serverLocal);
      count++;
      written.push({ result: 'new', id: serverLocal.folderId, name: serverLocal.name || '' });
    } else if (existing.SYNC_STATUS === SYNC_STATUS_PENDING ||
               existing.SYNC_STATUS === SYNC_STATUS_LOCAL ||
               existing.SYNC_STATUS === SYNC_STATUS_PENDING_DELETED) {
      continue;
    } else if (_syncGuardSkip(dto.syncedAt, existing.SYNCED_AT)) {
      continue; // Pull-loop guard
    } else if (_isServerNewer(dto.updatedAt, existing.SERVER_UPDATE_TIME)) {
      var merged = Object.assign({}, existing);
      merged.name = serverLocal.name || existing.name;
      if (serverLocal.parentFolderId !== null && serverLocal.parentFolderId !== undefined) merged.parentFolderId = serverLocal.parentFolderId;
      if (serverLocal.orderSeq != null) merged.orderSeq = serverLocal.orderSeq;
      merged.SYNC_STATUS = SYNC_STATUS_SYNCED;
      merged.SYNC_VERSION = serverLocal.SYNC_VERSION;
      merged.SERVER_UPDATE_TIME = serverLocal.SERVER_UPDATE_TIME;
      merged.SYNCED_AT = serverLocal.SYNCED_AT || existing.SYNCED_AT;
      merged.DIRTY_BITS = 0;
      toPut.push(merged);
      count++;
      written.push({ result: 'updated', id: merged.folderId, name: merged.name || '' });
    }
  }
  if (toPut.length > 0) await db.putMany('folders', toPut);
  return { count: count, written: written };
}

// ---- 应用服务端删除的 page / folder ----

async function _applyDeletedPages(urlMd5s) {
  if (!urlMd5s || urlMd5s.length === 0) return 0;
  var count = 0;
  // 按 urlMd5 索引查（page 主键是 url，urlMd5 是索引）：逐 urlMd5 独立短事务，
  // 双 store 事务（pages + annotations）：删前检查是否有活跃标注，防止"页面已删但有新标注"的隐身 bug。
  for (var i = 0; i < urlMd5s.length; i++) {
    count += await new Promise(function (resolve, reject) {
      var tx = db.db.transaction(['pages', 'annotations'], 'readwrite');
      var pageStore = tx.objectStore('pages');
      var annStore = tx.objectStore('annotations');
      var pageIdx = pageStore.index('urlMd5');
      var deletedCount = 0;
      var gReq = pageIdx.getAll(urlMd5s[i]);
      gReq.onsuccess = function () {
        var matches = gReq.result || [];
        for (var j = 0; j < matches.length; j++) {
          var p = matches[j];
          // 保护本地脏页（PENDING/LOCAL 状态跳过）
          if (p.SYNC_STATUS === SYNC_STATUS_PENDING || p.SYNC_STATUS === SYNC_STATUS_LOCAL) continue;
          // 删前检查：该 page 是否还有"本地未同步的新标注"（SYNCED 标注不算，理由见下）
          try {
            var annIdx = annStore.index('webUri');
            var annReq = annIdx.openCursor(IDBKeyRange.only(p.url));
            var hasActive = false;
            annReq.onsuccess = function (ev) {
              var c = ev.target.result;
              if (!c) {
                // 游标遍历完毕：无活跃标注才删
                if (!hasActive) {
                  pageStore.delete(p.url);
                  deletedCount++;
                } else {
                  // 有活跃标注 → 复活 page 而非删除
                  p.SYNC_STATUS = SYNC_STATUS_SYNCED;
                  p.DIRTY_BITS = 0;
                  pageStore.put(p);
                  try { console.log('[Sync] _applyDeletedPages: skip delete (has active annotations), revive page url=' + p.url); } catch (e) { /* ignore */ }
                }
                return;
              }
              // 仅本地未同步的新标注（LOCAL/PENDING/ERROR）才算需保护的"活跃"：它们服务端尚不知情，
              // 删 page 会让新标注隐身丢失，故复活 page。SYNCED 标注已与服务端一致，服务端删 page 时
              // softDeleteByWebUri 已级联软删（会经 deletedIds 下行删本地），若也算活跃会把刚删的 page
              // 误复活——表现为"对端删除 page 后本机同步仍显示，清空重同步才消失"。故不保护 SYNCED。
              var _annSt = c.value.SYNC_STATUS;
              if (_annSt === SYNC_STATUS_LOCAL || _annSt === SYNC_STATUS_PENDING || _annSt === SYNC_STATUS_ERROR) {
                hasActive = true;
              }
              c.continue();
            };
            annReq.onerror = function () {
              // 索引不可用 → 安全回退：保留 page 不删
              try { console.warn('[Sync] _applyDeletedPages: annotation index error, skip delete url=' + p.url); } catch (e) { /* ignore */ }
            };
          } catch (e) {
            // annotations store 可能不存在（极端情况）→ 回退旧行为
            pageStore.delete(p.url);
            try { console.warn('[Sync] _applyDeletedPages: annotations store not available, fallback delete url=' + p.url); } catch (e2) { /* ignore */ }
          }
        }
      };
      tx.oncomplete = function () { resolve(deletedCount); };
      tx.onerror = function () { reject(tx.error); };
      tx.onabort = function () { reject(tx.error); };
    });
  }
  return count;
}

async function _applyDeletedFolders(folderIds) {
  if (!folderIds || folderIds.length === 0) return 0;
  // 批量读 existing（一个 readonly 事务并发 get），内存判断后批量删
  var existingList = await db.getByKeys('folders', folderIds);
  var toDelete = [];
  for (var i = 0; i < folderIds.length; i++) {
    var existing = existingList[i];
    if (existing && existing.SYNC_STATUS !== SYNC_STATUS_PENDING && existing.SYNC_STATUS !== SYNC_STATUS_LOCAL) {
      toDelete.push(folderIds[i]);
    }
  }
  if (toDelete.length > 0) {
    await db.deleteByKeys('folders', toDelete);
  }
  return toDelete.length;
}

// ---- V69: 页面总量 / 快照每日限额达限提示（30 分钟冷却，mark_limit 同款双键模式） ----
var PAGE_LIMIT_TOAST_KEY = 'wpzl_page_limit_toast_time';
var PAGE_LIMIT_TOAST_COOLDOWN_MS = 30 * 60 * 1000;
var SNAP_LIMIT_TOAST_KEY = 'wpzl_snap_limit_toast_time';
var SNAP_LIMIT_TOAST_COOLDOWN_MS = 30 * 60 * 1000;

async function _maybeShowResourceLimitToast(toastKey, cooldownMs, msgKey, msgKeyNoLimit, limitValue) {
  try {
    var stored = await new Promise(function (r) { chrome.storage.local.get([toastKey], r); });
    if (Date.now() - ((stored && stored[toastKey]) || 0) <= cooldownMs) return;
    await new Promise(function (r) {
      var obj = {};
      obj[toastKey] = Date.now();
      chrome.storage.local.set(obj, r);
    });
    if (typeof _notifyToastToActiveTab === 'function' && typeof chrome.i18n !== 'undefined' && chrome.i18n.getMessage) {
      var msg = (typeof limitValue === 'number' && limitValue >= 0)
        ? chrome.i18n.getMessage(msgKey, [String(limitValue)])
        : chrome.i18n.getMessage(msgKeyNoLimit || msgKey);
      if (msg) _notifyToastToActiveTab(msg, { clickable: true, duration: 4000 });
    }
  } catch (e) { /* ignore */ }
}

function _maybeShowPageLimitToast(limit) {
  return _maybeShowResourceLimitToast(PAGE_LIMIT_TOAST_KEY, PAGE_LIMIT_TOAST_COOLDOWN_MS,
    'pageLimitToast', 'pageLimitToastNoLimit', limit);
}

function _maybeShowSnapLimitToast(limit) {
  return _maybeShowResourceLimitToast(SNAP_LIMIT_TOAST_KEY, SNAP_LIMIT_TOAST_COOLDOWN_MS,
    'snapLimitToast', 'snapLimitToastNoLimit', limit);
}

// ---- 处理 page / folder 上传结果（标 synced / error）----

async function _markPageUploadResult(dirtyPages, rejectedUrlMd5s, rejectedReasons) {
  if (!dirtyPages || dirtyPages.length === 0) return;
  var rejectedSet = new Set(rejectedUrlMd5s || []);
  var reasonsMap = rejectedReasons || {};
  var maxR = await _getSyncMaxRetries();
  var nowIso = new Date().toISOString();
  var _pageLimitHit = false;
  var store = db._tx('pages', 'readwrite');
  for (var i = 0; i < dirtyPages.length; i++) {
    var p = dirtyPages[i];
    if (rejectedSet.has(p.URL_MD5)) {
      var _pReason = reasonsMap[p.URL_MD5];
      p.SYNC_STATUS = SYNC_STATUS_ERROR;
      p.SYNC_RETRY_COUNT = (p.SYNC_RETRY_COUNT || 0) + 1;
      p.SYNC_LAST_ERROR = _pReason || 'rejected by server';
      p.SYNC_LAST_ATTEMPT_AT = nowIso;
      // V69: 云端页面总量达限（page_limit）——当日/调额前重试无意义，立即耗尽
      //（清理页面或调额后由 _maybeResumePageDocSnapLimitExhausted 自动复位重传）。
      if (_pReason === 'page_limit') {
        if (!p.SYNC_EXHAUSTED) {
          p.SYNC_EXHAUSTED = true;
          _broadcastSyncExhausted({ kind: 'page', id: p.URL_MD5, reason: 'page_limit' });
        }
        _pageLimitHit = true;
        _setPdsLimitBlocked('page_limit', true);
      } else if (p.SYNC_RETRY_COUNT >= maxR && !p.SYNC_EXHAUSTED) {
        p.SYNC_EXHAUSTED = true;
        _broadcastSyncExhausted({ kind: 'page', id: p.URL_MD5, retryCount: p.SYNC_RETRY_COUNT }); // P1-14/33
      }
    } else {
      p.SYNC_STATUS = SYNC_STATUS_SYNCED;
      p.DIRTY_BITS = 0;
      p.SYNC_RETRY_COUNT = 0;
      p.SYNC_EXHAUSTED = false;
      p.SERVER_UPDATE_TIME = p.lastVisited || wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
      if (_currentUid && p.USER_ID !== String(_currentUid)) {
        p.USER_ID = String(_currentUid);
      }
      p.SYNCED_AT = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
    }
    store.put(p);
  }
  // V69: 页面总量达限提示（30 分钟冷却）
  if (_pageLimitHit) {
    var _plLimit = null;
    try {
      var _plPro = (typeof wpzl_getProStatus === 'function') ? await wpzl_getProStatus() : null;
      _plLimit = _plPro && _plPro.limits && _plPro.limits.pageLimit;
    } catch (e2) { /* limits 读不到时 toast 走无数字版本 */ }
    _maybeShowPageLimitToast(_plLimit);
  }
}

async function _markFolderUploadResult(dirtyFolders, rejectedIds) {
  if (!dirtyFolders || dirtyFolders.length === 0) return;
  var rejectedSet = new Set(rejectedIds || []);
  var maxR = await _getSyncMaxRetries();
  var nowIso = new Date().toISOString();
  var store = db._tx('folders', 'readwrite');
  for (var i = 0; i < dirtyFolders.length; i++) {
    var f = dirtyFolders[i];
    if (rejectedSet.has(f.folderId)) {
      f.SYNC_STATUS = SYNC_STATUS_ERROR;
      f.SYNC_RETRY_COUNT = (f.SYNC_RETRY_COUNT || 0) + 1;
      f.SYNC_LAST_ERROR = 'rejected by server';
      f.SYNC_LAST_ATTEMPT_AT = nowIso;
      if (f.SYNC_RETRY_COUNT >= maxR && !f.SYNC_EXHAUSTED) {
        f.SYNC_EXHAUSTED = true;
        _broadcastSyncExhausted({ kind: 'folder', id: f.folderId, retryCount: f.SYNC_RETRY_COUNT }); // P1-14/33
      }
    } else {
      f.SYNC_STATUS = SYNC_STATUS_SYNCED;
      f.DIRTY_BITS = 0;
      f.SYNC_RETRY_COUNT = 0;
      f.SYNC_EXHAUSTED = false;
      f.SERVER_UPDATE_TIME = f.updatedAt || wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
      if (_currentUid && f.USER_ID !== String(_currentUid)) {
        f.USER_ID = String(_currentUid);
      }
      f.SYNCED_AT = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
    }
    store.put(f);
  }
}

// 硬删除已确认删除的 page / folder（push 成功后清理 pending_deleted）
async function _hardDeletePagesByUrlMd5(urlMd5s) {
  if (!urlMd5s || urlMd5s.length === 0) return;
  // 按 urlMd5 索引查（page 主键是 url）：逐 urlMd5 独立短事务，
  // getAll 的 onsuccess 回调内同步派发 delete（无条件硬删，事务活跃，不跨 await），等 tx.oncomplete 收敛。
  // 同事务清理 imageData（按 pageKey=urlMd5 索引）— 图片资产无独立 tombstone 路径，
  // 必须在 page 确认删除时一并清掉，否则会留下孤儿 base64 blob 占用配额。
  // 直接用底层 IDBDatabase.transaction 开多 store 事务（db._tx helper 只支持单 store）。
  for (var i = 0; i < urlMd5s.length; i++) {
    await new Promise(function (resolve, reject) {
      var tx = db.db.transaction(['pages', 'imageData'], 'readwrite');
      var store = tx.objectStore('pages');
      var imgStore = tx.objectStore('imageData');
      var idx = store.index('urlMd5');
      var gReq = idx.getAll(urlMd5s[i]);
      gReq.onsuccess = function () {
        var matches = gReq.result || [];
        for (var j = 0; j < matches.length; j++) {
          store.delete(matches[j].url);
          // 同步清理该 page 的所有 imageData（pageKey 索引）
          var pageMd5 = matches[j].URL_MD5 || urlMd5s[i];
          try {
            var imgIdx = imgStore.index('pageKey');
            var imgReq = imgIdx.openCursor(IDBKeyRange.only(pageMd5));
            imgReq.onsuccess = function (ev) {
              var c = ev.target.result;
              if (!c) return;
              c.delete();
              c.continue();
            };
          } catch (e) { /* pageKey 索引可能不存在（老版本） */ }
        }
      };
      tx.oncomplete = function () { resolve(); };
      tx.onerror = function () { reject(tx.error); };
      tx.onabort = function () { reject(tx.error); };
    });
  }
}

async function _hardDeleteFoldersById(folderIds) {
  if (!folderIds || folderIds.length === 0) return;
  var store = db._tx('folders', 'readwrite');
  for (var i = 0; i < folderIds.length; i++) store.delete(folderIds[i]);
}

// ---- document 下载应用 / 删除 / 上传结果 / 硬删（第5类，镜像 folder 模式）----

async function _applyDownloadedDocuments(serverDocuments) {
  if (!serverDocuments || serverDocuments.length === 0) return 0;
  var total = 0;
  for (var i = 0; i < serverDocuments.length; i += WPZL_IDB_WRITE_CHUNK) {
    var chunk = serverDocuments.slice(i, i + WPZL_IDB_WRITE_CHUNK);
    total += await _applyDownloadedDocumentsChunk(chunk);
  }
  return total;
}

async function _applyDownloadedDocumentsChunk(serverDocuments) {
  if (!serverDocuments || serverDocuments.length === 0) return 0;
  _throwIfSyncAborted(); // P1-7：分块写事务前检查——登出中则抛哨兵终止本轮
  var keys = serverDocuments.map(function (d) { return d && d.docId; });
  var existingList = await db.getByKeys('documents', keys);
  var toPut = [];
  var count = 0;
  for (var i = 0; i < serverDocuments.length; i++) {
    var dto = serverDocuments[i];
    if (!dto || !dto.docId) continue;
    var existing = existingList[i];
    var serverLocal = serverDocumentDtoToLocal(dto);
    // P1-8 分仓：服务端 DTO 若带 bodyHtml（防御 legacy 通道），落 docBodies（云读回语义：
    // 不标 bodyDirty——body 与服务端一致）；记录本身不再承载该字段。
    if (dto.bodyHtml) {
      try { await db.saveDocBody(dto.docId, dto.bodyHtml); } catch (e) { /* ignore */ }
    }
    if (!existing) {
      toPut.push(serverLocal);
      count++;
    } else if (existing.SYNC_STATUS === SYNC_STATUS_PENDING ||
               existing.SYNC_STATUS === SYNC_STATUS_LOCAL ||
               existing.SYNC_STATUS === SYNC_STATUS_PENDING_DELETED) {
      continue;
    } else if (_syncGuardSkip(dto.syncedAt, existing.SYNCED_AT)) {
      continue; // Pull-loop guard
    } else if (_isServerNewer(dto.updatedAt, existing.SERVER_UPDATE_TIME)) {
      var merged = Object.assign({}, existing);
      merged.webUri = serverLocal.webUri || existing.webUri;
      merged.domain = serverLocal.domain || existing.domain;
      merged.urlMd5 = serverLocal.urlMd5 || existing.urlMd5;
      merged.title = serverLocal.title != null ? serverLocal.title : existing.title;
      // body 在 R2（服务端同步永不下发 bodyHtml）：本地 body（docBodies）仅本地工作副本，
      // 下载一律保留既有、不覆盖。body 位置由 bodyObjectKey 指示（文档 key 稳定 u/{uid}/doc/{docId}.html）。
      // 跨设备 body 变更检测：服务端 bodyContentHash 与本地不同 → 另一设备编辑覆盖过 → 本地 body 失效，
      // 删 docBodies 条目 + 清 bodyDirty，触发编辑器/后台下载器走 REST 回拉新 body
      //（覆盖策略下 key 不变，必须用 hash 判定）。
      if (serverLocal.bodyObjectKey) {
        var prevDocHash = existing.bodyContentHash || null;
        merged.bodyObjectKey = serverLocal.bodyObjectKey;
        merged.bodyContentHash = serverLocal.bodyContentHash || prevDocHash;
        if (prevDocHash && serverLocal.bodyContentHash && prevDocHash !== serverLocal.bodyContentHash) {
          try { await db.deleteBodies('docBodies', [dto.docId]); } catch (e) { /* ignore */ }
          merged.bodyDirty = false;
        }
      }
      // tags：服务端权威（空串 = 清空标签）
      merged.tags = serverLocal.tags != null ? serverLocal.tags : (existing.tags || '');
      if (serverLocal.folderId !== undefined) merged.folderId = serverLocal.folderId;
      if (serverLocal.pageWidth) merged.pageWidth = serverLocal.pageWidth;
      if (serverLocal.isReadOnly != null) merged.isReadOnly = !!serverLocal.isReadOnly;
      if (serverLocal.sortOrder !== undefined) merged.sortOrder = serverLocal.sortOrder; // 目录树手动排序号（null=未排序）
      merged.SYNC_STATUS = SYNC_STATUS_SYNCED;
      merged.SYNC_VERSION = serverLocal.SYNC_VERSION;
      merged.SERVER_UPDATE_TIME = serverLocal.SERVER_UPDATE_TIME;
      merged.SYNCED_AT = serverLocal.SYNCED_AT || existing.SYNCED_AT;
      merged.DIRTY_BITS = 0;
      toPut.push(merged);
      count++;
    }
  }
  if (toPut.length > 0) await db.putMany('documents', toPut);
  // D3：合并落库的文档里 body 仍在 R2（bodyObjectKey 非空且本地 docBodies 无 body）→ 入后台下载清单。
  // P1-7：精确入队（新文档 + 跨设备 hash 不匹配被清 body 者），collector 不再全表扫。
  // P1-8：本地有无 body 的判定 = docBodies 键集（在 hash 失配删除之后取，保证刚失效者被入队）。
  // 镜像 _applyDownloadedImageAssetsChunk 的 image 触发（那边天然带 records）。
  var _dlDocIds = [];
  try {
    var _bodyKeySet = await db.getDocBodyKeySet();
    for (var pi = 0; pi < toPut.length; pi++) {
      var _pd = toPut[pi];
      if (_pd && _pd.bodyObjectKey && !_bodyKeySet.has(_pd.docId)) _dlDocIds.push(_pd.docId);
    }
  } catch (e) { /* 键集读失败跳过本轮入队：alarm/下轮 sync 重试 */ }
  if (_dlDocIds.length > 0 && typeof _enqueueDocSyncDownloads === 'function') {
    try { _enqueueDocSyncDownloads(_dlDocIds); } catch (e) { /* ignore */ }
  }
  return count;
}

async function _applyDeletedDocuments(docIds) {
  if (!docIds || docIds.length === 0) return 0;
  var existingList = await db.getByKeys('documents', docIds);
  var toDelete = [];
  for (var i = 0; i < docIds.length; i++) {
    var existing = existingList[i];
    if (existing && existing.SYNC_STATUS !== SYNC_STATUS_PENDING && existing.SYNC_STATUS !== SYNC_STATUS_LOCAL) {
      toDelete.push(docIds[i]);
    }
  }
  if (toDelete.length > 0) {
    await db.deleteByKeys('documents', toDelete);
    // P1-8：已删文档的本地 body 同删（分仓 store；服务端副本由删除推送清理）
    try { await db.deleteBodies('docBodies', toDelete); } catch (e) { /* ignore */ }
    // P1-7：已删文档出下载清单（防 ghost 项让分类/门禁虚高、重下已删对象）
    if (typeof _removeDocDlPendingByIds === 'function') {
      try { _removeDocDlPendingByIds(toDelete); } catch (e) { /* ignore */ }
    }
  }
  return toDelete.length;
}

async function _markDocumentUploadResult(dirtyDocs, rejectedReasons) {
  if (!dirtyDocs || dirtyDocs.length === 0) return;
  var reasons = rejectedReasons || {};
  var maxR = await _getSyncMaxRetries();
  var nowIso = new Date().toISOString();
  // cloud_quota 拒绝：置阻断标志 + 节流提示（供释放探测自动恢复，见 _maybeResumeQuotaExhausted）
  var _quotaHit = false;
  var _docLimitHit = false;
  var _importHitD = false;
  for (var qk in reasons) {
    if (_isQuotaRejectionReason(reasons[qk])) { _quotaHit = true; }
    if (reasons[qk] === 'doc_limit') { _docLimitHit = true; }
    if (reasons[qk] === 'import_limit') { _importHitD = true; }
  }
  if (_quotaHit) {
    _setQuotaBlocked(true);
    _maybeShowQuotaToast();
  }
  if (_docLimitHit) {
    _setPdsLimitBlocked('doc_limit', true);
    // doc_limit 不加专用 toast：创建入口已有拦截提示，此处靠失败查看器展示原因（spec §2 非目标）
  }
  if (_importHitD) {
    _setImportLimitBlocked(true);   // V70: 释放探测触发标志（不重复 toast——标注路径已提示）
  }
  var store = db._tx('documents', 'readwrite');
  for (var i = 0; i < dirtyDocs.length; i++) {
    var d = dirtyDocs[i];
    var reason = reasons[d.docId];
    if (reason !== undefined) {
      d.SYNC_STATUS = SYNC_STATUS_ERROR;
      d.SYNC_LAST_ERROR = reason || 'rejected';
      d.SYNC_LAST_ATTEMPT_AT = nowIso;
      if (_isPermanentRejectionReason(reason)) {
        // 永久失败（body 过大/冲突）：立即停止自动重发，等用户编辑后手动重试
        if (!d.SYNC_EXHAUSTED) {
          d.SYNC_EXHAUSTED = true;
          _broadcastSyncExhausted({ kind: 'document', id: d.docId, reason: reason }); // P1-14
        }
      } else if (reason === 'doc_limit') {
        // 每日文档数达限：立即耗尽（原走瞬时分支会烧满 maxRetries 次×整篇 body 重推）；
        // 跨天/调额后由 _maybeResumePageDocSnapLimitExhausted 自动复位重传
        if (!d.SYNC_EXHAUSTED) {
          d.SYNC_EXHAUSTED = true;
          _broadcastSyncExhausted({ kind: 'document', id: d.docId, reason: reason });
        }
      } else if (reason === 'import_limit') {
        // V70: 每日导入额度达限：立即耗尽；跨天/调额后由 _maybeResumeImportLimitExhausted 复位
        if (!d.SYNC_EXHAUSTED) {
          d.SYNC_EXHAUSTED = true;
          _broadcastSyncExhausted({ kind: 'document', id: d.docId, reason: reason });
        }
      } else if (_isQuotaRejectionReason(reason)) {
        // 云端存储配额满：与图片路径同款语义——立即耗尽（不烧 maxRetries 次全量 body 重推，
        // 纯浪费带宽且期间无提示），配额释放后由 _maybeResumeQuotaExhausted 自动复位重传
        if (!d.SYNC_EXHAUSTED) {
          d.SYNC_EXHAUSTED = true;
          _broadcastSyncExhausted({ kind: 'document', id: d.docId, reason: reason }); // P1-14
        }
      } else {
        // 瞬时失败（存储/网络）：累计重试，到 maxRetries 才 EXHAUSTED
        d.SYNC_RETRY_COUNT = (d.SYNC_RETRY_COUNT || 0) + 1;
        if (d.SYNC_RETRY_COUNT >= maxR && !d.SYNC_EXHAUSTED) {
          d.SYNC_EXHAUSTED = true;
          _broadcastSyncExhausted({ kind: 'document', id: d.docId, retryCount: d.SYNC_RETRY_COUNT }); // P1-14
        }
      }
    } else {
      d.SYNC_STATUS = SYNC_STATUS_SYNCED;
      d.DIRTY_BITS = 0;
      d.SYNC_RETRY_COUNT = 0;
      d.SYNC_EXHAUSTED = false;
      d.SYNC_LAST_ERROR = null;
      d.SERVER_UPDATE_TIME = d.updatedAt || wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
      if (_currentUid && d.USER_ID !== String(_currentUid)) {
        d.USER_ID = String(_currentUid);
      }
      d.SYNCED_AT = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
      // body 已上云（成功上传）→ 清 bodyDirty，下次同步不重传（除非再次编辑置 dirty）。
      // bodyObjectKey/bodyContentHash 经随后的下载合并从服务端回填（覆盖策略下 key 稳定）。
      d.bodyDirty = false;
    }
    store.put(d);
  }
}

async function _hardDeleteDocumentsById(docIds) {
  if (!docIds || docIds.length === 0) return;
  var store = db._tx('documents', 'readwrite');
  for (var i = 0; i < docIds.length; i++) store.delete(docIds[i]);
}

// ---- snapshot 下载应用 / 删除 / 上传结果 / 硬删（第6类，镜像 document 模式）----

async function _applyDownloadedSnapshots(serverSnapshots) {
  if (!serverSnapshots || serverSnapshots.length === 0) return 0;
  var total = 0;
  for (var i = 0; i < serverSnapshots.length; i += WPZL_IDB_WRITE_CHUNK) {
    var chunk = serverSnapshots.slice(i, i + WPZL_IDB_WRITE_CHUNK);
    total += await _applyDownloadedSnapshotsChunk(chunk);
  }
  return total;
}

async function _applyDownloadedSnapshotsChunk(serverSnapshots) {
  if (!serverSnapshots || serverSnapshots.length === 0) return 0;
  _throwIfSyncAborted(); // P1-7：分块写事务前检查——登出中则抛哨兵终止本轮
  var keys = serverSnapshots.map(function (s) { return s && s.snapId; });
  var existingList = await db.getByKeys('snapshots', keys);
  var toPut = [];
  var count = 0;
  for (var i = 0; i < serverSnapshots.length; i++) {
    var dto = serverSnapshots[i];
    if (!dto || !dto.snapId) continue;
    // 解压服务端返回的 bodyHtml（若是 "GZ:" 前缀压缩数据）
    if (dto.bodyHtml) dto.bodyHtml = await _decompressBodyHtml(dto.bodyHtml);
    var existing = existingList[i];
    var serverLocal = serverSnapshotDtoToLocal(dto);
    // P1-8 分仓：服务端 DTO 若带 bodyHtml（防御 legacy 通道）→ 落 snapBodies；记录不再承载。
    if (dto.bodyHtml) {
      try { await db.saveSnapBody(dto.snapId, dto.bodyHtml); } catch (e) { /* ignore */ }
    }
    if (!existing) {
      toPut.push(serverLocal);
      count++;
    } else if (existing.SYNC_STATUS === SYNC_STATUS_PENDING ||
               existing.SYNC_STATUS === SYNC_STATUS_LOCAL ||
               existing.SYNC_STATUS === SYNC_STATUS_PENDING_DELETED) {
      continue;
    } else if (_syncGuardSkip(dto.syncedAt, existing.SYNCED_AT)) {
      continue; // Pull-loop guard
    } else if (_isServerNewer(dto.updatedAt, existing.SERVER_UPDATE_TIME)) {
      var merged = Object.assign({}, existing);
      merged.webUri = serverLocal.webUri || existing.webUri;
      merged.domain = serverLocal.domain || existing.domain;
      merged.urlMd5 = serverLocal.urlMd5 || existing.urlMd5;
      merged.title = serverLocal.title != null ? serverLocal.title : existing.title;
      // 服务端同步永不下发 bodyHtml（body 在 R2，查看走服务端渲染 /snap/{snapId}）：
      // 本地 bodyHtml 仅采集时写入，下载一律保留既有、不覆盖；body 位置由 bodyObjectKey 指示。
      if (serverLocal.bodyObjectKey) {
        merged.bodyObjectKey = serverLocal.bodyObjectKey;
        merged.bodyContentHash = serverLocal.bodyContentHash || existing.bodyContentHash || null;
      }
      merged.sourceWebUri = serverLocal.sourceWebUri || existing.sourceWebUri;
      merged.sourceUrlMd5 = serverLocal.sourceUrlMd5 || existing.sourceUrlMd5;
      if (serverLocal.folderId !== undefined) merged.folderId = serverLocal.folderId;
      // snapType 跨设备真值：优先服务端（V45 同步字段），回退本地既有（采集时写入），再回退 'full'。
      merged.snapType = serverLocal.snapType || existing.snapType || 'full';
      if (serverLocal.sortOrder !== undefined) merged.sortOrder = serverLocal.sortOrder; // 目录树手动排序号（null=未排序）
      merged.SYNC_STATUS = SYNC_STATUS_SYNCED;
      merged.SYNC_VERSION = serverLocal.SYNC_VERSION;
      merged.SERVER_UPDATE_TIME = serverLocal.SERVER_UPDATE_TIME;
      merged.SYNCED_AT = serverLocal.SYNCED_AT || existing.SYNCED_AT;
      merged.DIRTY_BITS = 0;
      toPut.push(merged);
      count++;
    }
  }
  if (toPut.length > 0) await db.putMany('snapshots', toPut);
  return count;
}

async function _applyDeletedSnapshots(snapIds) {
  if (!snapIds || snapIds.length === 0) return 0;
  var existingList = await db.getByKeys('snapshots', snapIds);
  var toDelete = [];
  for (var i = 0; i < snapIds.length; i++) {
    var existing = existingList[i];
    if (existing && existing.SYNC_STATUS !== SYNC_STATUS_PENDING && existing.SYNC_STATUS !== SYNC_STATUS_LOCAL) {
      toDelete.push(snapIds[i]);
    }
  }
  if (toDelete.length > 0) {
    await db.deleteByKeys('snapshots', toDelete);
    // P1-8：已删快照的本地 body 同删
    try { await db.deleteBodies('snapBodies', toDelete); } catch (e) { /* ignore */ }
  }
  return toDelete.length;
}

async function _markSnapshotUploadResult(dirtySnaps, rejectedReasons) {
  if (!dirtySnaps || dirtySnaps.length === 0) return;
  var reasons = rejectedReasons || {};
  var maxR = await _getSyncMaxRetries();
  var nowIso = new Date().toISOString();
  // cloud_quota 拒绝：置阻断标志 + 节流提示（同 _markDocumentUploadResult）
  var _quotaHitS = false;
  var _snapLimitHitS = false;
  var _importHitS = false;
  for (var qsk in reasons) {
    if (_isQuotaRejectionReason(reasons[qsk])) { _quotaHitS = true; }
    if (reasons[qsk] === 'snap_limit') { _snapLimitHitS = true; }
    if (reasons[qsk] === 'import_limit') { _importHitS = true; }
  }
  if (_quotaHitS) {
    _setQuotaBlocked(true);
    _maybeShowQuotaToast();
  }
  // V69: 每日快照数达限提示（30 分钟冷却）
  if (_snapLimitHitS) {
    var _slLimit = null;
    try {
      var _slPro = (typeof wpzl_getProStatus === 'function') ? await wpzl_getProStatus() : null;
      _slLimit = _slPro && _slPro.limits && _slPro.limits.snapLimit;
    } catch (e2) { /* limits 读不到时 toast 走无数字版本 */ }
    _maybeShowSnapLimitToast(_slLimit);
    _setPdsLimitBlocked('snap_limit', true);
  }
  if (_importHitS) {
    _setImportLimitBlocked(true);   // V70: 同 _markDocumentUploadResult（不重复 toast）
  }
  var store = db._tx('snapshots', 'readwrite');
  for (var i = 0; i < dirtySnaps.length; i++) {
    var s = dirtySnaps[i];
    var reason = reasons[s.snapId];
    if (reason !== undefined) {
      s.SYNC_STATUS = SYNC_STATUS_ERROR;
      s.SYNC_LAST_ERROR = reason || 'rejected';
      s.SYNC_LAST_ATTEMPT_AT = nowIso;
      if (_isPermanentRejectionReason(reason)) {
        if (!s.SYNC_EXHAUSTED) {
          s.SYNC_EXHAUSTED = true;   // 永久失败（快照过大/冲突）：立即停止自动重发
          _broadcastSyncExhausted({ kind: 'snapshot', id: s.snapId, reason: reason }); // P1-14
        }
      } else if (reason === 'snap_limit') {
        // 每日快照数达限：立即耗尽（原 PERMANENT 成员，移出后走本分支获得探测自动恢复）
        if (!s.SYNC_EXHAUSTED) {
          s.SYNC_EXHAUSTED = true;
          _broadcastSyncExhausted({ kind: 'snapshot', id: s.snapId, reason: reason });
        }
      } else if (reason === 'import_limit') {
        // V70: 每日导入额度达限：立即耗尽；跨天/调额后由 _maybeResumeImportLimitExhausted 复位
        if (!s.SYNC_EXHAUSTED) {
          s.SYNC_EXHAUSTED = true;
          _broadcastSyncExhausted({ kind: 'snapshot', id: s.snapId, reason: reason });
        }
      } else if (_isQuotaRejectionReason(reason)) {
        // 云端存储配额满：立即耗尽（不烧 maxRetries 次全量 body 重推），释放后自动复位
        if (!s.SYNC_EXHAUSTED) {
          s.SYNC_EXHAUSTED = true;
          _broadcastSyncExhausted({ kind: 'snapshot', id: s.snapId, reason: reason }); // P1-14
        }
      } else {
        s.SYNC_RETRY_COUNT = (s.SYNC_RETRY_COUNT || 0) + 1;
        if (s.SYNC_RETRY_COUNT >= maxR && !s.SYNC_EXHAUSTED) {
          s.SYNC_EXHAUSTED = true;
          _broadcastSyncExhausted({ kind: 'snapshot', id: s.snapId, retryCount: s.SYNC_RETRY_COUNT }); // P1-14
        }
      }
    } else {
      s.SYNC_STATUS = SYNC_STATUS_SYNCED;
      s.DIRTY_BITS = 0;
      s.SYNC_RETRY_COUNT = 0;
      s.SYNC_EXHAUSTED = false;
      s.SYNC_LAST_ERROR = null;
      s.SERVER_UPDATE_TIME = s.updatedAt || wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
      if (_currentUid && s.USER_ID !== String(_currentUid)) {
        s.USER_ID = String(_currentUid);
      }
      s.SYNCED_AT = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
    }
    store.put(s);
  }
}

async function _hardDeleteSnapshotsById(snapIds) {
  if (!snapIds || snapIds.length === 0) return;
  var store = db._tx('snapshots', 'readwrite');
  for (var i = 0; i < snapIds.length; i++) store.delete(snapIds[i]);
}

// ---- imageAsset 上传结果处理 + tombstone 硬删 ----
async function _markImageAssetUploadResult(dirtyImageAssets, rejectedKeys) {
  if (!dirtyImageAssets || dirtyImageAssets.length === 0) return;
  var rejectedSet = new Set(rejectedKeys || []);
  var maxR = await _getSyncMaxRetries();
  var store = db._tx('imageData', 'readwrite');
  var settledIds = [];
  for (var i = 0; i < dirtyImageAssets.length; i++) {
    var rec = dirtyImageAssets[i];
    var bizKey = imageAssetBizKey(rec);
    var isRejected = rejectedSet.has(bizKey);
    // P1-19: 同事务先读 fresh 再合并——push 在飞期间 ISD 下载回填的 data 等并发写
    // 不被本侧快照整记录 put 抹掉。IDB 请求在同一事务内排队是安全的（仍是循环内
    // 不 await 别的 store）。
    (function (rec, isRejected) {
      var getReq = store.get(rec.id);
      getReq.onsuccess = function () {
        var fresh = getReq.result || rec;
        if (isRejected) {
          // P1-12：元数据被拒计数对齐标注侧体系（大写字段，与 R2 上传侧小写 retryCount 并行）——
          // 此前仅置 ERROR 无计数，_collectDirtyImageData 每轮重新采集 → 无限重推。
          fresh.SYNC_STATUS = SYNC_STATUS_ERROR;
          fresh.SYNC_RETRY_COUNT = (fresh.SYNC_RETRY_COUNT || 0) + 1;
          fresh.SYNC_LAST_ERROR = 'rejected by server';
          fresh.SYNC_LAST_ATTEMPT_AT = new Date().toISOString();
          if (fresh.SYNC_RETRY_COUNT >= maxR && !fresh.SYNC_EXHAUSTED) {
            fresh.SYNC_EXHAUSTED = true;
            _broadcastSyncExhausted({ kind: 'imageAsset', id: bizKey, retryCount: fresh.SYNC_RETRY_COUNT });
          }
        } else {
          fresh.SYNC_STATUS = SYNC_STATUS_SYNCED;
          fresh.DIRTY_BITS = 0;
          // P1-12：成功复位计数与耗尽标记（与标注侧成功分支对齐）
          fresh.SYNC_RETRY_COUNT = 0;
          fresh.SYNC_EXHAUSTED = false;
          fresh.SERVER_UPDATE_TIME = rec.timestamp || new Date().toISOString();
          fresh.SYNCED_AT = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
        }
        store.put(fresh);
      };
      getReq.onerror = function () { store.put(rec); };
    })(rec, isRejected);
    settledIds.push(rec.id);   // P1-18b：put 循环内不能 await（事务失活），循环后统一清清单
  }
  for (var c = 0; c < settledIds.length; c++) {
    try { await _clearImageMetaDirty(settledIds[c]); } catch (e) { /* ignore */ }
  }
}

// 按 bizKey 硬删 imageData（push 删除被服务端确认后清理本地）
async function _hardDeleteImageAssetsByBizKey(bizKeys) {
  if (!bizKeys || bizKeys.length === 0) return;
  var store = db._tx('imageData', 'readwrite');
  for (var i = 0; i < bizKeys.length; i++) store.delete(bizKeys[i]);
}

// ---- Pro Gating ----

// 属主一致性校验（owner-auth consistency，spec 改动 B）：wpzl_local_data_owner 与当前登录账号
// 不一致时拒绝同步，防止分裂态下以新账号身份推/拉旧账号数据（跨用户污染）。
// owner 为 null（首登前/刚清空）不拦——走 _finalizeAuth 既有认领逻辑；未登录不拦——
// 调用方后续的 isLoggedIn 检查已处理。storage 读异常 fail-open（比属主分裂更基础的环境故障，
// 不因它锁死正常同步）。
// 定义在 sync-engine（而非 service-worker）一处，SW 的 db-operation handler 经共享作用域直接调用。
async function _isOwnerAuthMismatch() {
  try {
    var stored = await new Promise(function (resolve) {
      chrome.storage.local.get(['wpzl_local_data_owner', 'wpzl_auth'], function (r) { resolve(r); });
    });
    var owner = stored.wpzl_local_data_owner;
    var auth = stored.wpzl_auth;
    if (!owner || !auth || !auth.user) return false;
    return String(owner.userId) !== String(auth.user.id);
  } catch (e) { return false; }
}

async function isSyncAllowed() {
  if (!_syncEnabled) return false;
  // 属主分裂态拒止（spec 改动 B）：静默 return false + warn。不置 sync 状态——
  // 状态机无 'error' 态，且 connectivity-tick 每轮先无条件置 online 会造成双广播抖动、
  // pullForUrlIfNeeded 每次页面导航先过本 gate 会刷屏。用户沟通由 manager 阻断对话框承担。
  if (await _isOwnerAuthMismatch()) {
    console.warn('[Sync] blocked: local data owner ≠ current login, sync disabled until resolved');
    return false;
  }
  try {
    var auth = await wpzl_getAuthStatus();
    if (!auth.isLoggedIn) return false;
    var pro = await wpzl_getProStatus();
    var features = (pro.gradeConfig || {}).features || {};
    return features.cloudSync === true;
  } catch (e) {
    return false;
  }
}

async function isImageCloudUploadAllowed() {
  if (!_syncEnabled) return false;
  if (await _isOwnerAuthMismatch()) {
    console.warn('[Sync] blocked: local data owner ≠ current login, sync disabled until resolved');
    return false;
  }
  try {
    var auth = await wpzl_getAuthStatus();
    if (!auth.isLoggedIn) return false;
    var pro = await wpzl_getProStatus();
    var features = (pro.gradeConfig || {}).features || {};
    return features.imageCloudUpload === true;
  } catch (e) {
    return false;
  }
}
self.wpzl_isImageCloudUploadAllowed = isImageCloudUploadAllowed;

// 读取 effective 同步权限（auth + pro.gradeConfig.features），不做 _syncEnabled 短路。
// onLogin 用它判定"登录后是否真正具备同步权限"——避免新注册 / 无 cloudSync 用户一登录就被触发 sync，
// 造成"也能同步"的错觉。与 isSyncAllowed/isImageCloudUploadAllowed 的 features 读取同源，
// 但去掉了 !_syncEnabled 早退（否则 onLogin 永远拿到 false，先有鸡先有蛋）。
// wpzl_getProStatus fail-closed：缓存空 / 脱机时返回 free（cloudSync≠true），故不会误开同步。
async function _readEffectiveSyncPermissions() {
  var auth = await wpzl_getAuthStatus();
  if (!auth || !auth.isLoggedIn) return { cloudSync: false, imageCloudUpload: false };
  var pro = await wpzl_getProStatus();
  var gc = (pro && pro.gradeConfig) || {};
  var features = gc.features || {};
  return {
    cloudSync: features.cloudSync === true,
    imageCloudUpload: features.imageCloudUpload === true
  };
}

// ---- Sync Max Retries（服务端 sys_sync_max_retries 配置，登录下发）----

// 读 wpzl_sync_max_retries（chrome.storage.local），非正数/缺失回退 SYNC_MAX_RETRIES。
async function _getSyncMaxRetries() {
  try {
    var v = await new Promise(function (resolve) {
      chrome.storage.local.get(['wpzl_sync_max_retries'], function (res) {
        resolve(res && res.wpzl_sync_max_retries);
      });
    });
    return (typeof v === 'number' && v > 0) ? v : SYNC_MAX_RETRIES;
  } catch (e) {
    return SYNC_MAX_RETRIES;
  }
}

// 耗尽复位：清 SYNC_EXHAUSTED/retryCount，恢复自动重试（onLogin 与手动重传统一调用）。
// 经既有 syncStatus 索引（pending/local/error/pending_deleted）定位脏记录后内存过滤
// （exhausted 记录的 SYNC_STATUS 必在这些状态内——exhausted 不改 SYNC_STATUS）。
// opts.imagesOnly：仅复位 imageData（无 cloudSync 但有 imageCloudUpload 的等级）。
async function _resetExhaustedState(opts) {
  var imagesOnly = !!(opts && opts.imagesOnly);
  // reasonFilter(reason)→bool：仅复位失败原因命中的记录（配额释放探测用——只恢复配额耗尽项，
  // 不动网络重试耗尽/永久失败项）。设置时下载侧/缩略图侧/offline_queue 复位一并跳过（与配额无关）。
  var reasonFilter = (opts && typeof opts.reasonFilter === 'function') ? opts.reasonFilter : null;
  var dirtyStatuses = [SYNC_STATUS_PENDING, SYNC_STATUS_LOCAL, SYNC_STATUS_ERROR, SYNC_STATUS_PENDING_DELETED];
  var total = 0;

  async function resetStore(storeName, isImage) {
    var idx = db._tx(storeName, 'readonly').index('syncStatus');
    var results = await Promise.all(dirtyStatuses.map(function (s) {
      return _getAllFromIndex(idx, s);
    }));
    var candidates = [];
    for (var r = 0; r < results.length; r++) {
      var arr = results[r];
      for (var i = 0; i < arr.length; i++) {
        var rec = arr[i];
        if (isImage) {
          // P1-12：一并复位元数据路径的大写计数（与 R2 上传侧小写字段并行存在的两套体系）
          if (rec.exhausted || (rec.retryCount || 0) > 0 ||
              rec.SYNC_EXHAUSTED || (rec.SYNC_RETRY_COUNT || 0) > 0) {
            if (reasonFilter && !reasonFilter(rec.lastError || rec.SYNC_LAST_ERROR)) continue;
            rec.exhausted = false;
            rec.retryCount = 0;
            rec.SYNC_EXHAUSTED = false;
            rec.SYNC_RETRY_COUNT = 0;
            candidates.push(rec);
          }
        } else {
          // 永久失败（文档/快照 body 过大/冲突）不自动复位——re-login 不应让其在每轮重发；
          // 用户编辑后可手动重试。标注/页面/文件夹的 SYNC_LAST_ERROR 不含永久原因，照常复位。
          if ((rec.SYNC_EXHAUSTED || (rec.SYNC_RETRY_COUNT || 0) > 0)
              && !_isPermanentRejectionReason(rec.SYNC_LAST_ERROR)) {
            if (reasonFilter && !reasonFilter(rec.SYNC_LAST_ERROR)) continue;
            rec.SYNC_EXHAUSTED = false;
            rec.SYNC_RETRY_COUNT = 0;
            candidates.push(rec);
          }
        }
      }
    }
    for (var j = 0; j < candidates.length; j += WPZL_IDB_WRITE_CHUNK) {
      await db.putMany(storeName, candidates.slice(j, j + WPZL_IDB_WRITE_CHUNK));
    }
    return candidates.length;
  }

  try {
    if (!imagesOnly) {
      total += await resetStore('annotations', false);
      total += await resetStore('pages', false);
      total += await resetStore('folders', false);
      total += await resetStore('documents', false);
      total += await resetStore('snapshots', false);
      // P1-15/P1-24: 下载侧/缩略图侧重试计数复位。exhausted 记录的 SYNC_STATUS 是 'synced'
      // （上传本体已同步成功），不在上面 dirtyStatuses 索引扫描可见范围——必须独立扫描。
      // 配额释放探测（reasonFilter）只关心上传配额耗尽项，这两类与配额无关，跳过。
      if (!reasonFilter) {
        total += await _resetDocDownloadExhausted();
        total += await _resetThumbExhausted();
      }
    }
    total += await resetStore('imageData', true);

    // offline_queue 条目复位（mark FIFO 队列；imagesOnly 时跳过——图片不走 offline_queue）。
    // 队列条目的 lastError 不区分上传配额，reasonFilter 场景无法安全筛选，整段跳过。
    if (!imagesOnly && !reasonFilter) {
      var queue = await _syncGetMeta('offline_queue') || [];
      var qChanged = false;
      for (var q = 0; q < queue.length; q++) {
        if (queue[q] && (queue[q].exhausted || (queue[q].retryCount || 0) > 0)) {
          queue[q].exhausted = false;
          queue[q].retryCount = 0;
          qChanged = true;
        }
      }
      if (qChanged) {
        await _syncSetMeta('offline_queue', queue);
        total += queue.length;
      }
    }
  } catch (e) {
    console.warn('[Sync] _resetExhaustedState error:', e && e.message);
  }
  if (total > 0) console.log('[Sync] reset exhausted/retryCount, count=' + total);
  return total;
}

// P1-15: 复位文档 body 下载侧重试计数（dlRetryCount/dlExhausted/dlLastError）。
// documents 数量小，全表扫可接受；复位后重arm doc-sync alarm（可能已被全员耗尽时 clear）。
async function _resetDocDownloadExhausted() {
  var fixed = 0;
  try {
    var store = db._tx('documents', 'readonly');
    var all = await new Promise(function (resolve, reject) {
      var req = store.getAll();
      req.onsuccess = function () { resolve(req.result || []); };
      req.onerror = function () { reject(req.error); };
    });
    var candidates = [];
    for (var i = 0; i < all.length; i++) {
      var d = all[i];
      if (d && ((d.dlRetryCount || 0) > 0 || d.dlExhausted || d.dlLastError)) {
        d.dlRetryCount = 0;
        d.dlExhausted = false;
        d.dlLastError = null;
        candidates.push(d);
      }
    }
    for (var j = 0; j < candidates.length; j += WPZL_IDB_WRITE_CHUNK) {
      await db.putMany('documents', candidates.slice(j, j + WPZL_IDB_WRITE_CHUNK));
    }
    fixed = candidates.length;
    if (fixed > 0 && typeof _ensureDocSyncAlarm === 'function') {
      _ensureDocSyncAlarm();
    }
    // P1-7：耗尽项在标记时已出清单——复位后 body 仍缺者重新入队（否则要等 24h 自愈扫），并即跑首批。
    // P1-8：body 缺失判定 = docBodies 键集（记录不再内联 bodyHtml）。
    if (fixed > 0 && typeof _noteDocDlPending === 'function') {
      var reIds = [];
      var _resetBodyKeys = null;
      try { _resetBodyKeys = await db.getDocBodyKeySet(); } catch (e) { /* ignore */ }
      if (_resetBodyKeys) {
        for (var k = 0; k < candidates.length; k++) {
          var c = candidates[k];
          if (c && c.bodyObjectKey && !_resetBodyKeys.has(c.docId)) reIds.push(c.docId);
        }
      }
      if (reIds.length > 0) {
        try { _noteDocDlPending(reIds); } catch (e) { /* ignore */ }
        if (typeof _scheduleNextDocBatch === 'function') { try { _scheduleNextDocBatch(); } catch (e) { /* ignore */ } }
      }
    }
  } catch (e) { /* ignore */ }
  return fixed;
}

// P1-24: 复位缩略图上传侧重试计数（THUMB_RETRY_COUNT/THUMB_EXHAUSTED/THUMB_LAST_ERROR）。
// 从有界 thumb_pending_ids（≤50）读取，不清 THUMBNAIL_PENDING——耗尽记录保持 PENDING=true，
// 复位后下一轮 flush 自然重新进批。
async function _resetThumbExhausted() {
  var fixed = 0;
  try {
    var ids = await _getThumbPendingIds();
    if (!ids || ids.length === 0) return 0;
    var recs = await db.getByKeys('annotations', ids);
    var candidates = [];
    for (var i = 0; i < recs.length; i++) {
      var r = recs[i];
      // 终态（本地字节缺失）不复位：复位也传不上去，只会造成每轮 9 次空转 + 反复同步耗尽弹窗。
      // 该类记录已不在工作清单里（PENDING 已清），正常扫不到；此判据是防漂移的兜底。
      if (r && !r.THUMB_LOCAL_MISSING &&
          ((r.THUMB_RETRY_COUNT || 0) > 0 || r.THUMB_EXHAUSTED || r.THUMB_LAST_ERROR)) {
        r.THUMB_RETRY_COUNT = 0;
        r.THUMB_EXHAUSTED = false;
        r.THUMB_LAST_ERROR = null;
        candidates.push(r);
      }
    }
    if (candidates.length > 0) {
      for (var j = 0; j < candidates.length; j += WPZL_IDB_WRITE_CHUNK) {
        await db.putMany('annotations', candidates.slice(j, j + WPZL_IDB_WRITE_CHUNK));
      }
      fixed = candidates.length;
    }
  } catch (e) { /* ignore */ }
  return fixed;
}

// 复活卡死的 conflict 标注：SYNC_STATUS_CONFLICT 是死状态（不在 dirty 查询 4 态内、也不被
// _resetExhaustedState 复位），旧 _handleConflict 撞锁 409 时会误标，导致标注永久不再同步。
// onLogin 时降级为 PENDING，让其重新进入正常 LWW 闭环（下轮 dirty 推 → 服务端判 → 接受或再进
// conflict 列表被 serverVersion 覆盖）。当前无人工裁决 UI，降级优于卡死。
async function _reviveStuckConflicts() {
  var total = 0;
  try {
    var idx = db._tx('annotations', 'readonly').index('syncStatus');
    var stuck = await _getAllFromIndex(idx, SYNC_STATUS_CONFLICT);
    for (var i = 0; i < stuck.length; i++) {
      stuck[i].SYNC_STATUS = SYNC_STATUS_PENDING;
      stuck[i].SYNC_RETRY_COUNT = 0;
    }
    for (var j = 0; j < stuck.length; j += WPZL_IDB_WRITE_CHUNK) {
      await db.putMany('annotations', stuck.slice(j, j + WPZL_IDB_WRITE_CHUNK));
    }
    total = stuck.length;
  } catch (e) {
    console.warn('[Sync] _reviveStuckConflicts error:', e && e.message);
  }
  if (total > 0) console.log('[Sync] revived stuck conflict annotations, count=' + total);
  return total;
}

// ---- Sync Lock ----

// P1-9：等锁等待者——进程内事件通知（chrome.runtime.sendMessage 不回投 SW 自身，故不能用消息）。
// 手动同步入口（SW sync-trigger）此前 200ms×1500 次 getStatus 轮询等锁（每次轮询跨 3 store×12
// index count）；改为挂一次性 waiter，withSyncLock 释放时统一 resolve。
var _syncLockWaiters = [];
function _waitForSyncUnlock(timeoutMs) {
  if (!_syncLock) return Promise.resolve();
  return new Promise(function (resolve) {
    var done = false;
    var timer = setTimeout(function () {
      if (done) return;
      done = true;
      var ix = _syncLockWaiters.indexOf(finish);
      if (ix >= 0) _syncLockWaiters.splice(ix, 1);
      resolve(); // 超时兜底放行（与旧轮询的 5min 上限语义一致）
    }, timeoutMs || 5 * 60 * 1000);
    function finish() {
      if (done) return;
      done = true;
      clearTimeout(timer);
      resolve();
    }
    _syncLockWaiters.push(finish);
  });
}
function _releaseSyncLockWaiters() {
  var ws = _syncLockWaiters.splice(0, _syncLockWaiters.length);
  for (var i = 0; i < ws.length; i++) {
    try { ws[i](); } catch (e) { /* ignore */ }
  }
}

async function withSyncLock(fn) {
  if (_syncLock) {
    console.log('[Sync] Previous sync cycle still running, skipping');
    return { skipped: true, reason: 'sync_in_progress' };
  }
  _syncLock = true;
  _syncAbandoned = false; // 新周期开始，清防御标记
  try {
    return await fn();
  } finally {
    _syncLock = false;
    _releaseSyncLockWaiters(); // P1-9：事件通知等待方，取代轮询
  }
}

// ---- Dirty Data Tracking ----

// 解析调用栈，提取首个非本文件的调用位置，用于诊断「谁触发了脏数据」
function _extractCaller(stack) {
  try {
    var lines = (stack || '').split('\n');
    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i].trim();
      // 跳过 Error / markDirty / markDeleted 自身
      if (!ln) continue;
      if (ln.indexOf('markDirty') !== -1) continue;
      if (ln.indexOf('markDeleted') !== -1) continue;
      if (ln.indexOf('Error') === 0) continue;
      // 返回首个外部调用方
      // Chrome: "    at foo (service-worker.js:1331:17)"
      // 我们只取文件名:行号
      var m = ln.match(/(\b[\w.\-]+\.(?:js|html)):(\d+):\d+/);
      if (m) return m[1] + ':' + m[2];
      return ln.slice(0, 120);
    }
  } catch (e) { /* ignore */ }
  return 'unknown';
}

async function markDirty(markInfoId, dirtyBits) {
  // 诊断日志：记录谁在何时把哪条标注标脏（用于排查「幽灵推送」的来源）
  try {
    console.log('[Sync] markDirty: id=' + markInfoId +
      ' bits=' + dirtyBits +
      ' fields=[' + decodeDirtyBits(dirtyBits, 'annotation').join(',') + ']' +
      ' caller=' + _extractCaller(new Error().stack));
  } catch (e) { /* ignore */ }
  var store = db._tx('annotations', 'readwrite');
  return new Promise(function (resolve, reject) {
    var getReq = store.get(markInfoId);
    getReq.onsuccess = function () {
      var ann = getReq.result;
      if (!ann) { resolve(); return; }
      ann.SYNC_STATUS = SYNC_STATUS_PENDING;
      ann.DIRTY_BITS = (ann.DIRTY_BITS || 0) | dirtyBits;
      // 任何本地变更都推进 UPDATE_TIME（含 THUMBNAIL 后台补传）。
      // UPDATE_TIME 同时是 LWW 同步时钟与详情页业务时间：thumbnail 补传若不推进它，
      // dto.updateDate 就停在创建时刻，过不了服务器 doSync:297 的严格 isAfter LWW 判定，
      // 被判 server_newer 后字段被拒、跨设备拉不到图（详见 docs/2026-07-05-annotation-lww-time-separation.md）。
      // 代价：详情页时间会体现后台补传时刻，已确认可接受。
      ann.UPDATE_TIME = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
      var putReq = store.put(ann);
      putReq.onsuccess = function () { resolve(); };
      putReq.onerror = function () { reject(putReq.error); };
    };
    getReq.onerror = function () { reject(getReq.error); };
  });
}

async function markDeleted(markInfoId) {
  try {
    console.log('[Sync] markDeleted: id=' + markInfoId +
      ' caller=' + _extractCaller(new Error().stack));
  } catch (e) { /* ignore */ }
  var store = db._tx('annotations', 'readwrite');
  return new Promise(function (resolve, reject) {
    var getReq = store.get(markInfoId);
    getReq.onsuccess = function () {
      var ann = getReq.result;
      if (!ann) { resolve(); return; }
      ann.SYNC_STATUS = SYNC_STATUS_PENDING_DELETED;
      ann.DIRTY_BITS = DIRTY_BIT_DELETED;
      ann.UPDATE_TIME = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
      var putReq = store.put(ann);
      putReq.onsuccess = function () { resolve(); };
      putReq.onerror = function () { reject(putReq.error); };
    };
    getReq.onerror = function () { reject(getReq.error); };
  });
}

// 统计单个 store（带 syncStatus 索引）的待同步记录数（4 态求和）。
async function _countStoreSyncStatus(storeName) {
  try {
    var store = db._tx(storeName, 'readonly');
    var index = store.index('syncStatus');
    // 并发派发 4 个 count（同一事务活跃期内全部派发），避免顺序 await 导致事务失活
    var statuses = [SYNC_STATUS_PENDING, SYNC_STATUS_LOCAL, SYNC_STATUS_ERROR, SYNC_STATUS_PENDING_DELETED];
    var counts = await Promise.all(statuses.map(function (st) {
      return new Promise(function (resolve) {
        var req = index.count(st);
        req.onsuccess = function () { resolve(req.result || 0); };
        req.onerror = function () { resolve(0); }; // index 可能无该状态条目
      });
    }));
    return counts[0] + counts[1] + counts[2] + counts[3];
  } catch (e) { return 0; }
}

// 统计 annotations store 中指定同步状态的记录数（markLimit 预拦截用：估算已上云条数）。
async function _countAnnotationsByStatus(status) {
  try {
    var index = db._tx('annotations', 'readonly').index('syncStatus');
    return await new Promise(function (resolve) {
      var req = index.count(status);
      req.onsuccess = function () { resolve(req.result || 0); };
      req.onerror = function () { resolve(0); };
    });
  } catch (e) { return 0; }
}

// 统计 synced 状态且非协作（SOURCE!=='collab'）的标注数（markLimit 预拦截用）。
// 2026-11-05 起协作行不占属主总量额度（服务端 countByUserIdActive 已排除 collab），客户端估算须同口径；
// _countAnnotationsByStatus 是 syncStatus 索引 count() 无法带 source 过滤，故走游标。
// 无 SOURCE 属性的存量旧行计入（保守=旧行为，可能多算），随下次拉取落 SOURCE 后自愈。
async function _countSyncedAnnotationsExcludingCollab() {
  try {
    var index = db._tx('annotations', 'readonly').index('syncStatus');
    return await new Promise(function (resolve) {
      var count = 0;
      var req = index.openCursor(IDBKeyRange.only(SYNC_STATUS_SYNCED));
      req.onsuccess = function () {
        var cursor = req.result;
        if (!cursor) { resolve(count); return; }
        var v = cursor.value;
        if (!v || v.SOURCE !== 'collab') count++;
        cursor.continue();
      };
      req.onerror = function () { resolve(count); };
    });
  } catch (e) { return 0; }
}

async function getPendingCount() {
  // P2-2: 跨全部六类统计待同步总数（popup"待同步"口径与实际推送范围一致——此前只数
  // annotations/documents/snapshots，pages/folders/imageData 的待推/墓碑不计入，角标虚低）。
  var counts = await Promise.all([
    _countStoreSyncStatus('annotations'),
    _countStoreSyncStatus('documents'),
    _countStoreSyncStatus('snapshots')
  ]);
  var base = counts[0] + counts[1] + counts[2];
  // pages / folders / imageData：复用现有 collector，看 .dirty + .deleted（P1-13 墓碑计入）
  var results = await Promise.all([
    _collectDirtyPages().catch(function () { return { dirty: [], deleted: [] }; }),
    _collectDirtyFolders().catch(function () { return { dirty: [], deleted: [] }; }),
    _collectDirtyImageData().catch(function () { return { dirty: [], deleted: [] }; })
  ]);
  return base +
    results[0].dirty.length + results[0].deleted.length +
    results[1].dirty.length + results[1].deleted.length +
    results[2].dirty.length + results[2].deleted.length;
}

// 跨 6 类存储（annotations / documents / snapshots / pages / folders / imageData）统计是否有任何待推记录。
// 用于 connectivity-tick alarm 的 dirty 队列非空判定（仅判"有没有"，不算总数 → 更快）。
// P2-2 连带：getPendingCount 已覆盖全部六类，直接复用。
async function getDirtyCount() {
  try {
    return await getPendingCount();
  } catch (e) {
    return 0;
  }
}

// ---- IndexedDB Helpers ----

function _getAllFromIndex(index, query) {
  return new Promise(function (resolve, reject) {
    var req = index.getAll(query);
    req.onsuccess = function () { resolve(req.result || []); };
    req.onerror = function () { reject(req.error); };
  });
}

function _getAllFromStore(store) {
  return new Promise(function (resolve, reject) {
    var req = store.getAll();
    req.onsuccess = function () { resolve(req.result || []); };
    req.onerror = function () { reject(req.error); };
  });
}

// ---- Push / Pull Engine（legacy，P1-39 已删除）----
// 旧版 push()/pull() 走 /api/v1/sync/upload、/sync/download 分体端点，服务端已 410 下线；
// 统一由下方 sync() 承担（POST /api/v1/sync 单请求推拉合一）。
// 其使用的 _applyDownloaded* / _applyDeleted* / _handleConflict / _markXxxUploadResult /
// buildXxxUploadDto 等 helper 由统一路径共用，保留。

// P1-2 Step A：比较层归一化——server/local 时间统一经 _tsMs 转 ms 后数值比较。
// 取代旧「同格式字符串字典序比较」：FMT/ISO/epoch 混存时字典序结果无意义（本地钟慢误判、
// guard 恒不命中等）。历史「HH」字面量 bug 格式在 _tsMs 下解析为 0（无本地时间 → 服务端赢），
// 与旧的字母检测守卫语义一致（触发合并修正本地数据）。
function _isServerNewer(serverTime, localTime) {
  var s = _tsMs(serverTime);
  if (!s) return false;
  var l = _tsMs(localTime);
  if (!l) return true;
  return s > l;
}

// P1-2 Step A：Pull-loop guard 归一化——服务端 syncedAt 与本地 SYNCED_AT 经 _tsMs 数值比较。
// 旧字符串字典序在 FMT/ISO 混存时恒不命中（guard 失效退化为全量 _isServerNewer 比较，正确但费）。
// 任一侧无时间信息（0）不命中 guard，落到 _isServerNewer 全量比较（保守路径）。
function _syncGuardSkip(serverSyncedAt, localSyncedAt) {
  var s = _tsMs(serverSyncedAt), l = _tsMs(localSyncedAt);
  return !!(s && l && s <= l);
}

// ---- Sync Orchestrator (Unified) ----
// 合并 push/pull 为单次 POST /api/v1/sync 请求。
// 服务端先查后写：先查询待下载数据，再处理上传，确保不重复下载。

async function sync(priority) {
  // P1：本地清空进行中——拒绝一切新周期（库正在被清，同步无意义；含 manual）
  if (_localClearGuard) return { pushed: 0, pulled: 0, reason: 'local_clear' };
  // P2：导入会话期间抑制自动同步（manual 用户主动不受限）
  if (_importSessionActive && priority !== 'manual') {
    return { pushed: 0, pulled: 0, reason: 'import_session_skip' };
  }
  if (!(await isSyncAllowed())) return { pushed: 0, pulled: 0, reason: 'not_allowed' };

  // 脱机整体休眠：自动同步（非 manual）在 offline 时直接短路，避免逐项发注定失败的请求。
  // manual（用户主动点「立即同步」）不 gate——必须真发请求让 catch 把网络错误返回给 UI，
  // 否则静默 skip 会带 reason='offline_skip' 但无 error 字段，被 sync-trigger handler 当作 success 误报「同步完成」。
  if (typeof wpzl_getSyncState === 'function' && wpzl_getSyncState() === 'offline' && priority !== 'manual') {
    return { pushed: 0, pulled: 0, reason: 'offline_skip' };
  }

  // 服务端错误熔断：探活可达但 /api/v1/sync 连续失败（5xx 等）时，自动同步在冷却期内短路，
  // 避免 connectivity-tick / SW 冷启动 init / manager 轮询唤醒等路径无限重发给服务器加压。
  // manual（用户点「立即同步」）不 gate——直通并作为复位手段（成功即 _resetServerErrBackoff）。
  if (priority !== 'manual' && (await _isServerErrPaused())) {
    if (typeof wpzl_setSyncState === 'function') wpzl_setSyncState('server_error');
    console.warn('[Sync] sync(' + priority + ') skipped: server-error backoff active');
    return { pushed: 0, pulled: 0, reason: 'server_error_paused' };
  }

  // 决策 4：每次 sync 前 refresh 当前用户 id，作为 serverXxxDtoToLocal 的 fallback。
  // 服务端响应不带 userId，必须前端填充，否则按 USER_ID 隔离的读路径查不到。
  await _refreshCurrentUid();

  return withSyncLock(async function () {
    var deviceId = await getDeviceId();
    var syncToken = await _syncGetMeta('sync_token');
    var totalPushed = 0;
    var totalPulled = 0;
    var totalConflicts = 0;
    var totalRejected = 0;
    var totalDeleted = 0;
    var totalPushedImageAssets = 0;
    var totalPulledImageAssets = 0;

    // ---- 收集本地待上传数据 ----
    var store = db._tx('annotations', 'readonly');
    var index = store.index('syncStatus');

    // 并发派发 4 个 getAll（同一事务活跃期内全部派发），避免顺序 await 导致事务失活
    var _dirtyResults = await Promise.all([
      _getAllFromIndex(index, SYNC_STATUS_PENDING),
      _getAllFromIndex(index, SYNC_STATUS_LOCAL),
      _getAllFromIndex(index, SYNC_STATUS_ERROR),
      _getAllFromIndex(index, SYNC_STATUS_PENDING_DELETED)
    ]);
    var _dirtyAll = _dirtyResults[0].concat(_dirtyResults[1]).concat(_dirtyResults[2]);
    // 跳过已耗尽项（SYNC_EXHAUSTED）：不再自动推送，仅手动重传/重新登录复位（计划 4e）
    var dirty = _dirtyAll.filter(function (a) { return !a.SYNC_EXHAUSTED; });
    var pendingDeleted = _dirtyResults[3];
    var deletedIds = pendingDeleted.map(function (a) { return a.MARK_INFO_ID; });
    // P0-E 观察埋点：sync() 入口计数 + 本轮脏量快照——验证大上传是否单轮排空
    //（对照批数即可判断有无 SW 重启重收集）。验证后保留（本地 IDB 写 + console，无网络开销）。
    try {
      var _peCount = ((await _syncGetMeta('sync_entry_count')) || 0) + 1;
      await _syncSetMeta('sync_entry_count', _peCount);
      await _syncSetMeta('last_dirty_size', dirty.length + pendingDeleted.length);
      if (dirty.length > 1000) console.info('[Sync] P0-E entry#' + _peCount + ': dirty=' + dirty.length);
    } catch (e) { /* ignore */ }

    // markLimit 客户端预拦截（近似预警；服务端软拒才是权威——本地计数不含他端批注；2026-11-05 起
    // 协作（SOURCE==='collab'）已与服务端同口径排除——协作不占属主总量额度，上限在服务端按分享计数）：
    // 已在服务端 ≈ synced 状态非协作计数 + 本批带 SYNCED_AT 的非协作脏项（已同步标注的本地编辑）。
    // 剩余 headroom 内按收集顺序放行"从未上过服务器"（!SYNCED_AT）的新增项，超额部分剔出本轮推送
    // （dirty 必须在 uploadDtos=dirty.map 之前过滤——上传队列按下标配对）；更新（有 SYNCED_AT）与
    // 删除（pending_deleted 墓碑）不受影响。被扣项不改动任何状态（保持 pending/local，不制造假
    // EXHAUSTED）——下轮 headroom 恢复（删除传播/升级）即自动放行。达限仅影响新增上云，本地创建不受限。
    try {
      var _mlStatus = (typeof wpzl_getProStatus === 'function') ? (await wpzl_getProStatus()) : null;
      var _mlLimit = _mlStatus && _mlStatus.limits && _mlStatus.limits.markLimit;
      if (typeof _mlLimit === 'number' && _mlLimit > 0) {
        var _mlNeverSynced = dirty.filter(function (a) { return !a.SYNCED_AT; });
        if (_mlNeverSynced.length > 0) {
          var _mlOnServer = (await _countSyncedAnnotationsExcludingCollab())
            + dirty.filter(function (a) { return !!a.SYNCED_AT && a.SOURCE !== 'collab'; }).length;
          var _mlHeadroom = _mlLimit - _mlOnServer;
          if (_mlHeadroom < _mlNeverSynced.length) {
            var _mlAllow = _mlNeverSynced.slice(0, Math.max(0, _mlHeadroom));
            var _mlAllowSet = new Set();
            for (var _mlI = 0; _mlI < _mlAllow.length; _mlI++) _mlAllowSet.add(_mlAllow[_mlI].MARK_INFO_ID);
            var _mlHeld = 0;
            dirty = dirty.filter(function (a) {
              if (!a.SYNCED_AT && !_mlAllowSet.has(a.MARK_INFO_ID)) { _mlHeld++; return false; }
              return true;
            });
            console.info('[Sync] mark limit gate: held ' + _mlHeld +
              ' never-synced annotations (limit=' + _mlLimit + ', est-on-server=' + _mlOnServer + ')');
            _setMarkLimitBlocked(true);
            _maybeShowMarkLimitToast(_mlLimit);
          }
        }
      }
    } catch (e) { /* 预检失败不阻塞同步：服务端软拒兜底 */ }

    // V69: 每日标注创建限额客户端预拦截（mark_limit 同款近似预警，服务端软拒权威）。
    // 估算今日将占服务端额度数 = 本地计数器（今日新建，含已同步）
    //   + 昨日积压未上云项（!SYNCED_AT 且 CREATE_TIME 非本地今日——服务端插入时刻是今天）；
    // 超额的 !SYNCED_AT 项剔出本轮（保持 pending/local 不造假 EXHAUSTED），下轮跨天/调额自动放行。
    // CREATE_TIME 是 UTC-naive 'yyyy-MM-dd HH:mm:ss'（Bug B 时区轴），须换算本地日比较，勿字符串前缀直比。
    // V70: IS_IMPORTED=1 项不参与本门（收集与扣留两处都豁免）——服务端对 imported 直接 continue
    // 不占每日额度，改受 daily_import_limit 约束（import_limit 拒绝 token 驱动既有阻断/探测框架，
    // 客户端无 import 预拦截，服务端权威）。若只豁免收集不改扣留过滤，混合批次中导入项不在
    // allowSet 仍会被通用 !SYNCED_AT 条件扣留（2026-09-30 E2E 实测整批滞留）。
    // 2026-11-05: SOURCE==='collab' 同两处豁免——协作行不占属主每日额度（服务端
    // countCreatedTodayByUserId 已排除 collab）。正常协作行有 SYNCED_AT 本就不进 neverSynced，
    // 此为防御（如本地异常路径产生无 SYNCED_AT 的协作行时仍不被门禁误扣）。
    try {
      var _dmlLimit = _mlStatus && _mlStatus.limits && _mlStatus.limits.dailyMarkLimit;
      if (typeof _dmlLimit === 'number' && _dmlLimit > 0) {
        var _dmlNeverSynced = dirty.filter(function (a) { return !a.SYNCED_AT && a.IS_IMPORTED !== 1 && a.SOURCE !== 'collab'; });
        if (_dmlNeverSynced.length > 0) {
          var _dmlUid = _currentUid || (await _refreshCurrentUid());
          var _dmlLocalCount = (typeof wpzl_readDailyMarkCount === 'function')
            ? await wpzl_readDailyMarkCount(_dmlUid) : 0;
          var _dmlToday = _wpzlSyncLocalDateStr(new Date());
          var _dmlBacklog = _dmlNeverSynced.filter(function (a) {
            var d = _wpzlSyncParseStoredDate(a.CREATE_TIME);
            return !d || _wpzlSyncLocalDateStr(d) !== _dmlToday; // 无时间按积压保守计
          }).length;
          var _dmlHeadroom = _dmlLimit - _dmlLocalCount - _dmlBacklog;
          if (_dmlHeadroom < _dmlNeverSynced.length) {
            var _dmlAllow = _dmlNeverSynced.slice(0, Math.max(0, _dmlHeadroom));
            var _dmlAllowSet = new Set();
            for (var _dmlI = 0; _dmlI < _dmlAllow.length; _dmlI++) _dmlAllowSet.add(_dmlAllow[_dmlI].MARK_INFO_ID);
            var _dmlHeld = 0;
            dirty = dirty.filter(function (a) {
              if (!a.SYNCED_AT && a.IS_IMPORTED !== 1 && a.SOURCE !== 'collab' && !_dmlAllowSet.has(a.MARK_INFO_ID)) { _dmlHeld++; return false; }
              return true;
            });
            console.info('[Sync] daily mark limit gate: held ' + _dmlHeld +
              ' never-synced annotations (limit=' + _dmlLimit + ', local-today=' + _dmlLocalCount +
              ', backlog=' + _dmlBacklog + ')');
            _setDailyMarkBlocked(true);
            _maybeShowDailyMarkLimitToast(_dmlLimit);
          }
        }
      }
    } catch (e) { /* 预检失败不阻塞同步：服务端软拒兜底 */ }

    // 标注立即同步（缩略图后补）：不因 THUMBNAIL_PENDING hold 标注（避免对端页面菜单闪烁，详见 doSyncPush）。
    var uploadDtos = dirty.map(function (ann) { return buildDiffUploadDto(ann); });
    var dirtyMap = {};
    for (var d = 0; d < dirty.length; d++) {
      dirtyMap[dirty[d].MARK_INFO_ID] = dirty[d];
    }

    // 注：图片上云（_uploadPendingImages）已移出 sync cycle，改由 connectivity-tick alarm 独立调度。
    // 历史上此处会逐张 multipart fetch（无超时），R2 不可用时整段 withSyncLock 被阻塞 60s+，
    // 进而与切账号的 clearAllLocalData 竞争、污染 sync_token。详见 plan 文件改动 B。

    // ---- 收集脏 page / folder / imageAsset（第4类）/ document（第5类） ----
    // P1-41: R2 降级静默退避——上一轮 degraded 置的 r2_degraded_until 未到期时，自动同步跳过
    // doc/snap 的 dirty 收集（tombstone 仍收集：删除不写 R2 put）。manual（用户强制）不受限。
    var _r2DegradedSkip = false;
    try {
      var _r2Until = (await _syncGetMeta('r2_degraded_until')) || 0;
      _r2DegradedSkip = (_r2Until > Date.now()) && priority !== 'manual';
      if (_r2DegradedSkip) console.info('[Sync] R2 degraded backoff active — doc/snap dirty collection skipped');
    } catch (e) { /* ignore */ }
    var pageCol = await _collectDirtyPages();
    var folderCol = await _collectDirtyFolders();
    var docCol = await _collectDirtyDocuments(_r2DegradedSkip);
    var snapCol = await _collectDirtySnapshots(_r2DegradedSkip);
    var imageCol = { dirty: [], deleted: [] };
    // 仅 Pro 用户参与 imageData 上云（免费用户纯本地，无 cloudUrl 元数据可推）
    if (await isImageCloudUploadAllowed()) {
      imageCol = await _collectDirtyImageData();
    }
    var uploadPageDtos = pageCol.dirty.map(buildPageDiffUploadDto);
    // 诊断日志：显示所有待推送的 dirty pages
    try {
      pageCol.dirty.forEach(function (p) {
        console.log('[Sync][Push] dirty page: url=' + p.url + ' status=' + p.SYNC_STATUS + ' dirtyBits=' + (p.DIRTY_BITS || 0) + ' title=' + (p.title || '').slice(0, 50) + ' lastVisited=' + p.lastVisited);
      });
      if (pageCol.deleted.length > 0) {
        console.log('[Sync][Push] deleted page urlMd5s: ' + pageCol.deleted.join(', '));
      }
    } catch (e) { /* ignore */ }
    var uploadFolderDtos = folderCol.dirty.map(buildFolderDiffUploadDto);
    var uploadDocDtos = await Promise.all(docCol.dirty.map(async function (d) {
      var dto = buildDocumentDiffUploadDto(d);
      // P1-8 分仓 join：'' 哨兵（需上传 body）→ 从 docBodies 回填实际正文；null（跳过）保持 null。
      // bodyHtml 可能 null（无 body 本轮）；_compressBodyHtml 对 null/小串原样返回，对大 body gzip 压缩。
      if (dto.bodyHtml != null) dto.bodyHtml = await db.getDocBodyHtml(d.docId);
      dto.bodyHtml = await _compressBodyHtml(dto.bodyHtml);
      return dto;
    }));
    var uploadSnapDtos = await Promise.all(snapCol.dirty.map(async function (s) {
      var dto = buildSnapshotDiffUploadDto(s);
      // P1-8 分仓 join：同 doc 侧
      if (dto.bodyHtml != null) dto.bodyHtml = await db.getSnapBodyHtml(s.snapId);
      dto.bodyHtml = await _compressBodyHtml(dto.bodyHtml);
      return dto;
    }));
    var uploadImageDtos = imageCol.dirty.map(buildImageAssetDiffUploadDto);

    // ---- 同步明细收集（用于「立即同步」后给用户看的同步报告） ----
    // 每条记录：{ type, result, id, url, title, dirtyFields, prevStatus, note }
    // 为避免大数据量爆内存/UI，每个分类最多保留前 50 条；超出的计入 overflow 计数。
    var REPORT_CAP = 50;
    var report = {
      pushedAnn: [], pushedAnnOverflow: 0,
      pushedPage: [], pushedPageOverflow: 0,
      pushedFolder: [], pushedFolderOverflow: 0,
      pulledAnn: [], pulledAnnOverflow: 0,
      pulledPage: [], pulledPageOverflow: 0,
      pulledFolder: [], pulledFolderOverflow: 0,
      deletedAnn: [], deletedPage: [], deletedFolder: [],
      // 上传时的待处理总量（含未上传成功的），让用户感知"还有多少在排队"
      attemptedPushAnn: dirty.length,
      attemptedPushPage: pageCol.dirty.length,
      attemptedPushFolder: folderCol.dirty.length,
      attemptedDeleteAnn: deletedIds.length,
      attemptedDeletePage: pageCol.deleted.length,
      attemptedDeleteFolder: folderCol.deleted.length
    };
    function _pushCapped(arr, item) {
      if (arr.length < REPORT_CAP) arr.push(item);
      else if (arr.length === REPORT_CAP) arr.push({ _overflow: true });
    }

    // ---- 发送请求 + 处理分页续传 ----
    // 协议 v2：客户端声明支持 cursor 分页。服务端对老客户端（不发 pv）回退到 500 上限兼容路径。
    // 三个 cursor 独立推进：annotations.cursor / pages.pageCursor / folders.folderCursor。
    // 上传分批：每轮最多 200 条（annotations + pages + folders + tombstones 合计），与服务端 maxUploadBatchSize 对齐。
    // syncToken 仅在所有 cursor 为 null（末页）时由服务端签发，避免分页中途中断导致 token 越过未分页数据。
    var UPLOAD_BATCH_SIZE = 200;
    // G-4 导入回灌车道：dirty 中 IS_IMPORTED=1 项超过阈值才启用批间限速（小导入零开销）；
    // 间隔 300ms——5000 批 × 300ms ≈ +25min，换服务端突发抹平。常量集中可调。
    var IMPORT_BACKFILL_THRESHOLD = 500;
    var IMPORT_BACKFILL_PACING_MS = 300;
    // 断点续传（Bug 7）：SW 30s 回收中断的大同步，从持久化 cursor 续传（而非从头）
    var _resume = await _getPullCursor();
    var cursor = _resume ? (_resume.cursor || null) : null;
    var pageCursor = _resume ? (_resume.pageCursor || null) : null;
    var folderCursor = _resume ? (_resume.folderCursor || null) : null;
    var imageAssetCursor = _resume ? (_resume.imageAssetCursor || null) : null;
    var documentCursor = _resume ? (_resume.documentCursor || null) : null;
    var snapshotCursor = _resume ? (_resume.snapshotCursor || null) : null;
    if (_resume) {
      console.log('[Sync] 续传下载: cursor=' + cursor + ' pageCursor=' + pageCursor + ' folderCursor=' + folderCursor + ' imageAssetCursor=' + imageAssetCursor + ' documentCursor=' + documentCursor);
      _ensureResumeAlarm(); // 续传期间保活 alarm，SW 再被杀时兜底
    }
    // P1-44: 长离线对账——token 年龄逼近墓碑保留期时置的标记（响应处理处检测 serverNow）。
    // 对账轮：丢弃 sync_token 与续传游标，pull 走 since=null 全量分页（服务端无需新端点），
    // 拉尽后 diff 删除本地多余 SYNCED 记录。中断则下轮再全量（标记未清、token 保持为空，
    // 故触发不依赖 syncToken 存在）。
    var _reconcileRequested = false;
    try {
      if (await _syncGetMeta('full_reconcile_pending')) {
        syncToken = null;
        await _syncSetMeta('sync_token', null);
        // 注意：**不清下载游标**。token=null 时服务端走 id-cursor 全量分页，持久化游标
        // 即全量进度——SW 30s 回收后 resume alarm 续传接着拉。若在此清游标，中断→续传→
        // 又清→又从头拉，全量永远跑不完（SW 忙死循环，实测踩坑）。首轮进入时游标本为 null
        // （上次正常 sync 末页已清）。
        // 例外：残留游标若是「中断的增量分页」所存（复合游标 "syncedAt|id"，含 '|'），与
        // token=null 的全量纯数字游标语义不符——服务端全量分支按数字解析直接 500，本端又
        // 原样保留游标重试 → 同步永久死锁。仅丢弃复合格式游标（全量进度游标恒为纯数字 id，
        // 不受影响，续传防死循环语义保持）。
        var _hadIncr = false;
        if (cursor && String(cursor).indexOf('|') >= 0) { cursor = null; _hadIncr = true; }
        if (pageCursor && String(pageCursor).indexOf('|') >= 0) { pageCursor = null; _hadIncr = true; }
        if (folderCursor && String(folderCursor).indexOf('|') >= 0) { folderCursor = null; _hadIncr = true; }
        if (imageAssetCursor && String(imageAssetCursor).indexOf('|') >= 0) { imageAssetCursor = null; _hadIncr = true; }
        if (documentCursor && String(documentCursor).indexOf('|') >= 0) { documentCursor = null; _hadIncr = true; }
        if (snapshotCursor && String(snapshotCursor).indexOf('|') >= 0) { snapshotCursor = null; _hadIncr = true; }
        if (_hadIncr) {
          console.warn('[Sync] full reconcile: 弃用残留的增量复合游标（与全量分页语义不符）');
          await _savePullCursor(cursor, pageCursor, folderCursor, imageAssetCursor, documentCursor, snapshotCursor);
        }
        _reconcileRequested = true;
        console.log('[Sync] full reconcile: token age near tombstone retention — pulling full active set this round');
      }
    } catch (e) { /* ignore */ }
    // 单用户单设备优化：本地无脏数据 + 非断点续传 + 已完成首次全量(syncToken 非空) + 非用户主动(manual)
    // → 服务端不会有本设备不知道的新数据，跳过本次同步请求，减少无谓探测压力。
    // 例外：manual（用户点「立即同步」/ 网络恢复）即使无脏数据也发；首次登录(syncToken 空)仍全量拉取；
    // P1-44 对账轮必须发（目的就是拉全量）。
    // P1-5（多设备可见性兜底，30min 冷却上限）：连续跳过以"上次成功拉取"计时——距今超
    // PROBE_PULL_MAX_STALE_MS 不再跳过，放行一次轻量 pull（空上传+游标），否则对端删除在
    // 不打开页面的设备上永远无法到达。任何成功周期都会刷新 last_pull_time（含手动/脏推送），
    // 故冷却窗口按真实拉取新鲜度计；请求量约为"每 tick 轻拉"方案的 1/7。
    var _noDirtyAll = dirty.length === 0 && deletedIds.length === 0 &&
        pageCol.dirty.length === 0 && pageCol.deleted.length === 0 &&
        folderCol.dirty.length === 0 && folderCol.deleted.length === 0 &&
        imageCol.dirty.length === 0 && imageCol.deleted.length === 0 &&
        docCol.dirty.length === 0 && docCol.deleted.length === 0 &&
        snapCol.dirty.length === 0 && snapCol.deleted.length === 0;
    var _probeDue = false; // 冷却到期 → 无脏也放行一次轻量 pull
    try {
      var _lastPullMs = _tsMs(await _syncGetMeta('last_pull_time'));
      _probeDue = !_lastPullMs || (Date.now() - _lastPullMs) >= PROBE_PULL_MAX_STALE_MS;
    } catch (e) { _probeDue = false; }
    if (priority !== 'manual' && !_resume && !_reconcileRequested && syncToken && _noDirtyAll && !_probeDue) {
      console.log('[Sync] skip: no dirty data & already incremental (single-device) — skip probe request');
      return { pushed: 0, pulled: 0, reason: 'no_dirty_skip' };
    }
    if (priority !== 'manual' && !_resume && !_reconcileRequested && syncToken && _noDirtyAll && _probeDue) {
      console.log('[Sync] no dirty but last pull stale > ' + Math.round(PROBE_PULL_MAX_STALE_MS / 60000) +
        'min — forced lightweight pull for multi-device visibility (P1-5)');
    }
    var newSyncToken = null;
    // P1-44: 对账轮累计服务端 active 全集（仅 _reconcileRequested 时填充；分页拉尽后 diff）
    var _reconCollect = _reconcileRequested
      ? { ann: new Set(), page: new Set(), folder: new Set(), image: new Set(), doc: new Set(), snap: new Set() }
      : null;

    // 统一上传队列：每项带 _type 标签，按 200 切片
    // G-4 车道隔离：IS_IMPORTED=1 的导入回灌项（ann/doc/snap 三类）排到普通脏数据之后——
    // 用户刚做的编辑永远先于历史回灌上云；tombstone 队列语义不动（删除仍最先下发）。
    var uploadQueue = [];
    var _backfillQueue = [];
    function _enqueueUpload(item) {
      var _loc = item.local;
      // 字节预算：序列化一次得精确线上体积（JSON.stringify 已含转义膨胀，Blob.size 为 UTF-8
      // 字节数——对 CJK 3 字节/字符也不会低估）。仅对能长到 MB 级的三类做硬上限拦截
      // （document/snapshot bodyHtml 内联、annotation CONTEXT 可内嵌 dataUrl 图片，S3-14 实测
      // 16MB context 曾 413）；page/folder/imageAsset 历史未观察到 MB 级，保留旧行为。
      try { item._bytes = item.dto ? new Blob([JSON.stringify(item.dto)]).size : 0; } catch (e) { item._bytes = 0; }
      if (_loc && item._bytes > SYNC_ITEM_BYTES_HARD_CAP &&
          (item._type === 'ann' || item._type === 'document' || item._type === 'snapshot')) {
        var _sizeToken = item._type === 'document' ? 'doc_size_limit'
          : (item._type === 'snapshot' ? 'snap_size_limit' : 'payload_too_large');
        console.warn('[Sync] ' + item._type + ' serialized ' + item._bytes + 'B > hard cap ' +
          SYNC_ITEM_BYTES_HARD_CAP + 'B — terminal ' + _sizeToken + ', not enqueued');
        _loc.SYNC_STATUS = SYNC_STATUS_ERROR;
        _loc.SYNC_LAST_ERROR = _sizeToken;
        _loc.SYNC_EXHAUSTED = true;
        _loc.SYNC_LAST_ATTEMPT_AT = new Date().toISOString();
        _broadcastSyncExhausted({
          kind: item._type === 'ann' ? 'annotation' : item._type,
          id: _loc.MARK_INFO_ID || _loc.docId || _loc.snapId,
          reason: _sizeToken
        });
        db.putMany(item._type === 'ann' ? 'annotations'
          : (item._type === 'document' ? 'documents' : 'snapshots'), [_loc])
          .catch(function () { /* ignore */ });
        return; // 不入队——入队只会拖垮所在批触发 413 连坐
      }
      if (_loc && _loc.IS_IMPORTED === 1 &&
          (item._type === 'ann' || item._type === 'document' || item._type === 'snapshot')) {
        _backfillQueue.push(item);
      } else {
        uploadQueue.push(item);
      }
    }
    for (var ai = 0; ai < uploadDtos.length; ai++) {
      _enqueueUpload({ _type: 'ann', dto: uploadDtos[ai], local: dirty[ai] });
    }
    for (var pi = 0; pi < uploadPageDtos.length; pi++) {
      _enqueueUpload({ _type: 'page', dto: uploadPageDtos[pi], local: pageCol.dirty[pi] });
    }
    for (var fi = 0; fi < uploadFolderDtos.length; fi++) {
      _enqueueUpload({ _type: 'folder', dto: uploadFolderDtos[fi], local: folderCol.dirty[fi] });
    }
    for (var ii = 0; ii < uploadImageDtos.length; ii++) {
      _enqueueUpload({ _type: 'imageAsset', dto: uploadImageDtos[ii], local: imageCol.dirty[ii] });
    }
    for (var di = 0; di < uploadDocDtos.length; di++) {
      _enqueueUpload({ _type: 'document', dto: uploadDocDtos[di], local: docCol.dirty[di] });
    }
    for (var si = 0; si < uploadSnapDtos.length; si++) {
      _enqueueUpload({ _type: 'snapshot', dto: uploadSnapDtos[si], local: snapCol.dirty[si] });
    }
    // G-4 回灌限速开关：dirty 导入项超过阈值才启用批间间隔（小导入零开销）
    var _backfillPacing = _backfillQueue.length > IMPORT_BACKFILL_THRESHOLD;
    if (_backfillPacing) {
      console.info('[Sync] import backfill lane: ' + _backfillQueue.length +
        ' imported items queued after normal dirty data (pacing ' + IMPORT_BACKFILL_PACING_MS + 'ms/batch)');
    }
    uploadQueue = uploadQueue.concat(_backfillQueue);
    // tombstone 队列（首批集中下发，避免删除与实体跨批导致复活）
    var remainingDeletes = {
      ann: deletedIds.slice(),
      page: pageCol.deleted.slice(),
      folder: folderCol.deleted.slice(),
      imageAsset: imageCol.deleted.slice(),
      document: docCol.deleted.slice(),
      snapshot: snapCol.deleted.slice()
    };

    function _takeBatch() {
      var ann = [], pages = [], folders = [], imageAssets = [], documents = [], snapshots = [];
      var delAnn = [], delPage = [], delFolder = [], delImageAsset = [], delDoc = [], delSnap = [];
      var total = 0;
      while (total < UPLOAD_BATCH_SIZE && remainingDeletes.ann.length) {
        delAnn.push(remainingDeletes.ann.shift()); total++;
      }
      while (total < UPLOAD_BATCH_SIZE && remainingDeletes.page.length) {
        delPage.push(remainingDeletes.page.shift()); total++;
      }
      while (total < UPLOAD_BATCH_SIZE && remainingDeletes.folder.length) {
        delFolder.push(remainingDeletes.folder.shift()); total++;
      }
      while (total < UPLOAD_BATCH_SIZE && remainingDeletes.imageAsset.length) {
        delImageAsset.push(remainingDeletes.imageAsset.shift()); total++;
      }
      while (total < UPLOAD_BATCH_SIZE && remainingDeletes.document.length) {
        delDoc.push(remainingDeletes.document.shift()); total++;
      }
      while (total < UPLOAD_BATCH_SIZE && remainingDeletes.snapshot.length) {
        delSnap.push(remainingDeletes.snapshot.shift()); total++;
      }
      var batchBytes = 0;
      while (total < UPLOAD_BATCH_SIZE && uploadQueue.length) {
        var item = uploadQueue.shift();
        // 字节预算切批：本批已有内容且装不下本项 → 退回留给下一批（防止单个大 DTO 撑爆整批
        // 触发服务端 15MB filter 413）。首批保底收下保证前进——能到这里的项都 ≤ 硬上限
        // （超限项已在 _enqueueUpload 终态化），单独成批必然 < 15MB。
        if (total > 0 && item._bytes && batchBytes + item._bytes > SYNC_BATCH_BYTES_BUDGET) {
          uploadQueue.unshift(item);
          break;
        }
        batchBytes += item._bytes || 0;
        if (item._type === 'page') pages.push(item);
        else if (item._type === 'folder') folders.push(item);
        else if (item._type === 'imageAsset') imageAssets.push(item);
        else if (item._type === 'document') documents.push(item);
        else if (item._type === 'snapshot') snapshots.push(item);
        else ann.push(item);
        total++;
      }
      return {
        annotations: ann, pages: pages, folders: folders, imageAssets: imageAssets, documents: documents, snapshots: snapshots,
        deletedIds: delAnn, deletedPageUrlMd5s: delPage, deletedFolderIds: delFolder,
        deletedImageAssetKeys: delImageAsset, deletedDocIds: delDoc, deletedSnapIds: delSnap
      };
    }

    // P0-7 连带保护：应用持续失败时防止 do-while 同游标无限重拉（死循环）——
    // 连续 2 轮有应用失败即跳出本轮 sync（pull_cursor 已持久化 + resume alarm 兜底续传）。
    var _consecutiveApplyFails = 0;

    do {
      var batch = _takeBatch();
      var reqAnnotations = batch.annotations.map(function (x) { return x.dto; });
      var reqDeletedIds = batch.deletedIds;
      var reqPages = batch.pages.map(function (x) { return x.dto; });
      var reqDeletedPageUrlMd5s = batch.deletedPageUrlMd5s;
      var reqFolders = batch.folders.map(function (x) { return x.dto; });
      var reqDeletedFolderIds = batch.deletedFolderIds;
      var reqImageAssets = batch.imageAssets.map(function (x) { return x.dto; });
      var reqDeletedImageAssetKeys = batch.deletedImageAssetKeys;
      var reqDocuments = batch.documents.map(function (x) { return x.dto; });
      var reqDeletedDocIds = batch.deletedDocIds;
      var reqSnapshots = batch.snapshots.map(function (x) { return x.dto; });
      var reqDeletedSnapIds = batch.deletedSnapIds;

      var resp;
      try {
        resp = await wpzl_sync(deviceId, syncToken, reqAnnotations, reqDeletedIds,
                              reqPages, reqDeletedPageUrlMd5s, reqFolders, reqDeletedFolderIds,
                              cursor, pageCursor, folderCursor,
                              reqImageAssets, reqDeletedImageAssetKeys, imageAssetCursor,
                              reqDocuments, reqDeletedDocIds, documentCursor,
                              reqSnapshots, reqDeletedSnapIds, snapshotCursor);
      } catch (e) {
        console.warn('[Sync] Unified sync request failed:', e.message);

        // P1（登出×在途竞争）：清空已发生 → 丢弃错误处理——本 catch 的 putMany 回写会把
        // 本批 locals 按原 pending 状态种回已清空的库（"登出后残留 16 条 pending"的来源路径），
        // enqueueOffline/健康度写同理。不计失败不烧重试，直接静默收尾。
        if (_syncAborted()) {
          console.warn('[Sync] cycle abandoned (logout/switch-user) — in-flight batch error handling discarded');
          return { pushed: 0, pulled: 0, reason: 'abandoned' };
        }

        // 409 撞锁（"另一个设备正在同步中"）：临时态，不烧配额、不入离线队列、不切 offline、不计健康失败。
        // dirty 项保留原状态，由 connectivity-tick（3.5-6.5min 抖动）下轮 getDirtyCount()>0 时重试。
        var _isLockConflict = !!(e && (e.kind === 'conflict_lock' || e.status === 409));
        if (_isLockConflict) {
          console.warn('[Sync] sync skipped: another device is syncing (409), will retry on next connectivity-tick');
          return { pushed: 0, pulled: 0, error: e.message, retriable: true };
        }

        // 413 整批超限（服务端 filter 直拒，非 ApiResponse 包裹体）：传输层**批级**失败，
        // 不是逐项业务拒绝——不得写任何记录的 SYNC_LAST_ERROR（否则批内逐项真实原因如
        // daily_mark_limit 全被「请求体过大」覆盖）、不得烧重试计数（无辜项陪耗尽）。
        // 字节预算分批后正常不会触达；真触达（预算外膨胀）→ 留原状下轮重批。
        if (e && e.status === 413) {
          console.warn('[Sync] 413 payload too large: batch-level transport failure — skip per-item branding/retry-burn, will re-batch next round');
          return { pushed: 0, pulled: 0, error: e.message, retriable: true };
        }

        // 错误分类先行（供状态机与计数分支共用）：
        // network = 探活也不通（脱机/不可达）；其余（5xx/坏响应）= 探活可达但业务请求失败。
        // P1-10 新增：client = 4xx 客户端侧问题（400/404/413/422，重试大概率同错，不喂 5xx 熔断）；
        // forbidden = 403 授权被拒（含 40310 等级未开通云同步）。
        var _isNetwork = !!(e && (e.kind === 'network'
          || (e.message && e.message.indexOf('Network error') === 0)));
        var _isUnauthorized = (e && e.kind === 'unauthorized')
          || (e && e.message && e.message.indexOf('reason=unauthorized') >= 0);
        var _isClient = !!(e && e.kind === 'client');
        var _isForbidden = !!(e && e.kind === 'forbidden');

        // State machine: 网络→OFFLINE；未授权→TOKEN_EXPIRED；探活通但业务请求失败→SERVER_ERROR
        // （修正历史误报：5xx 曾被置成 offline，与真断网混淆）
        if (typeof wpzl_setSyncState === 'function') {
          wpzl_setSyncState(_isUnauthorized ? 'token_expired'
            : (_isNetwork ? 'offline' : 'server_error'));
        }

        // P1-11: 等级未开通云同步（服务端专用业务码 40310）→ Pro 到期/降级，立即关同步。
        // 取代对 message 里 "Pro" 字样的字符串嗅探（任何含 Pro 子串的错误都会误关同步）。
        if (_isForbidden && e && e.serverCode === 40310) {
          if (typeof wpzlSyncEngine !== 'undefined') wpzlSyncEngine.onProChanged(false);
          await _updateHealth(false, 0, 0, 0, 0, e.message);
          return { pushed: 0, pulled: 0, error: e.message };
        }
        // 逐项失败计数（计数权威）：仅 5xx/锁/4xx 客户端错误计数；401/token_expired(_isUnauthorized) 与 40310(上面已 return) 不计。
        // network 错误（脱机/不可达）只记诊断字段，不烧 SYNC_RETRY_COUNT——脱机是环境问题，不应让所有项
        // 耗尽配额（否则重新上线后全部 SYNC_EXHAUSTED，需手动复位才能同步）。
        // P1-1: 计数只作用于**本批**（batch.*.local 与 dirty 数组同一对象引用）——此前一次请求失败
        // 给全部 dirty（含未发送的后续批）+1，服务端半死 10 轮后全体 EXHAUSTED 停推。
        // 连带：imageData 此前从不在计数列表——补齐本批 imageAssets。
        if (!_isUnauthorized) {
          var _cfMaxR = await _getSyncMaxRetries();
          var _cfNowIso = new Date().toISOString();
          var _cfErrMsg = ((e && e.message) || '').slice(0, 500) || null;
          var _batchLocals = {
            annotations: batch.annotations.map(function (x) { return x.local; }),
            pages: batch.pages.map(function (x) { return x.local; }),
            folders: batch.folders.map(function (x) { return x.local; }),
            documents: batch.documents.map(function (x) { return x.local; }),
            snapshots: batch.snapshots.map(function (x) { return x.local; }),
            imageAssets: batch.imageAssets.map(function (x) { return x.local; })
          };
          if (_isNetwork) {
            // network 错误：仅写诊断字段，不 bump 计数、不置 exhausted
            function _cfMark(rec) {
              if (!rec) return;
              rec.SYNC_LAST_ERROR = _cfErrMsg;
              rec.SYNC_LAST_ATTEMPT_AT = _cfNowIso;
            }
            _batchLocals.annotations.forEach(_cfMark);
            _batchLocals.pages.forEach(_cfMark);
            _batchLocals.folders.forEach(_cfMark);
            _batchLocals.documents.forEach(_cfMark);
            _batchLocals.snapshots.forEach(_cfMark);
          } else {
            function _cfBump(rec) {
              if (!rec) return;
              rec.SYNC_RETRY_COUNT = (rec.SYNC_RETRY_COUNT || 0) + 1;
              rec.SYNC_LAST_ERROR = _cfErrMsg;
              rec.SYNC_LAST_ATTEMPT_AT = _cfNowIso;
              if (rec.SYNC_RETRY_COUNT >= _cfMaxR && !rec.SYNC_EXHAUSTED) {
                rec.SYNC_EXHAUSTED = true;
                _broadcastSyncExhausted({ kind: 'batch-fail', id: rec.MARK_INFO_ID || rec.docId || rec.snapId, retryCount: rec.SYNC_RETRY_COUNT }); // P1-14/33
              }
            }
            _batchLocals.annotations.forEach(_cfBump);
            _batchLocals.pages.forEach(_cfBump);
            _batchLocals.folders.forEach(_cfBump);
            _batchLocals.documents.forEach(_cfBump);
            _batchLocals.snapshots.forEach(_cfBump);
          }
          try { await db.putMany('annotations', _batchLocals.annotations); } catch (e2) { /* ignore */ }
          try { await db.putMany('pages', _batchLocals.pages); } catch (e2) { /* ignore */ }
          try { await db.putMany('folders', _batchLocals.folders); } catch (e2) { /* ignore */ }
          try { await db.putMany('documents', _batchLocals.documents); } catch (e2) { /* ignore */ }
          try { await db.putMany('snapshots', _batchLocals.snapshots); } catch (e2) { /* ignore */ }
          try { await db.putMany('imageData', _batchLocals.imageAssets); } catch (e2) { /* ignore */ }
        }
        // 网络/锁错误 — 入离线队列（per-item，enqueueOffline 内部拆分；FIFO 触发器）
        // P1-1: batchIds 只含本批标注（此前 dirty 全集，失败一次即 N×M 膨胀）
        if (uploadDtos.length > 0 || deletedIds.length > 0) {
          await enqueueOffline({
            type: 'sync',
            batchIds: batch.annotations.map(function (x) { return x.local && x.local.MARK_INFO_ID; }).filter(Boolean),
            deletedIds: deletedIds,
            queuedAt: new Date().toISOString(),
            retryCount: 0
          });
        }
        // 续传期间网络失败：保留 pull_cursor（未到 downloadDone 未清），确保 alarm 兜底下轮续传
        if (await _getPullCursor()) _ensureResumeAlarm();
        await _updateHealth(false, 0, 0, 0, 0, e.message);
        // 服务端错误（5xx/坏响应）→ 熔断计数；network 不动 backoff（保持现状侧）；
        // P1-10: client（4xx）与 forbidden（403）不喂熔断——客户端自身问题/授权拒绝连错 3 次
        // 即熔断 30min 会掩盖真实故障。
        if (!_isNetwork && !_isUnauthorized && !_isClient && !_isForbidden) {
          await _recordServerError(e.message);
        }
        return { pushed: 0, pulled: 0, error: e.message };
      }

      var data = resp.data;

      // P1（登出×在途竞争）：清空已发生 → 丢弃本批全部应用（成功置 SYNCED / 冲突处理 /
      // 硬删除 / 游标与 meta 写入都会把旧账号状态种回已清空的库）。上传侧此前无 P1-7
      // 哨兵（当年只护了下载侧），此处在应用起点补上。直接返回走 withSyncLock 正常收尾。
      if (_syncAborted()) {
        console.warn('[Sync] cycle abandoned (logout/switch-user) — in-flight batch response discarded');
        return { pushed: 0, pulled: 0, reason: 'abandoned' };
      }

      // P1-44: token 年龄检测——服务端带 serverNow + 墓碑保留天数，token 内嵌签发时间与之比较。
      // 超过 (retention - 15天) 安全边际 → 置标记，下一轮 sync 走全量对账（本轮已是增量，
      // 立即切全量会与本轮上传/游标状态纠缠）。对账轮自身（_reconcileRequested）不检测。
      if (data.serverNow && syncToken && !_reconcileRequested) {
        var _tokenMs = _syncTokenEpochMs(syncToken);
        var _retentionDays = data.tombstoneRetentionDays || 90;
        if (_tokenMs && (data.serverNow - _tokenMs) > (_retentionDays - 15) * 86400000) {
          try { await _syncSetMeta('full_reconcile_pending', true); } catch (e) { /* ignore */ }
          console.log('[Sync] token age ' + Math.round((data.serverNow - _tokenMs) / 86400000) +
            'd near retention ' + _retentionDays + 'd — full reconcile scheduled for next round');
        }
      }

      // P1-44: 对账轮累计服务端 active 全集
      if (_reconCollect) {
        try {
          var _ra = data.annotations || [];
          for (var _ri = 0; _ri < _ra.length; _ri++) if (_ra[_ri] && _ra[_ri].markInfoId) _reconCollect.ann.add(_ra[_ri].markInfoId);
          var _rp = data.pages || [];
          for (var _rj = 0; _rj < _rp.length; _rj++) if (_rp[_rj] && _rp[_rj].urlMd5) _reconCollect.page.add(_rp[_rj].urlMd5);
          var _rf = data.folders || [];
          for (var _rk = 0; _rk < _rf.length; _rk++) if (_rf[_rk] && _rf[_rk].folderId) _reconCollect.folder.add(_rf[_rk].folderId);
          var _rm = data.imageAssets || [];
          for (var _rl = 0; _rl < _rm.length; _rl++) if (_rm[_rl] && _rm[_rl].pageKey && _rm[_rl].imageKey) _reconCollect.image.add(_rm[_rl].pageKey + '_' + _rm[_rl].imageKey);
          var _rd = data.documents || [];
          for (var _rn = 0; _rn < _rd.length; _rn++) if (_rd[_rn] && _rd[_rn].docId) _reconCollect.doc.add(_rd[_rn].docId);
          var _rs = data.snapshots || [];
          for (var _ro = 0; _ro < _rs.length; _ro++) if (_rs[_ro] && _rs[_ro].snapId) _reconCollect.snap.add(_rs[_ro].snapId);
        } catch (e) { /* ignore */ }
      }

      // 保存 syncToken（末页返回，中间页为 null）
      if (data.syncToken) {
        newSyncToken = data.syncToken;
      }

      // 首次全量同步首页：缓存服务端回传的标注总数供进度展示
      if (data.totalAnnotations != null && _syncDownloadTotal == null) {
        _syncDownloadTotal = data.totalAnnotations;
      }

      // ---- 处理下载数据（服务端返回的 annotations）----
      var serverAnns = data.annotations || [];
      if (serverAnns.length > 0) {
        // 分块批读批写：避免单事务跨 await 失活（TransactionInactiveError）。
        // WPZL_IDB_WRITE_CHUNK=100 与 pages/folders 一致（消除原"annotations 无分块"的不一致）。
        for (var sa = 0; sa < serverAnns.length; sa += WPZL_IDB_WRITE_CHUNK) {
          _throwIfSyncAborted(); // P1-7：分块写事务前检查——登出中则抛哨兵终止本轮
          var annChunk = serverAnns.slice(sa, sa + WPZL_IDB_WRITE_CHUNK);
          var chunkIds = annChunk.map(function (d) { return d.markInfoId; });
          var existingList = await db.getByKeys('annotations', chunkIds);

          var toPut = [];
          var newAnnsForPage = []; // 新标注：批写后统一 fire-and-forget 调 _updatePageRecord
          for (var i = 0; i < annChunk.length; i++) {
            var dto = annChunk[i];
            var localAnn = serverDtoToLocal(dto);
            var existing = existingList[i];

            if (!existing) {
              toPut.push(localAnn);
              newAnnsForPage.push(localAnn);
              totalPulled++;
              _pushCapped(report.pulledAnn, {
                result: 'new', id: localAnn.MARK_INFO_ID,
                url: localAnn.WEB_URI || '', title: localAnn.TITLE || '',
                authorName: localAnn.AUTHOR_NAME || ''
              });
            } else if (existing.SYNC_STATUS === SYNC_STATUS_PENDING_DELETED) {
              continue;
            } else if (existing.SYNC_STATUS === SYNC_STATUS_PENDING ||
                       existing.SYNC_STATUS === SYNC_STATUS_LOCAL) {
              // P1-2 短期修复：本地未推送改动一律跳过下载覆盖（与 pages/folders 既有语义对齐）。
              // 此前仅护 PENDING_DELETED——本地钟慢时 _isServerNewer 字典序误判"服务端更新"，
              // 服务端旧版本覆盖本地新编辑（静默丢失）。跳过后由 push 侧 LWW + _handleConflict
              // 裁决，冲突不静默。
              continue;
            } else {
              // Pull-loop guard (see earlier site for rationale)
              if (existing.SYNC_STATUS === SYNC_STATUS_SYNCED &&
                  _syncGuardSkip(dto.syncedAt, existing.SYNCED_AT)) {
                continue;
              }
              if (_isServerNewer(dto.updateDate, existing.UPDATE_TIME)) {
                // 保留本地独有字段（含截图补传/终态状态，见 _preserveLocalOnlyFields）
                toPut.push(_preserveLocalOnlyFields(localAnn, existing));
                totalPulled++;
                _pushCapped(report.pulledAnn, {
                  result: 'updated', id: localAnn.MARK_INFO_ID,
                  url: localAnn.WEB_URI || '', title: localAnn.TITLE || '',
                  authorName: localAnn.AUTHOR_NAME || ''
                });
              }
            }
          }

          // 批量写（一个 readwrite 事务并发 put，不跨 await）
          if (toPut.length > 0) {
            await db.putMany('annotations', toPut);
            // 批量补建 page 记录（一次事务处理所有新 url，避免逐条 N 次独立事务 + MD5 重算）
            if (newAnnsForPage.length > 0) {
              try { await db._updatePageRecordsForPulled(newAnnsForPage); } catch (e) { /* ignore */ }
            }
          }
        }
      }

      // ---- 处理下载的 page / folder / imageAsset（每页都可能返回）----
      // P0-7: 此前九个应用调用全部 catch{ignore} 且游标照常推进——任一类型合并失败
      // （IDB abort、磁盘满、畸形记录抛错）即该页该类型数据永久跳过（静默漏下载），
      // 唯一恢复是清 sync_token 全量重拉。现记录失败类型，游标推进处按类型条件推进。
      var _applyFail = { pages: false, folders: false, imageAssets: false,
                         deletedPages: false, deletedFolders: false,
                         documents: false, deletedDocuments: false,
                         snapshots: false, deletedSnapshots: false };
      var _pageRes = { count: 0, written: [] };
      try { _pageRes = await _applyDownloadedPages(data.pages || []); }
      catch (e) {
        if (e && e.message === WPZL_SYNC_ABORTED_ERR) throw e; // P1-7：登出哨兵直接上抛终止本轮
        _applyFail.pages = true; console.warn('[Sync] apply downloaded pages failed (pageCursor held):', e && e.message); }
      totalPulled += _pageRes.count || 0;
      var _folderRes = { count: 0, written: [] };
      try { _folderRes = await _applyDownloadedFolders(data.folders || []); }
      catch (e) {
        if (e && e.message === WPZL_SYNC_ABORTED_ERR) throw e; // P1-7：登出哨兵直接上抛终止本轮
        _applyFail.folders = true; console.warn('[Sync] apply downloaded folders failed (folderCursor held):', e && e.message); }
      totalPulled += _folderRes.count || 0;
      try {
        var _imgApplied = await _applyDownloadedImageAssets(data.imageAssets || []);
        totalPulled += _imgApplied;
        totalPulledImageAssets += _imgApplied;
      } catch (e) {
        if (e && e.message === WPZL_SYNC_ABORTED_ERR) throw e; // P1-7：登出哨兵直接上抛终止本轮
        _applyFail.imageAssets = true; console.warn('[Sync] apply downloaded imageAssets failed (imageAssetCursor held):', e && e.message); }
      try { totalDeleted += await _applyDeletedPages(data.deletedPageUrlMd5s || []); }
      catch (e) {
        if (e && e.message === WPZL_SYNC_ABORTED_ERR) throw e; // P1-7：登出哨兵直接上抛终止本轮
        _applyFail.deletedPages = true; console.warn('[Sync] apply deleted pages failed (pageCursor held):', e && e.message); }
      try { totalDeleted += await _applyDeletedFolders(data.deletedFolderIds || []); }
      catch (e) {
        if (e && e.message === WPZL_SYNC_ABORTED_ERR) throw e; // P1-7：登出哨兵直接上抛终止本轮
        _applyFail.deletedFolders = true; console.warn('[Sync] apply deleted folders failed (folderCursor held):', e && e.message); }
      // P1-13 连带：消费服务端下发的 imageAsset 删除墓碑（对端传播下行侧）。失败持有 imageAssetCursor。
      try { totalDeleted += await _applyDeletedImageAssetKeys(data.deletedImageAssetKeys || []); }
      catch (e) {
        if (e && e.message === WPZL_SYNC_ABORTED_ERR) throw e; // P1-7：登出哨兵直接上抛终止本轮
        _applyFail.imageAssets = true; console.warn('[Sync] apply deleted imageAssets failed (imageAssetCursor held):', e && e.message); }
      try { totalPulled += await _applyDownloadedDocuments(data.documents || []); }
      catch (e) {
        if (e && e.message === WPZL_SYNC_ABORTED_ERR) throw e; // P1-7：登出哨兵直接上抛终止本轮
        _applyFail.documents = true; console.warn('[Sync] apply downloaded documents failed (documentCursor held):', e && e.message); }
      try { totalDeleted += await _applyDeletedDocuments(data.deletedDocIds || []); }
      catch (e) {
        if (e && e.message === WPZL_SYNC_ABORTED_ERR) throw e; // P1-7：登出哨兵直接上抛终止本轮
        _applyFail.deletedDocuments = true; console.warn('[Sync] apply deleted documents failed (documentCursor held):', e && e.message); }
      try { totalPulled += await _applyDownloadedSnapshots(data.snapshots || []); }
      catch (e) {
        if (e && e.message === WPZL_SYNC_ABORTED_ERR) throw e; // P1-7：登出哨兵直接上抛终止本轮
        _applyFail.snapshots = true; console.warn('[Sync] apply downloaded snapshots failed (snapshotCursor held):', e && e.message); }
      try { totalDeleted += await _applyDeletedSnapshots(data.deletedSnapIds || []); }
      catch (e) {
        if (e && e.message === WPZL_SYNC_ABORTED_ERR) throw e; // P1-7：登出哨兵直接上抛终止本轮
        _applyFail.deletedSnapshots = true; console.warn('[Sync] apply deleted snapshots failed (snapshotCursor held):', e && e.message); }

      // 更新可查询进度（manager 主动查询时使用，不依赖 push 消息时序）
      _syncDownloadPulled = totalPulled;

      // 广播下载进度（manager 页面实时更新 overlay 文字和即时渲染侧栏）
      try {
        chrome.runtime.sendMessage(
          { type: 'wpzl-sync-progress', pulled: totalPulled, pushed: totalPushed, total: _syncDownloadTotal },
          function () { void chrome.runtime.lastError; }
        );
      } catch (e) { /* ignore */ }

      // 同步报告：仅记录实际写入的 page / folder（去重 guard 跳过的不计，避免"本地已有却显示已下载"虚胖）
      var _writtenPages = (_pageRes && _pageRes.written) || [];
      for (var pp = 0; pp < _writtenPages.length; pp++) {
        _pushCapped(report.pulledPage, _writtenPages[pp]);
      }
      if (report.pulledPage.length === REPORT_CAP + 1) {
        report.pulledPage.pop();
        report.pulledPageOverflow = Math.max(0, _writtenPages.length - REPORT_CAP);
      }
      var _writtenFolders = (_folderRes && _folderRes.written) || [];
      for (var ff = 0; ff < _writtenFolders.length; ff++) {
        _pushCapped(report.pulledFolder, _writtenFolders[ff]);
      }
      if (report.pulledFolder.length === REPORT_CAP + 1) {
        report.pulledFolder.pop();
        report.pulledFolderOverflow = Math.max(0, _writtenFolders.length - REPORT_CAP);
      }
      // 删除明细（page / folder 来自服务端确认）
      var _svDelPages = data.deletedPageUrlMd5s || [];
      for (var dpp = 0; dpp < _svDelPages.length; dpp++) {
        report.deletedPage.push({ urlMd5: _svDelPages[dpp] });
      }
      var _svDelFolders = data.deletedFolderIds || [];
      for (var dff = 0; dff < _svDelFolders.length; dff++) {
        report.deletedFolder.push({ id: _svDelFolders[dff] });
      }

      // ---- 处理上传结果（仅针对本轮发送的 batch）----
      var conflictList = data.conflicts || [];
      var rejectedList = data.rejected || [];
      // D-15: 标注配额逐条软拒（服务端 rejectedAnnotations/rejectedAnnotationReasons，与 docs/snaps
      // 语义对齐）——带原因标 ERROR+计数重试（配额类属瞬时失败，quota 释放/调额后重试可过），
      // 不再把整批拖成 400 硬失败后的无限重推。
      var quotaRejectReasons = data.rejectedAnnotationReasons || {};
      var conflictIds = new Set();
      var rejectIds = new Set();
      var _markLimitHit = false; // mark_limit 软拒命中标记（本轮收尾置阻断标志 + 达限提示）
      var _dailyMarkLimitHit = false; // V69: daily_mark_limit 软拒命中标记（同上）
      var _importLimitHit = false; // V70: import_limit 软拒命中标记（同上）

      for (var ci = 0; ci < conflictList.length; ci++) {
        conflictIds.add(conflictList[ci].markInfoId);
      }
      for (var ri = 0; ri < rejectedList.length; ri++) {
        rejectIds.add(rejectedList[ri].markInfoId);
      }

      // 处理本轮上传标注的状态
      if (batch.annotations.length > 0) {
        var _maxRetries = await _getSyncMaxRetries();
        var _nowIsoSync = new Date().toISOString();
        var syncResultStore = db._tx('annotations', 'readwrite');
        for (var j = 0; j < batch.annotations.length; j++) {
          var ann = batch.annotations[j].local;
          var _origBits = ann.DIRTY_BITS;
          var _origStatus = ann.SYNC_STATUS;
          var _webUri = ann.WEB_URI || '';
          var _title = ann.TITLE || '';
          if (conflictIds.has(ann.MARK_INFO_ID)) {
            totalConflicts++;
            _pushCapped(report.pushedAnn, {
              result: 'conflict', id: ann.MARK_INFO_ID, url: _webUri, title: _title,
              dirtyFields: decodeDirtyBits(_origBits, 'annotation'),
              prevStatus: _origStatus
            });
          } else if (quotaRejectReasons[ann.MARK_INFO_ID] !== undefined) {
            // D-15 配额软拒：与文档/快照同款语义——带原因标 ERROR；瞬时失败计数重试，
            // 越限置 SYNC_EXHAUSTED 并广播（失败查看器可见拒绝原因）。
            var _qReason = quotaRejectReasons[ann.MARK_INFO_ID];
            ann.SYNC_STATUS = SYNC_STATUS_ERROR;
            ann.SYNC_LAST_ERROR = _qReason || 'rejected by server';
            ann.SYNC_LAST_ATTEMPT_AT = _nowIsoSync;
            if (_isMarkLimitRejectionReason(_qReason)) {
              // 标注总量达限：立即耗尽防每轮整批重推（同 cloud_quota 语义），失败查看器可读原因；
              // 升级/管理员调额后由 _maybeResumeMarkLimitExhausted 探测自动复位重传。
              // 不触发 wpzl_quota_blocked/_maybeShowQuotaToast——那是存储配额链路，"云端存储已满"文案会误导。
              if (!ann.SYNC_EXHAUSTED) {
                ann.SYNC_EXHAUSTED = true;
                _broadcastSyncExhausted({ kind: 'annotation', id: ann.MARK_INFO_ID, reason: _qReason });
              }
              _markLimitHit = true;
            } else if (_isDailyMarkLimitRejectionReason(_qReason)) {
              // V69: 每日创建达限（同 mark_limit 语义立即耗尽）；跨天服务端计数归零后由
              // _maybeResumeDailyMarkLimitExhausted 探测自动复位重传。
              if (!ann.SYNC_EXHAUSTED) {
                ann.SYNC_EXHAUSTED = true;
                _broadcastSyncExhausted({ kind: 'annotation', id: ann.MARK_INFO_ID, reason: _qReason });
              }
              _dailyMarkLimitHit = true;
            } else if (_isImportLimitRejectionReason(_qReason)) {
              // V70: 每日导入额度达限（导入数据豁免每日新建后的共享上限）；跨天/调额后由
              // _maybeResumeImportLimitExhausted 探测自动复位重传。
              if (!ann.SYNC_EXHAUSTED) {
                ann.SYNC_EXHAUSTED = true;
                _broadcastSyncExhausted({ kind: 'annotation', id: ann.MARK_INFO_ID, reason: _qReason });
              }
              _importLimitHit = true;
            } else if (_isPermanentRejectionReason(_qReason)) {
              if (!ann.SYNC_EXHAUSTED) {
                ann.SYNC_EXHAUSTED = true;
                _broadcastSyncExhausted({ kind: 'annotation', id: ann.MARK_INFO_ID, reason: _qReason });
              }
            } else {
              ann.SYNC_RETRY_COUNT = (ann.SYNC_RETRY_COUNT || 0) + 1;
              if (ann.SYNC_RETRY_COUNT >= _maxRetries && !ann.SYNC_EXHAUSTED) {
                ann.SYNC_EXHAUSTED = true;
                _broadcastSyncExhausted({ kind: 'annotation', id: ann.MARK_INFO_ID, retryCount: ann.SYNC_RETRY_COUNT });
              }
            }
            syncResultStore.put(ann);
            totalRejected++;
            _pushCapped(report.pushedAnn, {
              result: 'rejected', id: ann.MARK_INFO_ID, url: _webUri, title: _title,
              dirtyFields: decodeDirtyBits(_origBits, 'annotation'),
              prevStatus: _origStatus, reason: _qReason
            });
          } else if (rejectIds.has(ann.MARK_INFO_ID)) {
            ann.SYNC_STATUS = SYNC_STATUS_ERROR;
            // 计数权威：rejected 自增 SYNC_RETRY_COUNT，越限置 SYNC_EXHAUSTED（保留不丢）
            ann.SYNC_RETRY_COUNT = (ann.SYNC_RETRY_COUNT || 0) + 1;
            ann.SYNC_LAST_ERROR = 'rejected by server';
            ann.SYNC_LAST_ATTEMPT_AT = _nowIsoSync;
            if (ann.SYNC_RETRY_COUNT >= _maxRetries && !ann.SYNC_EXHAUSTED) {
              ann.SYNC_EXHAUSTED = true;
              _broadcastSyncExhausted({ kind: 'annotation', id: ann.MARK_INFO_ID, retryCount: ann.SYNC_RETRY_COUNT }); // P1-14/33
            }
            syncResultStore.put(ann);
            totalRejected++;
            _pushCapped(report.pushedAnn, {
              result: 'rejected', id: ann.MARK_INFO_ID, url: _webUri, title: _title,
              dirtyFields: decodeDirtyBits(_origBits, 'annotation'),
              prevStatus: _origStatus
            });
          } else {
            ann.SYNC_STATUS = SYNC_STATUS_SYNCED;
            ann.DIRTY_BITS = 0;
            // 成功：复位重试计数/耗尽态
            ann.SYNC_RETRY_COUNT = 0;
            ann.SYNC_EXHAUSTED = false;
            ann.SERVER_UPDATE_TIME = ann.UPDATE_TIME;
            // 用当前登录 userId 纠正本地 USER_ID（服务端以 JWT 为权威）
            if (_currentUid && ann.USER_ID !== String(_currentUid)) {
              ann.USER_ID = String(_currentUid);
            }
            ann.SYNCED_AT = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
            syncResultStore.put(ann);
            totalPushed++;
            _pushCapped(report.pushedAnn, {
              result: 'accepted', id: ann.MARK_INFO_ID, url: _webUri, title: _title,
              dirtyFields: decodeDirtyBits(_origBits, 'annotation'),
              prevStatus: _origStatus
            });
          }
        }
      }
      // 标注总量软拒收尾：置阻断标志（供每轮成功后的释放探测）+ 专用达限提示（30 分钟冷却）
      if (_markLimitHit) {
        var _mlHitLimit = null;
        try {
          var _mlHitPro = await wpzl_getProStatus();
          _mlHitLimit = _mlHitPro && _mlHitPro.limits && _mlHitPro.limits.markLimit;
        } catch (e2) { /* limits 读不到时 toast 走无数字版本 */ }
        _setMarkLimitBlocked(true);
        _maybeShowMarkLimitToast(_mlHitLimit);
      }
      // V69: 每日限额软拒收尾（同上）
      if (_dailyMarkLimitHit) {
        var _dmlHitLimit = null;
        try {
          var _dmlHitPro = await wpzl_getProStatus();
          _dmlHitLimit = _dmlHitPro && _dmlHitPro.limits && _dmlHitPro.limits.dailyMarkLimit;
        } catch (e2) { /* limits 读不到时 toast 走无数字版本 */ }
        _setDailyMarkBlocked(true);
        _maybeShowDailyMarkLimitToast(_dmlHitLimit);
      }
      // V70: 导入额度软拒收尾（同上：置阻断标志 + 节流 toast）
      if (_importLimitHit) {
        var _ilHitLimit = null;
        try {
          var _ilHitPro = await wpzl_getProStatus();
          _ilHitLimit = _ilHitPro && _ilHitPro.limits && _ilHitPro.limits.dailyImportLimit;
        } catch (e3) { /* limits 读不到时 toast 走无数字版本 */ }
        _setImportLimitBlocked(true);
        _maybeShowImportLimitToast(_ilHitLimit);
      }

      if (report.pushedAnn.length === REPORT_CAP + 1) {
        report.pushedAnn.pop();
        report.pushedAnnOverflow = Math.max(0, report.attemptedPushAnn - REPORT_CAP);
      }

      // 冲突裁决（用 dirtyMap 索引）：交给 _handleConflict 做 LWW 下载比对——
      // 服务端 newer 则用 serverDtoToLocal 覆盖本地，本地 newer 则保留 DIRTY_BITS 重标 PENDING 下轮重推。
      // 绝不能再无脑标 synced+清 dirty：那会让被拒字段（如 thumbnail 补传）永久静默丢失、本地却以为成功。
      // （与 legacy push() 路径 line 1341 的处理保持一致。）
      for (var csi = 0; csi < conflictList.length; csi++) {
        var conflictAnn = dirtyMap[conflictList[csi].markInfoId];
        if (conflictAnn) {
          await _handleConflict(conflictAnn, conflictList[csi].serverVersion);
        }
      }

      // 硬删除本轮确认已删除的标注（仅本轮 batch.deletedIds 已被服务端接收）
      if (batch.deletedIds.length > 0) {
        var delStore = db._tx('annotations', 'readwrite');
        for (var di = 0; di < batch.deletedIds.length; di++) {
          delStore.delete(batch.deletedIds[di]);
        }
        // P2-6: 级联清 localThumbnails——标注行已确认删除，本地缩略图缓存无读取方
        // （deleteByKeys 自带新事务，不在上方 annotations 事务内 await）
        try { await db.deleteByKeys('localThumbnails', batch.deletedIds); } catch (e) { /* ignore */ }
        for (var did = 0; did < batch.deletedIds.length; did++) {
          report.deletedAnn.push({ id: batch.deletedIds[did] });
        }
      }

      // 处理服务端已删除的标注（批量读 + 内存判断 + 批量删，避免跨 await 复用单事务失活）
      var serverDeletedIds = data.deletedIds || [];
      if (serverDeletedIds.length > 0) {
        var sDelExistingList = await db.getByKeys('annotations', serverDeletedIds);
        var sDelToDelete = [];
        for (var sdi = 0; sdi < serverDeletedIds.length; sdi++) {
          var sDelExisting = sDelExistingList[sdi];
          if (sDelExisting && sDelExisting.SYNC_STATUS !== SYNC_STATUS_PENDING && sDelExisting.SYNC_STATUS !== SYNC_STATUS_LOCAL) {
            sDelToDelete.push(serverDeletedIds[sdi]);
          }
        }
        if (sDelToDelete.length > 0) {
          await db.deleteByKeys('annotations', sDelToDelete);
          // P2-6: 级联清 localThumbnails（墓碑确认硬删，同步用户的主删除路径）
          try { await db.deleteByKeys('localThumbnails', sDelToDelete); } catch (e) { /* ignore */ }
          totalDeleted += sDelToDelete.length;
        }
      }

      // ---- 处理本轮 page / folder / imageAsset / document 上传结果（仅针对 batch）----
      if (batch.pages.length > 0 || batch.folders.length > 0 || batch.imageAssets.length > 0 || batch.documents.length > 0 || batch.snapshots.length > 0) {
        var _rejectedPageSet = new Set(data.rejectedPageUrlMd5s || []);
        var _rejectedFolderSet = new Set(data.rejectedFolderIds || []);
        var _batchDirtyPages = batch.pages.map(function (x) { return x.local; });
        var _batchDirtyFolders = batch.folders.map(function (x) { return x.local; });
        var _batchDirtyImageAssets = batch.imageAssets.map(function (x) { return x.local; });
        var _batchDirtyDocuments = batch.documents.map(function (x) { return x.local; });
        var _batchDirtySnapshots = batch.snapshots.map(function (x) { return x.local; });
        try { await _markPageUploadResult(_batchDirtyPages, data.rejectedPageUrlMd5s || [], data.rejectedPageReasons || {}); } catch (e) { /* ignore */ }
        try { await _markFolderUploadResult(_batchDirtyFolders, data.rejectedFolderIds || []); } catch (e) { /* ignore */ }
        // P1-41: degraded 轮的 storage_error 拒绝不算失败——从 dirty 数组剔除后再传 _mark*（不能
        // 从 reasons map 里删：_mark* 对不在 map 的记录走"成功"分支会误置 SYNCED）。
        // 被剔除的记录不触碰 IDB（保持 pending dirty），不烧 SYNC_RETRY_COUNT；
        // 非 degraded 的零星 storage_error 维持原瞬时失败计数。
        var _keptDocs = data.degraded ? _batchDirtyDocuments.filter(function (dd) {
          return (data.rejectedDocReasons || {})[dd.docId] !== 'storage_error';
        }) : _batchDirtyDocuments;
        var _keptSnaps = data.degraded ? _batchDirtySnapshots.filter(function (ss) {
          return (data.rejectedSnapReasons || {})[ss.snapId] !== 'storage_error';
        }) : _batchDirtySnapshots;
        try { await _markDocumentUploadResult(_keptDocs, data.rejectedDocReasons || {}); } catch (e) { /* ignore */ }
        try { await _markSnapshotUploadResult(_keptSnaps, data.rejectedSnapReasons || {}); } catch (e) { /* ignore */ }
        if (data.degraded) {
          // 10min 静默退避窗（manual 可穿透；窗内自动同步空 doc/snap 上传，R2 恢复后自动续传）
          try {
            await _syncSetMeta('r2_degraded_until', Date.now() + 10 * 60 * 1000);
            console.info('[Sync] R2 degraded (storage_error) — doc/snap auto-upload backed off 10min');
          } catch (e) { /* ignore */ }
        }
        try {
          await _markImageAssetUploadResult(_batchDirtyImageAssets, data.rejectedImageAssetKeys || []);
          totalPushedImageAssets += _batchDirtyImageAssets.length;
        } catch (e) { /* ignore */ }

        // 同步报告：上传的 page / folder 明细
        for (var pj = 0; pj < _batchDirtyPages.length; pj++) {
          var _pd = _batchDirtyPages[pj];
          _pushCapped(report.pushedPage, {
            result: _rejectedPageSet.has(_pd.URL_MD5 || _pd.url_md5) ? 'rejected' : 'accepted',
            url: _pd.url || '', title: _pd.title || chrome.i18n.getMessage('noTitle'),
            dirtyFields: decodeDirtyBits(_pd.DIRTY_BITS, 'page'),
            prevStatus: _pd.SYNC_STATUS
          });
        }
        if (report.pushedPage.length === REPORT_CAP + 1) {
          report.pushedPage.pop();
          report.pushedPageOverflow = Math.max(0, report.attemptedPushPage - REPORT_CAP);
        }
        for (var fk = 0; fk < _batchDirtyFolders.length; fk++) {
          var _fd = _batchDirtyFolders[fk];
          _pushCapped(report.pushedFolder, {
            result: _rejectedFolderSet.has(_fd.FOLDER_ID || _fd.folderId) ? 'rejected' : 'accepted',
            id: _fd.FOLDER_ID || _fd.folderId,
            name: _fd.NAME || _fd.name || chrome.i18n.getMessage('unnamedDoc'),
            prevStatus: _fd.SYNC_STATUS
          });
        }
        if (report.pushedFolder.length === REPORT_CAP + 1) {
          report.pushedFolder.pop();
          report.pushedFolderOverflow = Math.max(0, report.attemptedPushFolder - REPORT_CAP);
        }
      }

      // 硬删除已确认删除的 page / folder / imageAsset（严格 tombstone：仅删服务端 acceptedDeletedXxx 命中的）
      // 老 server 不返回该字段时 fallback 到本轮推送全集（沿用旧行为）。
      // 未确认的保留 PENDING_DELETED 下轮重试，避免本地误删导致 pull 复活。
      if (batch.deletedPageUrlMd5s.length > 0 || batch.deletedFolderIds.length > 0 || batch.deletedImageAssetKeys.length > 0 || batch.deletedDocIds.length > 0 || batch.deletedSnapIds.length > 0) {
        var _acceptedDelPageSet = new Set(data.acceptedDeletedPageUrlMd5s || batch.deletedPageUrlMd5s);
        var _acceptedDelFolderSet = new Set(data.acceptedDeletedFolderIds || batch.deletedFolderIds);
        var _acceptedDelImageAssetSet = new Set(data.acceptedDeletedImageAssetKeys || batch.deletedImageAssetKeys);
        var _acceptedDelDocSet = new Set(data.acceptedDeletedDocIds || batch.deletedDocIds);
        var _acceptedDelSnapSet = new Set(data.acceptedDeletedSnapIds || batch.deletedSnapIds);
        var _confirmedPageDeletes = batch.deletedPageUrlMd5s.filter(function (id) { return _acceptedDelPageSet.has(id); });
        var _confirmedFolderDeletes = batch.deletedFolderIds.filter(function (id) { return _acceptedDelFolderSet.has(id); });
        // P1-13: imageAsset 墓碑确认语义扩展——不在 rejected 里的都视为删除已达成：
        // accepted 命中=服务端已软删；两者都不在=服务端已无该行（早已删/从未上云），
        // 重试无意义且墓碑会永挂。仅 rejected（罕见，如行级校验失败）保留重试。
        var _rejectedImageAssetSet = new Set(data.rejectedImageAssetKeys || []);
        var _confirmedImageAssetDeletes = batch.deletedImageAssetKeys.filter(function (k) {
          return _acceptedDelImageAssetSet.has(k) || !_rejectedImageAssetSet.has(k);
        });
        var _confirmedDocDeletes = batch.deletedDocIds.filter(function (id) { return _acceptedDelDocSet.has(id); });
        var _confirmedSnapDeletes = batch.deletedSnapIds.filter(function (id) { return _acceptedDelSnapSet.has(id); });
        try { await _hardDeletePagesByUrlMd5(_confirmedPageDeletes); } catch (e) { /* ignore */ }
        try { await _hardDeleteFoldersById(_confirmedFolderDeletes); } catch (e) { /* ignore */ }
        try { await _hardDeleteImageAssetsByBizKey(_confirmedImageAssetDeletes); } catch (e) { /* ignore */ }
        try { await _hardDeleteDocumentsById(_confirmedDocDeletes); } catch (e) { /* ignore */ }
        try { await _hardDeleteSnapshotsById(_confirmedSnapDeletes); } catch (e) { /* ignore */ }
        if (_confirmedFolderDeletes.length < batch.deletedFolderIds.length || _confirmedPageDeletes.length < batch.deletedPageUrlMd5s.length) {
          console.log('[Sync] strict tombstone (sync): folder confirmed=' + _confirmedFolderDeletes.length + '/' + batch.deletedFolderIds.length +
            ', page confirmed=' + _confirmedPageDeletes.length + '/' + batch.deletedPageUrlMd5s.length + ' (unconfirmed kept as PENDING_DELETED)');
        }
      }

      // P0-7: 游标按类型条件推进——应用失败的类型保留原游标值，下轮按原游标重拉同页/同窗口
      //（服务端行 syncedAt 未变，增量窗口内会重发；六游标独立互不影响）。
      // annotations 主体未包裹 try（抛出即中断整轮、游标不落盘），无需条件推进。
      cursor = data.cursor; // null = annotations 末页
      if (!_applyFail.pages && !_applyFail.deletedPages) pageCursor = data.pageCursor; // null = pages 末页
      if (!_applyFail.folders && !_applyFail.deletedFolders) folderCursor = data.folderCursor; // null = folders 末页
      if (!_applyFail.imageAssets) imageAssetCursor = data.imageAssetCursor; // null = imageAssets 末页
      if (!_applyFail.documents && !_applyFail.deletedDocuments) documentCursor = data.documentCursor; // null = documents 末页
      if (!_applyFail.snapshots && !_applyFail.deletedSnapshots) snapshotCursor = data.snapshotCursor; // null = snapshots 末页

      // 断点续传（Bug 7）：持久化下载进度。下载完成则清 cursor+alarm；否则存供 SW 重启续传
      var downloadDone = (cursor == null && pageCursor == null && folderCursor == null && imageAssetCursor == null && documentCursor == null && snapshotCursor == null);
      if (downloadDone) {
        await _clearPullCursor();
      } else {
        await _savePullCursor(cursor, pageCursor, folderCursor, imageAssetCursor, documentCursor, snapshotCursor);
        _ensureResumeAlarm(); // 大同步进行中：确保 SW 被杀后 alarm 兜底续传
      }

      // 终止条件：上传队列空 + 下载完成（连带补 snapshot 墓碑队列检查——漏检会在快照墓碑
      // 待传时提前 break，靠下轮 tick 补传）
      var queueEmpty = uploadQueue.length === 0
          && remainingDeletes.ann.length === 0
          && remainingDeletes.page.length === 0
          && remainingDeletes.folder.length === 0
          && remainingDeletes.imageAsset.length === 0
          && remainingDeletes.document.length === 0
          && remainingDeletes.snapshot.length === 0;
      // P0-7 连带保护：见循环前注释。任何类型应用失败 → 游标被持有 → downloadDone 恒 false，
      // 若不跳出将同游标无限重拉。连续 2 轮失败即 break，resume alarm（1min）稍后续传重试。
      var _anyApplyFail = _applyFail.pages || _applyFail.folders || _applyFail.imageAssets ||
        _applyFail.deletedPages || _applyFail.deletedFolders || _applyFail.documents ||
        _applyFail.deletedDocuments || _applyFail.snapshots || _applyFail.deletedSnapshots;
      if (_anyApplyFail) {
        _consecutiveApplyFails++;
        if (_consecutiveApplyFails >= 2) {
          console.warn('[Sync] download apply failed twice in a row — abort this round, resume alarm will retry');
          break;
        }
      } else {
        _consecutiveApplyFails = 0;
      }
      // G-4 回灌限速：大批量导入回灌期间批间加间隔，抹平服务端突发（回灌在队尾，
      // 限速实际只作用于普通脏数据排空后的回灌阶段）
      if (_backfillPacing && !queueEmpty) {
        await new Promise(function (r) { setTimeout(r, IMPORT_BACKFILL_PACING_MS); });
      }
      if (queueEmpty && downloadDone) break;

    } while (true);

    // ---- P1-44: 对账 diff（仅对账轮且六类分页全部拉尽；中断轮游标非 null，标记保留下轮重做）----
    if (_reconcileRequested && _reconCollect && !_syncAborted() &&
        cursor == null && pageCursor == null && folderCursor == null &&
        imageAssetCursor == null && documentCursor == null && snapshotCursor == null) {
      await _runFullReconcileDiff(_reconCollect);
      _reconCollect = null;
      await _syncSetMeta('full_reconcile_pending', false);
      await _syncSetMeta('last_full_reconcile_at', new Date().toISOString());
    }

    // ---- 保存 syncToken 和状态 ----
    if (!_syncAborted()) {
      if (newSyncToken) {
        await _syncSetMeta('sync_token', newSyncToken);
      }
      await _syncSetMeta('last_push_time', new Date().toISOString());
      await _syncSetMeta('last_pull_time', new Date().toISOString());
      await _updateHealth(true, totalPushed, totalPulled, totalConflicts, totalRejected);
      // 配额释放探测（wpzl_quota_blocked 为真才发探测请求）：用户清理空间/管理员调额后，
      // 自动复位配额耗尽项并重传，无需重新登录或手动重试。fire-and-forget 不阻塞本轮收尾。
      _maybeResumeQuotaExhausted().catch(function () { /* ignore */ });
      // 标注总量限额释放探测同款（wpzl_mark_limit_blocked 为真才发探测请求）
      _maybeResumeMarkLimitExhausted().catch(function () { /* ignore */ });
      // V69: 每日限额释放探测（跨天服务端计数归零后自动复位重传）
      _maybeResumeDailyMarkLimitExhausted().catch(function () { /* ignore */ });
      // page/doc/snap 限额释放探测（wpzl_pds_limit_blocked_<kind> 任一为真才发请求，60 分钟冷却）
      _maybeResumePageDocSnapLimitExhausted().catch(function () { /* ignore */ });
      _maybeResumeImportLimitExhausted().catch(function () { /* ignore */ });
    }

    // pulledAnn overflow 收尾
    if (report.pulledAnn.length === REPORT_CAP + 1) {
      report.pulledAnn.pop();
      report.pulledAnnOverflow = Math.max(0, totalPulled - REPORT_CAP);
    }

    console.log('[Sync] Unified sync complete: pushed=' + totalPushed + ' pulled=' + totalPulled +
      ' conflicts=' + totalConflicts + ' rejected=' + totalRejected + ' deleted=' + totalDeleted +
      ' | imageAssets(push=' + totalPushedImageAssets + ', pull=' + totalPulledImageAssets + ')' +
      ' | report(pushAnn=' + report.pushedAnn.length + '/' + report.attemptedPushAnn +
      ',pushPage=' + report.pushedPage.length + '/' + report.attemptedPushPage +
      ',pushFolder=' + report.pushedFolder.length + '/' + report.attemptedPushFolder +
      ',pullAnn=' + report.pulledAnn.length + ',pullPage=' + report.pulledPage.length + ')');

    // State machine: success → ONLINE
    if (typeof wpzl_setSyncState === 'function') {
      wpzl_setSyncState('online', {
        lastSyncAt: Date.now(),
        pushed: totalPushed,
        pulled: totalPulled
      });
    }

    // 2026-10-04 方案2：本轮 sync 成功收尾 → 错峰启动后台图片/文档下载链（3-8s 抖动，
    // image/doc 相互错开）。消掉重登后"首批干等 ≤60s alarm"的起步延迟；延后错峰避免
    // 与 pull 峰值/收尾配额探测请求叠加（服务端全局限流桶 600/min）。无待办时批处理器
    // 自空转出清（确认真空才清 alarm），无副作用；_chainTimer 去重守卫防重排已排定的链。
    try {
      if (typeof _scheduleBgDownloadAfterSync === 'function') _scheduleBgDownloadAfterSync();
    } catch (e) { /* ignore */ }

    return {
      pushed: totalPushed, pulled: totalPulled,
      conflicts: totalConflicts, rejected: totalRejected, deleted: totalDeleted,
      pushedImageAssets: totalPushedImageAssets,
      pulledImageAssets: totalPulledImageAssets,
      report: report
    };
  }).catch(function (e) {
    // P1-7：登出中途哨兵——本轮已在 _applyDownloaded* 各分块写事务前检测到 _syncAbandoned
    // 并中止写入。此处静默收尾：不计失败、不烧重试计数、不做 token_expired 噪声广播
    //（登出/换号流程自身管理状态与 UI），避免在飞周期把旧账号数据写回已清空的 IDB。
    if (e && e.message === WPZL_SYNC_ABORTED_ERR) {
      console.log('[Sync] cycle aborted mid-flight (logout/switch-user) — no writes, no failure accounting');
      return { pushed: 0, pulled: 0, reason: 'aborted' };
    }
    throw e;
  });
}

// ---- Debounce / Request Sync ----

function requestSync(priority) {
  if (!_syncEnabled) {
    // init 仍在进行 → 入待办队列（取较高优先级），init 完成后 flush
    // init 已完成但仍未启用（未登录/非 Pro）→ 真正 skip
    var initState = _initState;
    if (initState === 'pending' || initState === 'running') {
      _pendingSyncRequest = (_pendingSyncRequest === 'immediate' || priority === 'immediate')
        ? 'immediate'
        : (priority || _pendingSyncRequest || 'normal');
      console.log('[Sync] requestSync(' + priority + ') deferred (init=' + initState + '), pending=' + _pendingSyncRequest);
    } else {
      console.log('[Sync] requestSync(' + priority + ') skipped (_syncEnabled=false, init=' + initState + ')');
    }
    return;
  }
  console.log('[Sync] requestSync(' + priority + ') caller=' + _extractCaller(new Error().stack));

  if (priority === 'immediate') {
    clearTimeout(_debounceTimer);
    _debounceTimer = setTimeout(function () {
      _debounceTimer = null;
      console.log('[Sync] immediate debounce fired, calling sync()');
      wpzlSyncEngine.sync().catch(function (e) {
        console.warn('[Sync] Immediate sync failed:', e.message);
      });
    }, 100);
  } else {
    if (_debounceTimer) {
      console.log('[Sync] requestSync(' + priority + ') debounce already pending, skip');
      return;
    }
    var debounceMs = _getPushDebounceMs();
    _debounceTimer = setTimeout(function () {
      _debounceTimer = null;
      console.log('[Sync] normal debounce(' + debounceMs + 'ms) fired, calling sync()');
      wpzlSyncEngine.sync().catch(function (e) {
        console.warn('[Sync] Debounced sync failed:', e.message);
      });
    }, debounceMs);
  }
}

// init 完成后若启用了同步且有 pending 请求，flush 一次（让 SW 重启窗口期的目录操作可靠入网）
function _flushPendingSyncRequest() {
  if (!_syncEnabled || !_pendingSyncRequest) return;
  var pending = _pendingSyncRequest;
  _pendingSyncRequest = null;
  console.log('[Sync] flushing deferred sync request after init: ' + pending);
  try { requestSync(pending); } catch (e) { /* ignore */ }
}

// ---- Lazy Pull ----
// 用户打开页面时触发，立即拉取该页面的最新标注。
// 使用有冷却的全局 pull，增量查询开销很小。

async function pullForUrlIfNeeded(url) {
  if (!(await isSyncAllowed())) return;
  var now = Date.now();
  var lastPull = _recentPulls._global;
  if (lastPull && (now - lastPull) < PULL_COOLDOWN_MS) return;
  // P2-4: 先占位再 sync（保留原防多 tab 并发双 sync 语义），失败回滚冷却——
  // 否则网络/服务端失败也烧掉 5min 冷却，下个页面访问无法重试。
  _recentPulls._global = now;
  var result;
  try {
    result = await sync();
  } catch (e) {
    // 意外异常（未被 sync 内部 try/catch 罩住）：回滚冷却后上抛给调用方打日志
    if (lastPull) _recentPulls._global = lastPull; else delete _recentPulls._global;
    throw e;
  }
  // 失败语义：网络/服务端/锁失败 resolve 带 error 字段（不 reject）→ 回滚冷却，下页可重试；
  // 短路（no_dirty_skip 等无 error）与成功一样消耗冷却——重试不可能拉到新东西，不消耗会空转。
  if (result && typeof result === 'object' && result.error) {
    if (lastPull) _recentPulls._global = lastPull; else delete _recentPulls._global;
  }
}

// ---- Conflict Resolution (LWW) ----

async function _handleConflict(ann, serverVersion) {
  console.log('[Sync] Conflict detected for:', ann.MARK_INFO_ID);

  // serverVersion 由主同步响应直接附带（服务端 ConflictInfo.serverVersion），无需再为每个冲突
  // 单独请求 /sync/download 全量拉取——既消除"N 冲突 = N 次串行往返"的慢路径，也修掉旧实现
  // 把 data.annotations（数组）当按 WEB_URI 分组的 Map 用、导致 serverMatch 恒为 null 的 bug。
  // 服务端进 conflict 列表的项必然 server 严格更新（clientWinsLww 秒级截断、平局 client 赢），
  // 与 _isServerNewer 口径一致；保留 _isServerNewer 判断作为防御性兜底。
  try {
    var store = db._tx('annotations', 'readwrite');

    if (serverVersion && _isServerNewer(serverVersion.updateDate, ann.UPDATE_TIME)) {
      // Server wins — overwrite local（本地独有字段统一走 _preserveLocalOnlyFields）
      var localAnn = _preserveLocalOnlyFields(serverDtoToLocal(serverVersion), ann);
      store.put(localAnn);
    } else {
      // serverVersion 缺失（实体并发删）或本地 newer — 标 PENDING 下轮重推
      ann.SYNC_STATUS = SYNC_STATUS_PENDING;
      store.put(ann);
    }
  } catch (e) {
    console.warn('[Sync] Conflict resolution failed:', e.message);
    var errStore = db._tx('annotations', 'readwrite');
    // 不再标 SYNC_STATUS_CONFLICT（死状态：不在 dirty 查询 4 态内、也不被 _resetExhaustedState 复位，
    // 一旦标上就永久卡死）。降级 PENDING，由下轮 connectivity-tick 兜底重试。
    ann.SYNC_STATUS = SYNC_STATUS_PENDING;
    errStore.put(ann);
  }

  // Log conflict
  await _saveConflictRecord(ann);
}

async function _saveConflictRecord(ann) {
  var conflicts = await new Promise(function (resolve) {
    chrome.storage.local.get(['wpzl_sync_conflicts'], function (r) {
      resolve(r.wpzl_sync_conflicts || []);
    });
  });
  conflicts.push({
    markInfoId: ann.MARK_INFO_ID,
    detectedAt: new Date().toISOString(),
    resolution: 'auto_lww',
    localUpdateTime: ann.UPDATE_TIME
  });
  // Keep only last 50 conflicts
  if (conflicts.length > 50) conflicts = conflicts.slice(-50);
  await new Promise(function (resolve) {
    chrome.storage.local.set({ wpzl_sync_conflicts: conflicts }, resolve);
  });
}

// ---- Offline Queue ----

// 入离线队列（按项）：多 id 操作拆成 N 条 per-item 条目，共享 queuedAt 作 FIFO 平局。
// E-P2-5: 按 itemId 去重 + 硬上限。抖动期同一批 id 每轮失败都重新 enqueue，无去重时
// 队列按失败轮数线性膨胀（offline_queue 是整读整写的单键，读写成本随之增长）；
// flush 被脱机/熔断 gate 挡住时无出队路径，重复条目会持续累积。触发器语义下重复
// 条目也无额外价值（决定是否 sync 的只是"队列是否非空"）。
var OFFLINE_QUEUE_MAX = 2000;
async function enqueueOffline(operation) {
  var queue = await _syncGetMeta('offline_queue') || [];
  var queuedAt = operation.queuedAt || new Date().toISOString();
  var ids = operation.batchIds || (operation.itemId ? [operation.itemId] : []);
  function _newEntry(itemId) {
    return {
      id: _syncGenerateUUID(),
      type: operation.type || 'sync',
      itemId: itemId,
      deletedIds: operation.deletedIds || [],
      queuedAt: queuedAt,
      retryCount: operation.retryCount || 0,
      exhausted: false,
      lastError: null,
      lastAttemptAt: null
    };
  }
  for (var i = 0; i < ids.length; i++) {
    var dup = false;
    for (var j = 0; j < queue.length; j++) {
      if (queue[j] && queue[j].itemId === ids[i]) { dup = true; break; }
    }
    if (!dup) queue.push(_newEntry(ids[i]));
  }
  if (queue.length > OFFLINE_QUEUE_MAX) {
    console.warn('[Sync] offline_queue 超上限，丢弃最旧条目:', queue.length - OFFLINE_QUEUE_MAX);
    queue = queue.slice(queue.length - OFFLINE_QUEUE_MAX);
  }
  // P0-5: 不再为"纯删除"（无 itemId 只有 deletedIds）创建条目——这类条目在 flushOfflineQueue
  // 的清理逻辑中无出队路径（记录已硬删无从核对），会永久滞留：_offlineQueueHasPending 永真
  // → connectivity-tick 被永久钉在 3.5-6.5min 最低档 + 每轮 flush 多触发一次冗余 sync('immediate')，
  // 且队列整读整写无限膨胀（运行时实证：2 条僵尸滞留 6.7h+）。
  // 删除的可恢复性由本地 PENDING_DELETED 状态 + 严格墓碑确认（sync 成功回执）保证，
  // offline_queue 本就是纯触发器，计数权威在 sync()。
  await _syncSetMeta('offline_queue', queue);
  console.log('[Sync] Enqueued offline ops, queue length:', queue.length);
}

function _getAnnotation(id) {
  return new Promise(function (resolve) {
    try {
      var tx = db._tx('annotations', 'readonly');
      var req = tx.get(id);
      req.onsuccess = function () { resolve(req.result || null); };
      req.onerror = function () { resolve(null); };
    } catch (e) { resolve(null); }
  });
}

// 薄层 FIFO 触发器（计数权威在 sync()，见上）：按 queuedAt 升序，跳过 exhausted，触发一次 sync('immediate')，
// 再按记录最终态清理/镜像条目。永不丢弃——exhausted 条目保留跳过，记录仍在 IDB 可手动重传。
async function flushOfflineQueue() {
  if (!(await isSyncAllowed())) return;   // 权限 gate：无同步权限不运行（计划「核心设计决策增补」B 节）
  // 脱机整体休眠：不可达时跳过（内部 sync('immediate') 会发注定失败的请求）
  if (typeof wpzl_getSyncState === 'function' && wpzl_getSyncState() === 'offline') return;
  // 服务端错误熔断冷却期不触发（关键：manager 1.2s 轮询反复唤醒 SW → 冷启动 init() →
  // flushOfflineQueue → sync('immediate') 的高频链路在此被 storage 持久化状态截断，SW 重启不重置）。
  // 下方的镜像/出队清理是本地 IDB 操作，无网络成本，直接 return 安全（冷却到期后下轮 tick 补齐）。
  if (await _isServerErrPaused()) return;
  var queue = await _syncGetMeta('offline_queue') || [];
  if (queue.length === 0) return;
  // 兼容遗留批条目（batchIds）→ per-item
  var normalized = [];
  for (var k = 0; k < queue.length; k++) {
    var oe = queue[k];
    if (oe && Array.isArray(oe.batchIds) && oe.batchIds.length > 0 && oe.itemId == null) {
      for (var bi = 0; bi < oe.batchIds.length; bi++) {
        normalized.push({
          id: _syncGenerateUUID(), type: oe.type || 'sync', itemId: oe.batchIds[bi],
          deletedIds: oe.deletedIds || [], queuedAt: oe.queuedAt,
          retryCount: oe.retryCount || 0, exhausted: !!oe.exhausted,
          lastError: oe.lastError || null, lastAttemptAt: oe.lastAttemptAt || null
        });
      }
    } else {
      normalized.push(oe);
    }
  }
  queue = normalized;
  // 按 queuedAt 升序 FIFO（ISO-8601 同格式字典序正确），id 平局
  queue.sort(function (a, b) {
    if (a.queuedAt !== b.queuedAt) return a.queuedAt < b.queuedAt ? -1 : 1;
    return (a.id || '') < (b.id || '') ? -1 : 1;
  });

  console.log('[Sync] Flushing offline queue, length:', queue.length);
  // 有非 exhausted 条目则触发一次 sync（计数由 sync() 内部统一处理）
  var hasNonExhausted = false;
  for (var n = 0; n < queue.length; n++) {
    if (!queue[n].exhausted) { hasNonExhausted = true; break; }
  }
  if (hasNonExhausted) {
    try { await sync('immediate'); } catch (e) { /* sync 内部已计数 */ }
  }
  // 按记录最终态清理/镜像条目
  var remaining = [];
  for (var j = 0; j < queue.length; j++) {
    var op = queue[j];
    if (!op.itemId) continue;   // P0-5: 历史遗留的纯删除僵尸条目直接出队丢弃（入队侧已不再产生，
                                // 见 enqueueOffline 注释；删除由 PENDING_DELETED + 墓碑确认兜底）
    var rec = await _getAnnotation(op.itemId);
    if (!rec) continue;                                     // 记录已硬删：出队
    if (rec.SYNC_STATUS === SYNC_STATUS_SYNCED) continue;  // 已同步：出队
    op.exhausted = !!rec.SYNC_EXHAUSTED;                   // 镜像耗尽态
    op.retryCount = rec.SYNC_RETRY_COUNT || 0;             // 镜像计数（仅展示/排序）
    remaining.push(op);                                    // 仍 dirty（含 exhausted）：保留不丢
  }
  await _syncSetMeta('offline_queue', remaining);
}

// 队列是否还有非 exhausted 条目（connectivity-tick 排空循环用）
// P0(CL-01, 2026-09-19 审计复核)：登出前统计「未上云」的本地修改数。
// 六个实体 store 的 syncStatus 索引按 'pending' 前缀计数（pending/pending_save/
// pending_update/pending_deleted…）+ offline_queue 未出队条目（口径同 _offlineQueueHasPending）。
// 只用 idx.count 游标计数、不取整行——避免把 base64 大字段整表载入 SW 内存（CL-04 教训）。
var _PENDING_SYNC_STORES = ['annotations', 'pages', 'folders', 'imageData', 'documents', 'snapshots'];
async function _countPendingLocalChanges() {
  var total = 0;
  for (var i = 0; i < _PENDING_SYNC_STORES.length; i++) {
    try {
      var store = db._tx(_PENDING_SYNC_STORES[i], 'readonly');
      var idx = store.index('syncStatus');
      total += await new Promise(function (resolve) {
        var rq = idx.count(IDBKeyRange.bound('pending', 'pending' + String.fromCharCode(0xFFFF)));
        rq.onsuccess = function () { resolve(rq.result || 0); };
        rq.onerror = function () { resolve(0); };
      });
    } catch (e) { /* store/index 不存在（老库）等 → 跳过该 store */ }
  }
  try {
    var q = await _syncGetMeta('offline_queue') || [];
    for (var j = 0; j < q.length; j++) {
      if (!q[j] || q[j].itemId == null) continue; // 纯删除条目永不出队，不计（P0-5 同口径）
      if (!q[j].exhausted) total++;
    }
  } catch (e) { /* ignore */ }
  return total;
}

async function _offlineQueueHasPending() {
  try {
    var q = await _syncGetMeta('offline_queue') || [];
    for (var i = 0; i < q.length; i++) {
      // P0-5: 跳过历史遗留的纯删除条目（itemId 为空）——它们永不出队，
      // 若计入则 connectivity-tick 被永久钉最低档（排空循环永不退出）
      if (!q[i] || q[i].itemId == null) continue;
      if (!q[i].exhausted) return true;
    }
    return false;
  } catch (e) { return false; }
}

// ---- Health Monitoring ----

async function _updateHealth(success, pushed, pulled, conflicts, errors, errorMsg) {
  var health = await new Promise(function (resolve) {
    chrome.storage.local.get(['wpzl_sync_health'], function (r) {
      resolve(r.wpzl_sync_health || {
        lastSyncTime: null,
        lastSyncDurationMs: 0,
        lastSyncSuccess: null,
        consecutiveFailures: 0,
        totalPushed: 0,
        totalPulled: 0,
        totalConflicts: 0,
        totalErrors: 0,
        lastError: null
      });
    });
  });

  if (success) {
    health.lastSyncSuccess = true;
    health.consecutiveFailures = 0;
    // 任何与服务端的成功交互（统一 sync / push / pull）→ 服务端错误熔断全复位。
    // 调用点覆盖所有成功路径；_syncAborted()（切账号清数据）时调用方跳过 health 更新，不会误复位。
    try { await _resetServerErrBackoff(); } catch (e) { /* ignore */ }
  } else {
    health.lastSyncSuccess = false;
    health.consecutiveFailures = (health.consecutiveFailures || 0) + 1;
    health.lastError = errorMsg || 'Unknown error';
  }

  health.lastSyncTime = new Date().toISOString();
  health.totalPushed = (health.totalPushed || 0) + pushed;
  health.totalPulled = (health.totalPulled || 0) + pulled;
  health.totalConflicts = (health.totalConflicts || 0) + conflicts;
  health.totalErrors = (health.totalErrors || 0) + errors;

  await new Promise(function (resolve) {
    chrome.storage.local.set({ wpzl_sync_health: health }, resolve);
  });

  // Badge warning for repeated failures
  if (health.consecutiveFailures >= 3) {
    try {
      chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
      chrome.action.setBadgeText({ text: '!' });
    } catch (e) { /* ignore if action API not available */ }
  }
}

async function getHealth() {
  return new Promise(function (resolve) {
    chrome.storage.local.get(['wpzl_sync_health'], function (r) {
      resolve(r.wpzl_sync_health || null);
    });
  });
}

// ---- Manual Sync Display Baseline ----
// 手动点击「立即同步」时，提示应展示「自上次提示以来」的累计增量，
// 而非单次同步周期的 pushed/pulled。
//
// 原因：保存标注后有 30s 防抖推送（requestSync('normal')），打开页面时有懒拉取
// （pullForUrlIfNeeded），两者都可能在用户点击前完成同步，使手动同步这一周期内
// pushed/pulled 恒为 0，提示「拉取 0 条，推送 0 条」误导用户以为没同步。
// 用累计计数 health.totalPushed/totalPulled 的增量替代单次周期计数。

var _SYNC_DISPLAY_BASELINE_KEY = 'wpzl_sync_display_baseline';

// 返回当前展示基线；若不存在则用当前累计计数初始化（本次提示仅计之后新增的部分）
async function getManualSyncBaseline() {
  var stored = await new Promise(function (resolve) {
    chrome.storage.local.get([_SYNC_DISPLAY_BASELINE_KEY], function (r) {
      resolve(r[_SYNC_DISPLAY_BASELINE_KEY] || null);
    });
  });
  if (stored) return stored;
  var health = await getHealth();
  var init = {
    totalPushed: (health && health.totalPushed) || 0,
    totalPulled: (health && health.totalPulled) || 0
  };
  await new Promise(function (resolve) {
    var obj = {};
    obj[_SYNC_DISPLAY_BASELINE_KEY] = init;
    chrome.storage.local.set(obj, resolve);
  });
  return init;
}

// 计算自 baseline 以来的增量，并把基线推进到当前累计计数
async function commitManualSync(baseline) {
  var health = await getHealth();
  var curPushed = (health && health.totalPushed) || 0;
  var curPulled = (health && health.totalPulled) || 0;
  var next = { totalPushed: curPushed, totalPulled: curPulled };
  await new Promise(function (resolve) {
    var obj = {};
    obj[_SYNC_DISPLAY_BASELINE_KEY] = next;
    chrome.storage.local.set(obj, resolve);
  });
  return {
    pushed: Math.max(0, curPushed - (baseline.totalPushed || 0)),
    pulled: Math.max(0, curPulled - (baseline.totalPulled || 0))
  };
}

// ---- Status Query ----

async function getStatus() {
  var auth = await wpzl_getAuthStatus().catch(function () { return { isLoggedIn: false }; });
  var pro = await wpzl_getProStatus().catch(function () { return { isPro: false }; });
  var deviceId = _cachedDeviceId || await getDeviceId().catch(function () { return 'unknown'; });
  var pendingCount = await getPendingCount().catch(function () { return 0; });
  var health = await getHealth();
  var conflicts = await new Promise(function (resolve) {
    chrome.storage.local.get(['wpzl_sync_conflicts'], function (r) {
      resolve(r.wpzl_sync_conflicts || []);
    });
  });

  // cloudSync 权限（数据驱动：复用已取的 auth/pro，逻辑同 isSyncAllowed）——供 popup 决定是否显示「云同步」行
  var _syncFeatures = (pro.gradeConfig || {}).features || {};
  var cloudSyncAllowed = _syncEnabled && auth.isLoggedIn && _syncFeatures.cloudSync === true;

  return {
    enabled: _syncEnabled,
    cloudSyncAllowed: cloudSyncAllowed,
    status: _syncLock ? 'syncing' : (health && health.consecutiveFailures >= 3 ? 'error' : 'idle'),
    lastSyncTime: health ? health.lastSyncTime : null,
    lastSyncSuccess: health ? health.lastSyncSuccess : null,
    pendingCount: pendingCount,
    conflictCount: conflicts.length,
    consecutiveFailures: health ? health.consecutiveFailures : 0,
    isPro: pro.isPro,
    isLoggedIn: auth.isLoggedIn,
    deviceId: deviceId,
    // 诊断字段：让 manager 能看到 init 进度，避免按钮在 init 跑完前误判为「不可用」
    initState: _initState,
    initElapsedMs: _initStartedAt ? ((_initCompletedAt || Date.now()) - _initStartedAt) : 0,
    initError: _initError
  };
}

// ---- 切换账号时重置同步状态 ----
// 清掉与同步进度/正确性相关的状态：sync_token（关键，清后下次为全量同步）、
// 离线队列、健康度、冲突记录、手动同步展示基线。保留 device_id（设备标识）。
async function resetSyncState() {
  try { await _syncSetMeta('sync_token', null); } catch (e) { /* ignore */ }
  try { await _syncSetMeta('offline_queue', []); } catch (e) { /* ignore */ }
  // 清断点续传进度（Bug 7）：避免上个账号的 pull_cursor 污染新账号的全量同步起点
  try { await _clearPullCursor(); } catch (e) { /* ignore */ }
  await new Promise(function (resolve) {
    chrome.storage.local.remove(
      ['wpzl_sync_health', 'wpzl_sync_conflicts', 'wpzl_sync_display_baseline',
       // 配额阻断标志/提示冷却随账号走：切换账号后不留旧账号的阻断状态
       QUOTA_BLOCKED_KEY, QUOTA_TOAST_KEY,
       MARK_LIMIT_BLOCKED_KEY, MARK_LIMIT_TOAST_KEY,
       DAILY_MARK_LIMIT_BLOCKED_KEY, DAILY_MARK_LIMIT_TOAST_KEY,
       IMPORT_LIMIT_BLOCKED_KEY, IMPORT_LIMIT_TOAST_KEY,
       PAGE_LIMIT_TOAST_KEY, SNAP_LIMIT_TOAST_KEY,
       LIMIT_PROBE_GATE_PREFIX + 'probe_quota', LIMIT_PROBE_GATE_PREFIX + 'probe_mark',
       LIMIT_PROBE_GATE_PREFIX + 'probe_daily_mark', LIMIT_PROBE_GATE_PREFIX + 'probe_daily_import', LIMIT_PROBE_GATE_PREFIX + 'probe_pds']
       .concat(PDS_LIMIT_REASONS.map(function (k) { return _pdsLimitKey(k); })),
      resolve
    );
  }).catch(function () { /* ignore */ });
  console.log('[Sync] resetSyncState: sync_token / queue / health cleared (device_id kept)');
}

// ---- Lifecycle ----

async function onLogin() {
  console.log('[Sync] onLogin triggered');
  // 权限门禁：以 effective features 为准（与 init / onProChanged 一致），不再无条件置 true。
  // 否则新注册 / 无同步权限用户一登录就被触发 sync，造成"也能同步"的错觉。
  // wpzl_getProStatus fail-closed：缓存空 / 脱机时返回 free（cloudSync≠true），故不会误开同步。
  var perm = await _readEffectiveSyncPermissions().catch(function () {
    return { cloudSync: false, imageCloudUpload: false };
  });
  _syncEnabled = perm.cloudSync === true;

  // 耗尽复位（"仅重新登录才恢复自动重试"的唯一入口）：清 SYNC_EXHAUSTED/retryCount，记录/条目保留不丢。
  // 权限 gating：无同步权限且无图片上云权限则跳过（无意义，也不会有耗尽项）。
  try {
    if (perm.cloudSync) {
      await _resetExhaustedState({ imagesOnly: false });
      // 复活历史卡死的 SYNC_STATUS_CONFLICT 标注（死状态：旧 _handleConflict 撞锁 409 时误标，
      // 不在 dirty 查询 4 态内也不被 _resetExhaustedState 复位）。降级 PENDING 让其重新进入 LWW 闭环。
      await _reviveStuckConflicts();
    } else if (perm.imageCloudUpload) {
      await _resetExhaustedState({ imagesOnly: true });
    }
  } catch (e) { console.warn('[Sync] onLogin exhausted reset failed:', e && e.message); }

  // 无 cloudSync 权限：不标脏标注、不触发 sync（避免"刚登录就在同步"的错觉）。
  // 仅当仍有 imageCloudUpload 权限时补做图片标记；图片上云本身已由 connectivity-tick alarm 独立调度，
  // 不依赖此处的 requestSync，故不会因此漏传。
  if (!_syncEnabled) {
    if (perm.imageCloudUpload) {
      try { await _ensureLocalImageAssetsMarked(); } catch (e) { /* ignore */ }
    }
    console.log('[Sync] onLogin: cloudSync feature off → _syncEnabled=false, skip annotation sync');
    return;
  }

  // setupPeriodicSync(); // 已禁用定时同步，仅手动触发
  await _ensureLocalAnnotationsMarked();
  try { await _ensureLocalImageAssetsMarked(); } catch (e) { /* ignore */ }
  requestSync('immediate');
}

async function onLogout() {
  console.log('[Sync] onLogout triggered');
  // 第一时间置 abandoned 标记：通知在飞的 sync 周期不要再写 syncMeta / IDB
  // （否则 in-flight 周期收尾会把上一个账号的 sync_token 写回已被清空的 syncMeta）
  _syncAbandoned = true;
  _syncEnabled = false;
  _syncDownloadTotal = null;
  _syncDownloadPulled = 0;
  clearTimeout(_debounceTimer);
  _debounceTimer = null;
  chrome.alarms.clear('sync-periodic');
  // 清除展示基线，避免跨用户/会话混用累计计数
  await new Promise(function (resolve) {
    chrome.storage.local.remove([_SYNC_DISPLAY_BASELINE_KEY], resolve);
  }).catch(function () { /* ignore */ });
  // 强制登录模型（决策 3）：登出/切换用户时清空 IDB
  // 调用方（_wpzlLogoutAndClearLocal）已先做 clearAllLocalData，
  // 这里作为兜底 — 防止调用方漏掉清空导致跨用户数据泄露。
  try {
    if (typeof db !== 'undefined' && db && typeof db.clearAllLocalData === 'function') {
      await db.clearAllLocalData();
      console.log('[Sync] onLogout: IDB stores cleared (defensive cleanup)');
    }
  } catch (e) {
    console.warn('[Sync] onLogout: clearAllLocalData failed:', e && e.message);
  }
  // 兜底清 sync_token / offline_queue / health / pull_cursor。
  // 即使 clearAllLocalData 已经清过 syncMeta，这一行是双保险（防御 IDB 关闭/异常等边界）。
  try {
    await resetSyncState();
  } catch (e) { /* ignore */ }
}

// 强制登录模型（决策 3）：登出/切换用户前调用，把所有 dirty 数据强制 push 到服务端，
// 避免本地清空后丢失未同步的修改。5 秒超时：用户已决定离开，不能无限等待。
// 不阻塞 onLogout — 超时直接 resolve 让清空流程继续。
async function flushImmediate(timeoutMs) {
  var timeout = timeoutMs || 5000;
  console.log('[Sync] flushImmediate: pushing all dirty data with', timeout, 'ms timeout');
  try {
    var result = await Promise.race([
      sync('manual'),
      new Promise(function (resolve) {
        setTimeout(function () { resolve({ _timeout: true }); }, timeout);
      })
    ]);
    if (result && result._timeout) {
      console.warn('[Sync] flushImmediate: timed out after', timeout, 'ms — proceeding with cleanup');
      return { flushed: false, reason: 'timeout' };
    }
    console.log('[Sync] flushImmediate: completed, pushed=' + (result && result.pushed) +
      ', pulled=' + (result && result.pulled));
    return { flushed: true, pushed: result && result.pushed, pulled: result && result.pulled };
  } catch (e) {
    console.warn('[Sync] flushImmediate: error (proceeding with cleanup):', e && e.message);
    return { flushed: false, reason: 'error', error: e && e.message };
  }
}

async function onProChanged(isPro) {
  console.log('[Sync] onProChanged(isPro hint):', isPro);
  // 实际能否同步以 effective features 为准——isPro 仅是触发信号，不作门禁（计划 C2）。
  // 客户端 gradeConfig 已被 _wpzlCheckProExpiry 到期降级，isSyncAllowed 读到的就是真值。
  // 这样管理员等级（无订阅但 cloudSync=on）在 isPro=false 时仍保持同步。
  var allowed = await isSyncAllowed().catch(function () { return false; });
  if (allowed) {
    _syncEnabled = true;
    // setupPeriodicSync(); // 已禁用定时同步，仅手动触发
    await _ensureLocalAnnotationsMarked();
    try { await _ensureLocalImageAssetsMarked(); } catch (e) { /* ignore */ }
    // 升级抬高限额后：立即探测配额已释放（force=true 绕过冷却门，消耗本次冷却）→ 自动复位配额耗尽项
    //（先于补传，让本轮就带上恢复的图片——保留原注释语义）
    try { await _maybeResumeQuotaExhausted(true); } catch (e) { /* ignore */ }
    // 标注总量限额同理（forceRefresh 后 limits.markLimit 已是新值，升级后立即恢复重传）
    try { await _maybeResumeMarkLimitExhausted(true); } catch (e) { /* ignore */ }
    try { await _maybeResumeDailyMarkLimitExhausted(true); } catch (e) { /* ignore */ }
    // page/doc/snap 限额同理（升级抬高 pageLimit/docLimit/snapLimit 后立即恢复）
    try { await _maybeResumePageDocSnapLimitExhausted(true); } catch (e) { /* ignore */ }
    try { await _maybeResumeImportLimitExhausted(true); } catch (e) { /* ignore */ }
    // 同步启用时把之前积压的未上云图片推到 R2
    try { await _uploadPendingImages(); } catch (e) { /* ignore */ }
  } else {
    _syncEnabled = false;
    clearTimeout(_debounceTimer);
    _debounceTimer = null;
    chrome.alarms.clear('sync-periodic');
  }
}

function setEnabled(enabled) {
  _syncEnabled = enabled;
}

function isEnabled() {
  return _syncEnabled;
}

function setupPeriodicSync() {
  chrome.alarms.create('sync-periodic', { periodInMinutes: SYNC_INTERVAL_MINUTES });
}

// 首次同步前，将本地未同步过的标注标记为待推送
async function _ensureLocalAnnotationsMarked() {
  // 独立 readonly 事务全表读（原写法 await getAll 后同事务 put 会触发 TransactionInactiveError）
  var allAnns = await db.getAll('annotations');
  var toMark = [];
  for (var i = 0; i < allAnns.length; i++) {
    var ann = allAnns[i];
    if (!ann.SYNC_STATUS || ann.SYNC_STATUS === SYNC_STATUS_LOCAL) {
      ann.SYNC_STATUS = SYNC_STATUS_PENDING;
      ann.DIRTY_BITS = 0xFF;
      toMark.push(ann);
    }
  }
  // 分块批量写（避免单事务过大 + 跨 await 失活）
  for (var j = 0; j < toMark.length; j += WPZL_IDB_WRITE_CHUNK) {
    await db.putMany('annotations', toMark.slice(j, j + WPZL_IDB_WRITE_CHUNK));
  }
}

// imageData 等价：把无 SYNC_STATUS 的老记录标 'local'，让 _collectDirtyImageData 收集
// saveImageFromUrl/Base64 写入时已带 SYNC_STATUS='local'，本函数主要兜底 dbVersion 9 升级前的老记录。
// 仅 Pro 用户参与 imageData 上云（免费用户跳过）。
async function _ensureLocalImageAssetsMarked() {
  if (!(await isImageCloudUploadAllowed())) return;
  var all = await db.getAll('imageData');
  var toMark = [];
  for (var i = 0; i < all.length; i++) {
    var rec = all[i];
    if (!rec.SYNC_STATUS) {
      rec.SYNC_STATUS = SYNC_STATUS_LOCAL;
      toMark.push(rec);
    }
  }
  for (var j = 0; j < toMark.length; j += WPZL_IDB_WRITE_CHUNK) {
    await db.putMany('imageData', toMark.slice(j, j + WPZL_IDB_WRITE_CHUNK));
  }
}

// 上传所有本地有 data 但无 cloudUrl 的图片到 R2（断网/失败积压补传）。
// 在 sync 入口、connectivity-tick、onProChanged 时调用，确保图片不永久滞留本地。
// 每轮最多处理 20 条（避免阻塞 sync 主流程）；返回实际上传数。
var IMAGE_PENDING_MAX = 50; // 最大积压数量，超限后新图片只存本地
var IMAGE_UPLOAD_INTERVAL_MS_MIN = 500;  // 逐张上传最小间隔 0.5s
var IMAGE_UPLOAD_INTERVAL_MS_MAX = 1500; // 逐张上传最大间隔 1.5s

// P1-22: 上传互斥——connectivity-tick 与 onProChanged/retryUploadAll/resetSyncFailures 可并发
// 进入本函数，两份 pending 列表 → 同图重复上传（R2 同 key 覆盖幂等但烧带宽/配额统计）。
var _imageUploadActive = false;

async function _uploadPendingImages() {
  if (typeof wpzl_uploadImage !== 'function') return 0;
  if (typeof wpzl_isImageCloudUploadAllowed !== 'function') return 0;
  if (!(await isImageCloudUploadAllowed())) return 0;   // 入口 gate（计划「核心设计决策增补」B 节）
  // 脱机整体休眠：不可达时跳过逐张上传（否则每张都发注定失败的 R2 请求）
  if (typeof wpzl_getSyncState === 'function' && wpzl_getSyncState() === 'offline') return 0;
  if (_imageUploadActive) return 0;   // P1-22: 重入保护（仿 _thumbnailFlushActive）
  _imageUploadActive = true;
  try {
    return await _uploadPendingImagesInner();
  } finally {
    _imageUploadActive = false;
  }
}

async function _uploadPendingImagesInner() {
  var UPLOAD_BATCH = 20;
  var maxR = await _getSyncMaxRetries();
  // 用 syncStatus 索引查 pending/local（替代全表扫），过滤 exhausted，按 firstPendingAt FIFO
  var idx = db._tx('imageData', 'readonly').index('syncStatus');
  var _imgResults = await Promise.all([
    _getAllFromIndex(idx, SYNC_STATUS_PENDING),
    _getAllFromIndex(idx, SYNC_STATUS_LOCAL)
  ]);
  var all = _imgResults[0].concat(_imgResults[1]);
  var pending = [];
  for (var i = 0; i < all.length; i++) {
    var rec = all[i];
    if (rec.exhausted) continue;             // 跳过耗尽（保留不丢，仅手动重传/登录复位）
    if (rec.data && !rec.cloudUrl) pending.push(rec);
  }
  if (pending.length === 0) return 0;
  // 按 firstPendingAt 升序 FIFO（图片按产生时间顺序上传），id 平局
  pending.sort(function (a, b) {
    var ka = a.firstPendingAt || '';
    var kb = b.firstPendingAt || '';
    if (ka !== kb) return ka < kb ? -1 : 1;
    return (a.id || '') < (b.id || '') ? -1 : 1;
  });
  var batch = pending.slice(0, UPLOAD_BATCH);
  console.log('[Sync] _uploadPendingImages: found ' + pending.length + ' pending, uploading ' + batch.length + ' this round');
  var uploaded = 0;
  for (var j = 0; j < batch.length; j++) {
    var item = batch[j];
    try {
      var b64Data = item.data;
      // SVG 存量记录自愈：服务端魔数白名单（D-12）必拒 SVG 字节，原样重试永远失败。
      // 先经 offscreen 栅格化为 PNG——成功则回写本地 data（记录从根上转正）后按 PNG 上传；
      // 失败置 exhausted 停止无意义重试（本地保留，同步失败弹窗给明确原因）。
      // （_wpzlRasterizeSvgDataUrl 定义在 service-worker.js，与本文件同在 SW 全局作用域）
      if (/^data:image\/svg\+xml/i.test(b64Data)) {
        var _svgPng = null;
        if (typeof _wpzlRasterizeSvgDataUrl === 'function') {
          _svgPng = await _wpzlRasterizeSvgDataUrl(b64Data).catch(function () { return null; });
        }
        if (_svgPng) {
          b64Data = _svgPng;
          // 刻意的格式自愈写：SVG data → PNG data（P1-19 的"patch 不含 data"约束针对
          // 并发回填保护，此处是上传线程对自身记录的确定性转换）
          try { await db.mergeImageData(item.pageKey, item.imageKey, { data: _svgPng }); } catch (e3) { /* ignore */ }
        } else {
          try {
            await db.mergeImageData(item.pageKey, item.imageKey, {
              exhausted: true,
              lastError: (typeof WPZL_SVG_LOCAL_ONLY_ERROR === 'string') ? WPZL_SVG_LOCAL_ONLY_ERROR : 'SVG 无法转为 PNG，仅本地保存',
              lastAttemptAt: new Date().toISOString(),
              SYNC_STATUS: 'pending'
            });
          } catch (e3) { /* ignore */ }
          continue;
        }
      }
      var byteChars = atob(b64Data.split(',')[1]);
      var byteNums = new Array(byteChars.length);
      for (var bi = 0; bi < byteChars.length; bi++) byteNums[bi] = byteChars.charCodeAt(bi);
      var _b64Mime = (b64Data.slice(0, b64Data.indexOf(';')).match(/data:([^,]+)/) || [])[1] || 'image/webp';
      var blob = new Blob([new Uint8Array(byteNums)], { type: _b64Mime });
      var resp = await wpzl_uploadImage(blob, item.pageKey, item.imageKey);
      if (resp && resp.cloudUrl) {
        // P1-19: read-merge 回写（item 是本轮索引扫描快照，patch 不含 data——上传在飞
        // 期间 ISD 回填的 data 等并发写得以保留）
        await db.mergeImageData(item.pageKey, item.imageKey, {
          cloudUrl: resp.cloudUrl,
          SYNC_STATUS: 'synced',
          DIRTY_BITS: 1, // cloudUrl 变更，待 sync push 元数据
          retryCount: 0,
          exhausted: false,
          lastError: null
        });
        uploaded++;
      } else {
        throw new Error('no cloudUrl in response');
      }
    } catch (e) {
      var _emsg = (e && e.message) || 'upload failed';
      console.warn('[Sync] _uploadPendingImages: failed for ' + item.id + ': ' + _emsg);
      // 配额超限：直接耗尽（不烧次数），停止本轮（其余多半也会失败）
      if (typeof _isQuotaExceededError === 'function' && _isQuotaExceededError(e)) {
        try {
          await db.mergeImageData(item.pageKey, item.imageKey, {
            exhausted: true,
            lastError: '配额超限',
            lastAttemptAt: new Date().toISOString(),
            SYNC_STATUS: 'pending'
          });
        } catch (e2) { /* ignore */ }
        _setQuotaBlocked(true);      // 供 _maybeResumeQuotaExhausted 释放探测自动恢复
        _maybeShowQuotaToast();      // 30 分钟冷却，批量失败不刷屏
        _broadcastSyncExhausted({ kind: 'image', id: item.id, reason: 'cloud_quota' }); // P1-14
        break;
      }
      try {
        var _exh = ((item.retryCount || 0) + 1 >= maxR) && !item.exhausted;
        await db.mergeImageData(item.pageKey, item.imageKey, {
          retryCount: (item.retryCount || 0) + 1,
          lastError: _emsg.slice(0, 500),
          lastAttemptAt: new Date().toISOString(),
          exhausted: ((item.retryCount || 0) + 1 >= maxR),
          SYNC_STATUS: 'pending'
        });
        if (_exh) _broadcastSyncExhausted({ kind: 'image', id: item.id, retryCount: (item.retryCount || 0) + 1 }); // P1-14
      } catch (e2) { /* ignore */ }
    }
    // 逐张间隔 1~3s 随机抖动，防止同一客户端瞬间打并发到 R2
    if (j < batch.length - 1) {
      var interval = IMAGE_UPLOAD_INTERVAL_MS_MIN + Math.floor(Math.random() * (IMAGE_UPLOAD_INTERVAL_MS_MAX - IMAGE_UPLOAD_INTERVAL_MS_MIN));
      await new Promise(function (r) { setTimeout(r, interval); });
    }
  }
  if (uploaded > 0) console.log('[Sync] _uploadPendingImages: uploaded ' + uploaded + '/' + batch.length);
  return uploaded;
}

// 检查积压的未上云图片是否达上限（服务端长时间不可达时防止无限制增长）
async function _checkPendingImageLimit() {
  try {
    if (!(await isImageCloudUploadAllowed())) return false;
    // P1-18: 此前每保存一张新图都 db.getAll('imageData') 全表扫（一页标 N 图 = O(N²)，
    // 且整表 base64 全部反序列化）。改走 syncStatus 索引只取 pending/local——
    // 待 R2 上传的积压被 IMAGE_PENDING_MAX=50 门控，有界。
    var idx = db._tx('imageData', 'readonly').index('syncStatus');
    var results = await Promise.all([
      _getAllFromIndex(idx, SYNC_STATUS_PENDING),
      _getAllFromIndex(idx, SYNC_STATUS_LOCAL)
    ]);
    var all = results[0].concat(results[1]);
    var count = 0;
    for (var i = 0; i < all.length; i++) {
      // 已耗尽图片不计入 50 背压阀（计划 6.2），避免长断网堵住新截图
      if (all[i].data && !all[i].cloudUrl && !all[i].exhausted) count++;
    }
    return count >= IMAGE_PENDING_MAX;
  } catch (e) { return false; }
}

// 积压超限时提示用户（30 分钟冷却，避免骚扰）
var IMAGE_BACKLOG_TOAST_KEY = 'wpzl_image_backlog_toast_time';
async function _maybeShowImageBacklogToast() {
  try {
    var result = await new Promise(function (resolve) {
      chrome.storage.local.get([IMAGE_BACKLOG_TOAST_KEY], function (r) { resolve(r); });
    });
    var lastTime = result[IMAGE_BACKLOG_TOAST_KEY] || 0;
    if (Date.now() - lastTime > 30 * 60 * 1000) {
      await new Promise(function (resolve) {
        chrome.storage.local.set({ [IMAGE_BACKLOG_TOAST_KEY]: Date.now() }, resolve);
      });
      // 通知活跃 tab（如果 service-worker.js 暴露了该函数）
      if (typeof _notifyToastToActiveTab === 'function') {
        _notifyToastToActiveTab(chrome.i18n.getMessage('imgServerDownToast'), { clickable: false, duration: 5000 });
      }
    }
  } catch (e) { /* ignore */ }
}

// ---- Initialization ----

async function init() {
  _initState = 'running';
  _initStartedAt = Date.now();
  _initError = null;
  console.log('[Sync] init() start at', new Date(_initStartedAt).toISOString(), '(SW pid=' + (chrome.runtime.instanceId || 'n/a') + ')');
  try {
    await getDeviceId();
    console.log('[Sync] init: getDeviceId ok, elapsed=' + (Date.now() - _initStartedAt) + 'ms');

    var auth = await wpzl_getAuthStatus().catch(function (e) {
      console.warn('[Sync] init: wpzl_getAuthStatus threw:', e && e.message);
      return { isLoggedIn: false };
    });
    console.log('[Sync] init: auth.isLoggedIn=' + (auth && auth.isLoggedIn) + ', elapsed=' + (Date.now() - _initStartedAt) + 'ms');

    if (auth.isLoggedIn) {
      var pro = await wpzl_getProStatus().catch(function (e) {
        console.warn('[Sync] init: wpzl_getProStatus threw:', e && e.message);
        return { isPro: false, gradeConfig: {} };
      });
      console.log('[Sync] init: pro.isPro=' + (pro && pro.isPro) + ', elapsed=' + (Date.now() - _initStartedAt) + 'ms');
      // P1-18 兜底：每次 SW 启动全表对账重建 img_meta_dirty / thumb_pending_ids 两份清单
      //（防 restoreBackup 导入、老版本升级等不经过常规写点的路径漏记；成本仅 init 一次）
      _reconcilePendingWorkLists().catch(function (e) { /* ignore */ });
      // effective 等级 features 判定（C1）：客户端 gradeConfig 已被 _wpzlCheckProExpiry 到期降级，
      // 直接读 features.cloudSync 即 effective 真值——不再用 isPro 当门禁。
      var gc = (pro && pro.gradeConfig) || {};
      var features = gc.features || {};
      if (features.cloudSync === true) {
        _syncEnabled = true;
        console.log('[Sync] init: enabling sync (cloudSync feature on), _syncEnabled=' + _syncEnabled);
        // setupPeriodicSync(); // 已禁用定时同步，仅手动触发
        flushOfflineQueue().catch(function (e) {
          console.warn('[Sync] Initial offline flush failed:', e.message);
        });
      } else {
        console.log('[Sync] init: cloudSync feature off, _syncEnabled stays false');
      }
    } else {
      console.log('[Sync] init: not logged in, _syncEnabled stays false');
    }

    _initState = 'completed';
    _initCompletedAt = Date.now();
    console.log('[Sync] init() completed, total=' + (_initCompletedAt - _initStartedAt) + 'ms, enabled=' + _syncEnabled);
  } catch (e) {
    _initState = 'failed';
    _initError = e && e.message;
    _initCompletedAt = Date.now();
    console.warn('[Sync] init() failed after ' + (_initCompletedAt - _initStartedAt) + 'ms:', e && e.message);
  } finally {
    // 不论成功/失败都 resolve，让所有 waitForInit 调用方解阻塞
    try { _initResolve(); } catch (e) { /* ignore */ }
    // E-P2-4: 启动浪涌打散延迟的两种承载方式：
    // ① 已有 pending 请求（尤其 immediate）→ 不睡 jitter 直接 flush——用户活动触发的同步
    //    不应被延迟最多 1 分钟，且此前的 setTimeout 期间 SW 被 MV3 回收会连内存态
    //    _pendingSyncRequest 一起丢（只能等 connectivity-tick 3.5min+ 兜底）。
    // ② 无 pending → jitter 改 chrome.alarms 承载（0.5-1.0min，alarm 最小粒度 0.5min）：
    //    SW 可被自由回收，alarm 由浏览器持久调度并重新唤醒（唤醒后脚本重跑，init 自会再走本分支）。
    if (_pendingSyncRequest) {
      console.log('[Sync] init: pending sync request present, flush without jitter');
      try { _flushPendingSyncRequest(); } catch (e) { /* ignore */ }
    } else if (_syncEnabled) {
      var jitterDelayMin = 0.5 + Math.random() * 0.5;
      console.log('[Sync] init: schedule jitter alarm in ' + (jitterDelayMin * 60).toFixed(0) + 's');
      try { chrome.alarms.create(SYNC_JITTER_ALARM, { delayInMinutes: jitterDelayMin }); } catch (e) { /* ignore */ }
    }
    // 断点续传（Bug 7）：SW 每次启动即检测未完成的大同步下载，立即续传（用户活动唤醒 SW 时推进）
    try {
      if (_syncEnabled && await _getPullCursor()) {
        console.log('[Sync] init: 检测到未完成的大同步下载，触发续传');
        _ensureResumeAlarm();
        requestSync('immediate');
      }
    } catch (e) { /* ignore */ }
  }
}

// ---- Public API ----

// ---- 同步失败查看器数据源（计划 5b/5c）----

// 读取一条 mark 记录（annotations/folders 主键查；pages keyPath=url 经 urlMd5 索引查）
function _readMark(storeName, kind, id) {
  return new Promise(function (resolve) {
    try {
      var tx = db._tx(storeName, 'readonly');
      var req = (kind === 'page') ? tx.index('urlMd5').get(id) : tx.get(id);
      req.onsuccess = function () { resolve(req.result || null); };
      req.onerror = function () { resolve(null); };
    } catch (e) { resolve(null); }
  });
}

// 收集所有待手动干预的失败项：exhausted 或 (dirty 状态 且 retryCount>0)。
// 权限 gating：无同步权限不返回 marks；无图片上云权限不返回 images（计划「核心设计决策增补」B 节）。
async function getSyncFailures() {
  var maxR = await _getSyncMaxRetries();
  var marks = [];
  var images = [];
  var markAllowed = await isSyncAllowed().catch(function () { return false; });
  var imgAllowed = await isImageCloudUploadAllowed().catch(function () { return false; });

  function collectMarks(storeName, idField, titleField, kind, timeField) {
    return new Promise(function (resolve) {
      try {
        var idx = db._tx(storeName, 'readonly').index('syncStatus');
        Promise.all([
          _getAllFromIndex(idx, SYNC_STATUS_PENDING),
          _getAllFromIndex(idx, SYNC_STATUS_LOCAL),
          _getAllFromIndex(idx, SYNC_STATUS_ERROR)
        ]).then(function (results) {
          var seen = {};
          var out = [];
          for (var r = 0; r < results.length; r++) {
            var arr = results[r];
            for (var i = 0; i < arr.length; i++) {
              var rec = arr[i];
              var recId = rec[idField];
              if (recId == null || seen[recId]) continue;
              // 收集所有未 SYNCED（PENDING/LOCAL/ERROR）项：过滤只看持久 syncStatus，不看 retryCount/瞬时 state——
              // 脱机整体休眠后 retryCount=0 既可能是脱机失败也可能是刚创建待 sync，靠它过滤会让列表闪烁。
              // syncStatus 索引已保证只查未同步项，sync 成功后自动 SYNCED 移出（不在索引）。下面 if 仅为保留块结构。
              if (recId != null) {
                seen[recId] = true;
                var _item = {
                  kind: kind, store: storeName, id: recId,
                  title: String(rec[titleField] || rec.url || rec.folderId || '').slice(0, 120),
                  syncStatus: rec.SYNC_STATUS,
                  retryCount: rec.SYNC_RETRY_COUNT || 0,
                  exhausted: !!rec.SYNC_EXHAUSTED,
                  lastError: rec.SYNC_LAST_ERROR || null,
                  lastAttemptAt: rec.SYNC_LAST_ATTEMPT_AT || null,
                  updateTime: timeField ? (rec[timeField] || null) : null
                };
                // 标注额外携带类型/预览所需字段，供 manager 失败查看器渲染类型徽标与内容预览
                // （文字片段 / 缩略图）。否则只展示 MARK_INFO_ID 或 TITLE 样式代码（如高亮的 "bjs"），
                // 对用户毫无意义——无法判断是哪条标注没同步上去。
                if (kind === 'annotation') {
                  _item.endXPath = rec.END_XPATH || '';
                  _item.color = rec.MARK_COLOR || '';
                  _item.webUri = rec.WEB_URI || '';
                  _item.context = String(rec.CONTEXT || '').slice(0, 300);
                  _item.comment = String(rec.COMMENT_TEXT || '').slice(0, 120);
                  _item.thumb = rec.THUMBNAIL || '';
                  _item.anchorW = rec.ANCHOR_WIDTH || 0;
                  _item.anchorH = rec.ANCHOR_HEIGHT || 0;
                  _item.endTagName = rec.END_TAG_NAME || '';
                }
                // 文档/快照额外携带 webUri（标题 + URL 供失败查看器渲染）
                if (kind === 'document' || kind === 'snapshot') {
                  _item.webUri = rec.webUri || '';
                }
                out.push(_item);
              }
            }
          }
          resolve(out);
        }).catch(function () { resolve([]); });
      } catch (e) { resolve([]); }
    });
  }
  // pageRect 截图未上云：标注 THUMBNAIL_PENDING=true（截图存 localThumbnails，走独立 _flushPendingThumbnails
  // 后台补传）。标注元数据可能已 synced → 不在 collectMarks 失败集合，需单独收集，
  // 否则用户在查看器中看不到"截图没上云"。与已收集的 annotation 失败项按 id 去重。
  // 另收 THUMB_LOCAL_MISSING 终态项（本地字节已不存在、传不上去，flush 已把它移出工作清单）——
  // 它们是本表全表扫，纳入不增加扫描成本；不纳入就等于让这类失败彻底隐形。
  // retryCount/exhausted/lastError 透出记录真实字段，供 UI 区分「排队中 / 重试耗尽 / 终态」。
  function collectThumbPending(existingIds) {
    return new Promise(function (resolve) {
      try {
        var store = db._tx('annotations', 'readonly');
        var req = store.getAll();
        req.onsuccess = function () {
          var all = req.result || [];
          var out = [];
          // P1-9 孤儿收养：flag=true 但 id 不在 thumb_pending_ids 清单的行，flush 永远看不到它们
          // （补传器只认清单），自愈重建又被 truncated=false 关死——这里全表扫正好是唯一能发现
          // 孤儿的地方，就地回填清单（发现处即收养处）。走 _mergeThumbPendingIds 串行链无丢更新；
          // 仅收非终态 PENDING 行，THUMB_LOCAL_MISSING 终态仍只展示不可补传。
          var _orphanIds = [];
          for (var i = 0; i < all.length; i++) {
            var rec = all[i];
            var recId = rec.MARK_INFO_ID;
            if (!recId || existingIds[String(recId)]) continue;
            // 两类都要收：排队中（PENDING）与终态（THUMB_LOCAL_MISSING，本地字节已不存在）。
            // 终态项 PENDING 已被清、不在工作清单里，只能靠这里的全表扫呈现给用户——
            // 这正是修复"传不上去就静默消失"的关键：让它以永久可见的失败项留在面板上。
            var _thumbTerminal = !!rec.THUMB_LOCAL_MISSING;
            if (rec.THUMBNAIL_PENDING) {
              _orphanIds.push(recId);
            }
            if (rec.THUMBNAIL_PENDING || _thumbTerminal) {
              existingIds[String(recId)] = true;
              out.push({
                kind: 'annotation', store: 'annotations', id: recId,
                title: String(rec.WEB_URI || '').slice(0, 120),
                syncStatus: rec.SYNC_STATUS,
                // 透出记录真实字段（此前硬编码 0/false/null，导致后端写入的耗尽/错误在面板上完全不可见）
                retryCount: rec.THUMB_RETRY_COUNT || 0,
                exhausted: !!rec.THUMB_EXHAUSTED,
                lastError: rec.THUMB_LAST_ERROR || null,
                lastAttemptAt: null,
                terminal: _thumbTerminal,
                updateTime: rec.UPDATE_TIME || null,
                thumbPending: true,
                endXPath: rec.END_XPATH || '',
                color: rec.MARK_COLOR || '',
                webUri: rec.WEB_URI || '',
                context: String(rec.CONTEXT || '').slice(0, 300),
                comment: String(rec.COMMENT_TEXT || '').slice(0, 120),
                thumb: rec.THUMBNAIL || '',
                anchorW: rec.ANCHOR_WIDTH || 0,
                anchorH: rec.ANCHOR_HEIGHT || 0,
                endTagName: rec.END_TAG_NAME || ''
              });
            }
          }
          // P1-9：孤儿回填（fire-and-forget，串行链内落盘；本函数已把孤儿呈现给用户，
          // 回填让下一次 flush/重传真正能带走它们）。失败已在 _mergeThumbPendingIds 内部静默容错。
          if (_orphanIds.length > 0) {
            console.log('[thumb] collectThumbPending adopted ' + _orphanIds.length + ' orphan(s) into work list');
            _mergeThumbPendingIds(_orphanIds).catch(function (e) {
              console.warn('[thumb] orphan adoption failed:', e && e.message);
            });
          }
          resolve(out);
        };
        req.onerror = function () { resolve([]); };
      } catch (e) { resolve([]); }
    });
  }

  if (markAllowed) {
    marks = marks.concat(await collectMarks('annotations', 'MARK_INFO_ID', 'TITLE', 'annotation', 'UPDATE_TIME'));
    marks = marks.concat(await collectMarks('pages', 'URL_MD5', 'title', 'page', 'lastVisited'));
    marks = marks.concat(await collectMarks('folders', 'folderId', 'NAME', 'folder', 'updatedAt'));
    // 文档/快照 body 上云失败项（含永久 EXHAUSTED：body 过大/冲突；瞬时重试中：配额/存储/网络）
    marks = marks.concat(await collectMarks('documents', 'docId', 'title', 'document', 'updatedAt'));
    marks = marks.concat(await collectMarks('snapshots', 'snapId', 'title', 'snapshot', 'updatedAt'));
    // pageRect 截图未上云：仅对有图片上云权限的用户收集（截图上云属 imageCloudUpload 功能）
    if (imgAllowed) {
      var _seenAnnIds = {};
      for (var si = 0; si < marks.length; si++) {
        if (marks[si].kind === 'annotation') _seenAnnIds[String(marks[si].id)] = true;
      }
      marks = marks.concat(await collectThumbPending(_seenAnnIds));
    }
  }

  if (imgAllowed) {
    try {
      var imgIdx = db._tx('imageData', 'readonly').index('syncStatus');
      var imgResults = await Promise.all([
        _getAllFromIndex(imgIdx, SYNC_STATUS_PENDING),
        _getAllFromIndex(imgIdx, SYNC_STATUS_LOCAL)
      ]);
      var imgSeen = {};
      for (var ir = 0; ir < imgResults.length; ir++) {
        var iarr = imgResults[ir];
        for (var ii = 0; ii < iarr.length; ii++) {
          var irec = iarr[ii];
          if (irec.id == null || imgSeen[irec.id]) continue;
          // 同 collectMarks：收集所有未 SYNCED（PENDING/LOCAL）项，过滤只看持久 syncStatus，不依赖 retryCount/瞬时 state。
          if (irec.id != null) {
            imgSeen[irec.id] = true;
            images.push({
              id: irec.id, pageKey: irec.pageKey, imageKey: irec.imageKey,
              imageUrl: irec.imageUrl || null,   // 透传图片源 URL：供 UI 兜底派生域名 + annotations 桥键
              retryCount: irec.retryCount || 0, exhausted: !!irec.exhausted,
              lastError: irec.lastError || irec.SYNC_LAST_ERROR || null,
              firstPendingAt: irec.firstPendingAt || null,
              lastAttemptAt: irec.lastAttemptAt || null,
              updateTime: irec.firstPendingAt || irec.lastAttemptAt || null
            });
          }
        }
      }
    } catch (e) { /* ignore */ }
  }

  // 图片资产身份反查（方案 A，2026-07-08）：
  // imageData.pageKey 是 SHA-256（_swMd5），而 pages.URL_MD5 是 MD5（wpzl_md5），口径不一致 ——
  // 原 pages.urlMd5 反查永远命中 0 条（实测 67 个 image pageKey 与 171 个 page URL_MD5 交集=0），
  // 属死代码。改走三条只读桥恢复页面身份（domain/pageUrl/title），均不命中时由 UI 从 imageUrl
  // 派生兜底（见 manager._sfImageRow）。不修改 imageData schema / 写入路径 / 哈希算法。
  if (images.length > 0) {
    // 桥① annotations：imageData.imageUrl === annotation.END_TAG_NAME（同一字符串）
    //   → DOMAIN / WEB_URI / TITLE。覆盖页面图片标注。注：END_TAG_NAME 写入时截断到 500 字符，
    //   超 500 字符的源 URL 会 miss → 落 UI 第 4 档。
    var annImgMap = {};
    try {
      var annAll = await _getAllFromStore(db._tx('annotations', 'readonly'));
      for (var ai = 0; ai < annAll.length; ai++) {
        var a = annAll[ai];
        var ex = a.END_XPATH || '';
        if (ex !== '$pic' && ex !== '$imgAnno' && ex !== '$picLine') continue;
        var imgSrc = a.END_TAG_NAME || '';
        if (!imgSrc || annImgMap[imgSrc]) continue;          // 同图取首条（同图通常同页）
        annImgMap[imgSrc] = { domain: a.DOMAIN || '', webUri: a.WEB_URI || '', title: a.TITLE || '' };
      }
    } catch (e) { /* annotations 读失败不阻断：UI 走 imageUrl 兜底 */ }

    // 桥③ pages url → title（标题增强）：pages.url 与 annotation.WEB_URI 同为协议剥离形态，可直接对齐。
    //   annotation 自带 TITLE 常为空，用 page 真实标题补全。
    var pageTitleMap = {};
    try {
      var pageAll = await _getAllFromStore(db._tx('pages', 'readonly'));
      for (var pi = 0; pi < pageAll.length; pi++) {
        var pgr = pageAll[pi];
        if (pgr.url && !(pgr.url in pageTitleMap)) pageTitleMap[pgr.url] = pgr.title || '';
      }
    } catch (e) { /* pages 读失败不阻断 */ }

    // 桥② documents：imageData.pageKey(sha256) === sha256(doc.webUri) → webUri/title/domain。
    //   文档图片无 annotation，桥① 命中不了；用 _swMd5（与写入端同口径 SHA-256）算 webUri 哈希匹配。
    var docPkMap = {};
    try {
      var docAll = await _getAllFromStore(db._tx('documents', 'readonly'));
      for (var di = 0; di < docAll.length; di++) {
        var d = docAll[di];
        if (!d.webUri) continue;
        var sha = await _swMd5(d.webUri);                    // _swMd5 在 SW 全局（service-worker.js 顶函数）
        docPkMap[sha] = { webUri: d.webUri, title: d.title || '', domain: d.domain || '' };
      }
    } catch (e) { /* documents 读失败 / store 不存在（v<12）不阻断 */ }

    // 合并填充每条失败图的身份（domain/pageUrl/title）。
    for (var ii2 = 0; ii2 < images.length; ii2++) {
      var im = images[ii2];
      var viaAnn = im.imageUrl ? annImgMap[im.imageUrl] : null;
      var viaDoc = im.pageKey ? docPkMap[im.pageKey] : null;
      if (viaAnn) {
        im.domain = viaAnn.domain || '';
        im.pageUrl = viaAnn.webUri || '';
        im.title = (viaAnn.webUri && pageTitleMap[viaAnn.webUri]) || viaAnn.title || '';
      } else if (viaDoc) {
        im.domain = viaDoc.domain || '';
        im.pageUrl = viaDoc.webUri || '';
        im.title = viaDoc.title || '';
      }
      // 两桥均 miss（孤儿图 / 超长 URL / 文档已删）→ 不填，UI 从 imageUrl 派生兜底
    }
  }

  return { maxRetries: maxR, marks: marks, images: images };
}

// 单项重传：复位 exhausted/retryCount、置 pending、重排队尾，触发同步/上传。
// payload: {kind:'annotation'|'page'|'folder'|'image', id, store}
async function retryUpload(payload) {
  var kind = payload && payload.kind;
  var id = payload && payload.id;
  if (!kind || id == null) return { success: false, error: 'missing kind/id' };
  var nowIso = new Date().toISOString();

  if (kind === 'image') {
    if (!(await isImageCloudUploadAllowed().catch(function () { return false; })))
      return { success: false, error: 'image cloud upload not allowed' };
    var imgRec = await _readMark('imageData', 'image', id);
    if (!imgRec) return { success: false, error: 'not found' };
    if (_isLimitRejectionReason(imgRec.lastError || imgRec.SYNC_LAST_ERROR)) {
      return { success: false, error: 'limit-reached' };
    }
    // P1-19: read-merge（imgRec 刚读过风险低，但统一走 merge 防窗口）
    // P1-12：一并复位元数据被拒路径的大写计数/耗尽标记（否则 SYNC_EXHAUSTED 仍拦住采集）
    await db.mergeImageData(imgRec.pageKey, imgRec.imageKey, {
      exhausted: false,
      retryCount: 0,
      lastError: null,
      firstPendingAt: nowIso,
      SYNC_EXHAUSTED: false,
      SYNC_RETRY_COUNT: 0,
      SYNC_STATUS: SYNC_STATUS_PENDING
    });
    try { await _uploadPendingImages(); } catch (e) { /* ignore */ }
    return { success: true, resetCount: 1 };
  }

  if (!(await isSyncAllowed().catch(function () { return false; })))
    return { success: false, error: 'sync not allowed' };
  var markStore = payload.store || (kind === 'annotation' ? 'annotations'
    : kind === 'page' ? 'pages'
    : kind === 'document' ? 'documents'
    : kind === 'snapshot' ? 'snapshots'
    : 'folders');
  var rec = await _readMark(markStore, kind, id);
  if (!rec) return { success: false, error: 'not found' };
  if (_isLimitRejectionReason(rec.SYNC_LAST_ERROR)) {
    return { success: false, error: 'limit-reached' };   // 限额项重试必被再拒（UI 已隐藏按钮，纯防御）
  }
  rec.SYNC_EXHAUSTED = false;
  rec.SYNC_RETRY_COUNT = 0;
  rec.SYNC_LAST_ERROR = null;
  rec.SYNC_STATUS = SYNC_STATUS_PENDING;
  await db.putMany(markStore, [rec]);
  await enqueueOffline({ type: 'sync', itemId: id, batchIds: [id], queuedAt: nowIso });
  try { await requestSync('immediate'); } catch (e) { /* ignore */ }
  return { success: true, resetCount: 1 };
}

// 放弃单项上传：保留本地数据，仅清脏同步状态（标 SYNCED、清 retry/exhausted/error/DIRTY_BITS），
// 使其离开 syncStatus PENDING/LOCAL/ERROR 索引扫描（getSyncFailures 不再返回），引擎不再尝试上传。
// 与 retryUpload 相反：不 enqueueOffline、不 requestSync、不触发上传。用户后续再编辑该记录会重新变脏入队（期望行为）。
async function discardUpload(payload) {
  var kind = payload && payload.kind;
  var id = payload && payload.id;
  if (!kind || id == null) return { success: false, error: 'missing kind/id' };

  // pageRect 截图未上云（THUMBNAIL_PENDING）：清标记使其离开 collectThumbPending 列表（标注本体可能已 SYNCED，仅截图待补传）。
  if (payload.thumbPending) {
    var annRec = await _readMark('annotations', 'annotation', id);
    if (!annRec) return { success: false, error: 'not found' };
    annRec.THUMBNAIL_PENDING = false;
    // 一并清掉失败/终态标记：否则 THUMB_LOCAL_MISSING 残留，collectThumbPending 仍会把该行
    // 扫出来 → 用户点「放弃」按不掉它（终态行只提供放弃按钮，那是它唯一的出口）。
    annRec.THUMB_LOCAL_MISSING = false;
    annRec.THUMB_LAST_ERROR = null;
    annRec.THUMB_RETRY_COUNT = 0;
    annRec.THUMB_EXHAUSTED = false;
    await db.putMany('annotations', [annRec]);
    // 同步出清单，不等下一轮 flush 的对账自清理——否则该 id 会短暂残留在工作清单里。
    // （cleanup-only，不影响返回结构：清理失败也不该让「放弃」报错。）
    try { await _removeThumbPending(id); } catch (e) { /* ignore */ }
    return { success: true, resetCount: 1 };
  }

  if (kind === 'image') {
    var imgRec = await _readMark('imageData', 'image', id);
    if (!imgRec) return { success: false, error: 'not found' };
    // P1-19: read-merge
    await db.mergeImageData(imgRec.pageKey, imgRec.imageKey, {
      exhausted: false,
      retryCount: 0,
      lastError: null,
      SYNC_STATUS: SYNC_STATUS_SYNCED
    });
    return { success: true, resetCount: 1 };
  }

  var markStore = payload.store || (kind === 'annotation' ? 'annotations'
    : kind === 'page' ? 'pages'
    : kind === 'document' ? 'documents'
    : kind === 'snapshot' ? 'snapshots'
    : 'folders');
  var rec = await _readMark(markStore, kind, id);
  if (!rec) return { success: false, error: 'not found' };
  rec.SYNC_EXHAUSTED = false;
  rec.SYNC_RETRY_COUNT = 0;
  rec.SYNC_LAST_ERROR = null;
  rec.SYNC_STATUS = SYNC_STATUS_SYNCED;
  if ('DIRTY_BITS' in rec) rec.DIRTY_BITS = 0;
  await db.putMany(markStore, [rec]);
  return { success: true, resetCount: 1 };
}

// 全部重传：批量复位所有失败+耗尽项，保持相对顺序重排到队尾。
// payload: {kinds:['mark','image']}（空=两者）
async function retryUploadAll(payload) {
  var kinds = (payload && payload.kinds) || [];
  var doMarks = kinds.length === 0 || kinds.indexOf('mark') >= 0;
  var doImages = kinds.length === 0 || kinds.indexOf('image') >= 0;
  var nowIso = new Date().toISOString();
  var resetCount = 0;

  if (doMarks && (await isSyncAllowed().catch(function () { return false; }))) {
    var markStores = [['annotations', 'MARK_INFO_ID'], ['pages', 'URL_MD5'], ['folders', 'folderId'], ['documents', 'docId'], ['snapshots', 'snapId']];
    for (var s = 0; s < markStores.length; s++) {
      var sn = markStores[s][0];
      try {
        var idx = db._tx(sn, 'readonly').index('syncStatus');
        var results = await Promise.all([
          _getAllFromIndex(idx, SYNC_STATUS_PENDING),
          _getAllFromIndex(idx, SYNC_STATUS_LOCAL),
          _getAllFromIndex(idx, SYNC_STATUS_ERROR)
        ]);
        var toReset = [];
        for (var r = 0; r < results.length; r++) {
          for (var i = 0; i < results[r].length; i++) {
            var rec = results[r][i];
            if (_isLimitRejectionReason(rec.SYNC_LAST_ERROR)) continue;   // 限额耗尽项不复位不重推
            if (rec.SYNC_EXHAUSTED || (rec.SYNC_RETRY_COUNT || 0) > 0) {
              rec.SYNC_EXHAUSTED = false;
              rec.SYNC_RETRY_COUNT = 0;
              rec.SYNC_LAST_ERROR = null;
              rec.SYNC_STATUS = SYNC_STATUS_PENDING;
              toReset.push(rec);
            }
          }
        }
        for (var c = 0; c < toReset.length; c += WPZL_IDB_WRITE_CHUNK) {
          await db.putMany(sn, toReset.slice(c, c + WPZL_IDB_WRITE_CHUNK));
        }
        resetCount += toReset.length;
      } catch (e) { /* ignore */ }
    }
    if (resetCount > 0) {
      await enqueueOffline({ type: 'sync', queuedAt: nowIso });
      try { await requestSync('immediate'); } catch (e) { /* ignore */ }
    }
  }

  if (doImages && (await isImageCloudUploadAllowed().catch(function () { return false; }))) {
    try {
      var imgIdx = db._tx('imageData', 'readonly').index('syncStatus');
      var imgResults = await Promise.all([
        _getAllFromIndex(imgIdx, SYNC_STATUS_PENDING),
        _getAllFromIndex(imgIdx, SYNC_STATUS_LOCAL),
        // P1-12：元数据被拒的记录停在 ERROR——手动重传必须扫到它们并复位大写计数
        _getAllFromIndex(imgIdx, SYNC_STATUS_ERROR)
      ]);
      var imgReset = [];
      for (var ir = 0; ir < imgResults.length; ir++) {
        for (var ii = 0; ii < imgResults[ir].length; ii++) {
          var irec = imgResults[ir][ii];
          if (_isLimitRejectionReason(irec.lastError || irec.SYNC_LAST_ERROR)) continue;
          // P1-16 连带：一并复位下载侧计数（dlExhausted 的记录不在 pending/local 索引里、
          // 在 download_pending——故凡扫到的记录只要有下载侧计数也复位；dlExhausted 的另扫一次）
          // P1-12：一并复位元数据被拒路径的大写计数/耗尽标记
          if (irec.exhausted || (irec.retryCount || 0) > 0 || (irec.dlRetryCount || 0) > 0 ||
              irec.SYNC_EXHAUSTED || (irec.SYNC_RETRY_COUNT || 0) > 0) {
            irec.exhausted = false;
            irec.retryCount = 0;
            irec.lastError = null;
            irec.firstPendingAt = nowIso;
            irec.SYNC_EXHAUSTED = false;
            irec.SYNC_RETRY_COUNT = 0;
            irec.SYNC_STATUS = SYNC_STATUS_PENDING;
            imgReset.push(irec);
          }
        }
      }
      // P1-16: dlExhausted 的记录 SYNC_STATUS='download_pending'，补扫复位（重新进入下载重试）
      try {
        var dlIdx = db._tx('imageData', 'readonly').index('syncStatus');
        var dlExhausted = await _getAllFromIndex(dlIdx, 'download_pending');
        var dlRetryRosterIds = [];
        for (var de = 0; de < dlExhausted.length; de++) {
          var drec = dlExhausted[de];
          if (drec.dlExhausted || (drec.dlRetryCount || 0) > 0) {
            drec.dlExhausted = false;
            drec.dlRetryCount = 0;
            drec.dlLastError = null;
            imgReset.push(drec);
            // P1-7：耗尽项在标记时已出清单——复位后 data 仍缺者重新入队（原要等 24h 自愈扫）
            if ((drec.cloudUrl || drec.imageUrl) && !drec.data) dlRetryRosterIds.push(drec.id);
          }
        }
        if (dlRetryRosterIds.length > 0 && typeof _noteImageDlPending === 'function') {
          try {
            _noteImageDlPending(dlRetryRosterIds.map(function (id) { return { id: id }; }));
            if (typeof _ensureImageSyncAlarm === 'function') { try { _ensureImageSyncAlarm(); } catch (e) { /* ignore */ } }
          } catch (e) { /* ignore */ }
        }
      } catch (e) { /* ignore */ }
      for (var ic = 0; ic < imgReset.length; ic += WPZL_IDB_WRITE_CHUNK) {
        await db.putMany('imageData', imgReset.slice(ic, ic + WPZL_IDB_WRITE_CHUNK));
      }
      resetCount += imgReset.length;
      if (imgReset.length > 0) {
        try { await _uploadPendingImages(); } catch (e) { /* ignore */ }
      }
    } catch (e) { /* ignore */ }
  }

  return { success: true, resetCount: resetCount };
}

var wpzlSyncEngine = {
  // Core（P1-39: legacy push()/pull() 已随旧分体端点下线删除，统一走 sync()）
  sync: sync,
  pullForUrlIfNeeded: pullForUrlIfNeeded,

  // Dirty tracking
  markDirty: markDirty,
  markDeleted: markDeleted,
  getPendingCount: getPendingCount,
  getDirtyCount: getDirtyCount,

  // Status
  getStatus: getStatus,
  getHealth: getHealth,
  getManualSyncBaseline: getManualSyncBaseline,
  commitManualSync: commitManualSync,
  getInitState: getInitState,
  waitForInit: waitForInit,
  decodeDirtyBits: decodeDirtyBits,
  getConflicts: function () {
    return new Promise(function (resolve) {
      chrome.storage.local.get(['wpzl_sync_conflicts'], function (r) {
        resolve(r.wpzl_sync_conflicts || []);
      });
    });
  },

  // Lifecycle
  onLogin: onLogin,
  onLogout: onLogout,
  onProChanged: onProChanged,
  flushImmediate: flushImmediate,
  requestSync: requestSync,
  setClearGuard: setClearGuard,        // P1：登出/清空前守卫（置中止+挡新周期+等在飞收尾由 SW 侧编排），清空后复位
  setImportSession: setImportSession,  // P2：导入会话抑制自动同步（restoreChunk/restoreBackup 驱动）

  // 切换账号时重置同步状态（清 sync_token 等，保留 device_id）
  resetSyncState: resetSyncState,

  // Config
  setEnabled: setEnabled,
  isEnabled: isEnabled,

  // Internal (exposed for service-worker hooks)
  _computeDirtyBits: computeDirtyBits,
  _flushPendingSyncRequest: _flushPendingSyncRequest, // E-P2-4: init jitter alarm 兜底调用
  _syncClearReconcileGates: _syncClearReconcileGates, // F-4: restoreBackup 后强制重建清单
  _uploadPendingImages: _uploadPendingImages,
  _checkPendingImageLimit: _checkPendingImageLimit,
  _noteImageMetaDirty: _noteImageMetaDirty,
  _clearImageMetaDirty: _clearImageMetaDirty,
  _getThumbPendingIds: _getThumbPendingIds,
  _setThumbPendingIds: _setThumbPendingIds,
  _noteThumbPending: _noteThumbPending,
  _removeThumbPending: _removeThumbPending,
  _mergeThumbPendingIds: _mergeThumbPendingIds, // 原子并入（链内重读，无丢更新窗口）
  _dropThumbPendingIds: _dropThumbPendingIds,   // 原子剔除（补传器对账自清理用）
  _getThumbPendingTruncated: _getThumbPendingTruncated, // C: 清单截断标志（补传器据此即时补货）
  _setThumbPendingTruncated: _setThumbPendingTruncated,
  _refreshThumbPendingIds: _refreshThumbPendingIds,     // C: 仅重建缩略图清单，绕开 24h 节流
  _resetThumbExhausted: _resetThumbExhausted,           // 手动「重传」先复位耗尽，否则补传器跳过该批 = 按钮空操作
  _reconcilePendingWorkLists: _reconcilePendingWorkLists,
  _noteR2DeletePending: _noteR2DeletePending,
  _flushR2DeleteQueue: _flushR2DeleteQueue,
  _maybeEvictImageData: _maybeEvictImageData,
  _getSyncMaxRetries: _getSyncMaxRetries, // P1-24: SW 缩略图 flush 耗尽上限复用同配置
  flushOfflineQueue: flushOfflineQueue,
  _offlineQueueHasPending: _offlineQueueHasPending,
  _countPendingLocalChanges: _countPendingLocalChanges, // P0(CL-01): 登出前未同步计数
  _updateHealth: _updateHealth,
  _getServerErrBackoff: _getServerErrBackoff,
  _isServerErrPaused: _isServerErrPaused,
  getSyncFailures: getSyncFailures,
  retryUpload: retryUpload,
  discardUpload: discardUpload,
  retryUploadAll: retryUploadAll,
  _maybeShowImageBacklogToast: _maybeShowImageBacklogToast,
  _maybeShowQuotaToast: _maybeShowQuotaToast,   // 配额满提示节流（30 分钟冷却）
  _setQuotaBlocked: _setQuotaBlocked,           // 配额阻断标志（供 SW 图片直传路径置位）

  // Init
  init: init,

  // Lock state（供 manager 页面判断同步是否进行中）
  _isLocked: function () { return _syncLock; },
  waitForUnlock: _waitForSyncUnlock, // P1-9：等锁事件通知（带超时兜底），取代 SW 侧 200ms 轮询

  // Download progress（供 manager 主动查询，不依赖 push 消息时序）
  _getDownloadProgress: function () {
    return { total: _syncDownloadTotal, pulled: _syncDownloadPulled };
  }
};
