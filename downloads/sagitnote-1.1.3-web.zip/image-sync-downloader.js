// ============================================================
// Sagitnote - Image Sync Downloader
// Loaded via importScripts('image-sync-downloader.js') by service-worker.js
//
// 职责：跨设备 pull 拿到 imageData 的 cloudUrl 元数据后，后台拉 blob 回填 data 字段。
// 因为 base64 不走 sync 通道（太大），只走 R2 直连。
//
// 设计要点（见 image-data-cloud-phase2-tasks.md §四）：
// - 独立 alarm 'image-sync-resume' 保活（MV3 SW 30s 回收，alarm 1min 唤醒续跑）
// - 入口 _enqueueImageSyncDownloads(records)：sync-engine._applyDownloadedImageAssetsChunk 在 pull
//   拿到新 cloudUrl 时调用（推入清单 + 激活 alarm 兜底 + 经链式调度器错峰起跑首批——P2-2 镜像 doc 侧）
// - 失败保留 cloudUrl，SYNC_STATUS='download_pending' 下次重试
// - 仅 Pro 用户参与（isImageCloudUploadAllowed 守门）
// ============================================================

var IMAGE_SYNC_ALARM = 'image-sync-resume';
var IMAGE_SYNC_ALARM_MINUTES = 1; // MV3 alarm 最小周期
var IMAGE_SYNC_BATCH = 8;         // 每 alarm 处理多少条
var IMAGE_SYNC_CONCURRENCY = 3;   // 并发下载数
// 2026-10-04 提速：批次完成后链式续跑（短歇即排下一批，不再干等下个 alarm tick）。
// 原纯 alarm 节流把吞吐钉死在 8 张/分钟（与网络无关）——全量重登 ~120 张要 15 分钟，
// 而实测单张 R2 下载仅 6-60ms。链式续跑后 alarm 仅作 SW 被回收后的保活兜底。
var IMAGE_SYNC_CHAIN_DELAY_MS = 1500; // 批间小歇（毫秒，实际 ±40% 抖动）
// P2-2（2026-10-05 测试报告，镜像 doc 侧）：enqueue→首批错峰小歇，不再等收尾错峰 kick
//（_scheduleBgDownloadAfterSync 的 3-8s）或 1min alarm 首跳。图片走预签名直连，
// 提前起跑只多 1 req/批的预签名往返，不占服务端中转吞吐。
var IMAGE_SYNC_FIRST_BATCH_DELAY_MS = 800;
// 方案1（同日）：失败项时间退避。链式提速后若失败仍按"每批必重试"，一次 40s 的服务端
// 抖动/限流就烧穿 dlRetryCount=10 → dlExhausted（本会话放弃）。改为指数退避：
// 失败后 dlNextAt = now + 30s·2^(n-1)（封顶 10min），到期前 collector 跳过且轮转到清单尾部。
// 429（服务端限流 IpRateLimitFilter 全局桶 600/min/60s 窗口）至少歇 60s——
// 防"429→链式密重试→更密 429"正反馈（服务端 javadoc 明示 429 会烧客户端重试计数）。
var IMG_DL_BACKOFF_BASE_MS = 30000;
var IMG_DL_BACKOFF_CAP_MS = 10 * 60 * 1000;
var IMG_DL_429_BACKOFF_MS = 60 * 1000;
// 第三批（2026-10-05，bulktest_10k 尾部实测 ~1 张/34s 拖到小时级）：尾部退避动态放宽。
// 资格=非 429 失败 且 近 IMG_DL_RECENT_SUCCESS_MS 内有任一张成功（源健康、单张偶发失败）——
// 退避减半、封顶降 3min；耗尽链从 ~68min 缩到 ~20min。**429 的 60s 下限不受放宽影响**
//（上方限流正反馈防护是有意设计，relax 不豁免 429）。
var IMG_DL_RECENT_SUCCESS_MS = 5 * 60 * 1000;
var IMG_DL_BACKOFF_RELAXED_CAP_MS = 3 * 60 * 1000;
var IMAGE_SYNC_STATUS_PENDING = 'download_pending';
// E-P2-8: 待下载图片的持久化 id 清单（syncMeta，镜像 thumb_pending_ids 模式）。
// 此前 _collectPendingImageDownloads 每分钟全表 getAll imageData（含全部 base64 data 字段，
// 300MB 水位库下每 tick 全量反序列化），只为找出"无 data 待回填"的少数记录。
// P1-7（2026-10-05 bulktest 10k 报告）：清单元素从纯 id 字符串升级为 tuple {id, nextAt}——
// _classifyPendingImageDownloads 改为纯清单数学，不再逐条 getImageData（旧实现全清单点查，
// 已下载未出队项每次物化 ~1MB blob，实测 93s/次）。读边界归一旧格式（字符串→nextAt:0）。
var IMG_DL_PENDING_MAX = 2000;      // 清单硬上限（超限丢最旧）
var IMG_DL_CHECK_PER_TICK = 24;     // 每 tick 核对的清单头部长度（批 8 的 3 倍，足够填批+出队已完成项）
var IMG_DL_FULLSCAN_INTERVAL_MS = 24 * 60 * 60 * 1000; // 全表自愈重建周期（兜底漏记/存量记录）

var _imageSyncActive = false;
// 2026-10-04 进度重做：原 _imageSyncProgress 是"批"作用域（total=本批 ≤8，每批重置 0/8→8/8 横跳），
// manager 提示条因此显示混乱。改为**会话累计** done（自队列上次确认为空起累计成功数）；
// 剩余数由 manager 轮询时从清单真值实时分类（_classifyPendingImageDownloads）+ 推送 nudge。
// 第三批（2026-10-05）：会话累计挪 chrome.storage.session（镜像 doc 侧）——MV3 SW 30s 回收后
// 进度条不再跳「已下 0」。求值即 hydrate；读路径（bg-download-progress）await 兜底。
var _imageDlSession = { done: 0 };
var _imageDlSessionHydrated = false;
var _imageDlSessionHydrating = null;
function _imageDlSessionHydrate() {
  if (_imageDlSessionHydrated) return Promise.resolve();
  if (_imageDlSessionHydrating) return _imageDlSessionHydrating;
  _imageDlSessionHydrating = (async function () {
    try {
      var st = await chrome.storage.session.get('image_dl_session');
      var saved = st && st.image_dl_session;
      if (saved && typeof saved.done === 'number' && saved.done > (_imageDlSession.done || 0)) {
        _imageDlSession.done = saved.done;   // 仅当持久值更大才覆盖（防丢 hydrate 前的本地增量）
      }
    } catch (e) { /* storage.session 不可用：退化为纯内存（与旧行为一致） */ }
    _imageDlSessionHydrated = true;
  })();
  return _imageDlSessionHydrating;
}
function _imageDlSessionAdd(delta) {
  _imageDlSession.done = (_imageDlSession.done || 0) + delta;   // 同步：读路径立刻可见
  try { chrome.storage.session.set({ image_dl_session: { done: _imageDlSession.done } }); } catch (e) { /* ignore */ }
}
function _imageDlSessionReset() {
  _imageDlSession.done = 0;   // 队列确认真空：会话结束，累计清零（持久化，防 SW 重启复活旧值）
  try { chrome.storage.session.set({ image_dl_session: { done: 0 } }); } catch (e) { /* ignore */ }
}
async function _imageDlSessionDone() {
  await _imageDlSessionHydrate();
  return _imageDlSession.done || 0;
}
_imageDlSessionHydrate();   // eval 即 hydrate

// 第三批：尾部退避放宽的资格信号——上次任一张下载成功的时刻（SW 内存；重启清零仅失去
// 放宽资格回到原曲线，无正确性影响）。批内任一成功即刷新。
var _imageDlLastSuccessAt = 0;

// ---- 入口：被 sync-engine._applyDownloadedImageAssetsChunk 调用 ----
// P2-2：记清单 + arm alarm 之外，经链式调度器 800ms 后起跑首批（fire-and-forget：
// _imageSyncChainTimer 去重 + _imageSyncActive 重入守卫，不阻塞 sync 主流程）。
// alarm 两职保留：SW 小歇间隙被回收的兜底接管 + 全员退避期的分钟级节流；
// _scheduleBgDownloadAfterSync 的收尾错峰 kick 仍在（与本 kick 经同一去重定时器，后到者空排）。
function _enqueueImageSyncDownloads(records) {
  if (!records || records.length === 0) return;
  console.log('[ImageSync] enqueued ' + records.length + ' image downloads');
  _noteImageDlPending(records);
  _ensureImageSyncAlarm();
  _scheduleNextImageBatch(IMAGE_SYNC_FIRST_BATCH_DELAY_MS);
}

// P1-7: 清单读边界——归一为 tuple 数组（旧字符串条目 → nextAt:0，首个写点落盘后即新格式）。
// catch 返回 null 供调用方区分瞬态读失败。
function _imgDlRosterNormalize(raw) {
  var out = [];
  for (var i = 0; i < (raw || []).length; i++) {
    var e = raw[i];
    if (typeof e === 'string') out.push({ id: e, nextAt: 0 });
    else if (e && e.id) out.push({ id: e.id, nextAt: e.nextAt || 0 });
  }
  return out;
}
function _loadImgDlRoster() {
  return _syncGetMeta('img_dl_pending_ids')
    .then(_imgDlRosterNormalize)
    .catch(function () { return null; });
}

// E-P2-8: 待下载 id 入清单（去重 + 有界）。fire-and-forget，失败仅丢本批提示（自愈扫描兜底）。
// 读失败（null）直接弃写：防瞬态读错把既有清单当空表覆盖（丢新条目可由自愈扫补回，覆盖全表不可）。
async function _noteImageDlPending(records) {
  try {
    var list = await _loadImgDlRoster();
    if (!list) return;
    for (var i = 0; i < records.length; i++) {
      var r = records[i];
      var id = r && (r.id || (r.pageKey && r.imageKey ? (r.pageKey + '_' + r.imageKey) : null));
      if (!id) continue;
      var hit = false;
      for (var j = 0; j < list.length; j++) { if (list[j] && list[j].id === id) { hit = true; break; } }
      if (!hit) list.push({ id: id, nextAt: 0 });
    }
    if (list.length > IMG_DL_PENDING_MAX) list = list.slice(list.length - IMG_DL_PENDING_MAX);
    await _syncSetMeta('img_dl_pending_ids', list);
  } catch (e) { /* ignore */ }
}

// P1-7: 出队（成功回填/已删/耗尽）与退避时钟镜像（分类只读清单；镜像 doc 侧同名函数）。
// 读失败（null）弃写同上——防瞬态读错覆盖清单。
async function _removeImageDlPendingByIds(ids) {
  if (!ids || ids.length === 0) return;
  try {
    var list = await _loadImgDlRoster();
    if (!list) return;
    var rm = {};
    for (var i = 0; i < ids.length; i++) rm[ids[i]] = true;
    var keep = list.filter(function (t) { return t && t.id && !rm[t.id]; });
    if (keep.length !== list.length) await _syncSetMeta('img_dl_pending_ids', keep);
  } catch (e) { /* ignore */ }
}

async function _setImgDlNextAt(id, nextAt) {
  if (!id) return;
  try {
    var list = await _loadImgDlRoster();
    if (!list) return;
    var found = false;
    for (var i = 0; i < list.length; i++) {
      if (list[i] && list[i].id === id) { list[i].nextAt = nextAt; found = true; break; }
    }
    if (found) await _syncSetMeta('img_dl_pending_ids', list);
  } catch (e) { /* ignore */ }
}

function _ensureImageSyncAlarm() {
  try {
    chrome.alarms.create(IMAGE_SYNC_ALARM, { periodInMinutes: IMAGE_SYNC_ALARM_MINUTES });
  } catch (e) { /* ignore */ }
}

// alarm 误清修复（2026-10-04）：仅清单本身确认读得到且为空才返回 true。
// 瞬态读失败（SW 冷启动 IDB 未就绪）按"未空"处理——曾因 collector 瞬态空读误清 alarm，
// 管线静默停摆到下次登录重新入队。
function _imagePendingListEmptyConfirmed() {
  return _syncGetMeta('img_dl_pending_ids')
    .then(function (l) { return !l || l.length === 0; })
    .catch(function () { return false; });
}

// 链式续跑调度（去重定时器）。SW 若在小歇间隙被回收，alarm 下个 tick 兜底接管。
// delayOverrideMs：错峰起步等场景用；缺省按链间抖动（方案3）——base ±40% 随机，
// 多客户端共同事件（早间重登）后去同步化，服务端到达曲线从梳齿变平滑。
var _imageSyncChainTimer = null;
function _scheduleNextImageBatch(delayOverrideMs) {
  if (_imageSyncChainTimer) return;
  var delay = (typeof delayOverrideMs === 'number' && delayOverrideMs > 0)
    ? delayOverrideMs
    : IMAGE_SYNC_CHAIN_DELAY_MS * (0.6 + Math.random() * 0.8);
  _imageSyncChainTimer = setTimeout(function () {
    _imageSyncChainTimer = null;
    _processImageSyncBatch();
  }, delay);
}

// sync 会话收尾错峰启动（方案2）：sync-engine 每轮成功收尾时调用。消掉重登后
// "首批干等 ≤60s alarm"的起步延迟；延后 3-8s 且 image/doc 错开，避免与 pull 峰值
// 及收尾配额探测请求叠加（服务端全局桶 600/min）。无待办时批处理器自空转出清
// （确认清单真空才清 alarm），无副作用；_chainTimer 去重守卫防重排已排定的链。
function _scheduleBgDownloadAfterSync() {
  try {
    if (typeof _scheduleNextImageBatch === 'function') _scheduleNextImageBatch(3000 + Math.random() * 3000);
    if (typeof _scheduleNextDocBatch === 'function') _scheduleNextDocBatch(5000 + Math.random() * 3000);
  } catch (e) { /* ignore */ }
}

// ---- 主处理流程（alarm 触发）----
async function _processImageSyncBatch() {
  if (_imageSyncActive) return;
  // P2-17 语义（有意行为，见 docs/同步机制重构方案-合并push和pull为单次请求.md 第十节）：
  // 无图片上云权限时 pull 到的 cloudUrl 记录不回填本地 data，渲染走原始 URL
  if (typeof wpzl_isImageCloudUploadAllowed !== 'function') return;
  var allowed = false;
  try { allowed = await wpzl_isImageCloudUploadAllowed(); } catch (e) { return; }
  if (!allowed) return;

  if (_imageSyncActive) return;   // kick/alarm 并发：await 后复查（检查+置位为同步相邻语句，原子）
  _imageSyncActive = true;
  try {
    var pending = await _collectPendingImageDownloads();
    // E-P2-8: 清单空 + 自愈扫描到期 → 全表重建一次（openCursor 流式，只留 id 不驻留记录）。
    // 兜底 pull 直投之外的来源：旧版本存量、清单丢失/截断、restoreBackup 导入。
    if (pending.length === 0 && await _imageDlFullScanDue()) {
      var rebuilt = await _rebuildImageDlPendingFullScan();
      if (rebuilt > 0) pending = await _collectPendingImageDownloads();
    }
    if (pending.length === 0) {
      // alarm 误清修复（2026-10-04）：collector 为空 ≠ 清单为空——瞬态读失败或头部
      // IMG_DL_CHECK_PER_TICK 条暂无可办而尾部仍待下载时，clear 掉 alarm 会令尾部饿死。
      // 仅当清单真值为空才 clear；下次 _enqueueImageSyncDownloads 仍会按需重建。
      if (await _imagePendingListEmptyConfirmed()) {
        try { chrome.alarms.clear(IMAGE_SYNC_ALARM); } catch (e) { /* ignore */ }
        _imageDlSessionReset();          // 队列确认真空：会话结束，累计清零
      }
      if (typeof _reportBgDownloadProgress === 'function') _reportBgDownloadProgress();
      return;
    }
    var batch = pending.slice(0, IMAGE_SYNC_BATCH);
    await _prewarmSignedAssetUrls(batch); // 方案4：批级预签名，摊薄逐张签名往返
    var successCount = 0;
    var doneIds = [];   // P1-7：成功项批末一次性出队（原滞留清单等下个头部核对，期间每轮 2s 分类点查 ~1MB blob）
    await _runConcurrent(batch, IMAGE_SYNC_CONCURRENCY, async function (rec) {
      var ok = false;
      try { ok = (await _downloadOneImage(rec)) === true; }
      finally {
        if (ok) {
          successCount++;
          _imageDlSessionAdd(1);
          _imageDlLastSuccessAt = Date.now();   // 第三批：刷新尾部退避放宽资格
          doneIds.push(rec.id);
        }
        if (typeof _reportBgDownloadProgress === 'function') _reportBgDownloadProgress();
      }
    });
    if (doneIds.length > 0) await _removeImageDlPendingByIds(doneIds);
    // 链式续跑：本批有进展即短歇后排下一批。全零成功（持续失败源）不续跑，
    // 交还 alarm 按分钟节流重试——既不热循环空转，也保住 dlRetryCount 退避语义。
    if (successCount > 0) _scheduleNextImageBatch();
  } catch (e) {
    console.warn('[ImageSync] batch failed:', e && e.message);
  } finally {
    _imageSyncActive = false;
  }
}

// E-P2-8: 从持久化清单核对出待下载记录（不再全表 getAll）。
// 每 tick 只核对清单头部 IMG_DL_CHECK_PER_TICK 条：按主键点查（索引读，不带无关行的 base64），
// 已完成/耗尽/已删的 id 顺手出队；尾部未核对的原样保留，后续 tick 轮到再核对。
// 过滤语义与旧全表扫一致：跳过 dlExhausted / pending_deleted / dataEvicted，
// 取 (cloudUrl || imageUrl) && !data 的记录。
// P1-7：清单元素为 tuple {id, nextAt}——核对时顺手用记录上的 dlNextAt 真值刷新 tuple
//（旧格式/漂移自愈），退避判定仍以记录为准（collector 是唯一有记录真值的路径）。
async function _collectPendingImageDownloads() {
  var roster;
  try { roster = await _loadImgDlRoster(); } catch (e) { return []; }
  if (!roster || !roster.length) return [];
  var pending = [];
  var keep = [];
  var deferred = []; // 方案1：退避未到期，轮转到清单最尾（防占住头部核对窗口阻塞新鲜项）
  var checked = 0;
  var i = 0;
  for (; i < roster.length && checked < IMG_DL_CHECK_PER_TICK; i++) {
    checked++;
    var t = roster[i];
    if (!t || !t.id) continue;          // 非法条目 → 出队
    var parts = String(t.id).split('_');
    if (parts.length !== 2 || parts[0].length !== 32 || parts[1].length !== 32) continue; // 非法 id 出队
    var rec = null, readErr = false;
    try { rec = await db.getImageData(parts[0], parts[1]); } catch (e) { readErr = true; }
    if (readErr) { keep.push(t); continue; } // 瞬态读失败：保队不误删（下个 tick 重查）
    if (!rec) continue;                 // 已删除 → 出队
    if (rec.dlExhausted) continue;      // 下载侧耗尽 → 出队（不再自动重试）
    if (rec.SYNC_STATUS === 'pending_deleted' || rec.dataEvicted) continue; // 终态/治理态 → 出队
    if ((rec.cloudUrl || rec.imageUrl) && !rec.data) {
      var nextAt = rec.dlNextAt || 0;
      if (nextAt > Date.now()) { deferred.push({ id: t.id, nextAt: nextAt }); continue; } // 退避中 → 让位
      pending.push(rec);
      keep.push({ id: t.id, nextAt: nextAt });   // 仍待下载 → 留队
    }
    // rec.data 已回填 → 出队（正常路径已批末即时出队，此处兜漏）
  }
  keep = keep.concat(roster.slice(i)).concat(deferred); // 未核对尾部在前、退避项垫最后
  try { await _syncSetMeta('img_dl_pending_ids', keep); } catch (e) { /* ignore */ }
  return pending;
}

// 导出门禁/进度条用：P1-7（2026-10-05）改为纯清单数学——不点查 imageData（旧实现全清单逐条
// getImageData，已下载未出队项每次物化 ~1MB blob，bulktest 10k 实测 93s/次）。
// due/backing 由 tuple.nextAt 比出；nextAt 与记录真值由 _markDownloadPending/头部核对成对维护。
// 记录级漂移（已删/已回填仍留清单）由出入队钩子 + 头部核对 + 24h 自愈扫收敛，瞬时虚高可接受。
async function _classifyPendingImageDownloads() {
  var roster;
  try { roster = await _loadImgDlRoster(); } catch (e) { return { due: 0, backing: 0 }; }
  if (!roster) return { due: 0, backing: 0 };
  var due = 0;
  var backing = 0;
  var now = Date.now();
  for (var i = 0; i < roster.length; i++) {
    var t = roster[i];
    if (!t || !t.id) continue;
    var parts = String(t.id).split('_');
    if (parts.length !== 2 || parts[0].length !== 32 || parts[1].length !== 32) continue; // 非法 id 不计
    if (t.nextAt && t.nextAt > now) backing++;
    else due++;
  }
  return { due: due, backing: backing };
}

// 导出门禁计数（语义不变：未耗尽且缺 data 的全部 = due + backing）
async function _countPendingImageDownloadsAll() {
  var c = await _classifyPendingImageDownloads();
  return c.due + c.backing;
}

async function _imageDlFullScanDue() {
  try {
    var last = await _syncGetMeta('img_dl_scan_last_run') || 0;
    return (Date.now() - last) > IMG_DL_FULLSCAN_INTERVAL_MS;
  } catch (e) { return false; }
}

// E-P2-8: 全表自愈重建清单（openCursor 流式逐条判断，不把全部记录驻留内存；
// 有 data 的大记录逐条流过即释放，内存峰值 = 单条记录而非全表）。
async function _rebuildImageDlPendingFullScan() {
  var ids = [];
  await new Promise(function (resolve) {
    var req;
    try { req = db._tx('imageData', 'readonly').openCursor(); } catch (e) { resolve(); return; }
    req.onsuccess = function (ev) {
      var cursor = ev.target.result;
      if (!cursor) { resolve(); return; }
      var rec = cursor.value;
      if (rec && !rec.dlExhausted && rec.SYNC_STATUS !== 'pending_deleted' && !rec.dataEvicted
          && (rec.cloudUrl || rec.imageUrl) && !rec.data) {
        ids.push({ id: rec.id, nextAt: rec.dlNextAt || 0 });   // P1-7: tuple 形态
        if (ids.length >= IMG_DL_PENDING_MAX) { resolve(); return; }
      }
      cursor.continue();
    };
    req.onerror = function () { resolve(); };
  });
  try {
    await _syncSetMeta('img_dl_pending_ids', ids);
    await _syncSetMeta('img_dl_scan_last_run', Date.now());
  } catch (e) { /* ignore */ }
  console.log('[ImageSync] full-scan rebuilt pending list:', ids.length);
  return ids.length;
}

// 下载源优先级：原始网络 URL > R2 cloudUrl。
// 阶段 1 用 rec.imageUrl（fetch 原生支持 data: 与 http(s): URL）；失败 fallback 阶段 2。
// 阶段 2 用 rec.cloudUrl 走 R2 签名 URL（原逻辑）。
// 两阶段都失败 → 标 download_pending 等下次 alarm 重试。
// 返回值：true=data 已回填（链式续跑依据）；false=失败已标 pending。
// 注：本扩展未启用 declarativeNetRequest 防盗链绕过，严格 referer 校验的图会自动 fallback 到 R2。
async function _downloadOneImage(rec) {
  // 阶段 1：优先原始网络 URL（节省 R2 流量）
  if (rec.imageUrl && /^(https?|data):/i.test(rec.imageUrl)) {
    try {
      var base64 = await _fetchImageAsBase64(rec.imageUrl);
      await _saveImageDataWithData(rec, base64);
      console.log('[ImageSync] fetched from original URL: ' + rec.id);
      return true;
    } catch (e) {
      console.warn('[ImageSync] original URL failed, fallback to cloudUrl: ' + rec.id + ' — ' + (e && e.message));
    }
  }

  // 阶段 2：fallback 到 R2 cloudUrl
  if (!rec.cloudUrl) {
    // 既无可用 imageUrl 也无 cloudUrl — 无法下载，标 pending 等下次
    await _markDownloadPending(rec);
    return false;
  }
  try {
    var signedUrl = await wpzl_getSignedAssetUrl(rec.cloudUrl);
    var cloudBase64 = await _fetchImageAsBase64(signedUrl);
    await _saveImageDataWithData(rec, cloudBase64);
    console.log('[ImageSync] fetched from cloudUrl: ' + rec.id);
    return true;
  } catch (e) {
    console.warn('[ImageSync] cloudUrl download failed: ' + rec.id + ' — ' + (e && e.message));
    rec._lastDlError = e && e.message;
    rec._lastDlStatus = (e && e.status) || 0; // _wpzlApiFetch 错误带 status（429 限流等）
    await _markDownloadPending(rec);
    return false;
  }
}

// 共用：fetch URL → base64 dataURL（仿 service-worker.js saveImageFromUrl case）
// E-P2-3: 必须带超时——裸 fetch 挂起时 _downloadOneImage 永不返回、_imageSyncActive 恒 true，
// 每分钟 alarm tick 全部被短路，整条图片回填管线卡死直到 SW 进程被系统回收。
async function _fetchImageAsBase64(url) {
  var resp = await _wpzlFetchWithTimeout(url, {}, 30000);
  if (!resp.ok) throw new Error('HTTP ' + resp.status);
  var blob = await resp.blob();
  return await new Promise(function (resolve, reject) {
    var reader = new FileReader();
    reader.onloadend = function () { resolve(reader.result); };
    reader.onerror = function () { reject(reader.error); };
    reader.readAsDataURL(blob);
  });
}

// 共用：写回 data，SYNC_STATUS=synced / DIRTY_BITS=0
// 先读再 merge（saveImageData 是 put 整记录覆盖，避免丢字段）
async function _saveImageDataWithData(rec, base64) {
  var fresh = await db.getImageData(rec.pageKey, rec.imageKey);
  var merged = Object.assign({}, fresh || rec, {
    data: base64,
    SYNC_STATUS: 'synced',
    DIRTY_BITS: 0,
    dlNextAt: 0 // 成功即清退避时钟（若曾有）
  });
  // P1-16: 下载成功即复位下载侧重试计数（上游源恢复后可自动恢复）
  if (merged.dlRetryCount || merged.dlExhausted) {
    merged.dlRetryCount = 0;
    merged.dlExhausted = false;
    merged.dlLastError = null;
  }
  await db.saveImageData(merged);
}

// 共用：失败标 download_pending，等下次 alarm 重试。
// P1-16: 下载侧独立计数（dlRetryCount/dlExhausted，与上传侧 retryCount/exhausted 语义不混），
// 达 IMAGE_DL_MAX_RETRIES 置耗尽——不再进收集器，重试频率从"每分钟"降为 0。
// 复位途径：sync-engine resetSyncFailures 的 doImages 分支统一清零。
var IMAGE_DL_MAX_RETRIES = 10;

// 第三批：退避曲线抽纯函数（可单测）。指数 30s·2^(n-1)；relaxed（非 429 且近期有全局成功）
// → 减半、封顶降 3min；429 恒 ≥60s——放宽先减半、后过 429 下限、最后封顶，429 不被豁免。
function _imgDlBackoffMs(retryCount, is429, relaxed) {
  var bo = IMG_DL_BACKOFF_BASE_MS * Math.pow(2, Math.max(0, retryCount - 1));
  if (relaxed) bo = bo / 2;
  if (is429) bo = Math.max(bo, IMG_DL_429_BACKOFF_MS);
  return Math.min(bo, relaxed ? IMG_DL_BACKOFF_RELAXED_CAP_MS : IMG_DL_BACKOFF_CAP_MS);
}

async function _markDownloadPending(rec) {
  try {
    var fresh2 = await db.getImageData(rec.pageKey, rec.imageKey);
    if (fresh2) {
      fresh2.SYNC_STATUS = IMAGE_SYNC_STATUS_PENDING;
      fresh2.dlRetryCount = (fresh2.dlRetryCount || 0) + 1;
      // 方案1：指数退避（曲线见 _imgDlBackoffMs）——429 至少歇 60s 对齐服务端限流窗口，
      // 切断 429→密重试正反馈；第三批放宽仅限非 429 且近期（5min）有全局成功的偶发失败。
      var _is429 = (rec._lastDlStatus === 429) || String(rec._lastDlError || '').indexOf('429') >= 0;
      var _relaxed = !_is429 && _imageDlLastSuccessAt && (Date.now() - _imageDlLastSuccessAt < IMG_DL_RECENT_SUCCESS_MS);
      fresh2.dlNextAt = Date.now() + _imgDlBackoffMs(fresh2.dlRetryCount, _is429, _relaxed);
      if (fresh2.dlRetryCount >= IMAGE_DL_MAX_RETRIES && !fresh2.dlExhausted) {
        fresh2.dlExhausted = true;
        console.warn('[ImageSync] download exhausted after ' + fresh2.dlRetryCount +
                     ' retries: ' + rec.id + ' — ' + (fresh2.dlLastError || ''));
        // P1-14/P1-33：耗尽主动通知（本文件与 sync-engine 同在 SW 全局作用域，importScripts 顺序加载）
        if (typeof _broadcastSyncExhausted === 'function') {
          _broadcastSyncExhausted({ kind: 'image-download', id: rec.id, retryCount: fresh2.dlRetryCount });
        }
      }
      fresh2.dlLastError = String(rec._lastDlError || '').slice(0, 200) || null;
      await db.saveImageData(fresh2);
      // P1-7：退避/耗尽成对镜像到清单（分类只读清单，不点查记录）
      await _setImgDlNextAt(rec.id, fresh2.dlNextAt);
      if (fresh2.dlExhausted) await _removeImageDlPendingByIds([rec.id]);  // 耗尽即出队（复位途径 resetSyncFailures 会重新入队）
    }
  } catch (e2) { /* ignore */ }
}

// 批级预签名（方案4）：一次 sign-batch 签整批 unique cloudUrl，回填 asset-uploader 的
// 签名 LRU 缓存——批内 _downloadOneImage 的 wpzl_getSignedAssetUrl 全命中缓存（零逐张请求），
// 图片链路对服务端签名端点的请求密度降 ~8×（对象 GET 仍直连存储）。失败静默：逐张路径天然兜底。
async function _prewarmSignedAssetUrls(batch) {
  if (typeof wpzl_preSignAssetUrls !== 'function') return;
  var keys = [];
  var seen = {};
  for (var i = 0; i < batch.length; i++) {
    var k = batch[i] && batch[i].cloudUrl;
    if (k && !seen[k]) { seen[k] = true; keys.push(k); }
  }
  if (keys.length < 2) return; // 单 key 走逐张路径成本相同
  try { await wpzl_preSignAssetUrls(keys); } catch (e) { /* 静默，逐张兜底 */ }
}

async function _runConcurrent(items, concurrency, worker) {
  var index = 0;
  async function next() {
    while (index < items.length) {
      var i = index++;
      await worker(items[i]);
    }
  }
  var workers = [];
  for (var w = 0; w < concurrency && w < items.length; w++) workers.push(next());
  await Promise.all(workers);
}
