!function () {
  'use strict';

  // ---- i18n ----

  function applyI18n() {
    var elements = document.querySelectorAll('[data-i18n]');
    for (var i = 0; i < elements.length; i++) {
      var el = elements[i];
      var key = el.getAttribute('data-i18n');
      var msg = chrome.i18n.getMessage(key);
      if (msg) el.textContent = msg;
    }
    var placeholders = document.querySelectorAll('[data-i18n-placeholder]');
    for (var i = 0; i < placeholders.length; i++) {
      var el = placeholders[i];
      var key = el.getAttribute('data-i18n-placeholder');
      var msg = chrome.i18n.getMessage(key);
      if (msg) el.placeholder = msg;
    }
    document.documentElement.lang = chrome.i18n.getUILanguage();
  }

  // ---- Data Layer (via service worker) ----

  function sendMessage(operation, params) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage(
        { type: 'db-operation', operation: operation, params: params || {} },
        function (resp) {
          if (resp && resp.success) resolve(resp.data);
          else reject(new Error((resp && resp.error) || 'Operation failed'));
        }
      );
    });
  }

  // ---- Validation ----

  var DEFAULT_COLORS = ['#ff3c82', '#4f46e5', '#10b981', '#f59e0b', '#8b5cf6', '#06b6d4'];

  // ---- 快捷键默认表（⚠️ keep in sync with src/injected/shortcuts.js WPZL_DEFAULT_SHORTCUTS）----
  // 模型：全局功能键(DEFAULT_MODIFIER) + 每动作一个主键(DEFAULT_SHORTCUTS[action])。
  // 默认 Alt：Shift 是数字键上档键，Shift+1 产出 "!"（运行时已按 e.code 归一化支持 Shift，
  // 但 Alt 不改变数字键产出、语义最干净，故仍为默认）。
  // SHORTCUTS_VERSION：默认方案有结构性变更时 +1；版本不匹配 → 丢弃旧存储用新默认。
  // ⚠️ keep in sync with src/injected/shortcuts.js WPZL_SHORTCUTS_VERSION。
  var SHORTCUTS_VERSION = 2;
  var DEFAULT_MODIFIER = 'Alt';
  var DEFAULT_SHORTCUTS = {
    'tool-arrow':         '1',
    'tool-flag':          '2',
    'tool-rect':          '3',
    'tool-pageRect':      '4',
    'tool-line':          '5',
    'tool-text':          '6',
    'tool-rectFrame':     '7',
    'tool-elementMark':   '8',
    'color-cycle':        'c',
    'style-cycle':        's',
    'auto-mark':          'a',
    'drawer-toggle':      'd',
    'annotation-toggle':  'e'
  };

  // 动作元数据：工具顺序与控制面板工具栏一致（箭头/旗帜/图片矩形/页面截图/自由划线/文字/矩形框/元素标记）
  // label 经 i18n 键本地化（复用工具/筛选类型键；快捷键专属动作用 sc* 键）
  var SHORTCUT_ACTIONS = [
    { action: 'tool-arrow',        i18nKey: 'toolArrow' },
    { action: 'tool-flag',         i18nKey: 'toolFlag' },
    { action: 'tool-rect',         i18nKey: 'filterRect' },
    { action: 'tool-pageRect',     i18nKey: 'filterPageRect' },
    { action: 'tool-line',         i18nKey: 'filterFreehand' },
    { action: 'tool-text',         i18nKey: 'typeTextNoteShort' },
    { action: 'tool-rectFrame',    i18nKey: 'filterRectFrame' },
    { action: 'tool-elementMark',  i18nKey: 'filterElementMark' },
    { action: 'color-cycle',       i18nKey: 'scCycleColor' },
    { action: 'style-cycle',       i18nKey: 'scCycleStyle' },
    { action: 'auto-mark',         i18nKey: 'scAutoMark' },
    { action: 'drawer-toggle',     i18nKey: 'scDrawerPanel' },
    { action: 'annotation-toggle', i18nKey: 'annotationToggle', alwaysOn: true }
  ];
  SHORTCUT_ACTIONS.forEach(function (a) {
    Object.defineProperty(a, 'label', {
      get: function () { return chrome.i18n.getMessage(this.i18nKey) || this.i18nKey; }
    });
  });

  // Ctrl 下的浏览器保留/不可拦截主键（页面/插件脚本无法 preventDefault）
  var CTRL_RESERVED_KEYS = { 'w': 1, 't': 1, 'n': 1, 'l': 1, '1': 1, '2': 1, '3': 1, '4': 1, '5': 1, '6': 1, '7': 1, '8': 1, '9': 1 };

  // Shift 上档归一化：按住 Shift 时数字键 e.key 产出上档符号（Shift+1→'!'）、小键盘产出 End 等，
  // 需用 e.code 物理键码还原主键，保证功能键=Shift 时捕获记录与运行时匹配口径一致。
  // ⚠️ keep in sync with src/injected/shortcuts.js / src/content/content.js（三上下文无法共享模块）。
  function normalizeShiftedKey(e) {
    if (e.shiftKey && e.code) {
      if (/^Digit\d$/.test(e.code)) return e.code.slice(5);    // Digit1 → '1'
      if (/^Numpad\d$/.test(e.code)) return e.code.slice(6);   // Numpad1 → '1'
    }
    return null;
  }

  // 从事件提取「主键」（单字符小写；多字符如 F1 保留；纯修饰键返回 null）
  function readShortcutKey(e) {
    var key = e.key;
    if (!key) return null;
    if (key === 'Control' || key === 'Shift' || key === 'Alt' || key === 'Meta') return null;
    var shifted = normalizeShiftedKey(e);
    if (shifted) return shifted;
    if (key === ' ') key = 'Space';
    if (key.length === 1) key = key.toLowerCase();
    return key;
  }

  // 调色板名称上限：最长 12 个字符，仅存 chrome.storage.local
  var NAME_MAX_CHARS = 12;

  function validateColorName(name) {
    if (!name || name.trim().length === 0) return false;
    return name.trim().length <= NAME_MAX_CHARS;
  }

  // ---- Toast ----

  function showToast(msg) {
    var existing = document.querySelector('.sp-toast');
    if (existing) existing.remove();
    var toast = document.createElement('div');
    toast.className = 'sp-toast';
    toast.textContent = msg;
    toast.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);padding:10px 24px;background:#1e293b;color:#fff;border-radius:8px;font-size:13px;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,0.15);';
    document.body.appendChild(toast);
    setTimeout(function () { toast.remove(); }, 2000);
  }

  // ---- 危险操作确认模态框（清空数据 / 切换用户并清空 / 退出并清空 共用） ----
  // 须输入与 phrase 匹配的文字后确认按钮才可用；替代原 window.confirm。

  var _dangerCtx = null;        // 当前确认动作 { onConfirm }
  var _dangerTrigger = null;    // 触发按钮，关闭时还原焦点

  function _dangerEls() {
    return {
      overlay: document.getElementById('spDangerModal'),
      input: document.getElementById('spDangerModalInput'),
      error: document.getElementById('spDangerModalError'),
      cancel: document.getElementById('spDangerModalCancel'),
      confirm: document.getElementById('spDangerModalConfirm'),
      // 本地模式（游客档，2026-09-29）：requireBackupCheck 两件套
      checkboxRow: document.getElementById('spDangerCheckboxRow'),
      checkbox: document.getElementById('spDangerCheckbox'),
      checkboxLabel: document.getElementById('spDangerCheckboxLabel'),
      backupHint: document.getElementById('spDangerBackupHint')
    };
  }

  function _dangerMatched() {
    if (!_dangerCtx) return false;
    var input = document.getElementById('spDangerModalInput');
    var phraseOk = (input && input.value || '').trim().toLowerCase() === _dangerCtx.phrase.trim().toLowerCase();
    // requireBackupCheck 门禁：短语匹配 且（无勾选要求 || 已勾选「我已备份数据」）
    var needCheck = !!(_dangerCtx && _dangerCtx.requireBackupCheck);
    var checked = false;
    if (needCheck) {
      var cb = document.getElementById('spDangerCheckbox');
      checked = !!(cb && cb.checked);
    }
    return phraseOk && (!needCheck || checked);
  }

  function _dangerRefreshState() {
    var els = _dangerEls();
    if (!els.input || !els.confirm) return;
    var needCheck = !!(_dangerCtx && _dangerCtx.requireBackupCheck);
    // 未勾选备份确认 → 输入框禁用（无可匹配的文字，confirm 自然保持禁用）
    els.input.disabled = needCheck && !(els.checkbox && els.checkbox.checked);
    var matched = _dangerMatched();
    els.confirm.disabled = !matched;
    if (els.input.classList) {
      if (matched) els.input.classList.add('match');
      else els.input.classList.remove('match');
    }
    if (els.error) els.error.textContent = '';
  }

  function closeDangerModal() {
    var els = _dangerEls();
    if (els.overlay) els.overlay.style.display = 'none';
    _dangerCtx = null;
    if (els.input) { els.input.value = ''; els.input.disabled = false; if (els.input.classList) els.input.classList.remove('match'); }
    if (els.error) els.error.textContent = '';
    if (els.confirm) { els.confirm.disabled = true; els.confirm.textContent = ''; }
    if (els.cancel) els.cancel.disabled = false;
    // 复位 requireBackupCheck 两件套（显隐/勾选/disabled）
    if (els.checkboxRow) els.checkboxRow.style.display = 'none';
    if (els.checkbox) els.checkbox.checked = false;
    if (els.backupHint) els.backupHint.style.display = 'none';
    if (_dangerTrigger && document.contains(_dangerTrigger)) {
      try { _dangerTrigger.focus(); } catch (e) { /* ignore */ }
    }
    _dangerTrigger = null;
  }

  function _dangerExecute() {
    if (!_dangerCtx || !_dangerMatched()) return;
    var fn = _dangerCtx.onConfirm;
    var els = _dangerEls();
    // 执行期防重入：先关框再跑回调（清空路径按钮 loading + toast，登出路径直接跳转）
    if (els.confirm) { els.confirm.disabled = true; els.confirm.textContent = '…'; }
    if (els.cancel) els.cancel.disabled = true;
    closeDangerModal();
    if (typeof fn === 'function') fn();
  }

  function _bindDangerModal() {
    var els = _dangerEls();
    if (!els.overlay || els.overlay.dataset.bound) return;
    els.overlay.dataset.bound = '1';
    els.input.addEventListener('input', _dangerRefreshState);
    els.input.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter') return;
      // IME 守卫：中文输入法组合期回车是选字，绝不能触发提交
      if (e.isComposing || e.keyCode === 229) return;
      e.preventDefault();
      if (_dangerMatched()) { _dangerExecute(); return; }
      if ((els.input.value || '').trim()) {
        els.error.textContent = chrome.i18n.getMessage('dangerMismatchHint') || '输入不一致，请核对后重新输入';
      }
    });
    // 本地模式（游客档，2026-09-29）：requireBackupCheck 的 checkbox change → 重算输入框/确定可用性
    if (els.checkbox) els.checkbox.addEventListener('change', _dangerRefreshState);
    if (els.backupHint) {
      var _bkLink = document.getElementById('spDangerBackupLink');
      if (_bkLink) {
        _bkLink.addEventListener('click', function (e) {
          e.preventDefault();
          _openManagerExportAll();
        });
      }
    }
    els.cancel.addEventListener('click', closeDangerModal);
    els.confirm.addEventListener('click', _dangerExecute);
    els.overlay.addEventListener('click', function (e) {
      if (e.target === els.overlay) closeDangerModal();
    });
    document.addEventListener('keydown', function (e) {
      if (_dangerCtx && e.key === 'Escape') closeDangerModal();
    });
  }

  // 「去备份 / 导出」类链接共用（数据管理区常驻链接 + 危险确认框内链接，2026-10-04）：
  // 深链直达 manager「导出全部」弹框——走 wpzl-open-manager 复用/聚焦已开 manager tab
  // （登记制，免 "tabs" 权限，见 SW _wpzlGetRegisteredTab；hash 由 manager 的
  // hashchange 监听/首载链接住），SW 不可达时退回普通新开（行为不劣于深链改造前）。
  function _openManagerExportAll() {
    try {
      chrome.runtime.sendMessage({ type: 'wpzl-open-manager', hash: '#export-all' })
        .catch(function () {
          chrome.tabs.create({ url: chrome.runtime.getURL('manager/manager.html#export-all') });
        });
    } catch (e) {
      chrome.tabs.create({ url: chrome.runtime.getURL('manager/manager.html#export-all') });
    }
  }

  // 数据管理区「去备份 / 导出」链接（常驻提示行内）
  var _spDataMgmtBackupLink = document.getElementById('spDataMgmtBackupLink');
  if (_spDataMgmtBackupLink) {
    _spDataMgmtBackupLink.addEventListener('click', function (e) {
      e.preventDefault();
      _openManagerExportAll();
    });
  }

  // opts: { title, desc, phrase, inputLabel, confirmLabel, onConfirm,
  //         requireBackupCheck, checkboxLabel, backupHint }   ← 后三者为本地模式（游客档）扩展，
  //         requireBackupCheck=true 时显示备份提示行 + 「我已备份数据」checkbox 门禁；
  //         缺省 false，既有调用行为不变。
  function openDangerConfirm(opts) {
    // 快捷键捕获器互斥：capture 态会吞掉模态输入框的每次按键当「主键」捕获
    if (activeCatcher) exitListening(activeCatcher, null);
    var els = _dangerEls();
    _dangerCtx = opts;
    _dangerTrigger = document.activeElement;
    document.getElementById('spDangerModalTitle').textContent = opts.title || '';
    document.getElementById('spDangerModalText').textContent = opts.desc || '';
    document.getElementById('spDangerModalInputLabel').textContent = opts.inputLabel || '';
    // requireBackupCheck 两件套显隐与文案
    var needCheck = !!opts.requireBackupCheck;
    if (els.checkboxRow) {
      els.checkboxRow.style.display = needCheck ? 'flex' : 'none';
      if (els.checkboxLabel) els.checkboxLabel.textContent = opts.checkboxLabel || '';
      if (els.checkbox) els.checkbox.checked = false;
    }
    if (els.backupHint) els.backupHint.style.display = needCheck ? 'flex' : 'none';
    els.confirm.textContent = opts.confirmLabel || '';
    els.confirm.disabled = true;
    els.cancel.disabled = false;
    els.input.value = '';
    els.input.disabled = needCheck;   // 未勾选 → 输入框禁用（change 后 _dangerRefreshState 解禁）
    if (els.input.classList) els.input.classList.remove('match');
    if (els.error) els.error.textContent = '';
    els.overlay.style.display = 'flex';
    if (needCheck && els.checkbox) els.checkbox.focus();
    else els.input.focus();
  }

  // ---- Broadcast settings update to all open tabs ----

  function broadcastUpdate(data) {
    chrome.tabs.query({}, function (tabs) {
      for (var i = 0; i < tabs.length; i++) {
        chrome.tabs.sendMessage(tabs[i].id, data).catch(function () {});
      }
    });
  }

  // ---- Color Palette ----

  function buildPaletteHTML(colors, names) {
    var html = '';
    for (var i = 0; i < colors.length; i++) {
      var n = names[i] || chrome.i18n.getMessage('colorDefault', [String(i + 1)]) || ('Color ' + (i + 1));
      html += '<div class="sp-item">' +
        '<input type="color" class="sp-color" data-idx="' + i + '" value="' + colors[i] + '">' +
        '<input type="text" class="sp-name" data-idx="' + i + '" value="' + n + '" maxlength="12" placeholder="' + (chrome.i18n.getMessage('paletteNamePlaceholder') || 'Name') + '">' +
        '</div>';
    }
    return html;
  }

  function loadPalette() {
    chrome.storage.local.get(['wpzl_colorPalette', 'wpzl_colorNames'], function (result) {
      var colors = result.wpzl_colorPalette;
      var names = result.wpzl_colorNames;
      if (!colors || !Array.isArray(colors) || colors.length !== 6) {
        colors = DEFAULT_COLORS.slice();
      }
      if (!names || !Array.isArray(names) || names.length !== 6) {
        names = [];
        for (var i = 0; i < 6; i++) {
          names.push(chrome.i18n.getMessage('colorDefault', [String(i + 1)]) || ('Color ' + (i + 1)));
        }
      }
      var paletteDiv = document.getElementById('spPalette');
      if (paletteDiv) paletteDiv.innerHTML = buildPaletteHTML(colors, names);
    });
  }

  function savePalette() {
    var colorInputs = document.querySelectorAll('.sp-color');
    var nameInputs = document.querySelectorAll('.sp-name');
    var newColors = [];
    var newNames = [];
    for (var i = 0; i < colorInputs.length; i++) {
      newColors.push(colorInputs[i].value);
      var name = nameInputs[i] ? nameInputs[i].value.trim() : '';
      if (!validateColorName(name)) {
        showToast(chrome.i18n.getMessage('toastNameTooLong', [String(NAME_MAX_CHARS)]) || 'Name too long');
        if (nameInputs[i]) nameInputs[i].focus();
        return;
      }
      newNames.push(name || (chrome.i18n.getMessage('colorDefault', [String(i + 1)]) || ('Color ' + (i + 1))));
    }
    if (newColors.length === 6) {
      chrome.storage.local.set({ wpzl_colorPalette: newColors, wpzl_colorNames: newNames }, function () {
        broadcastUpdate({ type: 'wpzl-settings-updated', palette: newColors, names: newNames });
        var btn = document.getElementById('spSavePalette');
        if (btn) {
          btn.textContent = '✓';
          btn.classList.add('saved');
          setTimeout(function () {
            btn.textContent = chrome.i18n.getMessage('savePalette') || 'Save';
            btn.classList.remove('saved');
          }, 1200);
        }
      });
    }
  }

  // ---- Image Annotation Settings ----

  function loadImgAnnoSettings() {
    chrome.storage.local.get(['wpzl_imgAnnoSettings', 'wpzl_autoSaveImage'], function (result) {
      var settings = result.wpzl_imgAnnoSettings;
      if (settings) {
        var mw = document.getElementById('spMinW');
        var mh = document.getElementById('spMinH');
        if (mw) mw.value = settings.minWidth || 100;
        if (mh) mh.value = settings.minHeight || 100;
      }
      var autoSaveCb = document.getElementById('spAutoSave');
      if (autoSaveCb) autoSaveCb.checked = (result.wpzl_autoSaveImage !== false);
    });
  }

  function saveImgAnnoSettings() {
    var minW = parseInt(document.getElementById('spMinW').value) || 100;
    var minH = parseInt(document.getElementById('spMinH').value) || 100;
    if (minW < 0) minW = 0;
    if (minH < 0) minH = 0;
    var autoSaveCb = document.getElementById('spAutoSave');
    var autoSave = autoSaveCb ? autoSaveCb.checked : false;

    var settings = { minWidth: minW, minHeight: minH };
    chrome.storage.local.set({ wpzl_imgAnnoSettings: settings, wpzl_autoSaveImage: autoSave }, function () {
      broadcastUpdate({
        type: 'wpzl-settings-updated',
        imgAnnoSettings: settings,
        autoSaveImage: autoSave
      });
      var btn = document.getElementById('spSaveImg');
      if (btn) {
        btn.textContent = '✓';
        btn.classList.add('saved');
        setTimeout(function () {
          btn.textContent = chrome.i18n.getMessage('saveImgAnnotationSettings') || 'Save';
          btn.classList.remove('saved');
        }, 1200);
      }
    });
  }

  // ---- 标注显示设置（"在页面上显示标记作者"开关；身份编辑与"允许修改他人标注"开关已移除） ----

  function loadAnnotationDisplay() {
    // 读取"在页面上显示标记作者"开关（默认关闭）
    chrome.storage.local.get(['wpzl_showAuthorLabels'], function (result) {
      var cb = document.getElementById('spShowLabels');
      if (cb) cb.checked = !!result.wpzl_showAuthorLabels;
    });
  }

  function toggleShowLabels() {
    var cb = document.getElementById('spShowLabels');
    if (!cb) return;
    var val = cb.checked;
    chrome.storage.local.set({ wpzl_showAuthorLabels: val }, function () {
      broadcastUpdate({
        type: 'wpzl-settings-updated',
        showAuthorLabels: val
      });
    });
  }

  // ---- 抽屉打开方式（推屏 / 覆盖） ----
  function loadDrawerMode() {
    chrome.storage.local.get(['wpzl_drawerMode'], function (result) {
      var sel = document.getElementById('spDrawerMode');
      if (sel) sel.value = result.wpzl_drawerMode || 'push';
    });
  }
  function saveDrawerMode() {
    var sel = document.getElementById('spDrawerMode');
    if (!sel) return;
    var val = sel.value;
    chrome.storage.local.set({ wpzl_drawerMode: val }, function () {
      broadcastUpdate({ type: 'wpzl-settings-updated', drawerMode: val });
    });
  }

  // ---- 退出并清空（清本地数据 + 登出；经输入确认模态框后执行） ----
  // settings 是常驻标签页（非 popup），window.close() 无效 → 清空后跳 auth.html 登录页。
  // SW 的 _wpzlLogoutAndClearLocal 会广播 auth-state-changed，settings 守卫也会触发跳转；
  // 这里主动 replace 避免依赖广播时序。
  // 注：原「清空本地全部数据」「切换用户并清空」两个按钮已移除（入口收敛，见 settings.html
  // 数据管理区）；SW 的 clearAllData 能力保留，「退出并清空」已覆盖解死锁场景。
  async function _doClearAndLogout(reason, force) {
    var btn = document.getElementById('spLogout');
    if (btn) { btn.disabled = true; btn.textContent = '…'; }
    var _resp = null;
    try {
      _resp = await chrome.runtime.sendMessage({ type: 'auth-logout', reason: reason, force: !!force });
    } catch (e) { /* ignore */ }
    // D-35: 清空失败 → 中止登出并提示重试（reload 恢复按钮状态），不跳登录页
    if (_resp && _resp.success === false && _resp.error === 'local_clear_failed') {
      window.alert(chrome.i18n.getMessage('logoutClearFailedRetry') ||
        '本地数据清空失败，已中止退出。请再试一次退出；若持续失败，请重启浏览器后重试。');
      location.reload();
      return;
    }
    // P0(CL-01) 2026-09-19：存在未上云的本地修改（离线创建/编辑）——SW 已尝试 flush 仍排不掉
    //（断网/配额满等）。弹确认：取消（可联网等自动同步后再退）/ 确认（force 重发，物理删除）。
    if (_resp && _resp.success === false && _resp.error === 'pending_unsynced' && !force) {
      var _n = _resp.pendingCount || 0;
      var _msg = chrome.i18n.getMessage('logoutPendingUnsynced', [String(_n)]) ||
        ('有 ' + _n + ' 条本地修改尚未同步到云端，退出将永久删除且无法恢复（服务器上的旧数据不受影响）。\n\n' +
          '「确定」= 直接退出并删除这些修改；「取消」= 暂不退出（联网后稍等自动同步完成再退出更安全）。');
      if (window.confirm(_msg)) {
        _doClearAndLogout(reason, true);
      } else {
        if (btn) { btn.disabled = false; location.reload(); }
      }
      return;
    }
    location.replace(chrome.runtime.getURL('popup/auth.html'));
  }

  // ---- 云存储管理（设置 → 数据管理；查看/批量删除已上云的图片、文档、快照） ----
  // 入口刻意放在设置而非标记管理：这是低频的清理类操作。数据链路与 SW 的
  // storage-overview / storage-list / storage-delete 消息一一对应（服务端 /api/v1/storage）。
  // 图片 tab 为两级结构：pageKey 目录行（选中 → 按目录级联删）+ 展开后的单图行（按 objectKey 删）。
  // 选中项统一记作 "type:key"，删除时按前缀分组发请求，因此目录与单图可混合勾选。
  var ST = {
    tab: 'page',
    page: 0,
    size: 50,
    total: 0,
    items: [],
    overview: null,
    sort: 'size',         // size | time | name（服务端白名单排序，分页拉取下前端排序会失真）
    dir: 'desc',          // asc | desc
    expandedPage: null,   // 当前展开的 pageKey（null=未展开）
    children: {},         // pageKey -> 单图数组缓存
    selected: {},         // "page:xxx" | "image:xxx" | "doc:xxx" | "snap:xxx" -> true
    loading: false
  };

  function stT(key, subs, fallback) {
    var m = chrome.i18n.getMessage(key, subs);
    return m || (fallback != null ? fallback : key);
  }

  /** 经 SW 转调服务端（与 manager 时代同一链路；settings 只发消息，不直连 REST） */
  function stSend(type, extra) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage(Object.assign({ type: type }, extra || {}), function (r) {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (r && r.success) return resolve(r.data);
        reject(new Error((r && r.error) || 'FAILED'));
      });
    });
  }

  function stKey(type, key) { return type + ':' + key; }

  function stFmtBytes(bytes) {
    if (bytes == null) return '—';
    var n = Number(bytes);
    if (n <= 0) return '0 B';
    if (n < 1024) return n + ' B';
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
    if (n < 1024 * 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB';
    return (n / 1024 / 1024 / 1024).toFixed(2) + ' GB';
  }

  function stOverviewHtml(o) {
    var pct = 0;
    var over = o && !o.unlimited && o.usedBytes > o.limitBytes;
    if (o && !o.unlimited && o.limitBytes > 0) {
      pct = Math.min(100, Math.round(o.usedBytes * 100 / o.limitBytes));
    }
    var barCls = over ? 'is-danger' : (pct > 75 ? 'is-warn' : '');
    var b = o || { image: {}, snapshot: {}, doc: {} };
    return ''
      + '<div class="sp-storage-ov-head">'
      +   '<span>' + stT('storageTotalUsed', null, '已用云存储') + '</span>'
      +   '<span class="sp-storage-ov-used' + (over ? ' is-over' : '') + '">'
      +     stFmtBytes(o ? o.usedBytes : 0) + ' / '
      +     (o && o.unlimited ? '∞' : stFmtBytes(o ? o.limitBytes : 0))
      +     (over ? ' · ' + stT('storageOverQuota', null, '已超额') : '')
      +   '</span>'
      + '</div>'
      + (o && o.unlimited ? ''
          : '<div class="sp-storage-bar"><i class="' + barCls + '" style="width:' + pct + '%"></i></div>')
      + '<div class="sp-storage-buckets">'
      +   '<span class="sp-storage-bucket">' + stT('storageTabImages', null, '标注图片')
      +     ' <b>' + stFmtBytes(b.image.bytes) + '</b> (' + (b.image.count || 0) + ')</span>'
      +   '<span class="sp-storage-bucket">' + stT('storageTabDocs', null, '文档')
      +     ' <b>' + stFmtBytes(b.doc.bytes) + '</b> (' + (b.doc.count || 0) + ')</span>'
      +   '<span class="sp-storage-bucket">' + stT('storageTabSnaps', null, '网页快照')
      +     ' <b>' + stFmtBytes(b.snapshot.bytes) + '</b> (' + (b.snapshot.count || 0) + ')</span>'
      + '</div>';
  }

  function stLoadOverview() {
    return stSend('storage-overview').then(function (o) {
      ST.overview = o;
      var el = document.getElementById('spStorageOv');
      if (el) el.innerHTML = stOverviewHtml(o);
    }).catch(function () { /* 概览失败不阻断列表 */ });
  }

  function stLoadList() {
    if (ST.loading) return Promise.resolve();
    ST.loading = true;
    var body = document.getElementById('spStorageBody');
    if (body && ST.items.length === 0) {
      body.innerHTML = '<div class="sp-storage-loading">' + stT('shareLoading', null, '加载中…') + '</div>';
    }
    return stSend('storage-list', {
      listType: ST.tab,
      params: { page: ST.page, size: ST.size, sort: ST.sort, dir: ST.dir }
    }).then(function (data) {
      ST.loading = false;
      ST.items = (data && data.items) || [];
      ST.total = (data && data.total) || 0;
      stRenderList();
    }).catch(function (err) {
      ST.loading = false;
      ST.items = [];
      ST.total = 0;
      if (body) {
        body.innerHTML = '<div class="sp-storage-empty">'
          + stT('storageLoadFailed', null, '加载云存储列表失败')
          + (err && err.message ? ': ' + err.message : '') + '</div>';
      }
    });
  }

  function stRenderList() {
    var body = document.getElementById('spStorageBody');
    if (!body) return;
    body.innerHTML = '';

    if (!ST.items.length) {
      var empty = document.createElement('div');
      empty.className = 'sp-storage-empty';
      empty.textContent = ST.page > 0
        ? stT('storageNoMore', null, '没有更多了')
        : stT('storageEmpty', null, '暂无云端内容');
      body.appendChild(empty);
    } else {
      ST.items.forEach(function (it) {
        if (ST.tab === 'page') stRenderImageGroupRow(body, it);
        else stRenderLeafRow(body, it);
      });
    }

    // 累积式分页：还有下一页时给"加载更多"（列表是清理场景，无需页码跳转）
    if (ST.items.length && (ST.page + 1) * ST.size < ST.total) {
      var more = document.createElement('div');
      more.className = 'sp-storage-more';
      var moreBtn = document.createElement('button');
      moreBtn.type = 'button';
      moreBtn.textContent = stT('storageLoadMore', null, '加载更多')
        + '（已显示 ' + ST.items.length + ' / ' + ST.total + '）';
      moreBtn.addEventListener('click', function () {
        ST.page += 1;
        stLoadList();
      });
      more.appendChild(moreBtn);
      body.appendChild(more);
    }
    stUpdateBulkBar();
  }

  /** 图片 tab：目录行（pageKey 聚合，选中 = 级联删整目录） */
  function stRenderImageGroupRow(container, g) {
    var row = document.createElement('div');
    row.className = 'sp-storage-row is-group';

    var cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'sp-storage-check';
    cb.checked = !!ST.selected[stKey('page', g.pageKey)];
    cb.addEventListener('change', function () { stToggle('page', g.pageKey, cb.checked); });
    row.appendChild(cb);

    var main = document.createElement('div');
    main.className = 'sp-storage-main';
    var name = document.createElement('div');
    name.className = 'sp-storage-name';
    name.textContent = g.pageKey;
    name.title = g.pageKey;
    var sub = document.createElement('div');
    sub.className = 'sp-storage-sub';
    sub.textContent = stT('storageImgCount', [String(g.count)], g.count + ' 张图片')
      + (g.lastActiveAt ? ' · ' + g.lastActiveAt : '');
    main.appendChild(name);
    main.appendChild(sub);
    row.appendChild(main);

    var size = document.createElement('div');
    size.className = 'sp-storage-size';
    size.textContent = stFmtBytes(g.bytes);
    row.appendChild(size);

    var isOpen = ST.expandedPage === g.pageKey;
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'sp-storage-expand';
    btn.textContent = isOpen ? stT('storageCollapse', null, '收起') : stT('storageExpand', null, '展开');
    btn.addEventListener('click', function () { stToggleExpand(g.pageKey); });
    row.appendChild(btn);

    container.appendChild(row);

    if (isOpen && ST.children[g.pageKey]) {
      ST.children[g.pageKey].forEach(function (img) {
        container.appendChild(stBuildImageChildRow(img));
      });
    }
  }

  // 服务端时间串（UTC-naive "yyyy-MM-dd HH:mm:ss"）→ 本地墙上钟展示（yyyy-MM-dd HH:mm）。
  // 裸渲染会偏一个时区（服务端 2026-11 起全链路 UTC 轴）；ISO 带 Z/偏移按绝对时间解析，失败原样返回。
  function stFmtTime(ts) {
    if (!ts) return '';
    var t = String(ts).trim();
    var m = t.replace('T', ' ').match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?$/);
    var d = m
      ? new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)))
      : new Date(t);
    if (isNaN(d.getTime())) return ts;
    function _p2(n) { return n < 10 ? '0' + n : '' + n; }
    return d.getFullYear() + '-' + _p2(d.getMonth() + 1) + '-' + _p2(d.getDate())
      + ' ' + _p2(d.getHours()) + ':' + _p2(d.getMinutes());
  }

  function stBuildImageChildRow(img) {
    var row = document.createElement('div');
    row.className = 'sp-storage-row is-child';

    var cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'sp-storage-check';
    cb.checked = !!ST.selected[stKey('image', img.objectKey)];
    cb.addEventListener('change', function () { stToggle('image', img.objectKey, cb.checked); });
    row.appendChild(cb);

    var main = document.createElement('div');
    main.className = 'sp-storage-main';
    var name = document.createElement('div');
    name.className = 'sp-storage-name';
    name.textContent = (img.objectKey || '').split('/').pop() || img.objectKey;
    name.title = img.objectKey;
    var sub = document.createElement('div');
    sub.className = 'sp-storage-sub';
    sub.textContent = (img.contentType || '') + (img.createdAt ? ' · ' + stFmtTime(img.createdAt) : '');
    main.appendChild(name);
    main.appendChild(sub);
    row.appendChild(main);

    var size = document.createElement('div');
    size.className = 'sp-storage-size';
    size.textContent = stFmtBytes(img.sizeBytes);
    row.appendChild(size);

    return row;
  }

  /** 文档 / 快照：单层行 */
  function stRenderLeafRow(container, it) {
    var isDoc = ST.tab === 'doc';
    var key = isDoc ? it.docId : it.snapId;

    var row = document.createElement('div');
    row.className = 'sp-storage-row';

    var cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'sp-storage-check';
    cb.checked = !!ST.selected[stKey(ST.tab, key)];
    cb.addEventListener('change', function () { stToggle(ST.tab, key, cb.checked); });
    row.appendChild(cb);

    var main = document.createElement('div');
    main.className = 'sp-storage-main';
    var name = document.createElement('div');
    name.className = 'sp-storage-name';
    name.textContent = it.title || stT('storageUntitled', null, '（无标题）');
    name.title = it.title || key;
    var sub = document.createElement('div');
    sub.className = 'sp-storage-sub';
    sub.textContent = key + (isDoc
      ? (it.updatedAt ? ' · ' + stFmtTime(it.updatedAt) : '')
      : (' · ' + (it.snapType || 'lite') + (it.createdAt ? ' · ' + stFmtTime(it.createdAt) : '')));
    main.appendChild(name);
    main.appendChild(sub);
    row.appendChild(main);

    var size = document.createElement('div');
    size.className = 'sp-storage-size';
    size.textContent = stFmtBytes(it.bytes);
    row.appendChild(size);

    container.appendChild(row);
  }

  function stToggle(type, key, on) {
    var k = stKey(type, key);
    if (on) ST.selected[k] = true; else delete ST.selected[k];
    stUpdateBulkBar();
  }

  function stToggleExpand(pageKey) {
    if (ST.expandedPage === pageKey) {
      ST.expandedPage = null;
      stRenderList();
      return;
    }
    ST.expandedPage = pageKey;
    if (ST.children[pageKey]) { stRenderList(); return; }
    stSend('storage-list', { listType: 'image', params: { pageKey: pageKey, page: 0, size: 200, sort: ST.sort, dir: ST.dir } })
      .then(function (data) {
        ST.children[pageKey] = (data && data.items) || [];
        stRenderList();
      })
      .catch(function () {
        ST.children[pageKey] = [];
        stRenderList();
      });
  }

  function stSelectedEntries() { return Object.keys(ST.selected); }

  function stUpdateBulkBar() {
    var info = document.getElementById('spStorageSelInfo');
    var delBtn = document.getElementById('spStorageDeleteBtn');
    var allCb = document.getElementById('spStorageSelectAll');
    var n = stSelectedEntries().length;
    if (info) {
      info.textContent = n
        ? stT('storageSelectedN', [String(n)], '已选 ' + n + ' 项')
        : stT('storageSelectHint', null, '勾选后可批量删除');
    }
    if (delBtn) delBtn.disabled = n === 0;
    // 全选态只针对本页顶层行（展开的单图不计入，需单独勾选）
    if (allCb) {
      var total = ST.items.length;
      allCb.checked = total > 0 && total === n;
      allCb.indeterminate = n > 0 && n < total;
    }
  }

  function stSelectAll(on) {
    if (on) {
      ST.items.forEach(function (it) {
        if (ST.tab === 'page') ST.selected[stKey('page', it.pageKey)] = true;
        else if (ST.tab === 'doc') ST.selected[stKey('doc', it.docId)] = true;
        else ST.selected[stKey('snap', it.snapId)] = true;
      });
    } else {
      ST.selected = {};
    }
    stRenderList();
  }

  /** 按前缀分组执行删除（目录/单图/文档/快照可混合选中 → 分次请求，逐个累加结果） */
  function stExecuteDelete() {
    var groups = { page: [], image: [], doc: [], snap: [] };
    stSelectedEntries().forEach(function (k) {
      var i = k.indexOf(':');
      var t = k.slice(0, i);
      var v = k.slice(i + 1);
      if (groups[t]) groups[t].push(v);
    });
    var jobs = [
      { payload: { type: 'page', pageKeys: groups.page } },
      { payload: { type: 'image', objectKeys: groups.image } },
      { payload: { type: 'doc', docIds: groups.doc } },
      { payload: { type: 'snap', snapIds: groups.snap } }
    ].filter(function (j) {
      var p = j.payload;
      return (p.pageKeys || p.objectKeys || p.docIds || p.snapIds || []).length > 0;
    });
    if (!jobs.length) return Promise.resolve({ deleted: 0, freed: 0 });

    return jobs.reduce(function (chain, job) {
      return chain.then(function (acc) {
        return stSend('storage-delete', { payload: job.payload }).then(function (r) {
          acc.deleted += (r && r.deleted) || 0;
          acc.freed += (r && r.freedBytes) || 0;
          return acc;
        });
      });
    }, Promise.resolve({ deleted: 0, freed: 0 }));
  }

  // 删除二次确认（模态内的覆盖层）
  var _stConfirmResolve = null;
  function stConfirm(count) {
    return new Promise(function (resolve) {
      _stConfirmResolve = resolve;
      var desc = document.getElementById('spStorageConfirmDesc');
      if (desc) {
        desc.textContent = stT('storageConfirmCount', [String(count)],
          '即将删除 ' + count + ' 项云端内容。');
      }
      var layer = document.getElementById('spStorageConfirm');
      if (layer) layer.style.display = 'flex';
    });
  }
  function stCloseConfirm(ok) {
    var layer = document.getElementById('spStorageConfirm');
    if (layer) layer.style.display = 'none';
    var r = _stConfirmResolve;
    _stConfirmResolve = null;
    if (r) r(ok);
  }

  function stSetTab(tab) {
    if (ST.tab === tab) return;
    ST.tab = tab;
    ST.items = [];
    ST.expandedPage = null;
    ST.children = {};
    ST.selected = {};
    ST.page = 0;
    var tabs = document.querySelectorAll('.sp-storage-tab');
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].classList.toggle('active', tabs[i].dataset.storageTab === tab);
    }
    stLoadList();
  }

  /** 切换排序（value = "size_desc" 等）：重置分页与展开缓存后重载；选中项按 key 记录，跨排序保留有效 */
  function stSetSort(value) {
    var i = String(value || '').indexOf('_');
    if (i < 0) return;
    var sort = value.slice(0, i);
    var dir = value.slice(i + 1);
    if (sort === ST.sort && dir === ST.dir) return;
    ST.sort = sort;
    ST.dir = dir;
    ST.items = [];
    ST.expandedPage = null;
    ST.children = {};
    ST.page = 0;
    stLoadList();
  }

  function openStorageModal() {
    var overlay = document.getElementById('spStorageModal');
    if (!overlay) return;
    // 与快捷键捕获器互斥（capture 态会吞掉模态内的每次按键）
    if (activeCatcher) exitListening(activeCatcher, null);
    ST.tab = 'page';
    ST.page = 0;
    ST.sort = 'size';
    ST.dir = 'desc';
    ST.items = [];
    ST.expandedPage = null;
    ST.children = {};
    ST.selected = {};
    var tabs = document.querySelectorAll('.sp-storage-tab');
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].classList.toggle('active', tabs[i].dataset.storageTab === 'page');
    }
    var sortSel = document.getElementById('spStorageSort');
    if (sortSel) sortSel.value = 'size_desc';
    var layer = document.getElementById('spStorageConfirm');
    if (layer) layer.style.display = 'none';
    overlay.style.display = 'flex';
    stLoadOverview();
    stLoadList();
  }

  function closeStorageModal() {
    var overlay = document.getElementById('spStorageModal');
    if (overlay) overlay.style.display = 'none';
    _stConfirmResolve = null;
  }

  function _bindStorageModal() {
    var overlay = document.getElementById('spStorageModal');
    if (!overlay || overlay.dataset.bound) return;
    overlay.dataset.bound = '1';

    var tabs = document.querySelectorAll('.sp-storage-tab');
    for (var i = 0; i < tabs.length; i++) {
      (function (btn) {
        btn.addEventListener('click', function () { stSetTab(btn.dataset.storageTab); });
      })(tabs[i]);
    }

    var allCb = document.getElementById('spStorageSelectAll');
    if (allCb) allCb.addEventListener('change', function () { stSelectAll(allCb.checked); });

    var sortSel = document.getElementById('spStorageSort');
    if (sortSel) sortSel.addEventListener('change', function () { stSetSort(sortSel.value); });

    var closeBtn = document.getElementById('spStorageClose');
    if (closeBtn) closeBtn.addEventListener('click', closeStorageModal);

    var cancelBtn = document.getElementById('spStorageConfirmCancel');
    if (cancelBtn) cancelBtn.addEventListener('click', function () { stCloseConfirm(false); });
    var okBtn = document.getElementById('spStorageConfirmOk');
    if (okBtn) okBtn.addEventListener('click', function () { stCloseConfirm(true); });

    var delBtn = document.getElementById('spStorageDeleteBtn');
    if (delBtn) delBtn.addEventListener('click', function () {
      var entries = stSelectedEntries();
      if (!entries.length || delBtn.dataset.busy) return;
      delBtn.dataset.busy = '1';
      stConfirm(entries.length).then(function (ok) {
        if (!ok) { delete delBtn.dataset.busy; return; }
        delBtn.disabled = true;
        stExecuteDelete().then(function (acc) {
          delete delBtn.dataset.busy;
          ST.items = [];
          ST.children = {};
          ST.expandedPage = null;
          ST.selected = {};
          ST.page = 0;
          showToast(stT('storageDeletedN', [String(acc.deleted), stFmtBytes(acc.freed)],
            '已删除 ' + acc.deleted + ' 项，释放 ' + stFmtBytes(acc.freed)));
          stLoadOverview();
          stLoadList();
        }).catch(function (err) {
          delete delBtn.dataset.busy;
          delBtn.disabled = false;
          showToast(stT('storageDeleteFailed', null, '删除失败') + ': ' + ((err && err.message) || ''));
        });
      });
    });

    // 点遮罩关闭（确认层打开时不响应，避免误关）
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay && !_stConfirmResolve) closeStorageModal();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (_stConfirmResolve) { stCloseConfirm(false); return; }
      if (overlay.style.display !== 'none') closeStorageModal();
    });
  }

  // ---- 快捷键自定义（全局功能键 + 每动作一个主键）----

  var modifierDraft = DEFAULT_MODIFIER;     // 当前编辑中的功能键
  var shortcutDraft = {};                    // action -> 主键|null
  var activeCatcher = null;                  // 当前处于监听态的捕获按钮

  function keyDisplayText(key) {
    if (!key) return chrome.i18n.getMessage('shortcutsNone') || '未设置';
    return modifierDraft + '+' + key;
  }

  function renderModifierDropdown() {
    var sel = document.getElementById('spShortcutModifier');
    if (sel) sel.value = modifierDraft;
  }

  function renderShortcutRows() {
    var container = document.getElementById('spShortcuts');
    if (!container) return;
    container.innerHTML = '';
    for (var i = 0; i < SHORTCUT_ACTIONS.length; i++) {
      var meta = SHORTCUT_ACTIONS[i];
      var key = shortcutDraft[meta.action];
      var row = document.createElement('div');
      row.className = 'sp-shortcut-row';
      row.dataset.action = meta.action;

      var label = document.createElement('span');
      label.className = 'sp-shortcut-label';
      label.textContent = meta.label;
      if (meta.alwaysOn) {
        var tag = document.createElement('span');
        tag.className = 'sp-shortcut-tag';
        tag.textContent = chrome.i18n.getMessage('shortcutsAlwaysOn') || '（常驻）';
        label.appendChild(tag);
      }

      var catcher = document.createElement('button');
      catcher.type = 'button';
      catcher.className = 'sp-key-catcher' + (key ? '' : ' none');
      catcher.textContent = keyDisplayText(key);
      catcher.dataset.action = meta.action;
      bindCatcher(catcher);

      var reset = document.createElement('button');
      reset.type = 'button';
      reset.className = 'sp-key-reset';
      reset.textContent = chrome.i18n.getMessage('shortcutsReset') || '重置';
      reset.addEventListener('click', (function (action) {
        return function () { shortcutDraft[action] = DEFAULT_SHORTCUTS[action]; renderShortcutRows(); validateShortcuts(); };
      })(meta.action));

      row.appendChild(label);
      row.appendChild(catcher);
      row.appendChild(reset);
      container.appendChild(row);
    }
  }

  // 捕获按钮：点击进入监听态（监听主键，功能键由全局下拉决定）
  function bindCatcher(catcher) {
    catcher.addEventListener('click', function () {
      if (activeCatcher && activeCatcher !== catcher) exitListening(activeCatcher, null);
      activeCatcher = catcher;
      catcher.classList.add('listening');
      catcher.classList.remove('none');
      catcher.textContent = chrome.i18n.getMessage('shortcutsListening') || '按下主键…';
    });
  }

  function exitListening(catcher, capturedKey) {
    if (!catcher) return;
    catcher.classList.remove('listening');
    var action = catcher.dataset.action;
    var key = (capturedKey === null) ? shortcutDraft[action] : capturedKey;
    if (capturedKey !== null) shortcutDraft[action] = capturedKey;
    catcher.textContent = keyDisplayText(key);
    if (!key) catcher.classList.add('none'); else catcher.classList.remove('none');
    if (activeCatcher === catcher) activeCatcher = null;
  }

  // 单一 document keydown：仅在有捕获按钮处于监听态时拦截（捕获主键）
  document.addEventListener('keydown', function (e) {
    if (!activeCatcher) return;
    e.preventDefault();
    e.stopPropagation();
    var catcher = activeCatcher;
    if (e.key === 'Escape') { exitListening(catcher, null); return; }               // 取消，不改原值
    if (e.key === 'Backspace' || e.key === 'Delete') {                              // 清空（禁用）
      shortcutDraft[catcher.dataset.action] = null;
      catcher.classList.add('none');
      catcher.textContent = keyDisplayText(null);
      catcher.classList.remove('listening');
      if (activeCatcher === catcher) activeCatcher = null;
      validateShortcuts();
      return;
    }
    var key = readShortcutKey(e);
    if (!key) return;  // 纯修饰键：继续等待主键
    exitListening(catcher, key);
    validateShortcuts();
  }, true);

  // 冲突校验：重复主键（同功能键下即同组合）或 Ctrl 不可拦截主键 → 标红 + 禁用保存
  function validateShortcuts() {
    var seen = {};
    var conflicts = {};
    for (var i = 0; i < SHORTCUT_ACTIONS.length; i++) {
      var action = SHORTCUT_ACTIONS[i].action;
      var key = shortcutDraft[action];
      if (!key) continue;
      if (modifierDraft === 'Ctrl' && CTRL_RESERVED_KEYS[key]) {
        conflicts[action] = true;  // 浏览器保留组合，插件无法拦截
      } else if (seen[key]) {
        conflicts[action] = true;
        conflicts[seen[key]] = true;
      } else {
        seen[key] = action;
      }
    }
    var rows = document.querySelectorAll('.sp-shortcut-row');
    for (var j = 0; j < rows.length; j++) {
      if (conflicts[rows[j].dataset.action]) rows[j].classList.add('conflict');
      else rows[j].classList.remove('conflict');
    }
    var msg = document.getElementById('spShortcutsMsg');
    var saveBtn = document.getElementById('spShortcutsSave');
    var hasConflict = Object.keys(conflicts).length > 0;
    if (msg) {
      if (hasConflict) {
        msg.textContent = chrome.i18n.getMessage('shortcutsConflict') || '存在重复主键或浏览器保留组合（Ctrl+数字/W/T/N 等无法拦截），请先解决再保存。';
        msg.className = 'sp-shortcut-msg error';
      } else {
        msg.textContent = '';
        msg.className = 'sp-shortcut-msg';
      }
    }
    if (saveBtn) saveBtn.disabled = hasConflict;
  }

  function loadShortcuts() {
    chrome.storage.local.get(['wpzl_shortcutModifier', 'wpzl_shortcuts', 'wpzl_shortcuts_version'], function (result) {
      var version = result.wpzl_shortcuts_version || 0;
      var useStored = (version === SHORTCUTS_VERSION) && result.wpzl_shortcuts;
      modifierDraft = (useStored && result.wpzl_shortcutModifier) ? result.wpzl_shortcutModifier : DEFAULT_MODIFIER;
      var stored = useStored ? result.wpzl_shortcuts : null;
      shortcutDraft = {};
      for (var i = 0; i < SHORTCUT_ACTIONS.length; i++) {
        var action = SHORTCUT_ACTIONS[i].action;
        if (stored && Object.prototype.hasOwnProperty.call(stored, action) && stored[action] !== undefined) {
          shortcutDraft[action] = stored[action];
        } else {
          shortcutDraft[action] = DEFAULT_SHORTCUTS[action];
        }
      }
      renderModifierDropdown();
      renderShortcutRows();
      validateShortcuts();
    });
  }

  function onModifierChange() {
    var sel = document.getElementById('spShortcutModifier');
    if (!sel) return;
    modifierDraft = sel.value;
    renderShortcutRows();   // 各行显示的功能键前缀随之更新
    validateShortcuts();    // 切到 Ctrl 时可能触发保留组合冲突
  }

  function saveShortcuts() {
    var map = {};
    for (var i = 0; i < SHORTCUT_ACTIONS.length; i++) {
      map[SHORTCUT_ACTIONS[i].action] = shortcutDraft[SHORTCUT_ACTIONS[i].action];
    }
    chrome.storage.local.set({ wpzl_shortcutModifier: modifierDraft, wpzl_shortcuts: map, wpzl_shortcuts_version: SHORTCUTS_VERSION }, function () {
      broadcastUpdate({ type: 'wpzl-settings-updated', shortcutModifier: modifierDraft, shortcuts: map, shortcutsVersion: SHORTCUTS_VERSION });
      var msg = document.getElementById('spShortcutsMsg');
      if (msg) {
        msg.textContent = chrome.i18n.getMessage('shortcutsSaved') || '已保存并立即生效。';
        msg.className = 'sp-shortcut-msg ok';
        setTimeout(function () {
          if (msg.classList.contains('ok')) { msg.textContent = ''; msg.className = 'sp-shortcut-msg'; }
        }, 1800);
      }
      var btn = document.getElementById('spShortcutsSave');
      if (btn) {
        btn.textContent = '✓';
        btn.classList.add('saved');
        setTimeout(function () {
          btn.textContent = chrome.i18n.getMessage('saveShortcuts') || '保存';
          btn.classList.remove('saved');
        }, 1200);
      }
    });
  }

  function resetAllShortcuts() {
    modifierDraft = DEFAULT_MODIFIER;
    shortcutDraft = {};
    for (var i = 0; i < SHORTCUT_ACTIONS.length; i++) {
      shortcutDraft[SHORTCUT_ACTIONS[i].action] = DEFAULT_SHORTCUTS[SHORTCUT_ACTIONS[i].action];
    }
    renderModifierDropdown();
    renderShortcutRows();
    validateShortcuts();
  }

  // ---- 主题皮肤（light / dark / sepia / auto） ----
  // 选中即存（即时生效）：写入 wpzl_theme 后，各扩展页面的 theme.js 经 storage.onChanged 自动换肤。
  var THEMES = [
    { id: 'light', i18nKey: 'themeLight', swatch: ['#ffffff', '#f8f9fc', '#ff3c82'] },
    { id: 'dark',  i18nKey: 'themeDark', swatch: ['#1a1b1e', '#212225', '#ff5c94'] },
    { id: 'sepia', i18nKey: 'themeSepia', swatch: ['#f5ecd9', '#efe4cb', '#c4708b'] },
    { id: 'auto',  i18nKey: 'themeAuto', swatch: null }
  ];
  THEMES.forEach(function (th) {
    Object.defineProperty(th, 'label', {
      get: function () { return chrome.i18n.getMessage(this.i18nKey) || this.i18nKey; }
    });
  });

  function renderThemeCards(current) {
    var grid = document.getElementById('spThemeGrid');
    if (!grid) return;
    grid.innerHTML = '';
    for (var i = 0; i < THEMES.length; i++) {
      var t = THEMES[i];
      var card = document.createElement('div');
      card.className = 'sp-theme-card' + (t.id === current ? ' active' : '');
      card.dataset.theme = t.id;

      var prev = document.createElement('div');
      prev.className = 'sp-theme-swatch' + (t.id === 'auto' ? ' auto' : '');
      if (t.swatch) {
        for (var j = 0; j < t.swatch.length; j++) {
          var dot = document.createElement('span');
          dot.className = 'sp-theme-dot';
          dot.style.background = t.swatch[j];
          prev.appendChild(dot);
        }
      }

      var label = document.createElement('div');
      label.className = 'sp-theme-label';
      label.textContent = t.label;

      card.appendChild(prev);
      card.appendChild(label);
      card.addEventListener('click', (function (id) { return function () { saveTheme(id); }; })(t.id));
      grid.appendChild(card);
    }
  }

  function loadTheme() {
    chrome.storage.local.get(['wpzl_theme'], function (result) {
      renderThemeCards((result && result.wpzl_theme) || 'auto');
    });
  }

  function saveTheme(theme) {
    chrome.storage.local.set({ wpzl_theme: theme }, function () {
      renderThemeCards(theme);                       // 本页卡片选中态
      broadcastUpdate({ type: 'wpzl-settings-updated', theme: theme }); // 注入页桥（扩展页靠 storage.onChanged）
      var msg = document.getElementById('spThemeMsg');
      if (msg) {
        msg.textContent = chrome.i18n.getMessage('themeApplied') || '已应用。';
        msg.className = 'sp-shortcut-msg ok';
        setTimeout(function () {
          if (msg.classList.contains('ok')) { msg.textContent = ''; msg.className = 'sp-shortcut-msg'; }
        }, 1500);
      }
    });
  }

  // ---- Init ----

  document.addEventListener('DOMContentLoaded', function () {
    // 强制登录守卫 + 本地模式（游客档，2026-09-29）：未登录无条件放行为本地模式——
    // 游客要能进设置页清数据（登录前清空引导的出口）；原「未登录+无数据跳 auth.html」
    // 分支移除（安装即用）。已登录路径零改动。
    chrome.runtime.sendMessage({ type: 'auth-status' }, function (statusResp) {
      if (statusResp && statusResp.success && statusResp.data && statusResp.data.isLoggedIn) {
        _wpzlAfterAuth(true);
        return;
      }
      // 未登录：本地模式（游客档）直接进入
      _wpzlAfterAuth(false);
    });

    function _wpzlAfterAuth(isLoggedIn) {
    applyI18n();
    loadPalette();
    loadImgAnnoSettings();
    loadAnnotationDisplay();
    loadDrawerMode();
    loadTheme();
    loadShortcuts();

    // Palette save
    var savePaletteBtn = document.getElementById('spSavePalette');
    if (savePaletteBtn) savePaletteBtn.addEventListener('click', savePalette);

    // Image annotation save
    var saveImgBtn = document.getElementById('spSaveImg');
    if (saveImgBtn) saveImgBtn.addEventListener('click', saveImgAnnoSettings);

    // 标注显示
    var showLabelsCb = document.getElementById('spShowLabels');
    if (showLabelsCb) showLabelsCb.addEventListener('change', toggleShowLabels);

    // 抽屉打开方式
    var drawerModeSel = document.getElementById('spDrawerMode');
    if (drawerModeSel) drawerModeSel.addEventListener('change', saveDrawerMode);

    // 快捷键保存 / 全部重置 / 功能键切换
    var shortcutsSaveBtn = document.getElementById('spShortcutsSave');
    if (shortcutsSaveBtn) shortcutsSaveBtn.addEventListener('click', saveShortcuts);
    var shortcutsResetBtn = document.getElementById('spShortcutsResetAll');
    if (shortcutsResetBtn) shortcutsResetBtn.addEventListener('click', resetAllShortcuts);
    var modifierSel = document.getElementById('spShortcutModifier');
    if (modifierSel) modifierSel.addEventListener('change', onModifierChange);

    // 数据管理：云存储管理入口 + 退出并清空（须输入确认文字；模态框监听只绑一次）
    _bindDangerModal();
    _bindStorageModal();

    var storageMgrBtn = document.getElementById('spStorageMgr');
    if (storageMgrBtn) storageMgrBtn.addEventListener('click', openStorageModal);
    // 云存储管理走服务端 API（需 JWT）：本地模式（未登录、仅本地有数据）下隐藏入口与说明，
    // 否则点开必然「加载失败」。退出并清空仍保留，正是本地模式解死锁的出口。
    if (isLoggedIn === false) {
      if (storageMgrBtn) storageMgrBtn.style.display = 'none';
      var storageHint = document.getElementById('spStorageHint');
      if (storageHint) storageHint.style.display = 'none';
      // 本地模式（游客档）：按钮语义切换为「清空本地数据」（applyI18n 已跑过，此处覆盖生效；
      // logoutBtn 声明在下方，此处直接取元素避免引用未初始化变量）
      var _guestLogoutBtn = document.getElementById('spLogout');
      if (_guestLogoutBtn) _guestLogoutBtn.textContent = chrome.i18n.getMessage('clearLocalDataGuestBtn') || '清空本地数据';
    }

    var logoutBtn = document.getElementById('spLogout');
    if (logoutBtn) logoutBtn.addEventListener('click', function () {
      if (isLoggedIn === false) {
        // ── 本地模式（游客档，2026-09-29）：未登录 →「清空本地数据」（无登出动作）。
        // SW clearAllData case 本就不要求登录（零改动）；清空后回登录页。
        var gPhrase = chrome.i18n.getMessage('dangerPhraseClearLocal') || '确认清空';
        openDangerConfirm({
          title: chrome.i18n.getMessage('clearLocalDataGuestBtn') || '清空本地数据',
          desc: chrome.i18n.getMessage('guestClearDesc') || '将清空本地全部数据（当前未登录，数据仅保存在本机），清空后无法恢复。服务器无此数据。',
          phrase: gPhrase,
          inputLabel: chrome.i18n.getMessage('dangerInputLabel', [gPhrase]) || ('输入「' + gPhrase + '」以确认'),
          confirmLabel: chrome.i18n.getMessage('dangerConfirmBtn') || '确认执行',
          requireBackupCheck: true,
          checkboxLabel: chrome.i18n.getMessage('dangerBackupCheckLabel') || '我已备份数据',
          backupHint: chrome.i18n.getMessage('dangerBackupHint') || '建议先将当前数据备份后再清空',
          onConfirm: function () {
            var _gBtn = document.getElementById('spLogout');
            if (_gBtn) { _gBtn.disabled = true; _gBtn.textContent = '…'; }
            chrome.runtime.sendMessage({ type: 'db-operation', operation: 'clearAllData' }, function (resp) {
              if (chrome.runtime.lastError) {
                if (_gBtn) { _gBtn.disabled = false; }
                showToast(chrome.i18n.getMessage('logoutClearFailedRetry') || '本地数据清空失败，请重试');
                return;
              }
              if (resp && resp.success) {
                try { location.replace(chrome.runtime.getURL('popup/auth.html')); } catch (e) { /* ignore */ }
              } else {
                if (_gBtn) { _gBtn.disabled = false; }
                showToast((resp && resp.error) || (chrome.i18n.getMessage('logoutClearFailedRetry') || '本地数据清空失败，请重试'));
              }
            });
          }
        });
        return;
      }
      // ── 已登录：原「退出并清空」+ 备份 checkbox 门禁 ──
      var phrase = chrome.i18n.getMessage('dangerPhraseLogout') || '退出登录';
      openDangerConfirm({
        title: chrome.i18n.getMessage('logoutClear') || '退出并清空',
        desc: chrome.i18n.getMessage('dangerDescLogout') || '将清空本地全部数据并退出登录。服务器上的数据不受影响（可重新同步回来）。',
        phrase: phrase,
        inputLabel: chrome.i18n.getMessage('dangerInputLabel', [phrase]) || ('输入「' + phrase + '」以确认'),
        confirmLabel: chrome.i18n.getMessage('dangerConfirmBtn') || '确认执行',
        requireBackupCheck: true,
        checkboxLabel: chrome.i18n.getMessage('dangerBackupCheckLabel') || '我已备份数据',
        backupHint: chrome.i18n.getMessage('dangerBackupHint') || '建议先将当前数据备份后再清空',
        onConfirm: function () { _doClearAndLogout('logout'); }
      });
    });

    // 反馈与建议 —— 与 popup/manager 统一走 SW 的 openFeedback：
    // SW 先用 access token 写 wpzl_page 会话 cookie，再开 Answer 连接器登录入口，实现 SSO 自动登录。
    var feedbackBtn = document.getElementById('spFeedback');
    if (feedbackBtn) feedbackBtn.addEventListener('click', function () {
      chrome.runtime.sendMessage({ type: 'openFeedback' }).catch(function () {});
    });
    } // _wpzlAfterAuth
  });

}();
