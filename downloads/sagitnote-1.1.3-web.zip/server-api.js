// ============================================================
// Sagitnote - Server API Module
// Loaded via importScripts('server-api.js') by service-worker.js
// Provides: auth (login/register/logout/status), Pro status caching, token refresh
// ============================================================

// 开发默认指向本机 webpz-server。生产发布由构建脚本按环境变量 WEBPZ_SERVER_BASE 注入（见 apply-env.mjs）。
var WPZL_SERVER_BASE = 'https://app.webnoteshub.com';
// 问题反馈系统（Apache Answer）base URL。开发占位 https://github.com；生产由 apply-env.mjs 按 WEBPZ_FEEDBACK_URL 替换。
var WPZL_FEEDBACK_URL = 'https://feedback.webnoteshub.com';
var WPZL_PRO_CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

// ---- Auth Token Management ----

function _wpzlGetTokens() {
  return new Promise(function (resolve) {
    chrome.storage.local.get(['wpzl_auth'], function (result) {
      resolve(result.wpzl_auth || null);
    });
  });
}

function _wpzlSetTokens(accessToken, refreshToken, expiresIn, user, provider) {
  // 委托 _wpzlSetTokensData 构造（单一形状来源）；本函数仅负责落盘（refresh 路径专用）。
  var authData = _wpzlSetTokensData(accessToken, refreshToken, expiresIn, user, provider);
  return new Promise(function (resolve) {
    chrome.storage.local.set({ wpzl_auth: authData }, resolve);
  });
}

// 构造 wpzl_auth 存储对象但不落盘（owner-auth consistency 改动 A）：
// 登录函数只验证并返回，落盘时序由 service-worker 的 _finalizeAuth 决定（通过后才写，
// 且与 wpzl_local_data_owner 一次 set() 原子写入）。
function _wpzlSetTokensData(accessToken, refreshToken, expiresIn, user, provider) {
  var now = Math.floor(Date.now() / 1000);
  return {
    accessToken: accessToken,
    refreshToken: refreshToken,
    expiresAt: now + expiresIn,
    user: user,
    provider: provider || null, // 登录方式 'password'|'google'|'github'...，token 失效重登按此分支
    updatedAt: new Date().toISOString()
  };
}

// 登录通过后的伴随存储动作（从三个登录函数原样聚合，spec 改动 A）：
// 仅在 _finalizeAuth 判定通过、token 真正落地之后调用——这些动作只有 token 落地才该发生。
async function _wpzlPostLoginStorage(tokenData) {
  // Invalidate pro cache on login — fresh fetch needed
  await _wpzlClearProCache();
  // 全新会话：清掉上一轮坏周期残留（连续 401 计数 / 离线标记），否则 wpzl_getAuthStatus
  // 的 count>=3 → tokenExpired 分支会继续误判、离线标记也会让后续判定走脱机路径。
  chrome.storage.local.remove(['wpzl_unauthorized_count', 'wpzl_offline_mode']);
  // 持久化服务端下发的同步重试上限（limits.syncMaxRetries），供 sync-engine _getSyncMaxRetries 读取
  var _smr = tokenData.user && tokenData.user.limits && tokenData.user.limits.syncMaxRetries;
  if (typeof _smr === 'number' && _smr > 0) {
    chrome.storage.local.set({ wpzl_sync_max_retries: _smr });
  }
  // 登录成功 = 新 token 已落地。若上一轮坏周期把全局状态卡在 token_expired，
  // 立即恢复 online 并广播，否则其它已开页面 / 新开页面冷启动仍拉到 token_expired、继续弹重登框。
  if (typeof wpzl_sync_state !== 'undefined' && wpzl_sync_state === 'token_expired') {
    try { wpzl_setSyncState('online'); } catch (e) { /* ignore */ }
  }
}

function _wpzlClearTokens() {
  return new Promise(function (resolve) {
    chrome.storage.local.remove(['wpzl_auth'], resolve);
  });
}

// ---- Connectivity Check ----

// 用 health 端点真实验证网络可达性（防止 captive portal 误报）
// 返回 boolean；2 秒超时
async function _wpzlCheckConnectivity() {
  if (!navigator.onLine) return false;
  try {
    var controller = new AbortController();
    var timeoutId = setTimeout(function () { controller.abort(); }, 2000);
    var resp = await fetch(WPZL_SERVER_BASE + '/api/v1/health', {
      method: 'HEAD',
      signal: controller.signal,
      cache: 'no-store'
    });
    clearTimeout(timeoutId);
    return resp.ok;
  } catch (e) {
    return false;
  }
}

function _wpzlIsTokenExpired(authData) {
  if (!authData || !authData.expiresAt) return true;
  // Consider expired 60 seconds early to allow safe refresh
  return (Math.floor(Date.now() / 1000) + 60) >= authData.expiresAt;
}

// ---- HTTP Helper ----

// P0-4: 统一超时包装。此前所有 API fetch 无 AbortController 超时——挂起的请求（TCP 半开、
// 服务端 hang）会永久占住 in-memory 互斥锁（withSyncLock / _thumbnailFlushActive 等），
// 令同步/上传引擎假死，且 connectivity-tick 串行链路挂死会扯断闹钟链（handler 末尾才重排）。
// AbortError 与真实网络错误统一转 kind='network'（脱机语义：不烧 SYNC_RETRY_COUNT、不进熔断计数，
// 与 sync-engine.js:2514-2532 的既有分类一致）。
function _wpzlFetchWithTimeout(url, fetchOpts, timeoutMs) {
  var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  var timer = ctrl ? setTimeout(function () {
    try { ctrl.abort(); } catch (e) { /* ignore */ }
  }, timeoutMs) : null;
  var opts = Object.assign({}, fetchOpts, ctrl ? { signal: ctrl.signal } : {});
  return fetch(url, opts).then(function (response) {
    if (timer) clearTimeout(timer);
    return response;
  }, function (e) {
    if (timer) clearTimeout(timer);
    var err = new Error((e && e.name === 'AbortError')
      ? 'Request timeout (' + timeoutMs + 'ms): ' + url
      : 'Network error: ' + (e && e.message));
    err.kind = 'network';
    throw err;
  });
}

async function _wpzlApiFetch(path, options) {
  options = options || {};
  var url = WPZL_SERVER_BASE + path;
  var headers = options.headers || {};
  headers['Content-Type'] = 'application/json';

  if (options.auth) {
    var tokens = await _wpzlGetTokens();
    if (tokens && tokens.accessToken) {
      headers['Authorization'] = 'Bearer ' + tokens.accessToken;
    }
  }

  var fetchOptions = {
    method: options.method || 'GET',
    headers: headers
  };
  if (options.body) {
    fetchOptions.body = JSON.stringify(options.body);
  }

  var response = await _wpzlFetchWithTimeout(url, fetchOptions, options.timeoutMs || 30000);

  // Handle 401 with automatic token refresh (one retry)
  if (response.status === 401 && options.auth && !options._retrying) {
    var refreshResult = await _wpzlRefreshAccessToken();
    if (refreshResult.ok) {
      options._retrying = true;
      return _wpzlApiFetch(path, options);
    }
    // 状态机由上层根据 reason 分流（OFFLINE / TOKEN_EXPIRED）
    var err = new Error('Session expired (reason=' + (refreshResult.reason || 'unknown') + ').');
    err.kind = refreshResult.reason || 'unknown';
    throw err;
  }

  var data;
  try {
    data = await response.json();
  } catch (e) {
    var _pe = new Error('Invalid server response');
    _pe.kind = 'server';
    throw _pe;
  }

  if (!response.ok) {
    var serverErr = new Error(data.message || data.error || 'Server error: ' + response.status);
    // P1-10 错误分类细化：401→unauthorized（会话失效）；403→forbidden（授权被拒，如等级未开通云同步
    // ——不再与 401 混淆触发重登录）；其余 4xx（400/404/413/422）→client（客户端侧问题，
    // 不喂服务端 5xx 熔断计数）；5xx→server。附 serverCode（服务端业务码，如 40310）供精确分流。
    serverErr.kind = response.status === 409 ? 'conflict_lock'
      : (response.status >= 500 ? 'server'
      : (response.status === 401 ? 'unauthorized'
      : (response.status === 403 ? 'forbidden' : 'client')));
    serverErr.status = response.status;
    if (typeof data.code === 'number') serverErr.serverCode = data.code;
    // 仅 401 广播 token_expired 引导重登录（P1-10：403 是授权被拒非会话失效——
    // Pro 到期此前被误判为需要重新登录）
    if (response.status === 401 && typeof wpzl_setSyncState === 'function') {
      try { wpzl_setSyncState('token_expired'); } catch (e) { /* ignore */ }
    }
    throw serverErr;
  }
  return data;
}

// multipart 上传专用（不设 Content-Type，让浏览器自动加 boundary）。timeoutMs 默认 120s（图片上传）。
async function _wpzlApiFetchMultipart(path, formData, timeoutMs) {
  var url = WPZL_SERVER_BASE + path;
  var headers = {};

  var tokens = await _wpzlGetTokens();
  if (tokens && tokens.accessToken) {
    headers['Authorization'] = 'Bearer ' + tokens.accessToken;
  }

  var response = await _wpzlFetchWithTimeout(url, { method: 'POST', headers: headers, body: formData }, timeoutMs || 120000);

  // Handle 401 with automatic token refresh (one retry)
  if (response.status === 401) {
    var refreshResult = await _wpzlRefreshAccessToken();
    if (refreshResult.ok) {
      tokens = await _wpzlGetTokens();
      headers['Authorization'] = 'Bearer ' + tokens.accessToken;
      response = await _wpzlFetchWithTimeout(url, { method: 'POST', headers: headers, body: formData }, timeoutMs || 120000);
    } else {
      var err = new Error('Session expired (reason=' + (refreshResult.reason || 'unknown') + ').');
      err.kind = refreshResult.reason || 'unknown';
      throw err;
    }
  }

  var data;
  try {
    data = await response.json();
  } catch (e) {
    var _pe2 = new Error('Invalid server response');
    _pe2.kind = 'server';
    throw _pe2;
  }

  if (!response.ok) {
    var mpErr = new Error(data.message || data.error || 'Server error: ' + response.status);
    // P1-10：与 _wpzlApiFetch 同款分类矩阵（见其注释）
    mpErr.kind = response.status === 409 ? 'conflict_lock'
      : (response.status >= 500 ? 'server'
      : (response.status === 401 ? 'unauthorized'
      : (response.status === 403 ? 'forbidden' : 'client')));
    mpErr.status = response.status;
    if (typeof data.code === 'number') mpErr.serverCode = data.code;
    if (response.status === 401 && typeof wpzl_setSyncState === 'function') {
      try { wpzl_setSyncState('token_expired'); } catch (e) { /* ignore */ }
    }
    throw mpErr;
  }
  return data;
}

// ---- Auth API ----

// 拉取滑块拼图验证码（匿名 GET，发码前人机校验）。
// 成功返回 { captchaId, backgroundImage, blockImage, blockY, width, height, blockSize, ttlSeconds }
async function wpzl_fetchCaptcha() {
  var resp = await _wpzlApiFetch('/api/v1/auth/captcha', { method: 'GET' });
  return resp && resp.data;
}

// 发送邮箱验证码。成功返回 { ttlSeconds, cooldownSeconds }；失败时 _wpzlApiFetch 抛 Error（.message 为服务端本地化提示）。
// captchaId/captchaAnswer：滑块拼图答案（服务端强制校验，缺参返回 40010「请升级扩展」）
async function wpzl_sendVerifyCode(email, captchaId, captchaAnswer) {
  var resp = await _wpzlApiFetch('/api/v1/auth/send-code', {
    method: 'POST',
    body: { email: email, captchaId: captchaId, captchaAnswer: captchaAnswer }
  });
  return resp && resp.data;
}

// 找回密码：发送重置验证码。成功返回 { ttlSeconds, cooldownSeconds }（未注册邮箱也返回相同结构）。
// captchaId/captchaAnswer：与注册发码同口径的滑块答案
async function wpzl_forgotPassword(email, captchaId, captchaAnswer) {
  var resp = await _wpzlApiFetch('/api/v1/auth/forgot-password', {
    method: 'POST',
    body: { email: email, captchaId: captchaId, captchaAnswer: captchaAnswer }
  });
  return resp && resp.data;
}

// 找回密码：用验证码重置密码。成功无返回 data
async function wpzl_resetPassword(email, code, newPassword) {
  await _wpzlApiFetch('/api/v1/auth/reset-password', {
    method: 'POST',
    body: { email: email, code: code, newPassword: newPassword }
  });
}

async function wpzl_register(loginId, password, email, name, code, marketingEmailOptIn) {
  var resp = await _wpzlApiFetch('/api/v1/auth/register', {
    method: 'POST',
    body: { loginId: loginId, password: password, email: email, name: name || loginId, code: code, marketingEmailOptIn: !!marketingEmailOptIn }
  });
  var tokenData = resp.data;
  // 只验证不落盘：token 落地由 _finalizeAuth 通过后与 owner 原子写入（spec 改动 A）
  return { user: tokenData.user, authData: _wpzlSetTokensData(tokenData.accessToken, tokenData.refreshToken, tokenData.expiresIn, tokenData.user, 'password') };
}

async function wpzl_login(loginId, password) {
  var resp = await _wpzlApiFetch('/api/v1/auth/login', {
    method: 'POST',
    body: { loginId: loginId, password: password }
  });
  var tokenData = resp.data;
  // 只验证不落盘：token 落地由 _finalizeAuth 通过后与 owner 原子写入（spec 改动 A）
  return { user: tokenData.user, authData: _wpzlSetTokensData(tokenData.accessToken, tokenData.refreshToken, tokenData.expiresIn, tokenData.user, 'password') };
}

async function wpzl_getOAuthAuthorizeUrl(provider, redirectUri) {
  var resp = await _wpzlApiFetch(
    '/api/v1/auth/oauth/' + encodeURIComponent(provider) + '/authorize-url?redirectUri=' + encodeURIComponent(redirectUri),
    { method: 'GET' }
  );
  return resp && resp.data && resp.data.authorizeUrl;
}

// 第三方登录：用 provider 回调的授权码换本系统 token，复用与 wpzl_login 一致的 token 落地逻辑。
// state（SEC-05）：authorize-url 发起时服务端生成、provider 原样回传的一次性防 CSRF 令牌。
// 旧服务端不识别该字段（Jackson 忽略未知属性），向前兼容；新服务端缺失 state 会拒绝换码。
async function wpzl_oauthLogin(provider, code, redirectUri, state) {
  var resp = await _wpzlApiFetch('/api/v1/auth/oauth/' + encodeURIComponent(provider), {
    method: 'POST',
    body: { code: code, redirectUri: redirectUri, state: state || '' }
  });
  var tokenData = resp.data;
  // 只验证不落盘：token 落地由 _finalizeAuth 通过后与 owner 原子写入（spec 改动 A）
  return { user: tokenData.user, authData: _wpzlSetTokensData(tokenData.accessToken, tokenData.refreshToken, tokenData.expiresIn, tokenData.user, provider) };
}

async function wpzl_logout() {
  try {
    await _wpzlApiFetch('/api/v1/auth/logout', { method: 'POST', auth: true });
  } catch (e) {
    // Ignore logout server errors — still clear local tokens
  }
  await _wpzlClearTokens();
  await _wpzlClearProCache();
}

// 串行化 refresh：access 过期瞬间，多个在飞请求会同时收到 401。服务端 refresh token 是
// 一次性轮换（AuthService.refreshToken 用后即吊销），若不串行化，N 个并发 401 各自发起
// /auth/refresh，只有第一个能成功（吊销旧 token、拿到新 token），其余 N-1 个拿已吊销的
// 旧 token 被拒 → 每个都广播 token_expired + 累计 unauthorized_count → 每个网页弹重登录框。
// 这里用 in-flight promise 守卫：并发调用共享同一次 refresh，结束 finally 清空。
var _wpzlRefreshInFlight = null;
function _wpzlRefreshAccessToken() {
  if (_wpzlRefreshInFlight) return _wpzlRefreshInFlight;
  _wpzlRefreshInFlight = _wpzlRefreshAccessTokenImpl().finally(function () {
    _wpzlRefreshInFlight = null;
  });
  return _wpzlRefreshInFlight;
}

async function _wpzlRefreshAccessTokenImpl() {
  // Returns: { ok: boolean, reason?: 'network' | 'unauthorized' | 'server' }
  var tokens = await _wpzlGetTokens();
  if (!tokens || !tokens.refreshToken) return { ok: false, reason: 'unauthorized' };
  // P1-28: 快照本次使用的 refreshToken——写回前重读比对，防止"refresh 在飞 → 登出 → 登录账号 B"
  // 窗口内旧账号的新 token 对覆盖 B 的会话（后续请求以 A 身份执行、UI 显示 B）。
  var usedRefreshToken = tokens.refreshToken;
  try {
    var resp = await _wpzlApiFetch('/api/v1/auth/refresh', {
      method: 'POST',
      body: { refreshToken: usedRefreshToken }
    });
    var tokenData = resp.data;
    // 写回前代次校验：refreshToken 已变 = 会话已被登出/换号替换 → 丢弃本响应（含全部副作用），
    // 不写 token、不清 storage 键、不动状态机。调用方按 ok 处理；重试路径会重新读当前 token。
    var current = await _wpzlGetTokens();
    if (!current || current.refreshToken !== usedRefreshToken) {
      return { ok: true, superseded: true };
    }
    // E-P2-2: 第 5 参必须传 provider——漏传会落盘 null，覆盖登录时写入的登录方式标记，
    // token 失效重登分支判断错误（github 用户被 loginId 前缀 fallback 误推断为 google）。
    await _wpzlSetTokens(tokenData.accessToken, tokenData.refreshToken, tokenData.expiresIn, tokenData.user, tokens.provider);
    chrome.storage.local.remove(['wpzl_offline_mode']);
    // Refresh 成功：清零连续 401 计数
    chrome.storage.local.remove(['wpzl_unauthorized_count']);
    // refresh 成功 = 服务端可达且鉴权通过。若 SW 状态卡在 token_expired（上一轮坏周期残留，
    // 例如曾因并发 race / 服务端抖动反复 401），立即恢复为 online，无需等下一次 sync ——
    // 否则 wpzl_sync_state 留在 token_expired，每个新开网页 content.js 冷启动拉状态时都会
    // 弹重登录框。
    if (typeof wpzl_sync_state !== 'undefined' && wpzl_sync_state === 'token_expired'
        && typeof wpzl_setSyncState === 'function') {
      try { wpzl_setSyncState('online'); } catch (e) { /* ignore */ }
    }
    return { ok: true };
  } catch (e) {
    // 优先用结构化 err.kind（Task 4 已为 _wpzlApiFetch 错误附加）；兜底字符串匹配
    var msg = String(e && e.message || '');
    var reason;
    if (e && e.kind === 'unauthorized') {
      reason = 'unauthorized';
    } else if (e && e.kind === 'server') {
      reason = 'server';
    } else if (msg.indexOf('Network error') === 0 || (e && e.kind === 'network')) {
      reason = 'network';
    } else if (msg.indexOf('Session expired (reason=unauthorized)') >= 0) {
      reason = 'unauthorized';
    } else if (msg.indexOf('Session expired (reason=server)') >= 0) {
      reason = 'server';
    } else {
      reason = 'network'; // 兜底归为网络问题，不归咎 token
    }
    chrome.storage.local.set({ wpzl_offline_mode: true });
    // 仅 unauthorized 累计计数；network/server 不递增（避免抖动掩盖真实过期）
    if (reason === 'unauthorized') {
      // 服务端拒绝 refresh token（HTTP 401）→ 产品要求：任何请求遇 401 都引导用户重登录。
      // 广播 token_expired，所有扩展页（manager/popup）与网页（content.js）收到后弹重登录框
      // （用户名只读、仅填密码）。network/server 不广播，避免网络抖动误弹。
      if (typeof wpzl_setSyncState === 'function') {
        try { wpzl_setSyncState('token_expired'); } catch (e) { /* ignore */ }
      }
      chrome.storage.local.get(['wpzl_unauthorized_count'], function (r) {
        var n = (r.wpzl_unauthorized_count || 0) + 1;
        chrome.storage.local.set({ wpzl_unauthorized_count: n });
      });
    }
    return { ok: false, reason: reason };
  }
}

async function wpzl_getAuthStatus(options) {
  var opts = options || {};
  var tokens = await _wpzlGetTokens();
  if (!tokens) return { isLoggedIn: false, user: null };
  if (_wpzlIsTokenExpired(tokens)) {
    // [脱机优先] skipConnectivityCheck：DB 读写路径不阻塞等服务器连通性检查，
    //   直接信任本地缓存 token，走离线模式。Token 真正过期（连续 401）由
    //   sync engine 的 TOKEN_EXPIRED 广播 + manager reauth dialog 处理。
    if (opts.skipConnectivityCheck) {
      return { isLoggedIn: true, user: tokens.user, offline: true };
    }
    var reachable = false;
    try { reachable = await _wpzlCheckConnectivity(); } catch (e) { reachable = false; }
    if (!reachable) {
      return { isLoggedIn: true, user: tokens.user, offline: true };
    }
    var refreshResult = await _wpzlRefreshAccessToken();
    if (refreshResult.ok) {
      tokens = await _wpzlGetTokens();
      if (tokens) return { isLoggedIn: true, user: tokens.user, offline: false };
      return { isLoggedIn: false, user: null };
    }
    // refresh 失败：network/server 仍视为已登录（脱机可用）；
    // unauthorized 由状态机根据连续计数决定是否进 TOKEN_EXPIRED
    if (refreshResult.reason === 'network' || refreshResult.reason === 'server') {
      return { isLoggedIn: true, user: tokens.user, offline: true };
    }
    // unauthorized：检查连续计数是否已达阈值
    var stored = await new Promise(function (resolve) {
      chrome.storage.local.get(['wpzl_unauthorized_count'], function (r) {
        resolve(r.wpzl_unauthorized_count || 0);
      });
    });
    if (stored >= 3) {
      return { isLoggedIn: false, user: tokens.user, tokenExpired: true };
    }
    return { isLoggedIn: true, user: tokens.user, offline: true };
  }
  return { isLoggedIn: true, user: tokens.user, offline: false };
}

// ---- Pro Status Caching ----

var _wpzlCachedProStatus = null;
var _wpzlProCacheTimestamp = 0;

function _wpzlGetCachedProFromStorage() {
  return new Promise(function (resolve) {
    chrome.storage.local.get(['wpzl_pro_cache'], function (result) {
      resolve(result.wpzl_pro_cache || null);
    });
  });
}

function _wpzlSaveProCacheToStorage(status) {
  var cacheEntry = {
    data: status,
    cachedAt: Date.now()
  };
  return new Promise(function (resolve) {
    chrome.storage.local.set({ wpzl_pro_cache: cacheEntry }, resolve);
  });
}

// ---- 本地 Pro 到期检查 ----
// 即使无法连接服务器，也根据缓存的 expiresAt 判断是否到期

// 服务端到期串（UTC-naive）→ epoch ms：naive 按 UTC 构造（服务端 2026-11 起全链路 UTC 轴），
// 裸 new Date(str) 按本地时区解释 naive → 判定偏一个时区。
function _wpzlApiProExpiryMs(s) {
  if (!s) return NaN;
  var t = String(s).trim();
  var m = t.replace('T', ' ').match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?$/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
  return Date.parse(t);
}

function _wpzlCheckProExpiry(proData) {
  if (!proData) return proData;
  // 服务端到期已把 isPro 置 false，但 user.gradeId 不变 → 下发的 gradeConfig 仍是用户当前等级（如 Pro）。
  // 因此降级判断只看 expiresAt（有到期时间且已过期），不依赖 isPro 字段。
  if (proData.expiresAt) {
    try {
      var expMs = _wpzlApiProExpiryMs(proData.expiresAt);
      if (!isNaN(expMs) && Date.now() >= expMs) {
        var downgrade = proData.defaultGradeConfig || null;
        return {
          isPro: false,
          limits: proData.limits,
          gradeConfig: downgrade,
          defaultGradeConfig: proData.defaultGradeConfig || null,
          expiresAt: proData.expiresAt
        };
      }
    } catch (e) { /* 日期解析失败，保持原状态 */ }
  }
  return proData;
}

async function _wpzlClearProCache() {
  _wpzlCachedProStatus = null;
  _wpzlProCacheTimestamp = 0;
  return new Promise(function (resolve) {
    chrome.storage.local.remove(['wpzl_pro_cache'], resolve);
  });
}

async function wpzl_getProStatus(forceRefresh) {
  // Check in-memory cache first (fast, but lost on SW restart)
  if (!forceRefresh && _wpzlCachedProStatus && (Date.now() - _wpzlProCacheTimestamp) < WPZL_PRO_CACHE_TTL_MS) {
    return _wpzlCheckProExpiry(_wpzlCachedProStatus);
  }

  // Check chrome.storage.local cache (persists across SW restarts)
  if (!forceRefresh) {
    var storageCache = await _wpzlGetCachedProFromStorage();
    if (storageCache && (Date.now() - storageCache.cachedAt) < WPZL_PRO_CACHE_TTL_MS) {
      _wpzlCachedProStatus = storageCache.data;
      _wpzlProCacheTimestamp = Date.now();
      return _wpzlCheckProExpiry(_wpzlCachedProStatus);
    }
  }

  // [脱机优先] 缓存未命中（或 forceRefresh）且服务器不可达时，不发起阻塞式 fetch
  //   （避免 6h pro-expiry-check alarm / onStartup 长期挂起 SW）。直接用持久化缓存，
  //   仍经 _wpzlCheckProExpiry 到期降级；无缓存则 Free 兜底（fail-closed）。
  //   这保证脱机下订阅到期照常降级，脱机不是绕过等级限额的通道。
  var _reachable = false;
  try { _reachable = await _wpzlCheckConnectivity(); } catch (e) { _reachable = false; }
  if (!_reachable) {
    var _offlineFallback = await _wpzlGetCachedProFromStorage();
    if (_offlineFallback) {
      _wpzlCachedProStatus = _offlineFallback.data;
      _wpzlProCacheTimestamp = Date.now();
      return _wpzlCheckProExpiry(_wpzlCachedProStatus);
    }
    var _offlineFree = { isPro: false, limits: null, gradeConfig: null, defaultGradeConfig: null, expiresAt: null };
    _wpzlCachedProStatus = _offlineFree;
    _wpzlProCacheTimestamp = Date.now();
    return _offlineFree;
  }

  // 未登录分两种（产品原则：脱机不降级、订阅到期才降级、只有 401 弹重登录）：
  //  - tokenExpired（服务端 401 拒绝 refresh token）：不降级！用缓存保持当前等级，
  //    重登录框由 _wpzlRefreshAccessToken / _wpzlApiFetch 检测到 401 时广播的 token_expired 触发。
  //  - 真未登录（无 token，首次使用/已退出）：才 free 兜底。
  var auth = await wpzl_getAuthStatus();
  if (!auth.isLoggedIn) {
    if (auth.tokenExpired) {
      var expiredFallback = await _wpzlGetCachedProFromStorage();
      if (expiredFallback && expiredFallback.data) {
        _wpzlCachedProStatus = expiredFallback.data;
        _wpzlProCacheTimestamp = Date.now();
        return _wpzlCheckProExpiry(_wpzlCachedProStatus);
      }
    }
    var freeStatus = { isPro: false, limits: null, gradeConfig: null, defaultGradeConfig: null, expiresAt: null };
    _wpzlCachedProStatus = freeStatus;
    _wpzlProCacheTimestamp = Date.now();
    return freeStatus;
  }

  // Fetch from server
  try {
    var resp = await _wpzlApiFetch('/api/v1/pro/status', { auth: true });
    var proStatus = resp.data;
    // 存原始数据（保留 defaultGradeConfig 供断网降级），返回经到期降级的 effective 状态
    _wpzlCachedProStatus = proStatus;
    _wpzlProCacheTimestamp = Date.now();
    await _wpzlSaveProCacheToStorage(proStatus);
    // 服务端取到新数据 → 广播让所有已打开页面热刷新限额。此前仅手动 forceRefresh 才广播，
    // 自动缓存刷新（TTL 未命中/登录预热/alarm）不广播 → 长开页面 snapSizeLimit 等冻结在旧值。
    var _effective = _wpzlCheckProExpiry(proStatus);
    try { _broadcastProStatusUpdated(_effective); } catch (e) { /* ignore */ }
    return _effective;
  } catch (e) {
    // Server unreachable — fall back to storage cache even if expired
    var fallback = await _wpzlGetCachedProFromStorage();
    if (fallback) {
      _wpzlCachedProStatus = fallback.data;
      _wpzlProCacheTimestamp = Date.now();
      return _wpzlCheckProExpiry(_wpzlCachedProStatus);
    }
    // No cached data — return free defaults (keep extension functional)
    var freeFallback = { isPro: false, limits: null, gradeConfig: null, defaultGradeConfig: null, expiresAt: null };
    _wpzlCachedProStatus = freeFallback;
    _wpzlProCacheTimestamp = Date.now();
    return freeFallback;
  }
}

// ---- Sync API ----

async function wpzl_sync(deviceId, lastSyncToken, annotations, deletedIds,
                         pages, deletedPageUrlMd5s, folders, deletedFolderIds,
                         cursor, pageCursor, folderCursor,
                         imageAssets, deletedImageAssetKeys, imageAssetCursor,
                         documents, deletedDocIds, documentCursor,
                         snapshots, deletedSnapIds, snapshotCursor) {
  return _wpzlApiFetch('/api/v1/sync', {
    method: 'POST',
    auth: true,
    timeoutMs: 120000,  // P0-4: 批量推拉合一请求（含 gzip body），给足超时；默认 30s 不够大同步
    body: {
      deviceId: deviceId,
      lastSyncToken: lastSyncToken || null,
      annotations: annotations || [],
      deletedIds: deletedIds || [],
      pages: pages || [],
      deletedPageUrlMd5s: deletedPageUrlMd5s || [],
      folders: folders || [],
      deletedFolderIds: deletedFolderIds || [],
      cursor: cursor || null,
      pageCursor: pageCursor || null,
      folderCursor: folderCursor || null,
      imageAssets: imageAssets || [],
      deletedImageAssetKeys: deletedImageAssetKeys || [],
      imageAssetCursor: imageAssetCursor || null,
      documents: documents || [],
      deletedDocIds: deletedDocIds || [],
      documentCursor: documentCursor || null,
      snapshots: snapshots || [],
      deletedSnapIds: deletedSnapIds || [],
      snapshotCursor: snapshotCursor || null
    }
  });
}

// P1-39: 旧版分体端点 /api/v1/sync/upload、/sync/download 已下线（服务端 410）。
// wpzl_syncUpload / wpzl_syncDownload 及 sync-engine 的 legacy push()/pull() 已随之删除，
// 统一走 wpzl_sync（POST /api/v1/sync 单请求推拉合一）。

async function wpzl_syncGetStatus() {
  return _wpzlApiFetch('/api/v1/sync/status', { auth: true });
}

// ---- Asset API（图片对象存储）----

async function wpzl_assetUpload(blob, sha256, pageKey, imageKey) {
  var fd = new FormData();
  fd.append('file', blob, 'image.webp');
  fd.append('sha256', sha256);
  if (pageKey) fd.append('pageKey', pageKey);
  if (imageKey) fd.append('imageKey', imageKey);
  return _wpzlApiFetchMultipart('/api/v1/assets/upload', fd);
}

async function wpzl_assetQuota() {
  return _wpzlApiFetch('/api/v1/assets/quota', { method: 'GET', auth: true });
}

async function wpzl_assetSign(objectKey) {
  return _wpzlApiFetch('/api/v1/assets/sign?key=' + encodeURIComponent(objectKey), {
    method: 'GET',
    auth: true
  });
}

// 批量签名（2026-10-04 方案4，下载器批级预热 wpzl_preSignAssetUrls 用）：
// 一次 POST 签 ≤16 个 objectKey，把图片回填链路对签名端点的请求密度降 ~8×
// （对象 GET 仍浏览器直连存储）。脏 key 服务端静默跳过不出现在响应里。
async function wpzl_assetSignBatch(objectKeys) {
  return _wpzlApiFetch('/api/v1/assets/sign-batch', {
    method: 'POST',
    auth: true,
    body: { keys: objectKeys }
  });
}

// 删除已上云图片对象（D2：每 page-image 独占对象，删即真删 R2 + 释放配额）。
// objectKey 形如 u/<uid>/<pageKey>/<imageKey>.webp。异常由调用方吞掉（不阻断文档保存）。
async function wpzl_assetDelete(objectKey) {
  return _wpzlApiFetch('/api/v1/assets?key=' + encodeURIComponent(objectKey), {
    method: 'DELETE',
    auth: true
  });
}

// D2：删页级联批量删该页全部图片对象 + R2 + 配额（服务端 hardDeleteByPageKey，幂等）。
// pageKey = md5(pageUrl)。删页流程 fire-and-forget 调用；同时本地 imageData 由调用方物理清掉。
async function wpzl_assetDeleteByPage(pageKey) {
  return _wpzlApiFetch('/api/v1/assets?pageKey=' + encodeURIComponent(pageKey), {
    method: 'DELETE',
    auth: true
  });
}

// ---- 云存储管理 API（manager「云存储管理」弹窗）----

// 总览：{usedBytes, limitBytes, unlimited, image/snapshot/doc: {bytes, count}}
async function wpzl_storageOverview() {
  return _wpzlApiFetch('/api/v1/storage/overview', { method: 'GET', auth: true });
}

// 列表：type=page（图片目录聚合）| image（需 pageKey）| doc | snap。
// params: {pageKey?, page?, size?, sort?, dir?}——sort=size|time|name，dir=asc|desc（服务端白名单）。
// 返回 {items, page, size, total}。
async function wpzl_storageList(type, params) {
  params = params || {};
  var qs = 'type=' + encodeURIComponent(type);
  if (params.pageKey) qs += '&pageKey=' + encodeURIComponent(params.pageKey);
  qs += '&page=' + (params.page || 0) + '&size=' + (params.size || 50);
  if (params.sort) qs += '&sort=' + encodeURIComponent(params.sort);
  if (params.dir) qs += '&dir=' + encodeURIComponent(params.dir);
  return _wpzlApiFetch('/api/v1/storage/list?' + qs, { method: 'GET', auth: true });
}

// 批量删除：payload = {type: 'page'|'image'|'doc'|'snap', pageKeys?, objectKeys?, docIds?, snapIds?}。
// 返回 {deleted, freedBytes}。删除文档/快照会连同内容与批注一并删除（跨设备经同步传播）。
async function wpzl_storageDelete(payload) {
  return _wpzlApiFetch('/api/v1/storage/delete', { method: 'POST', auth: true, body: payload });
}

// ============ 分享管理（Phase 4，属主、需登录）============
// payload: {domain, webUri, urlMd5, title?, editPower, password?, expiryDays?, originScheme, originHost, originPort}
// 返回 {shareId, code, url}（解包 ApiResponse.data）
async function wpzl_createShare(payload) {
  var resp = await _wpzlApiFetch('/api/v1/shares', { method: 'POST', auth: true, body: payload });
  return resp && resp.data;
}

// 返回 ShareSummary[]（我的活跃分享，解包 ApiResponse.data）
async function wpzl_listShares() {
  var resp = await _wpzlApiFetch('/api/v1/shares', { method: 'GET', auth: true });
  return (resp && resp.data) || [];
}

// 单条详情（解包 ApiResponse.data）
async function wpzl_getShare(shareId) {
  var resp = await _wpzlApiFetch('/api/v1/shares/' + encodeURIComponent(shareId), { method: 'GET', auth: true });
  return resp && resp.data;
}

// 部分更新 patch: {editPower?, password?, expiryDays?, title?}（解包 ApiResponse.data）
async function wpzl_updateShare(shareId, patch) {
  var resp = await _wpzlApiFetch('/api/v1/shares/' + encodeURIComponent(shareId), {
    method: 'PATCH', auth: true, body: patch
  });
  return resp && resp.data;
}

// 撤销（is_active=false，链接失效）。UI 已改用 disable/enable 开关，保留 RPC 兼容。
async function wpzl_revokeShare(shareId) {
  var resp = await _wpzlApiFetch('/api/v1/shares/' + encodeURIComponent(shareId) + '/revoke', {
    method: 'POST', auth: true
  });
  return resp && resp.data;
}

// 禁用（is_active=false：/share/{code} 及全部 API 立即 404；数据保留，可再启用）
async function wpzl_disableShare(shareId) {
  var resp = await _wpzlApiFetch('/api/v1/shares/' + encodeURIComponent(shareId) + '/disable', {
    method: 'POST', auth: true
  });
  return resp && resp.data;
}

// 启用（is_active=true：恢复链接访问）
async function wpzl_enableShare(shareId) {
  var resp = await _wpzlApiFetch('/api/v1/shares/' + encodeURIComponent(shareId) + '/enable', {
    method: 'POST', auth: true
  });
  return resp && resp.data;
}

// 重新生成 randomCode（旧链接失效），返回 {shareId, code, url}（解包 ApiResponse.data）
async function wpzl_regenerateShare(shareId) {
  var resp = await _wpzlApiFetch('/api/v1/shares/' + encodeURIComponent(shareId) + '/regenerate', {
    method: 'POST', auth: true
  });
  return resp && resp.data;
}

// 删除分享（只删 mark_shares 行；协作批注/回复保留，链接立即失效不可恢复）
async function wpzl_deleteShare(shareId) {
  var resp = await _wpzlApiFetch('/api/v1/shares/' + encodeURIComponent(shareId), {
    method: 'DELETE', auth: true
  });
  return resp && resp.data;
}

// ============ 属主侧回复（属主查看/回复/审删协作者回复，Req4）============
// 本页聚合：GET /api/v1/shares/page-replies?urlMd5= → OwnerPageReplyDto[]（含 shareId，自动聚合本页所有分享）
async function wpzl_listPageReplies(urlMd5) {
  var path = '/api/v1/shares/page-replies?urlMd5=' + encodeURIComponent(urlMd5);
  var resp = await _wpzlApiFetch(path, { method: 'GET', auth: true });
  return (resp && resp.data) || [];
}

// list: GET /api/v1/shares/{shareId}/replies?markId= → ShareReplyDto[]
async function wpzl_listShareReplies(shareId, markId) {
  var path = '/api/v1/shares/' + encodeURIComponent(shareId) + '/replies?markId=' + encodeURIComponent(markId);
  var resp = await _wpzlApiFetch(path, { method: 'GET', auth: true });
  return (resp && resp.data) || [];
}

// post: body {markId, message} → {success, id}
async function wpzl_postShareReply(shareId, body) {
  var resp = await _wpzlApiFetch('/api/v1/shares/' + encodeURIComponent(shareId) + '/replies', {
    method: 'POST', auth: true, body: body
  });
  return resp && resp.data;
}

// delete: 属主可删任意回复
async function wpzl_deleteShareReply(shareId, replyId) {
  var resp = await _wpzlApiFetch('/api/v1/shares/' + encodeURIComponent(shareId) + '/replies/' + encodeURIComponent(replyId), {
    method: 'DELETE', auth: true
  });
  return resp && resp.data;
}

// ============ 页面快照已升级为「一类实体」（user_snapshots），走统一 /api/v1/sync（第6类）============
// 旧独立通道（PUT/GET /api/v1/pages/{urlMd5}/snapshot）已随服务端 SnapshotApiController 一并移除。

// ============ 文档大小精确预检（P2-15）============
// manager 保存前调用：客户端本地按 raw 长度预检只偏严（raw ≥ 消毒后），raw > limit 时
// 调本端点拿与服务端 sync 同口径（HtmlSanitizer.sanitize 后 length）的精确判定。
// POST /api/v1/documents/size-check → data:{length, limit, exceeded}
async function wpzl_docSizeCheck(html) {
  var resp = await _wpzlApiFetch('/api/v1/documents/size-check', {
    method: 'POST', auth: true, body: { html: html }, timeoutMs: 60000
  });
  return resp && resp.data;
}

// ============ 用户信息面板（manager 右上角用户面板）============

// 改名（PUT /users/me）。email 暂不支持自助变更（服务端 400）。返回 UserInfoResponse。
async function wpzl_updateUserName(name) {
  var resp = await _wpzlApiFetch('/api/v1/users/me', {
    method: 'PUT', auth: true, body: { name: name }
  });
  return resp && resp.data;
}

// 更新产品更新邮件偏好（PUT /users/me，仅带 marketingEmailOptIn 字段）。返回 UserInfoResponse。
async function wpzl_updateMarketingOptIn(optIn) {
  var resp = await _wpzlApiFetch('/api/v1/users/me', {
    method: 'PUT', auth: true, body: { marketingEmailOptIn: !!optIn }
  });
  return resp && resp.data;
}

// 取当前用户信息（GET /users/me）。用户面板打开时刷新 SW 缓存的 wpzl_auth.user
//（兜底旧会话缓存缺新字段，如 marketingEmailOptIn）。返回 UserInfoResponse。
async function wpzl_getUserInfo() {
  var resp = await _wpzlApiFetch('/api/v1/users/me', { method: 'GET', auth: true });
  return resp && resp.data;
}

// 改密/设密（POST /users/me/password）。OAuth-only 用户 currentPassword 传空按「设置密码」。
async function wpzl_changePassword(currentPassword, newPassword) {
  var resp = await _wpzlApiFetch('/api/v1/users/me/password', {
    method: 'POST', auth: true,
    body: { currentPassword: currentPassword || null, newPassword: newPassword }
  });
  return resp && resp.data;
}

// 上传头像（POST /users/me/avatar，multipart）。返回 UserInfoResponse（含 avatarUpdatedAt）。
async function wpzl_uploadAvatar(blob) {
  var fd = new FormData();
  fd.append('file', blob, 'avatar.webp');
  return _wpzlApiFetchMultipart('/api/v1/users/me/avatar', fd);
}

// 取头像预签名 URL（GET /users/me/avatar）。未上传返回 null。
async function wpzl_getAvatarUrl() {
  var resp = await _wpzlApiFetch('/api/v1/users/me/avatar', { method: 'GET', auth: true });
  return (resp && resp.data) || null;
}

// 取使用情况统计（GET /users/me/usage）。
async function wpzl_getUsage() {
  var resp = await _wpzlApiFetch('/api/v1/users/me/usage', { method: 'GET', auth: true });
  return resp && resp.data;
}

// 取升级/续费联系方式（GET /pro/upgrade）→ {contact}。
async function wpzl_getUpgradeInfo() {
  var resp = await _wpzlApiFetch('/api/v1/pro/upgrade', { method: 'GET', auth: true });
  return (resp && resp.data) || { contact: '' };
}

// ---- 支付（Waffo Pancake 收款）。服务端未启用时 products 报 50300 → 调用方回落联系客服 ----

// 可购套餐目录（GET /payment/products）→ [{code,name,nameKey,gradeName,durationDays,amount,currency,formattedAmount}]。
// nameKey 优先走 chrome.i18n（新品上线无需改扩展代码），缺失回落服务端 name。
async function wpzl_getPaymentProducts() {
  var resp = await _wpzlApiFetch('/api/v1/payment/products', { method: 'GET', auth: true });
  return (resp && resp.data) || [];
}

// 下单前置风控（GET /payment/pay-hold）→ {held,until,orderNo}；held=true 时升级页禁购并展示解封日期。
async function wpzl_getPayHold() {
  var resp = await _wpzlApiFetch('/api/v1/payment/pay-hold', { method: 'GET', auth: true });
  return (resp && resp.data) || { held: false };
}

// 下单（POST /payment/orders）→ {orderNo,status,checkoutUrl,expiresAt}。checkoutUrl 含 #token=，须新标签页打开。
async function wpzl_createPaymentOrder(productCode) {
  var resp = await _wpzlApiFetch('/api/v1/payment/orders', {
    method: 'POST', auth: true, body: { productCode: productCode }
  });
  return resp && resp.data;
}

// 我的订单（GET /payment/orders）→ [{orderNo,...,canRefund,refundDeadline}]。
async function wpzl_getMyOrders(limit) {
  var resp = await _wpzlApiFetch('/api/v1/payment/orders?limit=' + (limit || 50), { method: 'GET', auth: true });
  return (resp && resp.data) || [];
}

// 订单状态单查（GET /payment/orders/{orderNo}）。CREATED / EXPIRED 时服务端都会节流主动查 Pancake：
// 前者是漏 webhook 自愈，后者是"本地已过期但远端其实收了钱"的补发（P0-1，2026-11-08）。
async function wpzl_getPaymentOrderStatus(orderNo) {
  var resp = await _wpzlApiFetch('/api/v1/payment/orders/' + encodeURIComponent(orderNo), { method: 'GET', auth: true });
  return resp && resp.data;
}

// 申请退款（POST /payment/orders/{orderNo}/refund）→ {refundNo,orderNo,status,...}。14 天窗口服务端强制。
async function wpzl_requestRefund(orderNo, reason) {
  var resp = await _wpzlApiFetch('/api/v1/payment/orders/' + encodeURIComponent(orderNo) + '/refund', {
    method: 'POST', auth: true, body: { reason: reason || null }
  });
  return resp && resp.data;
}

// ---- 等级对比表（GET /pro/grades）双缓存：内存 + storage，TTL 1h，本地优先 ----
var WPZL_GRADES_CACHE_TTL_MS = 60 * 60 * 1000;
var _wpzlCachedGrades = null;
var _wpzlGradesCacheTimestamp = 0;

async function wpzl_getGrades(forceRefresh) {
  if (!forceRefresh && _wpzlCachedGrades && (Date.now() - _wpzlGradesCacheTimestamp) < WPZL_GRADES_CACHE_TTL_MS) {
    return _wpzlCachedGrades;
  }
  if (!forceRefresh) {
    var storageCache = await new Promise(function (resolve) {
      chrome.storage.local.get(['wpzl_grades_cache'], function (r) { resolve(r.wpzl_grades_cache || null); });
    });
    if (storageCache && (Date.now() - storageCache.cachedAt) < WPZL_GRADES_CACHE_TTL_MS) {
      _wpzlCachedGrades = storageCache.data;
      _wpzlGradesCacheTimestamp = Date.now();
      return _wpzlCachedGrades;
    }
  }
  var resp = await _wpzlApiFetch('/api/v1/pro/grades', { method: 'GET', auth: true });
  var grades = (resp && resp.data) || [];
  _wpzlCachedGrades = grades;
  _wpzlGradesCacheTimestamp = Date.now();
  try {
    chrome.storage.local.set({ wpzl_grades_cache: { data: grades, cachedAt: Date.now() } });
  } catch (e) { /* ignore */ }
  return grades;
}
