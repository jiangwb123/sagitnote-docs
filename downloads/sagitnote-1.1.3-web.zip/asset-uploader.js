// ============================================================
// Sagitnote - Asset Uploader Module
// Loaded via importScripts('asset-uploader.js') by service-worker.js
// 决策 B：免费用户不上传（调用方用 wpzl_isImageCloudUploadAllowed 判定）
// 决策 C：签名 URL LRU 缓存，避免重复打服务端
// ============================================================

(function () {
  var signCache = new Map(); // objectKey -> {signedUrl, expiresAt}
  var SIGN_CACHE_TTL_BUFFER_MS = 5 * 60 * 1000; // 比服务端 expiresIn 提前 5 分钟过期
  var SIGN_CACHE_MAX = 500;

  function sha256Hex(blob) {
    return new Promise(function (resolve, reject) {
      blob.arrayBuffer().then(function (buf) {
        crypto.subtle.digest('SHA-256', buf).then(function (hash) {
          var bytes = new Uint8Array(hash);
          var hex = '';
          for (var i = 0; i < bytes.length; i++) {
            hex += bytes[i].toString(16).padStart(2, '0');
          }
          resolve(hex);
        }).catch(reject);
      }).catch(reject);
    });
  }

  async function uploadImage(blob, pageKey, imageKey) {
    // D2：objectKey 由服务端按 pageKey+imageKey 分配（u/{uid}/{pageKey}/{imageKey}.webp）。
    // sha 仅作传输完整性校验（服务端可选比对），不再用于寻址/去重。
    var sha = await sha256Hex(blob);
    var resp = await wpzl_assetUpload(blob, sha, pageKey, imageKey);
    return resp; // {cloudUrl(=objectKey), quotaUsed, quotaTotal, deduped}
  }

  async function getSignedUrl(objectKey) {
    var cached = signCache.get(objectKey);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.signedUrl;
    }
    // 超时保护：签名服务慢响应时避免拖慢 cloudUrl 回填（用户要求"不能一直等待"）
    var SIGN_TIMEOUT_MS = 10000;
    var resp = await new Promise(function (resolve, reject) {
      var timer = setTimeout(function () {
        reject(new Error('sign_timeout_' + SIGN_TIMEOUT_MS + 'ms'));
      }, SIGN_TIMEOUT_MS);
      wpzl_assetSign(objectKey).then(function (r) {
        clearTimeout(timer);
        resolve(r);
      }).catch(function (e) {
        clearTimeout(timer);
        reject(e);
      });
    });
    var entry = {
      signedUrl: resp.signedUrl,
      expiresAt: Date.now() + (resp.expiresIn * 1000) - SIGN_CACHE_TTL_BUFFER_MS
    };
    if (signCache.size >= SIGN_CACHE_MAX) {
      var firstKey = signCache.keys().next().value;
      signCache.delete(firstKey);
    }
    signCache.set(objectKey, entry);
    return resp.signedUrl;
  }

  function invalidateSignCache(objectKey) {
    if (objectKey) signCache.delete(objectKey);
    else signCache.clear();
  }

  // 批量预签名（2026-10-04 方案4，lite 下载器批级预热）：一次 sign-batch 请求签多个
  // objectKey 直接回填本缓存，批内逐张 getSignedUrl 全命中——签名请求密度降 ~8×。
  // 已缓存的跳过；异常上抛由调用方静默兜底（逐张路径）。
  async function preSignUrls(objectKeys) {
    var miss = [];
    for (var i = 0; i < objectKeys.length; i++) {
      var c = signCache.get(objectKeys[i]);
      if (!(c && c.expiresAt > Date.now())) miss.push(objectKeys[i]);
    }
    if (miss.length === 0) return;
    var resp = await wpzl_assetSignBatch(miss);
    var items = (resp && (resp.items || resp)) || []; // 兼容裸数组形状
    for (var j = 0; j < items.length; j++) {
      var it = items[j];
      if (!it || !it.objectKey || !it.signedUrl) continue; // 脏 key 服务端静默跳过，这里同样容错
      if (signCache.size >= SIGN_CACHE_MAX) signCache.delete(signCache.keys().next().value);
      signCache.set(it.objectKey, {
        signedUrl: it.signedUrl,
        expiresAt: Date.now() + (it.expiresIn * 1000) - SIGN_CACHE_TTL_BUFFER_MS
      });
    }
  }

  self.wpzl_uploadImage = uploadImage;
  self.wpzl_getSignedAssetUrl = getSignedUrl;
  self.wpzl_invalidateSignCache = invalidateSignCache;
  self.wpzl_preSignAssetUrls = preSignUrls;
})();
