// ============================================================
// Sagitnote - Document Sync Downloader (D3)
// Loaded via importScripts('doc-sync-downloader.js') by service-worker.js
//
// 职责：跨设备全量/增量同步拿到文档 metadata（bodyObjectKey）后，后台从 R2 拉文档 body 回填
//   docBodies（P1-8 分仓：bodyHtml 不在 documents 记录）。body 不走 sync 通道（与图片同理），
//   只走 REST（GET /api/v1/documents/{id}）。目的：文档是用户作品，全量备份/导出需完整本地化；
//   编辑器打开时若本地无 body 再走 REST 兜底。
//
// 设计要点（镜像 image-sync-downloader.js）：
// - 独立 alarm 'doc-sync-resume' 保活（MV3 SW 30s 回收，alarm 1min 唤醒续跑）
// - 入口 _enqueueDocSyncDownloads(docIds)：sync-engine._applyDownloadedDocumentsChunk 在下载合并后调用
//   （激活 alarm 作 SW 回收兜底 + 经链式调度器错峰起跑首批，不再干等 1min alarm 首跳——P2-2）
// - collector 读持久化清单 doc_dl_pending_ids（P1-7，2026-10-05 bulktest 10k 报告：原每轮全表
//   getAll 物化 128×8MB≈1GiB，pending=0 也照扫，2s 轮询把 SW 事件循环打满 15s/次）。清单由
//   sync pull 落库时精确入队（新文档 + 跨设备 hash 不匹配被清空者），24h 全表流式自愈兜漏记
// - 失败重试（P1-15，对齐 image 侧 dlRetryCount/dlExhausted 体系）：失败计数 dlRetryCount+1，
//   ≥DOC_DL_MAX_RETRIES 置 dlExhausted 出清单（不再自动重试）+ 广播耗尽通知；成功/重登复位。
//   body 仍留空——编辑器打开仍走 REST 兜底。复位走 sync-engine._resetDocDownloadExhausted。
// - 进度：_docDlSession 会话累计 + manager 轮询清单真值（2026-10-04 重做，见 _reportBgDownloadProgress）
// ============================================================

var DOC_SYNC_ALARM = 'doc-sync-resume';
var DOC_SYNC_ALARM_MINUTES = 1; // MV3 alarm 最小周期
var DOC_SYNC_BATCH = 6;         // 每 alarm 处理多少篇（body 可能较大，比图片保守）
var DOC_SYNC_CONCURRENCY = 2;   // 并发下载数
var DOC_DL_MAX_RETRIES = 10;    // P1-15: 下载失败重试上限（对齐 image 侧 IMAGE_DL_MAX_RETRIES）
// 2026-10-04 提速：镜像 image 侧链式续跑——批完成即排下一批，不等 1min alarm tick
//（原 6 篇/分钟的纯 alarm 节流与网络无关，全量重登多文档时排空极慢）。
var DOC_SYNC_CHAIN_DELAY_MS = 2000; // 批间小歇（毫秒，实际 ±40% 抖动），body 较大比图片侧稍保守
// P2-2（2026-10-05 测试报告）：enqueue→首批错峰小歇。原先只 arm alarm 等首跳，
// 登录后首批要空等 ~8-10s（实测 3.6s 入队、13.5s 才起跑）。
var DOC_SYNC_FIRST_BATCH_DELAY_MS = 800;
// 方案1（同日）：失败指数退避（镜像 image 侧）。doc 请求经服务端中转（GET /documents/{id}），
// 是下载链路里唯一直接消耗服务端吞吐的部分，429/5xx 退避更关键：429 至少歇 60s
//（对齐 IpRateLimitFilter 全局桶 60s 窗口），防止限流与重试互相放大。
var DOC_DL_BACKOFF_BASE_MS = 30000;
var DOC_DL_BACKOFF_CAP_MS = 10 * 60 * 1000;
var DOC_DL_429_BACKOFF_MS = 60 * 1000;
// P1-7（2026-10-05 bulktest 10k 报告）：待下文档持久化清单（syncMeta，镜像 img_dl_pending_ids）。
// 元素为小 tuple {id, nextAt}——due/backing 分类纯清单数学，不碰 documents 大记录（body ~MB 级）。
// nextAt 与记录上的 dlNextAt 由 _markDocDownloadFailed 成对维护；24h 全表流式自愈兜入队漏记。
var DOC_DL_PENDING_MAX = 2000;      // 清单硬上限（超限丢最旧）
var DOC_DL_FULLSCAN_INTERVAL_MS = 24 * 60 * 60 * 1000; // 全表自愈重建周期（兜漏记/restore 导入）

var _docSyncActive = false;
// 2026-10-04 进度重做（镜像 image 侧）：原 _docSyncProgress 的 total 每批按 due 数重算，
// pull 分块落地期间持续增长（用户实测 7/9 → 7/12），done 又按批重置——显示混乱。
// 改为会话累计 done + 剩余数由 manager 轮询清单真值（_collectPendingDocDownloads 的 due+backing）。
// 第三批（2026-10-05）：会话累计挪 chrome.storage.session——MV3 SW 被 30s 回收后进度条不再跳
//「已下 0」（bulktest_10k 实测 SW 重启两次归零）。storage.session 生命周期=浏览器会话，恰好匹配
//「会话累计」语义（比 SW 内存长寿、比 storage.local 短命）。求值即 hydrate（SW 唤醒时 script
// eval 立刻发起，内存读 ms 级完成）；读路径（bg-download-progress）await _docDlSessionDone() 兜底。
var _docDlSession = { done: 0 };
var _docDlSessionHydrated = false;
var _docDlSessionHydrating = null;
function _docDlSessionHydrate() {
  if (_docDlSessionHydrated) return Promise.resolve();
  if (_docDlSessionHydrating) return _docDlSessionHydrating;
  _docDlSessionHydrating = (async function () {
    try {
      var st = await chrome.storage.session.get('doc_dl_session');
      var saved = st && st.doc_dl_session;
      if (saved && typeof saved.done === 'number' && saved.done > (_docDlSession.done || 0)) {
        _docDlSession.done = saved.done;   // 仅当持久值更大才覆盖（防丢 hydrate 前的本地增量）
      }
    } catch (e) { /* storage.session 不可用：退化为纯内存（与旧行为一致） */ }
    _docDlSessionHydrated = true;
  })();
  return _docDlSessionHydrating;
}
function _docDlSessionAdd(delta) {
  _docDlSession.done = (_docDlSession.done || 0) + delta;   // 同步：读路径立刻可见
  try { chrome.storage.session.set({ doc_dl_session: { done: _docDlSession.done } }); } catch (e) { /* ignore */ }
}
function _docDlSessionReset() {
  _docDlSession.done = 0;   // 队列确认真空：会话结束，累计清零（持久化，防 SW 重启复活旧值）
  try { chrome.storage.session.set({ doc_dl_session: { done: 0 } }); } catch (e) { /* ignore */ }
}
async function _docDlSessionDone() {
  await _docDlSessionHydrate();
  return _docDlSession.done || 0;
}
_docDlSessionHydrate();   // eval 即 hydrate

// ---- 入口：被 sync-engine._applyDownloadedDocumentsChunk 调用 ----
// P2-2：不再干等 1min alarm 首跳——经链式调度器 800ms 后起跑首批（fire-and-forget：
// _docSyncChainTimer 去重 + _docSyncActive 重入守卫，不阻塞 sync 主流程）。
// alarm 保留两职：SW 小歇间隙被回收的兜底接管 + 全员退避期的分钟级节流。
// P1-7：docIds 由调用方精确传入（落库即知谁缺 body）；清单写失败丢本批，24h 自愈扫兜底。
function _enqueueDocSyncDownloads(docIds) {
  console.log('[DocSync] enqueued doc body downloads: ' + ((docIds && docIds.length) || 0));
  _noteDocDlPending(docIds);
  _ensureDocSyncAlarm();
  _scheduleNextDocBatch(DOC_SYNC_FIRST_BATCH_DELAY_MS);
}

function _ensureDocSyncAlarm() {
  try {
    chrome.alarms.create(DOC_SYNC_ALARM, { periodInMinutes: DOC_SYNC_ALARM_MINUTES });
  } catch (e) { /* ignore */ }
}

// P1-7: 待下文档入清单（去重保留既有退避时钟 + 有界）。镜像 image 侧 _noteImageDlPending。
async function _noteDocDlPending(docIds) {
  if (!docIds || docIds.length === 0) return;
  try {
    var list = await _syncGetMeta('doc_dl_pending_ids') || [];
    for (var i = 0; i < docIds.length; i++) {
      var id = docIds[i];
      if (!id) continue;
      var hit = false;
      for (var j = 0; j < list.length; j++) { if (list[j] && list[j].id === id) { hit = true; break; } }
      if (!hit) list.push({ id: id, nextAt: 0 });
    }
    if (list.length > DOC_DL_PENDING_MAX) list = list.slice(list.length - DOC_DL_PENDING_MAX);
    await _syncSetMeta('doc_dl_pending_ids', list);
  } catch (e) { /* ignore */ }
}

// P1-7: 出队（下载成功/记录已删/耗尽）。失败仅留陈旧项——重下自清 + 24h 自愈兜底。
async function _removeDocDlPendingByIds(ids) {
  if (!ids || ids.length === 0) return;
  try {
    var list = await _syncGetMeta('doc_dl_pending_ids') || [];
    var rm = {};
    for (var i = 0; i < ids.length; i++) rm[ids[i]] = true;
    var keep = list.filter(function (t) { return t && t.id && !rm[t.id]; });
    if (keep.length !== list.length) await _syncSetMeta('doc_dl_pending_ids', keep);
  } catch (e) { /* ignore */ }
}

// P1-7: 退避时钟镜像到清单（分类只读清单；记录上的 dlNextAt 仍由 updateDocumentFields 维护）。
async function _setDocDlNextAt(id, nextAt) {
  if (!id) return;
  try {
    var list = await _syncGetMeta('doc_dl_pending_ids') || [];
    var found = false;
    for (var i = 0; i < list.length; i++) {
      if (list[i] && list[i].id === id) { list[i].nextAt = nextAt; found = true; break; }
    }
    if (found) await _syncSetMeta('doc_dl_pending_ids', list);
  } catch (e) { /* ignore */ }
}

// alarm 误清防护（镜像 _imagePendingListEmptyConfirmed）：仅清单本身确认读得到且为空才 true。
// 瞬态读失败按"未空"处理——防 collector 瞬态空读误清 alarm 令管线静默停摆。
function _docDlPendingListEmptyConfirmed() {
  return _syncGetMeta('doc_dl_pending_ids')
    .then(function (l) { return !l || l.length === 0; })
    .catch(function () { return false; });
}

async function _docDlFullScanDue() {
  try {
    var last = await _syncGetMeta('doc_dl_scan_last_run') || 0;
    return (Date.now() - last) > DOC_DL_FULLSCAN_INTERVAL_MS;
  } catch (e) { return false; }
}

// P1-7: 全表自愈重建清单（openCursor 流式逐条，内存峰值=单条记录而非全表；镜像 image 侧）。
// 谓词与旧全扫 collector 一致：bodyObjectKey 非空 && 本地无 body && synced && 未耗尽。
// P1-8（dbVersion 25）：本地有无 body = docBodies 键集（记录不再内联 bodyHtml）。
async function _rebuildDocDlPendingFullScan() {
  var list = [];
  var bodyKeys = null;
  try { bodyKeys = await db.getDocBodyKeySet(); } catch (e) { bodyKeys = null; }
  if (!bodyKeys) return 0;   // 键集瞬态读失败：本轮不重建（下个 tick 重试），防误清清单
  await new Promise(function (resolve) {
    var req;
    try { req = db._tx('documents', 'readonly').openCursor(); } catch (e) { resolve(); return; }
    req.onsuccess = function (ev) {
      var cursor = ev.target.result;
      if (!cursor) { resolve(); return; }
      var rec = cursor.value;
      if (rec && rec.bodyObjectKey && !bodyKeys.has(rec.docId) &&
          rec.SYNC_STATUS === 'synced' && !rec.dlExhausted) {
        list.push({ id: rec.docId, nextAt: rec.dlNextAt || 0 });
        if (list.length >= DOC_DL_PENDING_MAX) { resolve(); return; }
      }
      cursor.continue();
    };
    req.onerror = function () { resolve(); };
  });
  try {
    await _syncSetMeta('doc_dl_pending_ids', list);
    await _syncSetMeta('doc_dl_scan_last_run', Date.now());
  } catch (e) { /* ignore */ }
  console.log('[DocSync] full-scan rebuilt pending list:', list.length);
  return list.length;
}

// 链式续跑调度（去重定时器，镜像 image 侧 _scheduleNextImageBatch）。
// SW 若在小歇间隙被回收，alarm 下个 tick 兜底接管。delayOverrideMs：错峰起步用；
// 缺省按链间抖动（方案3）base ±40%——多客户端去同步化，平滑服务端到达曲线。
var _docSyncChainTimer = null;
function _scheduleNextDocBatch(delayOverrideMs) {
  if (_docSyncChainTimer) return;
  var delay = (typeof delayOverrideMs === 'number' && delayOverrideMs > 0)
    ? delayOverrideMs
    : DOC_SYNC_CHAIN_DELAY_MS * (0.6 + Math.random() * 0.8);
  _docSyncChainTimer = setTimeout(function () {
    _docSyncChainTimer = null;
    _processDocSyncBatch();
  }, delay);
}

// ---- 主处理流程（alarm 触发）----
async function _processDocSyncBatch() {
  if (_docSyncActive) return;
  // 同步未启用则不跑（无 bodyObjectKey 文档也不会出现，防御性兜底）
  if (typeof wpzlSyncEngine === 'undefined' || typeof wpzlSyncEngine.isEnabled !== 'function') return;
  try { if (!wpzlSyncEngine.isEnabled()) return; } catch (e) { return; }

  _docSyncActive = true;
  try {
    var pending = await _collectPendingDocDownloads();
    // null = 清单瞬态读失败（区别于真·空队列，2026-10-04 修复）：保 alarm 由下个 tick 重试，绝不 clear
    if (pending === null) return;
    // P1-7：清单空 + 自愈扫描到期 → 全表流式重建一次（兜入队漏记 / restore 导入 / 清单漂移）
    if (pending.due.length === 0 && pending.backing === 0 && await _docDlFullScanDue()) {
      var rebuilt = await _rebuildDocDlPendingFullScan();
      if (rebuilt > 0) pending = await _collectPendingDocDownloads();
    }
    if (pending.due.length === 0 && pending.backing === 0) {
      // 仅清单真值为空才 clear（镜像 image 侧 alarm 误清修复）
      if (await _docDlPendingListEmptyConfirmed()) {
        try { chrome.alarms.clear(DOC_SYNC_ALARM); } catch (e) { /* ignore */ }
        _docDlSessionReset();             // 队列确认真空：会话结束，累计清零
      }
      _reportBgDownloadProgress();
      return;
    }
    if (pending.due.length === 0) {
      // 方案1：全员退避中（backing>0）——alarm 保留等退避到期，不链式空转
      _reportBgDownloadProgress();
      return;
    }
    var batch = pending.due.slice(0, DOC_SYNC_BATCH);
    var successCount = 0;
    var doneIds = [];   // P1-7：成功项批末一次性出队（避免逐条 read-modify-write 清单）
    await _runConcurrentDoc(batch, DOC_SYNC_CONCURRENCY, async function (d) {
      var ok = await _downloadOneDoc(d);
      if (ok) { successCount++; _docDlSessionAdd(1); doneIds.push(d.docId); }
      _reportBgDownloadProgress();
    });
    if (doneIds.length > 0) await _removeDocDlPendingByIds(doneIds);
    // 链式续跑（镜像 image 侧）：有进展即排下一批（退避项已被分类排除）；
    // 全零成功交还 alarm 按分钟节流，失败项按 nextAt 指数退避
    if (successCount > 0) _scheduleNextDocBatch();
  } catch (e) {
    console.warn('[DocSync] batch failed:', e && e.message);
  } finally {
    _docSyncActive = false;
  }
}

// P1-7（2026-10-05）：收集待下载文档——读 doc_dl_pending_ids 清单纯数学分类，不再全表 getAll
//（旧实现每轮物化全部 bodyHtml，128×8MB 库实测 15s/次，pending=0 也照扫）。
// 返回 {due:[{docId}], backing:N}：due=可立即下载；backing=nextAt 退避未到期数量（数据仍
// 缺失，门禁计数应含它）。null=清单瞬态读失败（区别于空=确无待办）——调用方不得据此清 alarm。
// 记录级真值（bodyHtml 已回填/已删/耗尽）由出入队钩子维护，24h 全表自愈扫兜底漂移。
async function _collectPendingDocDownloads() {
  var list;
  try { list = await _syncGetMeta('doc_dl_pending_ids'); } catch (e) { return null; }
  if (!list) list = [];
  var now = Date.now();
  var due = [];
  var backing = 0;
  for (var i = 0; i < list.length; i++) {
    var t = list[i];
    if (!t || !t.id) continue;
    if (t.nextAt && t.nextAt > now) backing++; // 方案1：退避中
    else due.push({ docId: t.id });
  }
  return { due: due, backing: backing };
}

// 下载单篇 body：GET /api/v1/documents/{docId} → bodyHtml → 写 IDB（不标 dirty）。
// 返回 true=body 非空（链式续跑+出队依据）；false=失败或空 body（空 body 视为未进展——
// bodyObjectKey 非空却取回空串属异常，按失败计数走 dlRetryCount 退避，防链式热循环空转）。
// P1-7：下载侧重试字段的复位并入 saveDocumentBodyFromCloud 的同一次 get-then-put
//（原单独 updateDocumentFields 会多一次大记录整读整写）。
async function _downloadOneDoc(d) {
  try {
    var resp = await _wpzlApiFetch('/api/v1/documents/' + encodeURIComponent(d.docId), { auth: true });
    var body = (resp && resp.data && resp.data.bodyHtml) || '';
    // P1-8：仅非空 body 落 docBodies——空 body 视为"仍缺失"（与分仓前 !bodyHtml 谓词语义一致），
    // 不创建空键占位（否则 docBodies 键集会把该文档误判为已有本地 body，自愈扫漏收）。
    if (body) await db.saveDocumentBodyFromCloud(d.docId, body);
    return !!body;
  } catch (e) {
    console.warn('[DocSync] download failed: ' + d.docId + ' — ' + (e && e.message));
    await _markDocDownloadFailed(d, e);
    return false;
  }
}

// P1-15: 失败计数 + 耗尽标记（镜像 image-sync-downloader._markDownloadPending）。
// 经 db.updateDocumentFields 中立 patch 写回（不碰 SYNC_*）；耗尽时广播通知（manager toast）。
// P1-7：nextAt 成对镜像到清单；记录已删/耗尽 → 出队（分类只信清单）。
async function _markDocDownloadFailed(d, e) {
  try {
    var fresh = await db.getDocument(d.docId);
    if (!fresh) { _removeDocDlPendingByIds([d.docId]); return; }  // 记录已被并发删除
    var rc = (fresh.dlRetryCount || 0) + 1;
    var exhausted = (rc >= DOC_DL_MAX_RETRIES) && !fresh.dlExhausted;
    // 方案1：指数退避 30s·2^(n-1) 封顶 10min；429（_wpzlApiFetch 错误带 status）
    // 至少歇 60s 对齐服务端限流窗口，切断 429→密重试正反馈
    var _bo = DOC_DL_BACKOFF_BASE_MS * Math.pow(2, Math.max(0, rc - 1));
    if ((e && e.status === 429) || String((e && e.message) || '').indexOf('429') >= 0) {
      _bo = Math.max(_bo, DOC_DL_429_BACKOFF_MS);
    }
    var nextAt = Date.now() + Math.min(_bo, DOC_DL_BACKOFF_CAP_MS);
    await db.updateDocumentFields(d.docId, {
      dlRetryCount: rc,
      dlExhausted: fresh.dlExhausted || (rc >= DOC_DL_MAX_RETRIES),
      dlLastError: String((e && e.message) || '').slice(0, 200) || null,
      dlNextAt: nextAt
    });
    await _setDocDlNextAt(d.docId, nextAt);
    if (exhausted) {
      console.warn('[DocSync] download exhausted after ' + rc + ' retries: ' + d.docId);
      if (typeof _broadcastSyncExhausted === 'function') {
        _broadcastSyncExhausted({ kind: 'doc-download', id: d.docId, retryCount: rc });
      }
      // 耗尽不再自动重试；复位途径 _resetDocDownloadExhausted 会重新入队
      _removeDocDlPendingByIds([d.docId]);
    }
  } catch (e2) { /* ignore */ }
}

// ---- 统一进度上报（文档 + 图片），供 manager 左下角提示条读取 ----
// 2026-10-04 重做：推送不再带数据（旧 {done,total} 是批作用域，manager 两个来源渲染不一致）。
// 推送退化为 nudge——manager 收到后立即向 SW 轮询 'bg-download-progress'（会话累计 done +
// IDB 真值 remaining/backing 分类），单一事实来源。定义在本文件（image 侧仅 typeof 调用）。
function _reportBgDownloadProgress() {
  try {
    chrome.runtime.sendMessage({ type: 'wpzl-bg-download-progress' })
      .catch(function () { /* manager 未打开时无接收方，忽略 */ });
  } catch (e) { /* ignore */ }
}

async function _runConcurrentDoc(items, concurrency, worker) {
  var index = 0;
  async function next() {
    while (index < items.length) {
      var i = index++;
      await worker(items[i]);
    }
  }
  var workers = [];
  for (var w = 0; w < concurrency && w < items.length; w++) workers.push(next());
  await Promise.all(workers);
}
