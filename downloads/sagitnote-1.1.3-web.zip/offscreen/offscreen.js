// ============================================================
// Sagitnote - Offscreen Document: SVG → PNG 栅格化服务
// ============================================================
// 背景：Service Worker 无 DOM，createImageBitmap / ImageDecoder 均不支持 SVG 解码
// （实测 Chrome 135：均报 "could not be decoded" / isTypeSupported=false）。
// 唯一可靠路径是 window 上下文的 Image + canvas —— 即本 offscreen document。
//
// 协议：SW 发 { type:'wpzl-rasterize-svg', requestId, svgDataUrl }
//       本页回 { type:'wpzl-rasterize-svg', requestId, ok, pngDataUrl?, width?, height?, reason? }
//
// 安全说明：SVG 以 data: URL 作为 Image src 加载（不产生 object-src / blob URL；
// manifest CSP object-src 'self'）。SVG-as-image 上下文天然不执行脚本、不加载外部
// 资源，仅做像素栅格化；输入是 SW 已合法抓取的 image/svg+xml 响应字节。
(function () {
  'use strict';

  // canvas 单边上限保护：超大 SVG（长图试卷等）等比缩小，避免 canvas 创建失败/内存爆炸
  var MAX_SIDE = 16384;

  // 串行队列：并发请求按序处理，避免极端大图同时占内存
  var _chain = Promise.resolve();

  // 解析 SVG 固有尺寸：优先显式 width/height，否则从 viewBox 推导。
  // Chrome 的 Image 解码要求 SVG 具备固有尺寸（xkw 试卷预览等导出的 SVG 常只有 viewBox）。
  function _resolveSvgSize(txt) {
    var wM = txt.match(/<svg[^>]*?\swidth\s*=\s*["']([\d.]+)(?:px)?["']/i);
    var hM = txt.match(/<svg[^>]*?\sheight\s*=\s*["']([\d.]+)(?:px)?["']/i);
    var w = wM ? parseFloat(wM[1]) : 0;
    var h = hM ? parseFloat(hM[1]) : 0;
    if (w > 0 && h > 0) return { w: w, h: h, needInject: false };
    var vb = txt.match(/viewBox\s*=\s*["']\s*[-\d.eE+]+[\s,]+[-\d.eE+]+[\s,]+([\d.eE+]+)[\s,]+([\d.eE+]+)/i);
    if (vb) {
      w = parseFloat(vb[1]); h = parseFloat(vb[2]);
      if (w > 0 && h > 0) return { w: w, h: h, needInject: true };
    }
    return null;
  }

  function _dataUrlToText(dataUrl) {
    var commaIdx = dataUrl.indexOf(',');
    var meta = dataUrl.slice(0, commaIdx);
    var payload = dataUrl.slice(commaIdx + 1);
    if (meta.indexOf(';base64') !== -1) {
      return decodeURIComponent(escape(atob(payload)));
    }
    return decodeURIComponent(payload);
  }

  function rasterizeOne(msg) {
    return new Promise(function (resolve) {
      try {
        var dataUrl = String(msg.svgDataUrl || '');
        if (dataUrl.indexOf('data:image/svg+xml') !== 0) {
          resolve({ ok: false, reason: 'not an svg data url' });
          return;
        }
        var txt;
        try {
          txt = _dataUrlToText(dataUrl);
        } catch (e) {
          resolve({ ok: false, reason: 'svg data url decode failed' });
          return;
        }
        var size = _resolveSvgSize(txt);
        if (!size) {
          resolve({ ok: false, reason: 'svg has no intrinsic size (no width/height/viewBox)' });
          return;
        }
        if (size.needInject) {
          txt = txt.replace(/<svg\b/i, '<svg width="' + size.w + '" height="' + size.h + '"');
          // btoa 不接受非 Latin1：走 encodeURIComponent(escape()) 经典往返
          dataUrl = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(txt)));
        }
        var img = new Image();
        img.onload = function () {
          try {
            var iw = img.naturalWidth || size.w;
            var ih = img.naturalHeight || size.h;
            var scale = Math.min(1, MAX_SIDE / Math.max(iw, ih));
            var cw = Math.max(1, Math.round(iw * scale));
            var ch = Math.max(1, Math.round(ih * scale));
            var canvas = document.createElement('canvas');
            canvas.width = cw;
            canvas.height = ch;
            var ctx = canvas.getContext('2d');
            // 铺白底再绘制：SVG 透明区域按原页面白纸观感固化成不透明 PNG——
            // 不铺底则透明部分在暗色查看器里透出黑底（实际反馈：学易金卷试卷图）。
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, cw, ch);
            ctx.drawImage(img, 0, 0, cw, ch);
            var png = canvas.toDataURL('image/png');
            resolve({ ok: true, pngDataUrl: png, width: cw, height: ch });
          } catch (e) {
            resolve({ ok: false, reason: 'canvas rasterize failed: ' + (e && e.message) });
          }
        };
        img.onerror = function () {
          resolve({ ok: false, reason: 'svg image decode failed' });
        };
        img.src = dataUrl;
      } catch (e) {
        resolve({ ok: false, reason: (e && e.message) || 'internal error' });
      }
    });
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || msg.type !== 'wpzl-rasterize-svg') return false;
    _chain = _chain
      .then(function () { return rasterizeOne(msg); })
      .then(function (result) {
        result.type = 'wpzl-rasterize-svg';
        result.requestId = msg.requestId;
        try { sendResponse(result); } catch (e) { /* 通道已关（SW 超时放弃） */ }
      })
      .catch(function () {
        try { sendResponse({ type: 'wpzl-rasterize-svg', requestId: msg.requestId, ok: false, reason: 'internal error' }); } catch (e) { /* ignore */ }
      });
    return true; // 异步 sendResponse
  });
})();
