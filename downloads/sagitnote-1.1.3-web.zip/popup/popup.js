// ============================================================
// Sagitnote - Popup Script
// ============================================================

document.addEventListener('DOMContentLoaded', async () => {
  // i18n: apply localized text to all [data-i18n] elements
  document.querySelectorAll('[data-i18n]').forEach(function(el) {
    var key = el.getAttribute('data-i18n');
    var msg = chrome.i18n.getMessage(key);
    if (msg) el.textContent = msg;
  });
  document.querySelectorAll('[data-i18n-title]').forEach(function(el) {
    var key = el.getAttribute('data-i18n-title');
    var msg = chrome.i18n.getMessage(key);
    if (msg) el.title = msg;
  });
  document.querySelectorAll('[data-i18n-aria-label]').forEach(function(el) {
    var key = el.getAttribute('data-i18n-aria-label');
    var msg = chrome.i18n.getMessage(key);
    if (msg) el.setAttribute('aria-label', msg);
  });
  document.documentElement.lang = chrome.i18n.getUILanguage();

  // Version from manifest
  var versionEl = document.querySelector('.popup-version');
  if (versionEl) {
    versionEl.textContent = 'v' + chrome.runtime.getManifest().version;
  }

  // --- 认证 / 用户状态 ---
  var userSection = document.getElementById('userSection');
  var userLoggedIn = document.getElementById('userLoggedIn');
  var userName = document.getElementById('userName');
  var userTier = document.getElementById('userTier');
  var userAvatar = document.getElementById('userAvatar');
  var loginBtn = document.getElementById('loginBtn');
  // 退出/切换用户等危险操作已收敛到设置页（settings → 数据管理），popup 不再提供入口。

  // 渲染用户等级标签：Pro(含到期日) / Pro 临期 / 已过期 / 免费版。供 updateAuthUI 与「刷新用户状态」复用。
  // reminderDays：服务端下发的到期提醒窗口（30=年付/3=月付），非空且剩余天数在窗口内 → 临期态。

  // 服务端到期串（UTC-naive）→ epoch ms：naive 按 UTC 构造（服务端 2026-11 起全链路 UTC 轴），
  // ISO 带 Z/偏移按绝对时间。裸 new Date(str) 会把 naive 串按本地时区解释 → 判定/剩余天数偏一个时区。
  function parseProExpiryMs(s) {
    if (!s) return NaN;
    var t = String(s).trim();
    var m = t.replace('T', ' ').match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?$/);
    if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
    return Date.parse(t);
  }

  function renderUserTier(isPro, proExpiresAt, reminderDays) {
    var hasExpiry = proExpiresAt && proExpiresAt.length > 0;
    var isExpired = false;
    if (!isPro && hasExpiry) {
      try { isExpired = Date.now() >= parseProExpiryMs(proExpiresAt); } catch(e) {}
    }
    if (isPro) {
      // 临期第四态：进入提醒窗口（剩余 ≤ reminderDays 天）时橙色提示，优先于普通 Pro 态
      if (hasExpiry && reminderDays) {
        var daysLeft = null;
        try { daysLeft = Math.ceil((parseProExpiryMs(proExpiresAt) - Date.now()) / 86400000); } catch(e) {}
        if (daysLeft != null && daysLeft >= 0 && daysLeft <= reminderDays) {
          userTier.textContent = chrome.i18n.getMessage('userExpiringSoon', [String(daysLeft)]) || 'Pro';
          userTier.className = 'user-tier expiring';
          return;
        }
      }
      var expiryDate = '';
      if (hasExpiry) {
        try {
          var _eMs = parseProExpiryMs(proExpiresAt);
          expiryDate = isNaN(_eMs) ? '' : new Date(_eMs).toLocaleDateString();
        } catch(e) {}
      }
      userTier.textContent = (chrome.i18n.getMessage('userPro') || 'Pro') + (expiryDate ? ' · ' + expiryDate : '');
      userTier.className = 'user-tier pro';
    } else if (isExpired) {
      userTier.textContent = chrome.i18n.getMessage('userExpired') || '已过期';
      userTier.className = 'user-tier expired';
    } else {
      userTier.textContent = chrome.i18n.getMessage('userFree') || '免费版';
      userTier.className = 'user-tier free';
    }
  }

  // 登录态渲染：已登录 / 未登录两种 UI。updateAuthUI 成功分支与脱机兜底分支复用。
  function renderLoggedIn(user) {
    document.body.classList.add('wpzl-logged-in');
    document.body.classList.remove('wpzl-logged-out');
    document.body.classList.remove('wpzl-has-local-data');
    // 本地模式提示行仅未登录显示（2026-09-29）
    var _lmn = document.getElementById('localModeNote');
    if (_lmn) _lmn.style.display = 'none';
    userLoggedIn.style.display = 'flex';
    userName.textContent = user.name || user.loginId;
    userAvatar.textContent = (user.name || user.loginId || 'U').charAt(0).toUpperCase();
    // 头像：本地缓存优先（SW avatar-get），有则覆盖首字母；无则保持字母（现状逻辑条件分支保留）。
    chrome.runtime.sendMessage({ type: 'avatar-get' }).then(function (resp) {
      if (resp && resp.success && resp.data && resp.data.dataUrl) {
        userAvatar.textContent = '';
        userAvatar.style.backgroundImage = 'url("' + resp.data.dataUrl + '")';
        userAvatar.style.backgroundSize = 'cover';
        userAvatar.style.backgroundPosition = 'center';
      }
    }).catch(function () { /* 忽略：保持首字母 */ });
    // 用户等级显示：Pro + 到期日期 / 已过期 / 免费版
    renderUserTier(user.proStatus === 'pro', user.proExpiresAt);
    loginBtn.style.display = 'none';
    // 等级热刷新：user.proStatus 是登录时刻的快照，后台改级后即陈旧——
    // 打开 popup 即向服务器核对一次并重绘（失败静默，保持当前渲染）。
    chrome.runtime.sendMessage({ type: 'pro-status', forceRefresh: true }).then(function (result) {
      if (result && result.success && result.data && result.data.isPro !== undefined) {
        renderUserTier(result.data.isPro, result.data.expiresAt, result.data.expiryReminderDays);
        updateSyncUI();
      }
    }).catch(function () { /* 脱机/超时：保持缓存渲染 */ });
  }

  // 未登录但本地仍有用户数据时保留业务菜单（标注管理/设置）——数据可达性优先于登录态。
  // 覆盖场景：切换账号被拦截、refresh token 失效（连续 401）等。此时用户必须仍能进
  // 「标注管理」查看本地数据、进「设置→清空本地数据」解死锁。
  function _exposeMenuIfLocalData() {
    var fallback = function () {
      try {
        chrome.storage.local.get(['wpzl_local_data_owner'], function (r) {
          if (r && r.wpzl_local_data_owner) document.body.classList.add('wpzl-has-local-data');
        });
      } catch (e) { /* ignore */ }
    };
    try {
      chrome.runtime.sendMessage({ type: 'wpzl-has-local-data' }, function (resp) {
        if (chrome.runtime.lastError) { fallback(); return; }
        if (resp && resp.success && resp.data && resp.data.hasData) {
          document.body.classList.add('wpzl-has-local-data');
        }
      });
    } catch (e) { fallback(); }
  }

  function renderLoggedOut() {
    document.body.classList.add('wpzl-logged-out');
    document.body.classList.remove('wpzl-logged-in');
    userLoggedIn.style.display = 'none';
    loginBtn.style.display = 'inline';
    // 本地模式（2026-09-29 游客档）：未登录也显示菜单（CSS 已放开）+ 本地模式提示行
    var _lmn = document.getElementById('localModeNote');
    if (_lmn) _lmn.style.display = 'flex';
    _exposeMenuIfLocalData();
  }

  // 脱机 / SW 不可响应时直接读本地缓存 auth（wpzl_auth.user），保证 popup 仍能渲染已知登录态。
  function _readCachedAuth() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(['wpzl_auth'], function (result) {
          resolve((result && result.wpzl_auth) || null);
        });
      } catch (e) { resolve(null); }
    });
  }

  async function updateAuthUI() {
    try {
      // 超时兜底：SW 冷启动 / 脱机不可响应时避免 popup 长时间空白（~5s）。
      var result = await Promise.race([
        chrome.runtime.sendMessage({ type: 'auth-status' }),
        new Promise(function (_, reject) {
          setTimeout(function () { reject(new Error('auth-status timeout')); }, 5000);
        })
      ]);
      userSection.style.display = 'block';
      if (result && result.success && result.data && result.data.isLoggedIn && result.data.user) {
        renderLoggedIn(result.data.user);
      } else {
        renderLoggedOut();
      }
    } catch (e) {
      // SW 未就绪 / 超时 / 脱机：优先读本地缓存 auth 渲染已知登录态（脱机仍可见用户信息），
      // 无缓存才显示登录按钮 —— 保证 popup 永不空白。
      userSection.style.display = 'block';
      var cached = await _readCachedAuth();
      if (cached && cached.user) {
        renderLoggedIn(cached.user);
      } else {
        renderLoggedOut();
      }
    }
  }

  if (loginBtn) {
    loginBtn.addEventListener('click', function() {
      // 无痕窗口内点登录：tabs.create 不带 windowId 时默认目标永不选无痕窗口（popup 是
      // 扩展页、属普通配置文件，spanning 模式），auth.html 会开到普通窗口。显式带上
      // popup 锚定窗口的 id（windows.getCurrent 对无痕窗口同样返回，且无需 tabs 权限），
      // 让登录页跟随点击所在窗口；取不到时退回默认行为。
      chrome.windows.getCurrent(function (win) {
        if (chrome.runtime.lastError) { /* 读不到窗口信息：退回默认开法 */ }
        var opts = { url: chrome.runtime.getURL('popup/auth.html') };
        if (win && typeof win.id === 'number') { opts.windowId = win.id; }
        chrome.tabs.create(opts);
        window.close();
      });
    });
  }

  // 刷新用户状态：用现有 token 从服务器重新拉等级/限额/到期，不清空本地数据、不重新登录。
  // 服务端改了用户限额后点此即可生效；SW 在 forceRefresh 时会广播 wpzl-pro-status-updated，页面内 content/feature-gate 限额热刷新。
  var refreshUserBtn = document.getElementById('refreshUserBtn');
  if (refreshUserBtn) {
    refreshUserBtn.addEventListener('click', async function() {
      if (refreshUserBtn.disabled) return;
      refreshUserBtn.disabled = true;
      refreshUserBtn.classList.add('refreshing');
      try {
        var result = await chrome.runtime.sendMessage({ type: 'pro-status', forceRefresh: true });
        if (result && result.success && result.data) {
          renderUserTier(result.data.isPro, result.data.expiresAt);
        } else {
          refreshUserBtn.title = (result && result.error) || chrome.i18n.getMessage('popupRefreshFailed');
        }
      } catch (e) {
        refreshUserBtn.title = chrome.i18n.getMessage('popupRefreshFailedWith', ['$1']).replace('$1', (e && e.message) || '');
      } finally {
        refreshUserBtn.classList.remove('refreshing');
        refreshUserBtn.disabled = false;
      }
    });
  }

  // Check auth on popup open
  updateAuthUI();

  // --- Sync status indicator ---
  var syncStatusRow = document.getElementById('syncStatusRow');
  var syncStatusBadge = document.getElementById('syncStatusBadge');

  async function updateSyncUI() {
    try {
      var result = await chrome.runtime.sendMessage({ type: 'sync-status' });
      if (result && result.success && result.data) {
        var s = result.data;
        if (s.enabled && s.cloudSyncAllowed) {
          syncStatusRow.style.display = 'flex';
          var statusText = '';
          var statusColor = '#888';
          if (s.status === 'syncing') {
            statusText = chrome.i18n.getMessage('syncSyncing') || 'Syncing...';
            statusColor = '#3b82f6';
          } else if (s.status === 'error') {
            statusText = chrome.i18n.getMessage('syncError') || 'Error';
            statusColor = '#ef4444';
          } else if (s.pendingCount > 0) {
            statusText = (chrome.i18n.getMessage('syncPending', ['$1']) || '$1 pending').replace('$1', s.pendingCount);
            statusColor = '#f59e0b';
          } else {
            statusText = chrome.i18n.getMessage('syncIdle') || 'Synced';
            statusColor = '#22c55e';
          }
          // P1-14/P1-33：耗尽未读提示——SW 广播时写入 storage 标志（popup 拉模式），
          // 用户在 manager 打开失败查看器后清除
          chrome.storage.local.get(['wpzl_exhausted_notify'], function (r) {
            if (r && r.wpzl_exhausted_notify) {
              syncStatusBadge.textContent = chrome.i18n.getMessage('syncExhaustedBadge') || 'Retries exhausted';
              syncStatusBadge.style.color = '#ef4444';
              syncStatusBadge.title = chrome.i18n.getMessage('syncExhaustedNotice') || 'Some items stopped retrying — check sync failures';
            } else {
              syncStatusBadge.textContent = statusText;
              syncStatusBadge.style.color = statusColor;
              syncStatusBadge.title = '';
            }
          });
          return;
        }
      }
    } catch (e) { /* sync not available */ }
    // 非同步用户/异常路径也清一次 title，避免残留
    try { syncStatusBadge.title = ''; } catch (e) { /* ignore */ }
  }

  updateSyncUI();

  // --- 标注开关 ---
  var toggleCheckbox = document.getElementById('annotationToggle');
  var storageKey = 'wpzl_annotationEnabled';

  // 读取当前状态（默认 true）
  chrome.storage.local.get([storageKey], function(result) {
    var enabled = result[storageKey];
    if (enabled === undefined) enabled = true;
    toggleCheckbox.checked = enabled;
  });

  // 切换时保存并通知 content script
  toggleCheckbox.addEventListener('change', function() {
    var enabled = toggleCheckbox.checked;
    chrome.storage.local.set({ wpzl_annotationEnabled: enabled });

    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: 'wpzl-annotation-toggle',
          enabled: enabled
        }).catch(function() {
          // content script 可能未加载（chrome:// 页面等）
        });
      }
    });
  });

  // --- 打开标注管理页面（已打开则直接切换到该 tab，不重复开新标签） ---
  // 复用/聚焦逻辑统一在 SW（登记制，免 "tabs" 权限——无权限时 tabs.query 按 url
  // 匹配自己的扩展页也会落空，本地判断必失效；详见 SW _wpzlGetRegisteredTab 注释）。
  document.getElementById('openManager').addEventListener('click', function() {
    chrome.runtime.sendMessage({ type: 'wpzl-open-manager' }).catch(function() { /* SW 不可用时静默 */ });
    window.close();
  });

  // --- 购买 Pro（A 项：付款入口必须好找）：统一打开升级弹窗（弹窗内自带未登录引导） ---
  var upgradeBtn = document.getElementById('upgradeBtn');
  if (upgradeBtn) {
    upgradeBtn.addEventListener('click', function () {
      chrome.runtime.sendMessage({ type: 'wpzl-open-upgrade' });
      window.close();
    });
  }

  // --- 设置按钮：打开独立设置页面 ---
  document.getElementById('settingsBtn').addEventListener('click', function() {
    chrome.tabs.create({ url: chrome.runtime.getURL('settings/settings.html') });
  });

  // --- 反馈与建议（SSO 自动登录到问题反馈系统；SW 负责写会话 cookie + 开连接器登录入口）---
  document.getElementById('feedbackLink').addEventListener('click', function() {
    chrome.runtime.sendMessage({ type: 'openFeedback' }).catch(function() {});
    window.close();
  });

  // --- 帮助文档（URL 由 SW 统一持有，发布时 apply-env 按 WEBPZ_DOCS_BASE 注入；与 manager 功能菜单一致）---
  document.getElementById('helpLink').addEventListener('click', function() {
    chrome.runtime.sendMessage({ type: 'wpzl-open-docs' }).catch(function() {});
    window.close();
  });
});
