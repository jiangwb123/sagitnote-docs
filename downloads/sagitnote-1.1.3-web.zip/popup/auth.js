// ============================================================
// Sagitnote - Auth Popup Script
// ============================================================

document.addEventListener('DOMContentLoaded', function () {
  // i18n: apply localized text to all [data-i18n] elements
  document.querySelectorAll('[data-i18n]').forEach(function (el) {
    var key = el.getAttribute('data-i18n');
    var msg = chrome.i18n.getMessage(key);
    if (msg) el.textContent = msg;
  });
  document.documentElement.lang = chrome.i18n.getUILanguage();

  var loginTab = document.querySelector('[data-tab="login"]');
  var registerTab = document.querySelector('[data-tab="register"]');
  var form = document.getElementById('authForm');
  var extraFields = document.getElementById('authExtraFields');
  var submitBtn = document.getElementById('authSubmitBtn');
  var errorDiv = document.getElementById('authError');
  var loginIdInput = document.getElementById('authLoginId');
  var loginIdLabel = document.getElementById('authLoginIdLabel');
  var passwordInput = document.getElementById('authPassword');
  var emailInput = document.getElementById('authEmail');
  var nameInput = document.getElementById('authName');
  var nameField = document.getElementById('authNameField');
  var verifyCodeInput = document.getElementById('authVerifyCode');
  var sendCodeBtn = document.getElementById('authSendCodeBtn');
  var marketingOptInInput = document.getElementById('authMarketingOptIn');

  // 找回密码相关元素
  var forgotLink = document.getElementById('authForgotLink');
  var switchHint = document.getElementById('authSwitchHint');
  var forgotView = document.getElementById('authForgotView');
  var forgotEmailInput = document.getElementById('authForgotEmail');
  var forgotCodeInput = document.getElementById('authForgotCode');
  var forgotSendBtn = document.getElementById('authForgotSendBtn');
  var forgotNewPwdInput = document.getElementById('authNewPassword');
  var forgotErrorEl = document.getElementById('authForgotError');
  var forgotSubmitBtn = document.getElementById('authForgotSubmitBtn');
  var backToLoginLink = document.getElementById('authBackToLogin');

  var oauthGoogleBtn = document.getElementById('oauthGoogleBtn');
  var oauthGithubBtn = document.getElementById('oauthGithubBtn');

  var currentMode = 'login';
  var _navigating = false;   // R2：认领成功提示的 1.5s 延迟跳转防重入（双击/重复 submit）

  // 密码最低强度：8-100 位且同时包含字母和数字（与服务端 PasswordPolicy 同规则）
  var PWD_POLICY_RE = /^(?=.*[A-Za-z])(?=.*\d).{8,100}$/;
  // 轻量邮箱格式校验（发码/提交前拦下明显写错的地址）
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // ── 错误/成功提示（可指定目标元素，默认主 error 区） ─────────────
  // 成功态用 auth-error--success 类（auth.css），颜色走主题 token，
  // 深色主题下不再出现浅色硬编码底色刺眼的问题
  function setError(el, msg, kind) {
    el = el || errorDiv;
    el.textContent = msg;
    el.style.display = 'block';
    el.classList.toggle('auth-error--success', kind === 'success');
  }
  function showError(msg, el) { setError(el || errorDiv, msg, 'error'); }
  function showSuccess(msg, el) { setError(el || errorDiv, msg, 'success'); }
  function hideError(el) { el = el || errorDiv; el.textContent = ''; el.style.display = 'none'; }

  // ── 验证码发送倒计时工厂（注册/找回各一份） ───────────────────
  // 按钮置灰、文案显示剩余秒数；归零后恢复
  function makeCountdown(button) {
    var timer = null;
    var remaining = 0;
    function stop() {
      if (timer) { clearInterval(timer); timer = null; }
      remaining = 0;
      if (button) {
        button.disabled = false;
        button.textContent = chrome.i18n.getMessage('authSendCode') || 'Send Code';
      }
    }
    function start(seconds) {
      stop();
      remaining = Math.max(1, seconds | 0);
      if (button) {
        button.disabled = true;
        button.textContent = chrome.i18n.getMessage('authCodeResend', [String(remaining)])
          || ('Resend (' + remaining + 's)');
      }
      timer = setInterval(function () {
        remaining -= 1;
        if (remaining <= 0) {
          stop();
        } else if (button) {
          button.textContent = chrome.i18n.getMessage('authCodeResend', [String(remaining)])
            || ('Resend (' + remaining + 's)');
        }
      }, 1000);
    }
    return { start: start, stop: stop };
  }

  var regCountdown = makeCountdown(sendCodeBtn);
  var forgotCountdown = makeCountdown(forgotSendBtn);

  // ── 滑块拼图验证码工厂（注册/找回各一份实例） ─────────────────
  // 服务端 SliderCaptchaGenerator 出图 280×140、抠块 60，与 auth.css 硬约定；
  // 拖动距离（把手左缘 x）= 缺口左缘 x = 服务端 answerX，1:1 无缩放（finishDrag 内留比例换算兜底）。
  // 流程：点「Send Code」→ show() 经 SW 拉图 → 用户拖动对齐缺口 → 松手回调 onAnswer(captchaId, answer)
  // 真正发码；成功 hide()，失败 refresh() 换新图（挑战已被服务端一次性消费）。
  function createSliderCaptcha(prefix, onAnswer) {
    var root = document.getElementById(prefix + 'Panel');
    var bgImg = document.getElementById(prefix + 'Bg');
    var blockImg = document.getElementById(prefix + 'Block');
    var statusEl = document.getElementById(prefix + 'Status');
    var bar = document.getElementById(prefix + 'Bar');
    var fill = document.getElementById(prefix + 'Fill');
    var handle = document.getElementById(prefix + 'Handle');
    var refreshBtn = document.getElementById(prefix + 'Refresh');
    var tipEl = document.getElementById(prefix + 'Tip');   // 滑条内提示文字，拖动即隐

    var challenge = null;      // 当前挑战 { captchaId, serverWidth }
    var loading = false;
    var dragging = false;
    var dragStartX = 0;
    var dragStartLeft = 0;
    var maxTravel = 220;       // width - blockSize，拉图后按服务端数据刷新

    function msg(key, fallback) { return chrome.i18n.getMessage(key) || fallback; }

    function setVisual(left) {
      left = Math.max(0, Math.min(maxTravel, left));
      handle.style.left = left + 'px';
      blockImg.style.left = left + 'px';
      fill.style.width = Math.min(left + handle.offsetWidth, bar.clientWidth) + 'px';
      if (tipEl) tipEl.style.opacity = left > 4 ? '0' : '1';
      return left;
    }

    function resetVisual() { setVisual(0); }

    function load() {
      if (loading) return;
      loading = true;
      challenge = null;
      statusEl.textContent = msg('authCaptchaLoading', 'Loading…');
      statusEl.style.display = 'flex';
      chrome.runtime.sendMessage({ type: 'auth-captcha-fetch' }).then(function (resp) {
        if (!(resp && resp.success && resp.data)) {
          throw new Error((resp && resp.error) || 'load failed');
        }
        var d = resp.data;
        challenge = { captchaId: d.captchaId, serverWidth: d.width || 280 };
        maxTravel = (d.width || 280) - (d.blockSize || 60);
        bgImg.src = d.backgroundImage;
        blockImg.src = d.blockImage;
        blockImg.style.top = (d.blockY || 0) + 'px';
        resetVisual();
        statusEl.style.display = 'none';
      }).catch(function () {
        challenge = null;
        statusEl.textContent = msg('authCaptchaLoadFailed', 'Failed to load captcha. Tap to retry.');
        statusEl.style.display = 'flex';
      }).finally(function () {
        loading = false;
      });
    }

    function show() {
      if (!root) return;
      root.style.display = 'block';
      resetVisual();
      if (!challenge) load();
    }

    function hide() {
      if (!root) return;
      root.style.display = 'none';
      challenge = null;
      resetVisual();
    }

    function refresh() {
      challenge = null;
      load();
    }

    function isVisible() { return !!(root && root.style.display !== 'none'); }

    if (refreshBtn) {
      refreshBtn.title = msg('authCaptchaRefresh', 'Get a new puzzle');
      refreshBtn.setAttribute('aria-label', refreshBtn.title);
      refreshBtn.addEventListener('click', function () { refresh(); });
    }
    // 加载失败时点图区重试
    if (statusEl) {
      statusEl.addEventListener('click', function () {
        if (!challenge && !loading) load();
      });
    }

    if (handle) {
      // Pointer Events 统一鼠标/触屏；setPointerCapture 保证拖出把手后仍收得到 move/up
      handle.addEventListener('pointerdown', function (e) {
        if (!challenge || loading || dragging) return;
        dragging = true;
        dragStartX = e.clientX;
        dragStartLeft = parseInt(handle.style.left, 10) || 0;
        try { handle.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        e.preventDefault();
      });
      handle.addEventListener('pointermove', function (e) {
        if (!dragging) return;
        setVisual(dragStartLeft + (e.clientX - dragStartX));
      });
      handle.addEventListener('pointerup', function () {
        if (!dragging) return;
        dragging = false;
        if (!challenge) return;
        var left = Math.round(parseFloat(handle.style.left) || 0);
        // 防御式比例换算：前端未来若缩放图区，仍按服务端坐标系提交（当前 1:1 恒等）
        var serverWidth = challenge.serverWidth || 280;
        var clientWidth = bgImg.clientWidth || serverWidth;
        var answer = Math.round(left * serverWidth / clientWidth);
        var captchaId = challenge.captchaId;
        challenge = null;   // 本地同步作废（服务端一次性消费，无论对错）
        if (typeof onAnswer === 'function') onAnswer(captchaId, answer);
      });
      handle.addEventListener('pointercancel', function () {
        if (dragging) { dragging = false; resetVisual(); }
      });
    }

    return { show: show, hide: hide, refresh: refresh, isVisible: isVisible };
  }

  // 注册视图实例：拖动松手 → 带 captchaId/answer 发码（成功收面板进倒计时；失败换新图可重试）
  var regCaptcha = createSliderCaptcha('authCaptcha', function (captchaId, answer) {
    sendCodeBtn.disabled = true;
    sendCodeBtn.textContent = chrome.i18n.getMessage('authProcessing') || 'Processing...';
    chrome.runtime.sendMessage({ type: 'auth-send-code', email: emailInput.value.trim(), captchaId: captchaId, captchaAnswer: answer })
      .then(function (result) {
        if (result && result.success) {
          regCaptcha.hide();
          var cooldown = (result && typeof result.cooldownSeconds === 'number') ? result.cooldownSeconds : 60;
          regCountdown.start(cooldown);
          showSuccess(chrome.i18n.getMessage('authCodeSent') || 'Verification code sent. Please check your email.');
        } else {
          regCountdown.stop();
          showError((result && result.error) ? result.error : (chrome.i18n.getMessage('authSendFailed') || 'Failed to send code.'));
          regCaptcha.refresh();
          sendCodeBtn.disabled = false;
          sendCodeBtn.textContent = chrome.i18n.getMessage('authSendCode') || 'Send Code';
        }
      })
      .catch(function (err) {
        regCountdown.stop();
        showError((err && err.message) || (chrome.i18n.getMessage('authSendFailed') || 'Failed to send code.'));
        regCaptcha.refresh();
        sendCodeBtn.disabled = false;
        sendCodeBtn.textContent = chrome.i18n.getMessage('authSendCode') || 'Send Code';
      });
  });

  // 找回密码视图实例（同构独立）
  var forgotCaptcha = createSliderCaptcha('authForgotCaptcha', function (captchaId, answer) {
    forgotSendBtn.disabled = true;
    forgotSendBtn.textContent = chrome.i18n.getMessage('authProcessing') || 'Processing...';
    chrome.runtime.sendMessage({ type: 'auth-forgot-password', email: forgotEmailInput.value.trim(), captchaId: captchaId, captchaAnswer: answer })
      .then(function (result) {
        if (result && result.success) {
          forgotCaptcha.hide();
          var cooldown = (result && typeof result.cooldownSeconds === 'number') ? result.cooldownSeconds : 60;
          forgotCountdown.start(cooldown);
          showSuccess(chrome.i18n.getMessage('authForgotSent') || 'If the email is registered, a code has been sent.', forgotErrorEl);
        } else {
          forgotCountdown.stop();
          showError((result && result.error) ? result.error : (chrome.i18n.getMessage('authSendFailed') || 'Failed to send code.'), forgotErrorEl);
          forgotCaptcha.refresh();
          forgotSendBtn.disabled = false;
          forgotSendBtn.textContent = chrome.i18n.getMessage('authSendCode') || 'Send Code';
        }
      })
      .catch(function (err) {
        forgotCountdown.stop();
        showError((err && err.message) || (chrome.i18n.getMessage('authSendFailed') || 'Failed to send code.'), forgotErrorEl);
        forgotCaptcha.refresh();
        forgotSendBtn.disabled = false;
        forgotSendBtn.textContent = chrome.i18n.getMessage('authSendCode') || 'Send Code';
      });
  });

  // 登录/注册成功后直接跳转到页面管理页面（manager.html）。
  // 用 location.replace 而非 href：不在历史栈留下 auth.html，避免用户后退回到登录页。
  function navigateToManager() {
    window.location.replace(chrome.runtime.getURL('manager/manager.html'));
  }

  // 切换账号被拦截时的通知框（仅「关闭」按钮）
  function showAccountSwitchBlockedNote(currentLoginId, newLoginId) {
    var existing = document.getElementById('wpzlAcctSwitchNote');
    if (existing) existing.remove();
    var overlay = document.createElement('div');
    overlay.id = 'wpzlAcctSwitchNote';
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.45);display:flex;align-items:center;justify-content:center;z-index:9999;';
    var cur = currentLoginId ? ('「' + currentLoginId + '」') : chrome.i18n.getMessage('acctSwitchOtherUser');
    var neu = newLoginId ? ('「' + newLoginId + '」') : chrome.i18n.getMessage('acctSwitchCurrentAccount');
    var bodyMsg = chrome.i18n.getMessage('acctSwitchBlockedBody', [cur, neu]);
    overlay.innerHTML =
      '<div style="background:#fff;border-radius:16px;padding:28px 24px;max-width:380px;width:90%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.25);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;">' +
        '<div style="font-size:18px;font-weight:700;color:#1e293b;margin-bottom:12px;">' + chrome.i18n.getMessage('acctSwitchBlockedTitle') + '</div>' +
        '<div style="font-size:13px;color:#475569;line-height:1.7;margin-bottom:20px;">' + bodyMsg + '</div>' +
        '<button id="wpzlAcctSwitchClose" style="width:100%;padding:10px 16px;background:#ff3c82;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;">' + chrome.i18n.getMessage('close') + '</button>' +
      '</div>';
    document.body.appendChild(overlay);
    var closeBtn = document.getElementById('wpzlAcctSwitchClose');
    if (closeBtn) closeBtn.addEventListener('click', function () { overlay.remove(); });
  }

  // ── 「去备份 / 导出」类链接共用（提醒条链接 + 清空确认框内链接，2026-10-04） ──
  // 深链直达 manager「导出全部」弹框——走 wpzl-open-manager 复用/聚焦已开 manager tab
  // （登记制，免 "tabs" 权限，见 SW _wpzlGetRegisteredTab；hash 由 manager 的
  // hashchange 监听/首载链接住），SW 不可达时退回普通新开（行为不劣于深链改造前）。
  // 位置在 IIFE 顶层：DOMContentLoaded 内的提醒条 handler 与 showLocalClearConfirm 都要用。
  function _openManagerExportAll() {
    try {
      chrome.runtime.sendMessage({ type: 'wpzl-open-manager', hash: '#export-all' })
        .catch(function () {
          chrome.tabs.create({ url: chrome.runtime.getURL('manager/manager.html#export-all') });
        });
    } catch (e) {
      chrome.tabs.create({ url: chrome.runtime.getURL('manager/manager.html#export-all') });
    }
  }

  // ── 本地数据预检（2026-11 R2 单一决策源）──────────────────────
  // SW 端 wpzl-has-local-data 已给出 preAction（判定顺序：先 owner 后 foreignData），这里只把它
  // 翻译成渲染动作，不自行拼判定表（与 _finalizeAuth 是同一决策源，避免两处规则漂移）：
  //   'none'    无数据 / 同号重登 → 直接提交
  //   'claim'   全部游客自有 → 直接提交自动认领，不设 forceClearLocal
  //   'confirm' 弹清空确认框；foreign=true 选 foreign 变体文案（loginClear*Foreign）
  //   'unknown' SW 不可达 → 照常提交，SW blocked 兜底（收到 blocked 后重跑本预检补弹框）
  // 表单提交与 OAuth 两处共用。
  async function _preflightLocalData(mode, loginId) {
    try {
      var pre = await chrome.runtime.sendMessage({ type: 'wpzl-has-local-data' });
      if (!(pre && pre.success && pre.data && pre.data.hasData)) return { action: 'none' };
      var d = pre.data;
      var ownerLoginId = (d.owner && d.owner.loginId) || '';
      // 同号重登豁免（现状保留）：登录模式 + owner.loginId 与输入一致
      if (mode === 'login' && ownerLoginId && ownerLoginId === loginId) return { action: 'none' };
      if (d.preAction === 'askForeign' || d.foreignData) return { action: 'confirm', foreign: true, ownerLoginId: ownerLoginId };
      if (d.preAction === 'askSwitch' || d.owner) return { action: 'confirm', foreign: false, ownerLoginId: ownerLoginId };
      if (d.preAction === 'claim') return { action: 'claim', total: d.total || 0 };
      return { action: 'none' };
    } catch (e) {
      return { action: 'unknown' };
    }
  }

  // ── 登录前清空确认框（本地模式/游客档，2026-09-29；2026-11 加 foreign 变体） ──────────────
  // 返回 Promise<boolean>：true=用户已勾选「我已备份数据」+ 输入匹配确认文字并点确定；
  // false=取消/遮罩点击（数据不动）。未勾选时输入框与确定按钮均禁用；IME 组合期回车不触发。
  // foreign=true（2026-11）：检测到外来属主数据——标题/正文换 loginClear*Foreign 变体，
  // $1 固定用 loginClearOwnerForeign（不展示他人 loginId），如实告知「连你自己未登录时
  // 创建的标注也会一并清空」。
  function showLocalClearConfirm(ownerLabel, targetLabel, foreign) {
    return new Promise(function (resolve) {
      var existing = document.getElementById('wpzlLocalClearConfirm');
      if (existing) existing.remove();
      var phrase = chrome.i18n.getMessage('dangerPhraseClearLocal') || '确认清空';
      // 文案 loginClearBody 自带「」包裹，这里只传裸 loginId；游客数据用 loginClearOwnerGuest，
      // OAuth 目标未知时用 acctSwitchOtherUser（对端账号待定）；外来数据固定用 loginClearOwnerForeign
      var cur = foreign
        ? chrome.i18n.getMessage('loginClearOwnerForeign')
        : (ownerLabel || chrome.i18n.getMessage('loginClearOwnerGuest'));
      var neu = targetLabel || chrome.i18n.getMessage('acctSwitchOtherUser');
      var titleMsg = chrome.i18n.getMessage(foreign ? 'loginClearTitleForeign' : 'loginClearTitle')
        || chrome.i18n.getMessage('loginClearTitle') || '';
      var bodyMsg = chrome.i18n.getMessage(foreign ? 'loginClearBodyForeign' : 'loginClearBody', [cur, neu])
        || chrome.i18n.getMessage('loginClearBody', [cur, neu]) || '';
      var backupHint = chrome.i18n.getMessage('dangerBackupHint') || '';
      var backupLinkText = chrome.i18n.getMessage('dangerBackupLink') || '';
      var checkLabel = chrome.i18n.getMessage('loginClearBackupCheck') || '';
      var inputLabel = chrome.i18n.getMessage('dangerInputLabel', [phrase]) || ('输入「' + phrase + '」以确认');
      var cancelText = chrome.i18n.getMessage('cancel') || '取消';
      var confirmText = chrome.i18n.getMessage('dangerConfirmBtn') || '确认执行';
      var overlay = document.createElement('div');
      overlay.id = 'wpzlLocalClearConfirm';
      overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.45);display:flex;align-items:center;justify-content:center;z-index:9999;';
      overlay.innerHTML =
        '<div style="background:#fff;border-radius:16px;padding:24px;max-width:400px;width:90%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.25);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;">' +
          '<div style="font-size:17px;font-weight:700;color:#1e293b;margin-bottom:10px;">' + titleMsg + '</div>' +
          '<div style="font-size:13px;color:#475569;line-height:1.7;margin-bottom:8px;text-align:left;">' + bodyMsg + '</div>' +
          '<div style="font-size:12px;color:#b45309;margin-bottom:14px;text-align:left;">' + backupHint +
            ' <a href="#" id="wpzlLocalClearBackup" style="color:#b45309;font-weight:600;">' + backupLinkText + '</a></div>' +
          '<label style="display:flex;align-items:flex-start;gap:8px;font-size:13px;color:#334155;text-align:left;margin-bottom:14px;cursor:pointer;">' +
            '<input type="checkbox" id="wpzlLocalClearCheck" style="margin-top:2px;">' +
            '<span>' + checkLabel + '</span></label>' +
          '<label style="display:block;font-size:12px;color:#64748b;text-align:left;margin-bottom:6px;">' + inputLabel + '</label>' +
          '<input type="text" id="wpzlLocalClearInput" autocomplete="off" spellcheck="false" disabled ' +
            'style="width:100%;box-sizing:border-box;padding:9px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;outline:none;margin-bottom:16px;">' +
          '<button id="wpzlLocalClearCancel" style="width:100%;padding:10px;border:none;background:transparent;color:#94a3b8;font-size:13px;cursor:pointer;margin-bottom:6px;">' + cancelText + '</button>' +
          '<button id="wpzlLocalClearConfirmBtn" disabled ' +
            'style="width:100%;padding:10px 16px;background:#ff3c82;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;">' + confirmText + '</button>' +
        '</div>';
      document.body.appendChild(overlay);

      var checkEl = document.getElementById('wpzlLocalClearBackup');
      if (checkEl) {
        checkEl.addEventListener('click', function (e) {
          e.preventDefault();
          _openManagerExportAll();
        });
      }
      var checkbox = document.getElementById('wpzlLocalClearCheck');
      var input = document.getElementById('wpzlLocalClearInput');
      var confirmBtn = document.getElementById('wpzlLocalClearConfirmBtn');
      var cancelBtn = document.getElementById('wpzlLocalClearCancel');

      function close(val) {
        overlay.remove();
        resolve(val);
      }
      function refresh() {
        // 未勾选：输入框 + 确定均禁用；勾选后输入可用，文字匹配才可确定
        var checked = !!(checkbox && checkbox.checked);
        if (input) input.disabled = !checked;
        var matched = checked && input && (input.value || '').trim().toLowerCase() === phrase.trim().toLowerCase();
        if (confirmBtn) confirmBtn.disabled = !matched;
      }
      if (checkbox) checkbox.addEventListener('change', refresh);
      if (input) {
        input.addEventListener('input', refresh);
        input.addEventListener('keydown', function (e) {
          if (e.key !== 'Enter') return;
          // IME 守卫（仿 settings 危险模态）：组合期回车是选字，不触发提交
          if (e.isComposing || e.keyCode === 229) return;
          e.preventDefault();
          if (!confirmBtn.disabled) close(true);
        });
      }
      if (confirmBtn) confirmBtn.addEventListener('click', function () { close(true); });
      if (cancelBtn) cancelBtn.addEventListener('click', function () { close(false); });
      overlay.addEventListener('click', function (e) {
        if (e.target === overlay) close(false);
      });
      document.addEventListener('keydown', function esc(e) {
        if (e.key === 'Escape' && document.getElementById('wpzlLocalClearConfirm')) {
          document.removeEventListener('keydown', esc);
          close(false);
        }
      });
      if (checkbox) checkbox.focus();
    });
  }

  // ── 注册：发送验证码 ──────────────────────────────────────────
  // 前置校验（2026-11-11 需求）：用户名（登录名）、显示名称、密码全部填写后才允许发码
  // ——避免用户先拿验证码再补资料，期间用户名/邮箱被他人注册导致验证码作废。
  // 密码强度也在发码前拦下（与提交注册同一规则），弱密码不必浪费一次发码。
  // 之后先展开滑块验证码面板，拖动对齐缺口后经 regCaptcha 的 onAnswer 回调真正发码。
  function handleSendCode() {
    hideError();
    var loginId = loginIdInput.value.trim();
    var name = nameInput.value.trim();
    var pwd = passwordInput.value;
    if (!loginId || !name || !pwd) {
      showError(chrome.i18n.getMessage('authSendCodePrereq') || 'Please fill in username, display name and password before sending the code.');
      if (!loginId) loginIdInput.focus();
      else if (!name) nameInput.focus();
      else passwordInput.focus();
      return;
    }
    if (!PWD_POLICY_RE.test(pwd)) {
      showError(chrome.i18n.getMessage('authPwdWeak') || 'Password must be at least 8 characters and contain both letters and numbers.');
      passwordInput.focus();
      return;
    }
    var email = emailInput.value.trim();
    if (!email) {
      showError(chrome.i18n.getMessage('authEmailRequired') || 'Please enter your email first.');
      emailInput.focus();
      return;
    }
    if (!EMAIL_RE.test(email)) {
      showError(chrome.i18n.getMessage('authEmailInvalid') || 'Please enter a valid email address.');
      emailInput.focus();
      return;
    }
    if (regCaptcha.isVisible()) return;   // 已展开等待拖动；换图用面板上的刷新按钮
    regCaptcha.show();
  }
  if (sendCodeBtn) {
    sendCodeBtn.addEventListener('click', handleSendCode);
  }

  // ── 找回密码视图显隐 ──────────────────────────────────────────
  function showForgotView() {
    regCountdown.stop();
    hideError();
    form.style.display = 'none';
    var tabs = document.querySelector('.auth-tabs'); if (tabs) tabs.style.display = 'none';
    var divider = document.querySelector('.auth-divider'); if (divider) divider.style.display = 'none';
    var footer = document.querySelector('.auth-footer'); if (footer) footer.style.display = 'none';
    // 第三方登录按钮一并隐藏（此前只藏了 divider/footer，找回视图下方仍挂着两个 OAuth 按钮）
    if (oauthGoogleBtn) oauthGoogleBtn.style.display = 'none';
    if (oauthGithubBtn) oauthGithubBtn.style.display = 'none';
    if (forgotView) forgotView.style.display = 'flex';
    if (forgotErrorEl) hideError(forgotErrorEl);
    if (forgotEmailInput) forgotEmailInput.focus();
  }

  function hideForgotView() {
    forgotCountdown.stop();
    forgotCaptcha.hide();
    if (forgotView) forgotView.style.display = 'none';
    form.style.display = '';            // 恢复 CSS 默认（flex）
    var tabs = document.querySelector('.auth-tabs'); if (tabs) tabs.style.display = '';
    var divider = document.querySelector('.auth-divider'); if (divider) divider.style.display = '';
    if (oauthGoogleBtn) oauthGoogleBtn.style.display = '';
    if (oauthGithubBtn) oauthGithubBtn.style.display = '';
    var footer = document.querySelector('.auth-footer'); if (footer) footer.style.display = '';
    // 清空找回密码表单
    if (forgotEmailInput) forgotEmailInput.value = '';
    if (forgotCodeInput) forgotCodeInput.value = '';
    if (forgotNewPwdInput) forgotNewPwdInput.value = '';
    setMode('login');
  }

  // ── 找回密码：发送验证码 ──────────────────────────────────────
  // 先展开滑块验证码面板，拖动对齐后经 forgotCaptcha 的 onAnswer 回调真正发码
  function handleForgotSendCode() {
    if (forgotErrorEl) hideError(forgotErrorEl);
    var email = forgotEmailInput.value.trim();
    if (!email) {
      showError(chrome.i18n.getMessage('authEmailRequired') || 'Please enter your email.', forgotErrorEl);
      forgotEmailInput.focus();
      return;
    }
    if (!EMAIL_RE.test(email)) {
      showError(chrome.i18n.getMessage('authEmailInvalid') || 'Please enter a valid email address.', forgotErrorEl);
      forgotEmailInput.focus();
      return;
    }
    if (forgotCaptcha.isVisible()) return;   // 已展开等待拖动；换图用面板上的刷新按钮
    forgotCaptcha.show();
  }

  // ── 找回密码：提交重置 ────────────────────────────────────────
  function handleForgotReset() {
    if (forgotErrorEl) hideError(forgotErrorEl);
    var email = forgotEmailInput.value.trim();
    var code = forgotCodeInput.value.trim();
    var np = forgotNewPwdInput.value;
    if (!email) {
      showError(chrome.i18n.getMessage('authEmailRequired') || 'Please enter your email.', forgotErrorEl);
      return;
    }
    if (!code || !/^\d{6}$/.test(code)) {
      showError(chrome.i18n.getMessage('authVerifyCodeRequired') || 'Please enter the 6-digit code.', forgotErrorEl);
      return;
    }
    if (!np || !PWD_POLICY_RE.test(np)) {
      showError(chrome.i18n.getMessage('authPwdWeak') || 'Password must be at least 8 characters and contain both letters and numbers.', forgotErrorEl);
      return;
    }
    forgotSubmitBtn.disabled = true;
    forgotSubmitBtn.textContent = chrome.i18n.getMessage('authProcessing') || 'Processing...';
    chrome.runtime.sendMessage({ type: 'auth-reset-password', email: email, code: code, newPassword: np }).then(function (result) {
      if (result && result.success) {
        showSuccess(chrome.i18n.getMessage('authResetDone') || 'Password reset. Please log in with your new password.', forgotErrorEl);
        setTimeout(function () { hideForgotView(); }, 1600);
      } else {
        showError((result && result.error) ? result.error : (chrome.i18n.getMessage('authFailed') || 'Reset failed.'), forgotErrorEl);
        forgotSubmitBtn.disabled = false;
        forgotSubmitBtn.textContent = chrome.i18n.getMessage('authResetBtn') || 'Reset Password';
      }
    }).catch(function (err) {
      showError((err && err.message) || 'Reset failed.', forgotErrorEl);
      forgotSubmitBtn.disabled = false;
      forgotSubmitBtn.textContent = chrome.i18n.getMessage('authResetBtn') || 'Reset Password';
    });
  }

  if (forgotLink) forgotLink.addEventListener('click', function (e) { e.preventDefault(); showForgotView(); });
  if (backToLoginLink) backToLoginLink.addEventListener('click', function (e) { e.preventDefault(); hideForgotView(); });
  if (forgotSendBtn) forgotSendBtn.addEventListener('click', handleForgotSendCode);
  if (forgotSubmitBtn) forgotSubmitBtn.addEventListener('click', handleForgotReset);

  // ── 登录/注册 模式切换 ────────────────────────────────────────
  function setMode(mode) {
    currentMode = mode;
    loginTab.classList.toggle('active', mode === 'login');
    registerTab.classList.toggle('active', mode === 'register');
    // 注册态：form 切两列网格、卡片加宽；extraFields 置空串让 CSS 的
    // display:contents 生效（子字段直接参与网格），登录态仍 display:none
    form.classList.toggle('auth-form--register', mode === 'register');
    var authCard = document.querySelector('.auth-container');
    if (authCard) authCard.classList.toggle('auth-container--wide', mode === 'register');
    extraFields.style.display = mode === 'register' ? '' : 'none';
    // 显示名称字段仅注册模式显示（2026-11-11：移至用户名（登录名）之后紧邻，两列布局中在其右侧）
    if (nameField) nameField.style.display = mode === 'register' ? '' : 'none';
    // 用户名 label 语义切换：注册强调「用户名（登录名）」，登录保持「用户名或邮箱」
    if (loginIdLabel) {
      var _labelMsg = chrome.i18n.getMessage(mode === 'register' ? 'authUsernameLabel' : 'authLoginId');
      if (_labelMsg) loginIdLabel.textContent = _labelMsg;
    }
    // 密码管理器语义：注册是设置新密码、登录是当前密码
    passwordInput.setAttribute('autocomplete', mode === 'register' ? 'new-password' : 'current-password');
    submitBtn.textContent = chrome.i18n.getMessage(mode === 'login' ? 'authLoginBtn' : 'authRegisterBtn') || (mode === 'login' ? 'Sign In' : 'Create Account');
    // 「忘记密码」链接仅在登录模式显示
    if (forgotLink) forgotLink.style.display = (mode === 'login') ? 'block' : 'none';
    // D 项：模式切换提示——登录态引导注册、注册态引导返回登录
    if (switchHint) switchHint.textContent = chrome.i18n.getMessage(mode === 'login' ? 'authNoAccount' : 'authHaveAccount') || switchHint.textContent;
    hideError();
    // 切换 tab 时清掉验证码倒计时、滑块面板与已填验证码
    regCountdown.stop();
    regCaptcha.hide();
    if (verifyCodeInput) verifyCodeInput.value = '';
  }

  loginTab.addEventListener('click', function () { setMode('login'); });
  registerTab.addEventListener('click', function () { setMode('register'); });
  // D 项：底部切换提示点击 = 跳到另一模式（登录→注册 / 注册→登录）
  if (switchHint) {
    switchHint.addEventListener('click', function (e) {
      e.preventDefault();
      setMode(currentMode === 'login' ? 'register' : 'login');
    });
  }

  // ── 密码可见性切换（登录密码 / 找回密码新密码两处共用 .auth-pwd-toggle） ──
  document.querySelectorAll('.auth-pwd-toggle').forEach(function (btn) {
    var _showMsg = chrome.i18n.getMessage('authPwdShow');
    if (_showMsg) btn.setAttribute('aria-label', _showMsg);
    btn.addEventListener('click', function () {
      var target = document.getElementById(btn.getAttribute('data-target'));
      if (!target) return;
      var show = target.type === 'password';
      target.type = show ? 'text' : 'password';
      var eyeOn = btn.querySelector('.auth-eye-on');
      var eyeOff = btn.querySelector('.auth-eye-off');
      if (eyeOn) eyeOn.style.display = show ? 'none' : '';
      if (eyeOff) eyeOff.style.display = show ? '' : 'none';
      var msg = chrome.i18n.getMessage(show ? 'authPwdHide' : 'authPwdShow');
      if (msg) btn.setAttribute('aria-label', msg);
    });
  });

  // 第三方登录（OAuth）
  if (oauthGoogleBtn) {
    oauthGoogleBtn.addEventListener('click', function () { doOAuth('google'); });
  }
  if (oauthGithubBtn) {
    oauthGithubBtn.addEventListener('click', function () { doOAuth('github'); });
  }

  async function doOAuth(provider) {
    // 错误路由：找回视图下 #authError 位于被隐藏的 authForm 内，写了也不可见，
    // 故改为写入找回视图自己的错误框；每次取值（而非发起时快照），避免用户中途
    // 切回登录视图时错误落进已隐藏的元素。
    function oauthErrTarget() {
      return (forgotView && forgotView.style.display !== 'none') ? forgotErrorEl : undefined;
    }
    hideError(oauthErrTarget());
    // 按发起方禁用对应按钮，防止双击重复发起授权
    var btn = (provider === 'github') ? oauthGithubBtn : oauthGoogleBtn;
    if (btn) { btn.disabled = true; }
    // 本地模式授权前预检（2026-11 R2 单一决策源）：目标账号授权前未知（loginId 传空，同号豁免
    // 不适用）——全部游客自有（claim）→ 不弹框直接发起授权，数据授权后自动认领；含外来属主
    // （askForeign）→ foreign 变体确认框；owner 存在（askSwitch）→ 沿用现状确认框。
    // 取消 → 不发起授权（一次性 code 从未消耗，无重放问题）。
    var forceClear = false;
    try {
      var _preO = await _preflightLocalData('oauth', '');
      if (_preO.action === 'confirm') {
        var ok = await showLocalClearConfirm(_preO.ownerLoginId, '', _preO.foreign);
        if (!ok) {
          if (btn) { btn.disabled = false; }
          return;
        }
        forceClear = true;
      }
    } catch (e) {
      // 预检失败（SW 未唤醒）：继续原流程，SW blocked 兜底拦截
    }
    chrome.runtime.sendMessage({ type: 'auth-oauth', provider: provider, forceClearLocal: forceClear }).then(async function (result) {
      if (result && result.success) {
        // R2：游客数据自动认领 → 绿色提示 + 1.5s 后跳转（同表单提交路径；文案写找回视图外的主提示区）
        var _claim = result.claim;
        if (_claim && _claim.total > 0 && !_navigating) {
          _navigating = true;
          showSuccess(chrome.i18n.getMessage('authClaimDone') || '', oauthErrTarget());
          setTimeout(navigateToManager, 1500);
        } else {
          navigateToManager();
        }
      } else if (result && result.blocked) {
        // R2：blocked 兜底（预检失败路径）→ 重跑预检补弹正确确认框，确认后重试一次
        //（重发 auth-oauth 会重新拉起 provider 授权，属用户确认后的预期行为）；
        // 取消/预检失败 → 维持既有提示。
        try {
          var _reO = await _preflightLocalData('oauth', '');
          if (_reO.action === 'confirm') {
            var _okO = await showLocalClearConfirm(_reO.ownerLoginId, '', _reO.foreign);
            if (_okO) {
              chrome.runtime.sendMessage({ type: 'auth-oauth', provider: provider, forceClearLocal: true }).then(function (r2) {
                if (r2 && r2.success) {
                  navigateToManager();
                } else {
                  var _e2 = (r2 && r2.error) ? r2.error : (chrome.i18n.getMessage('authOauthFailed') || 'Third-party sign-in failed.');
                  showError(_e2, oauthErrTarget());
                }
              }).catch(function (err2) {
                showError((chrome.i18n.getMessage('authOauthFailed') || 'Third-party sign-in failed.') + (err2 && err2.message ? (': ' + err2.message) : ''), oauthErrTarget());
              }).finally(function () {
                if (btn) { btn.disabled = false; }
              });
              return;
            }
          }
        } catch (e) { /* 落入下方既有提示 */ }
        showAccountSwitchBlockedNote(
          (result.currentOwner && result.currentOwner.loginId) || '',
          (result.newUser && result.newUser.loginId) || ''
        );
      } else {
        var errMsg = (result && result.error) ? result.error : (chrome.i18n.getMessage('authOauthFailed') || 'Third-party sign-in failed.');
        showError(errMsg, oauthErrTarget());
      }
    }).catch(function (err) {
      showError((chrome.i18n.getMessage('authOauthFailed') || 'Third-party sign-in failed.') + (err && err.message ? (': ' + err.message) : ''), oauthErrTarget());
    }).finally(function () {
      if (btn) { btn.disabled = false; }
    });
  }

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    hideError();

    var loginId = loginIdInput.value.trim();
    var password = passwordInput.value;

    if (!loginId || !password) {
      showError(chrome.i18n.getMessage('authRequiredFields') || 'Please fill in all required fields.');
      return;
    }

    if (currentMode === 'register' && !PWD_POLICY_RE.test(password)) {
      showError(chrome.i18n.getMessage('authPwdWeak') || 'Password must be at least 8 characters and contain both letters and numbers.');
      return;
    }

    // 注册额外校验：邮箱 + 验证码必填
    if (currentMode === 'register') {
      var emailForCheck = emailInput.value.trim();
      var codeForCheck = verifyCodeInput ? verifyCodeInput.value.trim() : '';
      if (!emailForCheck) {
        showError(chrome.i18n.getMessage('authEmailRequired') || 'Please enter your email.');
        emailInput.focus();
        return;
      }
      if (!EMAIL_RE.test(emailForCheck)) {
        showError(chrome.i18n.getMessage('authEmailInvalid') || 'Please enter a valid email address.');
        emailInput.focus();
        return;
      }
      if (!codeForCheck || !/^\d{6}$/.test(codeForCheck)) {
        showError(chrome.i18n.getMessage('authVerifyCodeRequired') || 'Please enter the 6-digit verification code.');
        if (verifyCodeInput) verifyCodeInput.focus();
        return;
      }
    }

    submitBtn.disabled = true;
    submitBtn.textContent = chrome.i18n.getMessage('authProcessing') || 'Processing...';

    var message;
    if (currentMode === 'login') {
      message = {
        type: 'auth-login',
        loginId: loginId,
        password: password
      };
    } else {
      var email = emailInput.value.trim();
      var name = nameInput.value.trim() || loginId;
      var code = verifyCodeInput ? verifyCodeInput.value.trim() : '';
      message = {
        type: 'auth-register',
        loginId: loginId,
        password: password,
        email: email,
        name: name,
        code: code,
        // 产品更新邮件 opt-in：默认不勾选（合规），未勾选照常注册
        marketingEmailOptIn: !!(marketingOptInInput && marketingOptInInput.checked)
      };
    }

    // 游客档登录自动认领（2026-11 R2 单一决策源）：分流决策由 SW 端 preAction 给出，前端只渲染。
    //   claim      全部游客自有 → 直接提交自动认领（正向提醒条已在页面加载时展示），不设 forceClearLocal
    //   askForeign 含外来属主 → 弹清空确认框（foreign 变体文案），确认 → forceClearLocal=true
    //   askSwitch  owner 存在且非同号（同号重登已在 _preflightLocalData 豁免）→ 现状清空确认（分支④领地）
    //   none       无数据 → 直接提交
    try {
      var _pre = await _preflightLocalData(currentMode, loginId);
      if (_pre.action === 'confirm') {
        var ok = await showLocalClearConfirm(_pre.ownerLoginId, loginId, _pre.foreign);
        if (!ok) {
          submitBtn.disabled = false;
          submitBtn.textContent = chrome.i18n.getMessage(currentMode === 'login' ? 'authLoginBtn' : 'authRegisterBtn') || (currentMode === 'login' ? 'Sign In' : 'Create Account');
          return;
        }
        message.forceClearLocal = true;
      }
    } catch (e) {
      // 预检失败（SW 未唤醒）：继续原流程，SW blocked 兜底拦截
    }

    // 提交（R2：blocked 时重跑预检补弹正确确认框后可带 forceClearLocal 重试，抽成函数避免复制粘贴）
    async function _sendAuthMessage(msg) {
      var result;
      try {
        result = await chrome.runtime.sendMessage(msg);
      } catch (err) {
        showError((chrome.i18n.getMessage('authFailed') || 'Authentication failed') + ': ' + ((err && err.message) || 'Unknown error'));
        submitBtn.disabled = false;
        submitBtn.textContent = chrome.i18n.getMessage(currentMode === 'login' ? 'authLoginBtn' : 'authRegisterBtn') || (currentMode === 'login' ? 'Sign In' : 'Create Account');
        return;
      }
      if (result && result.success) {
        // 登录/注册成功。R2：游客数据自动认领 → 绿色成功提示（「归属」是确定的，「上云」受额度
        // 约束走后台同步，文案不承诺已保存完成），留 1.5s 可读时间再跳 manager；
        // 无认领数据时维持原行为立即跳转。
        var _claim = result.claim;
        if (_claim && _claim.total > 0 && !_navigating) {
          _navigating = true;
          showSuccess(chrome.i18n.getMessage('authClaimDone') || '');
          setTimeout(navigateToManager, 1500);
        } else {
          navigateToManager();
        }
        return;
      }
      if (result && result.blocked) {
        // 切换账号被拦截（SW 权威兜底：预检后用户又导入了外来数据 / 预检失败路径）。
        // R2：重跑预检——外来数据 → 弹正确的 foreign 清空确认框，确认后带 forceClearLocal 重试
        // 一次（替代旧版只有「关闭」的死胡同提示）；取消/预检失败 → 维持既有提示。
        try {
          var _re = await _preflightLocalData(currentMode, loginId);
          if (_re.action === 'confirm') {
            var _ok2 = await showLocalClearConfirm(
              _re.ownerLoginId,
              (result.newUser && result.newUser.loginId) || loginId,
              _re.foreign
            );
            if (_ok2) {
              msg.forceClearLocal = true;
              await _sendAuthMessage(msg);
              return;
            }
          }
        } catch (e) { /* 落入下方既有提示 */ }
        submitBtn.disabled = false;
        submitBtn.textContent = chrome.i18n.getMessage(currentMode === 'login' ? 'authLoginBtn' : 'authRegisterBtn') || (currentMode === 'login' ? 'Sign In' : 'Create Account');
        showAccountSwitchBlockedNote(
          (result.currentOwner && result.currentOwner.loginId) || '',
          (result.newUser && result.newUser.loginId) || ''
        );
        return;
      }
      var errMsg = (result && result.error) ? result.error : (chrome.i18n.getMessage('authFailed') || 'Authentication failed');
      showError(errMsg);
      submitBtn.disabled = false;
      submitBtn.textContent = chrome.i18n.getMessage(currentMode === 'login' ? 'authLoginBtn' : 'authRegisterBtn') || (currentMode === 'login' ? 'Sign In' : 'Create Account');
    }
    _sendAuthMessage(message);
  });

  // 本地模式（游客档）：本地已有数据 → tabs 上方提醒条。2026-11 R2 按 preAction 分流文案：
  //   claim      绿色正向（authLocalDataClaimNote 含条数）+ 隐藏「先去备份」链接（无清空风险）
  //   askForeign 橙色警示（authLocalDataForeignNote）+ 保留备份链接
  //   其余/失败  维持静态默认文案（authLocalDataNote 原键，最保守；键不改不删）
  try {
    chrome.runtime.sendMessage({ type: 'wpzl-has-local-data' }, function (resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.success && resp.data && resp.data.hasData) {
        var note = document.getElementById('authLocalDataNote');
        if (!note) return;
        var d = resp.data;
        var span = note.querySelector('span');
        if (!d.owner && d.preAction === 'claim' && (d.total || 0) > 0) {
          var _msg = chrome.i18n.getMessage('authLocalDataClaimNote', [String(d.total)]);
          if (span && _msg) span.textContent = _msg;
          note.classList.add('auth-local-note--ok');
          var _bk = document.getElementById('authBackupLink');
          if (_bk) _bk.style.display = 'none';
        } else if (!d.owner && (d.preAction === 'askForeign' || d.foreignData)) {
          var _msg2 = chrome.i18n.getMessage('authLocalDataForeignNote');
          if (span && _msg2) span.textContent = _msg2;
        }
        note.style.display = 'flex';
      }
    });
  } catch (e) { /* ignore */ }
  var _backupLink = document.getElementById('authBackupLink');
  if (_backupLink) {
    _backupLink.addEventListener('click', function (e) {
      e.preventDefault();
      _openManagerExportAll();
    });
  }

  // Deep-link：#forgot 直达找回视图（内联登录框「忘记密码？」经 SW 开标签进入）。
  // showForgotView 内部已聚焦找回邮箱输入框。
  if (location.hash === '#forgot') {
    showForgotView();
  } else {
    loginIdInput.focus();
  }
});
