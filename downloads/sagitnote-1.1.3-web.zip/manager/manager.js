// ============================================================
// Sagitnote - Annotation Manager Page
// ============================================================

(function () {
  'use strict';

  // CSP 不允许 inline onerror，通过 capture 阶段全局代理处理图片加载失败。
  // 注意：有 data-image-url 或 data-orig-url-inflight 的图片由 wpzl_loadImageDataWithFallback
  // 三级回退链路管理（本地→原始URL→云存储），不在此处替换为静态 placeholder。
  document.addEventListener('error', function (e) {
    var img = e.target;
    if (!img || img.tagName !== 'IMG') return;
    if (img.dataset.imageUrl || img.dataset.origUrlInflight) return;
    if (img.dataset.errorPlaceholder) {
      var div = document.createElement('div');
      div.className = img.dataset.errorPlaceholder;
      div.textContent = getMessage('mgImageUnavailable');
      if (img.parentNode) img.parentNode.replaceChild(div, img);
    } else if (img.dataset.errorHide !== undefined) {
      img.style.display = 'none';
    }
  }, true);

  // TOKEN_EXPIRED 重登录弹框（manager 页面专用）
  var _managerReauthLastTime = 0;
  function _showManagerReauthDialog() {
    if (Date.now() - _managerReauthLastTime < 30 * 60 * 1000) return;
    _managerReauthLastTime = Date.now();
    var existing = document.querySelector('.manager-reauth-overlay');
    if (existing) existing.remove();

    // 取当前账户 + 登录方式（区分密码 / Google / GitHub 的重登 UI）
    chrome.storage.local.get(['wpzl_auth'], function (result) {
      var auth = result && result.wpzl_auth;
      if (!auth || !auth.user) return;
      var loginId = auth.user.loginId || '';
      var email = auth.user.email || '';
      if (!loginId) return;
      // 会话登录方式 wpzl_auth.provider 优先——本会话怎么登录的就按哪家重登。
      // 旧会话未存 provider 时：有密码一律密码框（安全默认）；无密码按服务端下发的
      // 已关联第三方身份（user.oauthProviders，来自 user_oauth_identities 的权威数据）
      // 分支——不猜邮箱域名、不猜 loginId 前缀（OAuth 建号后设置密码的账号 loginId
      // 仍带 oauth_ 前缀，用密码登录时必须弹密码框，与 control-panel.js 保持一致）。
      var oauthProviderList = (auth.user.oauthProviders || [])
        .filter(function (p) { return p === 'google' || p === 'github'; });
      var oauthProviders;
      if (auth.provider === 'google' || auth.provider === 'github') {
        oauthProviders = [auth.provider];
      } else if (!auth.provider && auth.user.hasPassword === false && oauthProviderList.length > 0) {
        oauthProviders = oauthProviderList;
      } else {
        oauthProviders = [];
      }
      var providerLabel = function (p) {
        return p === 'github' ? 'GitHub' : (p === 'google' ? 'Google' : (p.charAt(0).toUpperCase() + p.slice(1)));
      };
      var isOauth = oauthProviders.length > 0;

      var overlay = document.createElement('div');
      overlay.className = 'manager-reauth-overlay';
      overlay.setAttribute('abc18980900', 'aaa');
      overlay.style.cssText = 'position:fixed;z-index:99999;top:0;left:0;width:100%;height:100%;' +
        'display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.5);' +
        'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;';

      var box = document.createElement('div');
      box.setAttribute('abc18980900', 'aaa');
      box.style.cssText = 'background:#fff;border-radius:16px;padding:32px 28px;width:360px;' +
        'box-shadow:0 20px 60px rgba(0,0,0,0.3);text-align:center;';

      var titleText = chrome.i18n.getMessage('reauthTitle') || '会话已过期，请重新登录';
      var cancelText = chrome.i18n.getMessage('reauthCancel') || '取消';
      var networkErrText = chrome.i18n.getMessage('reauthNetworkError') || '网络错误，请重试';
      var errorDivHtml = '<div id="managerReauthError" style="display:none;background:#fef2f2;color:#dc2626;border-radius:6px;' +
        'padding:8px 12px;font-size:13px;margin-bottom:12px;text-align:left;"></div>';

      var bodyHtml;
      if (isOauth) {
        // 第三方登录用户：没有密码，按已关联 provider 渲染重登按钮（走 auth-oauth）
        var descText = oauthProviders.length > 1
          ? getMessage('reauthOauthMultiDesc')
          : getMessage('reauthOauthDesc', [providerLabel(oauthProviders[0])]);
        var accountText = email || loginId;
        var oauthBtnsHtml = oauthProviders.map(function (p, idx) {
          return '<button class="manager-reauth-oauth-btn" data-provider="' + escapeHtml(p) + '" style="width:100%;padding:12px;border:none;border-radius:8px;' +
            'font-size:15px;font-weight:600;cursor:pointer;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;' +
            (idx > 0 ? 'margin-top:10px;' : '') + '">' +
            escapeHtml(getMessage('reauthOauthBtn', [providerLabel(p)])) + '</button>';
        }).join('');
        bodyHtml =
          '<div style="font-size:18px;font-weight:700;color:#1e293b;margin-bottom:4px;">' + escapeHtml(titleText) + '</div>' +
          '<div style="font-size:13px;color:#94a3b8;margin-bottom:20px;">' + escapeHtml(descText) + '</div>' +
          errorDivHtml +
          '<div title="' + escapeHtml(accountText) + '" style="width:100%;padding:10px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;' +
          'background:#f1f5f9;color:#64748b;margin-bottom:16px;box-sizing:border-box;word-break:break-all;">' +
          escapeHtml(accountText) + '</div>' +
          oauthBtnsHtml +
          '<button id="managerReauthCancel" style="width:100%;padding:10px;border:none;background:transparent;' +
          'color:#94a3b8;font-size:13px;margin-top:8px;cursor:pointer;">' + escapeHtml(cancelText) + '</button>';
      } else {
        // 密码登录用户：维持原有 loginId(只读) + 密码 输入
        var pwdDescText = chrome.i18n.getMessage('reauthPwdDesc') || '您的登录凭证已失效，请输入密码重新验证';
        var pwdPlaceholder = chrome.i18n.getMessage('authPassword') || '密码';
        var loginBtnText = chrome.i18n.getMessage('authLoginBtn') || '登录';
        bodyHtml =
          '<div style="font-size:18px;font-weight:700;color:#1e293b;margin-bottom:4px;">' + escapeHtml(titleText) + '</div>' +
          '<div style="font-size:13px;color:#94a3b8;margin-bottom:20px;">' + escapeHtml(pwdDescText) + '</div>' +
          errorDivHtml +
          '<input id="managerReauthUser" type="text" value="' + escapeHtml(loginId) + '" readonly ' +
          'style="width:100%;padding:10px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;' +
          'background:#f1f5f9;color:#64748b;margin-bottom:10px;box-sizing:border-box;cursor:not-allowed;">' +
          '<input id="managerReauthPwd" type="password" placeholder="' + escapeHtml(pwdPlaceholder) + '" autocomplete="current-password" ' +
          'style="width:100%;padding:10px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;' +
          'margin-bottom:16px;box-sizing:border-box;outline:none;">' +
          '<button id="managerReauthSubmit" style="width:100%;padding:12px;border:none;border-radius:8px;' +
          'font-size:15px;font-weight:600;cursor:pointer;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;">' +
          escapeHtml(loginBtnText) + '</button>' +
          '<button id="managerReauthCancel" style="width:100%;padding:10px;border:none;background:transparent;' +
          'color:#94a3b8;font-size:13px;margin-top:8px;cursor:pointer;">' + escapeHtml(cancelText) + '</button>';
      }

      box.innerHTML = bodyHtml;
      overlay.appendChild(box);
      document.body.appendChild(overlay);

      var errorDiv = box.querySelector('#managerReauthError');
      function cleanup() { if (overlay.parentNode) overlay.parentNode.removeChild(overlay); }
      function showError(msg) { errorDiv.style.display = 'block'; errorDiv.textContent = msg; }
      box.querySelector('#managerReauthCancel').addEventListener('click', cleanup);
      overlay.addEventListener('click', function (e) { if (e.target === overlay) cleanup(); });

      if (isOauth) {
        var oauthBtns = Array.prototype.slice.call(box.querySelectorAll('.manager-reauth-oauth-btn'));
        oauthBtns[0].focus();
        oauthBtns.forEach(function (oauthBtn) {
          oauthBtn.addEventListener('click', function () {
            // 单飞：点击即禁用全部 provider 按钮
            oauthBtns.forEach(function (b) { b.disabled = true; });
            var origText = oauthBtn.textContent;
            oauthBtn.textContent = chrome.i18n.getMessage('authProcessing') || 'Processing...';
            errorDiv.style.display = 'none';
            // 走与登录相同的 auth-oauth 流程（launchWebAuthFlow 重新选账号 → 换 token）
            chrome.runtime.sendMessage({ type: 'auth-oauth', provider: oauthBtn.dataset.provider }).then(function (result) {
              if (result && result.success) {
                cleanup();
                location.reload();
              } else {
                oauthBtn.disabled = false;
                oauthBtn.textContent = origText;
                showError((result && result.error) || (chrome.i18n.getMessage('authOauthFailed') || 'Third-party sign-in failed.'));
              }
            }).catch(function () {
              oauthBtns.forEach(function (b) { b.disabled = false; });
              oauthBtn.textContent = origText;
              showError(networkErrText);
            });
          });
        });
      } else {
        var pwdInput = box.querySelector('#managerReauthPwd');
        var submitBtn = box.querySelector('#managerReauthSubmit');
        pwdInput.focus();
        submitBtn.addEventListener('click', function () {
          var pwd = pwdInput.value;
          if (!pwd) { showError(chrome.i18n.getMessage('authRequiredFields') || '请输入密码'); return; }
          submitBtn.disabled = true;
          submitBtn.textContent = chrome.i18n.getMessage('authProcessing') || 'Processing...';
          errorDiv.style.display = 'none';
          chrome.runtime.sendMessage({ type: 'auth-login', loginId: loginId, password: pwd })
            .then(function (result) {
              if (result && result.success) {
                cleanup();
                location.reload();
              } else {
                submitBtn.disabled = false;
                submitBtn.textContent = chrome.i18n.getMessage('authLoginBtn') || '登录';
                showError((result && result.error) || (chrome.i18n.getMessage('authFailed') || '认证失败，请重试'));
              }
            })
            .catch(function () {
              submitBtn.disabled = false;
              submitBtn.textContent = chrome.i18n.getMessage('authLoginBtn') || '登录';
              showError(networkErrText);
            });
        });
        pwdInput.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') submitBtn.click();
        });
      }
    });
  }

  // ---- Data Layer ----

  function sendMessage(operation, params) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage(
        { type: 'db-operation', operation: operation, params: params || {} },
        function (resp) {
          if (resp && resp.success) resolve(resp.data);
          else reject(new Error((resp && resp.error) || 'Operation failed'));
        }
      );
    });
  }

  function loadAllPages() { return sendMessage('getAllPages'); }
  function loadAllDocuments() { return sendMessage('getAllDocuments'); }
  function loadAllSnapshots() { return sendMessage('getAllSnapshots'); }
  function loadAnnotations(domain, webUri) { return sendMessage('loadAnnotations', { domain: domain, webUri: webUri }); }
  function deleteAnnotation(id) { return sendMessage('deleteAnnotation', { markInfoId: id }); }
  function updateAnnotation(id, updates) { return sendMessage('updateAnnotation', { markInfoId: id, updates: updates }); }
  function searchAnnotations(query) { return sendMessage('searchAnnotations', { query: query }); }
  function exportAllAnnotations() { return sendMessage('exportAll'); }
  function getImageData(pageUrl, imageUrl) {
    return sendMessage('getImageDataByUrl', { pageUrl: pageUrl, imageUrl: imageUrl });
  }
  function getImageDataBatch(pageUrl, imageUrls) {
    return sendMessage('getImageDataBatch', { pageUrl: pageUrl, imageUrls: imageUrls });
  }
  function saveImageFromUrlToSW(imageUrl, pageUrl) {
    return sendMessage('saveImageFromUrl', { imageUrl: imageUrl, pageUrl: pageUrl });
  }
  function cleanupImageReferences(webUri, imageUrl) {
    return sendMessage('cleanupImageReferences', { webUri: webUri, imageUrl: imageUrl });
  }
  function getAllTags() { return sendMessage('getAllTags'); }
  function getAllLocalThumbnails() { return sendMessage('getAllLocalThumbnails'); }
  function saveTag(name) { return sendMessage('saveTag', { name: name }); }
  function searchByTag(tagName) { return sendMessage('searchByTag', { tagName: tagName }); }
  function getSetting(key) { return sendMessage('getSetting', { key: key }); }
  function saveSettingData(data) { return sendMessage('saveSetting', { data: data }); }
  function getUserIdentity() { return sendMessage('getUserIdentity'); }

  // ---- State ----

  var state = {
    pages: [],
    currentPage: null,
    annotations: [],
    filteredAnnotations: [],
    activeFilter: 'all',
    selectedIds: new Set(),
    searchQuery: '',
    searchMode: false,
    searchResults: [],
    sortBy: 'time',
    sortOrder: 'desc',
    renderItems: [],
    activeTag: null,
    allTags: [],
    folders: [],
    showFavoritesOnly: false,
    folderCollapsed: {},
    currentAuthor: null,
    allowEditOthers: true,
    isLoggedIn: false,
    gradeConfig: {},      // 服务端下发的当前等级权限/限额配置（features/exportFormats/perTypeLimits…）；功能门控唯一来源
    limits: {},           // 服务端下发的等级限额快照（docLimit/docSizeLimit/markLimit…，已按 effective 等级计算）
    syncEnabled: false,   // SW sync-status 返回的 enabled（同步引擎是否就绪）
    awaitingFirstSync: true,  // 刚加载假设首次同步进行中：数据空时 sidebar 显示"正在同步"而非"无数据"；有数据/online/轮询超时后置 false
    syncFailures: { marks: [], images: [], maxRetries: 10 },   // 同步失败查看器数据（计划 D17）
    authors: [],
    hiddenAuthorIds: new Set(),
    batchMode: false,
    batchSelectedUrls: new Set(),
    activeFolderId: null,  // 目录联动过滤：null=全部(无过滤); ''=未分类; string=目录id(含子孙)
    documents: [],         // 自建文档（Phase 7）：独立于 pages，不参与 refreshPageCounts 过滤 / search / export / batch
    snapshots: []          // 网页快照（与文档同构的一类实体）：独立于 pages，侧栏混排显示
  };

  // 批量移动目录弹窗的回调状态
  var pendingMovePagesCallback = null;
  var pendingMovePagesSelection = null;

  // 删除弹窗的回调状态（与 annotation 删除共用 #deleteModal，但走 page 级联删除路径）
  var pendingPageDeleteItems = null;

  // 批量导出临时状态（非空时 executeExport 走批量路径）
  var pendingBatchExportUrls = null;

  // ---- Helpers ----

  // chrome.i18n.getMessage 的短封装：键缺失时回退 en（default_locale），再退键名本身
  function getMessage(key, subs) {
    return chrome.i18n.getMessage(key, subs) || key;
  }

  // 类型标签经 filter* 键本地化（与筛选页签同源）；getter 保证 UI 语言加载后取值始终是当前语言
  var TYPE_MAP = {
    highlight: { i18nKey: 'filterHighlight', icon: '✒', bg: '#e8f5e9' },
    arrow: { i18nKey: 'filterArrow', icon: '↗', bg: '#e3f2fd' },
    flag: { i18nKey: 'filterFlag', icon: '⚑', bg: '#fff3e0' },
    rect: { i18nKey: 'filterRect', icon: '▣', bg: '#f3e5f5' },
    pageRect: { i18nKey: 'filterPageRect', icon: '✂', bg: '#fce4ec' },
    rectFrame: { i18nKey: 'filterRectFrame', icon: '⬚', bg: '#e0f2fe' },
    elementMark: { i18nKey: 'filterElementMark', icon: '⌖', bg: '#fce7f3' },
    freehand: { i18nKey: 'filterFreehand', icon: '∿', bg: '#e0f7fa' },
    text: { i18nKey: 'filterText', icon: 'T', bg: '#fff8e1' },
    imgAnno: { i18nKey: 'filterImgAnno', icon: '♽', bg: '#ede7f6' }
  };
  Object.keys(TYPE_MAP).forEach(function (k) {
    Object.defineProperty(TYPE_MAP[k], 'label', {
      get: function () { return chrome.i18n.getMessage(this.i18nKey) || this.i18nKey; }
    });
  });

  function getAnnotationType(a) {
    var ex = a.END_XPATH || '';
    if (ex === '$arrow') return 'arrow';
    if (ex === '$flag') return 'flag';
    if (ex === '$pic') return 'rect';
    if (ex === '$pageRect') return 'pageRect';
    if (ex === '$rectFrame') return 'rectFrame';
    if (ex === '$elemMark') return 'elementMark';
    if (ex === '$picLine') return 'freehand';
    if (ex === '$char') return 'text';
    if (ex === '$imgAnno') return 'imgAnno';
    return 'highlight';
  }

  // ---- Permission helper ----
  function isOwnOrAllowed(annotation) {
    if (state.allowEditOthers) return true;
    return state.currentAuthor && annotation.AUTHOR_ID === state.currentAuthor.authorId;
  }

  // ---- 功能门控：以服务端下发的 gradeConfig 为唯一来源（数据驱动，不按"免费/Pro"身份判断）----
  // 可导出格式 = 当前等级 gradeConfig.exportFormats（各等级各自配置，随时可在后台增删，改配置即热生效）。
  // 兜底链同样只认服务端数据：gradeConfig.exportFormats → limits.exportFormats（同为按 effective 等级
  // 下发的快照）；仅在从未登录且无缓存的零数据场景落 ['json','csv'] —— 那是"数据可导出是用户权利"的
  // 产品底线（与后台等级编辑页的提示一致），不是任何等级的映射，与等级命名/档位无关。
  function canExportFormat(fmt) {
    var formats = (state.gradeConfig && state.gradeConfig.exportFormats)
      || (state.limits && state.limits.exportFormats)
      || ['json', 'csv'];
    return formats.indexOf(fmt) !== -1;
  }

  function updateExportFormatUI() {
    document.querySelectorAll('.export-format-pill').forEach(function (pill) {
      var fmt = pill.dataset.fmt;
      if (!canExportFormat(fmt)) {
        pill.classList.add('disabled');
        pill.style.opacity = '0.4';
        pill.style.pointerEvents = 'none';
        pill.title = getMessage('mgProFeature');
        if (pill.classList.contains('active')) {
          pill.classList.remove('active');
          // 回退选中到 JSON
          var jsonPill = document.querySelector('.export-format-pill[data-fmt="json"]');
          if (jsonPill) jsonPill.classList.add('active');
          _syncExportFormatHint();
        }
      } else {
        pill.classList.remove('disabled');
        pill.style.opacity = '';
        pill.style.pointerEvents = '';
        pill.title = '';
      }
    });
  }

  // 同步按钮显示门控：当前等级授予 cloudSync 功能 + 同步引擎就绪 才显示。
  // 权限由 gradeConfig.features.cloudSync 表达（数据驱动，与具体等级名称无关）；syncEnabled 表示同步引擎是否就绪。
  // 二者分别由不同异步设置（gradeConfig ← pro 缓存回调；syncEnabled ← sync-status 回调），
  // 因此在各自回调末尾都调用本函数，避免竞态导致误判。
  function updateSyncButtonVisibility() {
    var btn = document.getElementById('syncNowBtn');
    var failBtn = document.getElementById('syncFailuresBtn');
    var gc = state.gradeConfig || {};
    var cloudSync = !!(gc.features && gc.features.cloudSync === true);
    var imgCloud = !!(gc.features && gc.features.imageCloudUpload === true);
    if (btn) btn.style.display = (cloudSync && state.syncEnabled) ? 'inline-flex' : 'none';
    // manager 打开自愈（2026-09-13）：权限+引擎就绪且上次同步久远/失败（典型：刚升级 Pro 后
    // 首次打开、服务端部署窗口同步连败后引擎 idle——定时同步已禁用，只剩 connectivity-tick
    // 兜底，可能数十分钟无同步）→ 静默触发一次与「立即同步」同路径的同步，数据自来、遮罩自然收尾。
    // 在本函数触发是因为 gradeConfig 与 syncEnabled 两个异步恰好在此汇合；state 标记防重。
    if (cloudSync && state.syncEnabled && state.syncStale && !state.autoSyncKicked) {
      state.autoSyncKicked = true;
      try {
        chrome.runtime.sendMessage({ type: 'sync-trigger' }).catch(function () { /* ignore */ });
      } catch (e) { /* ignore */ }
    }
    // 失败查看器：有同步或图片上云权限即显示（图片上云用户也可能有失败项；计划 D17）
    if (failBtn) failBtn.style.display = ((cloudSync && state.syncEnabled) || imgCloud) ? 'inline-flex' : 'none';
    // awaitingFirstSync 与 cloudSync 权限对齐：无同步权限的用户永远不会有同步数据到来，
    // 不应停在"等待首次同步"态（空账号会长时间显示"正在同步"，让人以为也能同步）。
    // gradeConfig 到位即清除并重渲，切回"暂无标注页面"。
    if (!cloudSync && state.awaitingFirstSync) {
      state.awaitingFirstSync = false;
      try { renderSidebar(); } catch (e) { /* ignore */ }
    }
  }

  // 当前用户是否拥有 cloudSync（云同步）权限——数据驱动，读 gradeConfig.features.cloudSync。
  // 供"正在同步"遮罩等 UI 判定：无此权限的用户不会有同步数据到来，不应显示同步态。
  function _cloudSyncEnabled() {
    var gc = state.gradeConfig || {};
    return !!(gc.features && gc.features.cloudSync === true);
  }

  // 分享管理菜单项显示门控：登录 + 当前等级授予 collaboration（数据驱动，读 gradeConfig.features.collaboration，
  // 与具体等级名称无关）。init 加载与 _mgrApplyProStatus 热更新两处调用，等级变化后即时显隐。
  function _updateShareMgrItemVisibility() {
    var item = document.getElementById('featureShareItem');
    if (!item) return;
    var gc = state.gradeConfig || {};
    var allowed = !!(gc.features && gc.features.collaboration === true);
    item.style.display = (state.isLoggedIn && allowed) ? 'flex' : 'none';
  }


  // ---- 同步失败查看器（计划 D17）----
  // _escapeHtml / _truncate 提升到 IIFE 顶层：D17 函数群（renderSyncFailures/_sfMarkRow/_sfImageRow）
  // 与 DOMContentLoaded 内的 showSyncReportModal 都依赖它们。原定义曾错放在 DOMContentLoaded
  // 作用域内，导致顶层 renderSyncFailures 调用时 ReferenceError: _escapeHtml is not defined，
  // 列表渲染中途崩溃、永远空白（无论有无失败项）。详见 D17。
  function _escapeHtml(s) {
    if (s == null) return '';
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function _truncate(s, n) {
    if (!s) return '';
    s = String(s);
    return s.length > n ? s.slice(0, n) + '…' : s;
  }

  function sendDirectMessage(type, payload) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage(
        Object.assign({ type: type }, payload || {}),
        function (resp) {
          if (resp && resp.success) resolve(resp.data);
          else reject(new Error((resp && resp.error) || 'Operation failed'));
        }
      );
    });
  }
  function loadSyncFailures() {
    return sendDirectMessage('get-sync-failures').then(function (data) {
      state.syncFailures = data || { marks: [], images: [], maxRetries: 10 };
    }).catch(function (e) {
      console.warn('[Manager] loadSyncFailures failed:', e);
      state.syncFailures = { marks: [], images: [], maxRetries: 10 };
    }).then(function () {
      updateSyncFailuresBadge();
      renderSyncFailures();
    });
  }
  function updateSyncFailuresBadge() {
    var badge = document.getElementById('syncFailuresBadge');
    var sf = state.syncFailures || { marks: [], images: [] };
    var marks = sf.marks || [], images = sf.images || [];
    var count = marks.length + images.length;
    if (badge) {
      badge.textContent = count > 99 ? '99+' : String(count);
      badge.style.display = count > 0 ? 'inline-block' : 'none';
    }
    // 重试全部只统计可重试（非限额）项：限额项重试必被服务端再拒（spec 2026-09-21）。
    // 终态缩略图项（本地字节已不存在）同样排除——重传入口被隐藏，点"全部重传"对它也没有任何作用，
    // 计入会让计数与按钮状态说谎。徽标仍统计全部失败项（提醒用户有未同步数据）。
    var retryable = 0;
    for (var i = 0; i < marks.length; i++) {
      if (marks[i].terminal) continue;
      if (!_sfLimitClassEff(marks[i].lastError) && !_sfIsSizeTerminal(marks[i].lastError)) retryable++;
    }
    for (var j = 0; j < images.length; j++) { if (!_sfLimitClassEff(images[j].lastError) && !_sfIsSizeTerminal(images[j].lastError)) retryable++; }
    var cntEl = document.getElementById('sfRetryAllCount');
    if (cntEl) cntEl.textContent = String(retryable);
    var btn = document.getElementById('sfRetryAllBtn');
    if (btn) {
      btn.disabled = retryable === 0;
      btn.title = (count > 0 && retryable === 0) ? getMessage('sfRetryAllBlockedTitle') : '';
    }
  }
  function _sfStatusLabel(item) {
    // 终态必须排在 thumbPending 之前：终态项也带 thumbPending=true，若让它落到下面那支，
    // 会显示成蓝色的「缩略图未上云」（读起来像"排队中"），永远传不上去这件事就被藏住了。
    if (item.terminal) return '<span style="color:#ef4444;">' + _escapeHtml(getMessage('syncFailuresThumbMissing')) + '</span>';
    if (item.thumbPending) return '<span style="color:#3b82f6;">' + _escapeHtml(chrome.i18n.getMessage('syncFailuresThumbPending') || '缩略图未上云') + '</span>';
    var _limitCls = _sfLimitClassEff(item.lastError);
    if (_limitCls) return '<span style="color:#f97316;">' + _escapeHtml(getMessage('syncFailuresLimitReached')) + '</span>';
    if (item.exhausted) return '<span style="color:#ef4444;">' + _escapeHtml(chrome.i18n.getMessage('syncFailuresExhausted') || 'Exhausted') + '</span>';
    return '<span style="color:#f59e0b;">' + _escapeHtml(chrome.i18n.getMessage('syncFailuresRetrying') || 'Retrying') + '</span>';
  }
  function _sfRetryTxt(n) {
    var max = (state.syncFailures && state.syncFailures.maxRetries) || 10;
    return chrome.i18n.getMessage('syncFailuresRetryCount', [String(n), String(max)]) || (n + '/' + max);
  }
  // 文档/快照 body 上云拒绝原因 → 用户可读文案。永久原因（过大/冲突）= 已停止自动重试，需用户处理。
  function _sfReasonLabel(reason) {
    if (!reason) return '';
    // 跨账号迁移残留：原样显示会误导（本账号明明是无限额，却显示"已达上限"）
    if (_sfIsStaleLimit(reason)) return getMessage('sfReasonStaleLimit');
    var map = {
      'snap_size_limit': getMessage('sfReasonSnapSizeLimit'),
      'snap_size_limit=0': getMessage('sfReasonSnapSizeZero'),
      'doc_size_limit': getMessage('sfReasonDocSizeLimit'),
      'doc_size_limit=0': getMessage('sfReasonDocSizeZero'),
      'payload_too_large': getMessage('sfReasonPayloadTooLarge'),
      'body_conflict': getMessage('sfReasonBodyConflict'),
      'cloud_quota': getMessage('sfReasonCloudQuota'),
      'mark_limit': getMessage('sfReasonMarkLimit'),
      'daily_mark_limit': getMessage('sfReasonDailyMarkLimit'),
      'import_limit': getMessage('sfReasonImportLimit'),
      'page_limit': getMessage('sfReasonPageLimit'),
      'snap_limit': getMessage('sfReasonSnapLimit'),
      'storage_error': getMessage('sfReasonStorageError'),
      'doc_limit': getMessage('sfReasonDocLimit'),
      'invalid': getMessage('sfReasonInvalid'),
      'rejected': getMessage('sfReasonRejected')
    };
    return map[reason] || reason;
  }
  // 限额类拒绝原因 → 'daily'（每日周期）| 'total'（总量/存储）| null。与 sync-engine
  // _isLimitRejectionReason 同规则（spec 2026-09-21）：每日类提示「明天恢复」，总量/存储类
  // 提示升级；命中者不显示重试入口（重试必被服务端再拒）。「配额超限」仅精确匹配——
  // 图片路径专用 token（sync-engine _uploadPendingImagesInner 唯一写入点）；注解路径服务端
  // 业务文本「配额超限：…」（单页/类型限额 quotaMessage）不匹配，保持可手动重试恢复。
  var _SF_LIMIT_TOKENS = {
    daily_mark_limit: 'daily', doc_limit: 'daily', snap_limit: 'daily', import_limit: 'daily',
    mark_limit: 'total', page_limit: 'total', cloud_quota: 'total'
  };
  function _sfLimitClass(err) {
    if (!err) return null;
    var s = String(err);
    if (_SF_LIMIT_TOKENS[s]) return _SF_LIMIT_TOKENS[s];
    return s === '配额超限' ? 'total' : null;
  }
  // 尺寸类永久失败：单条内容物理超出单次请求上限，重试必再失败 → 隐藏重传入口/不计入
  // 「全部重传」（同限额项的"重试入口对必失败项是欺骗"语义）。payload_too_large 是
  // sync-engine 发送前字节预检新写入的标注/通用 token；doc/snap_size_limit 是既有永久 token。
  var _SF_SIZE_TERMINAL = {
    'payload_too_large': true,
    'doc_size_limit': true, 'doc_size_limit=0': true,
    'snap_size_limit': true, 'snap_size_limit=0': true
  };
  function _sfIsSizeTerminal(err) {
    return !!(err && _SF_SIZE_TERMINAL[String(err)]);
  }
  // 拒绝原因 token → 当前等级 limits 里的对应上限字段（state.limits，来自 wpzl_pro_cache）。
  var _SF_LIMIT_FIELD = {
    daily_mark_limit: 'dailyMarkLimit', doc_limit: 'docLimit', snap_limit: 'snapLimit',
    import_limit: 'dailyImportLimit',
    mark_limit: 'markLimit', page_limit: 'pageLimit', cloud_quota: 'cloudStorageMb'
  };
  // 跨账号迁移残留判定：当前账号该项限额为 -1（无限）→ 这条失败原因不可能是本账号产生的
  //（典型来源：旧账号导出的备份带着 SYNC_LAST_ERROR 被导入到本账号）。limits 不可读时
  // 一律判 false，即维持原有的限额语义，绝不因读不到数据而误放行。
  function _sfIsStaleLimit(err) {
    if (!err) return false;
    var field = _SF_LIMIT_FIELD[String(err)];
    if (!field) return false;
    var limits = state.limits;
    if (!limits || limits[field] == null) return false;
    return Number(limits[field]) === -1;
  }
  // 生效的分类入口：所有"是否显示重试入口/是否算限额"的判定都走这里。
  // 残留项按非限额处理 → 恢复重试按钮，用户可一键重传（服务端对本账号必然放行）。
  function _sfLimitClassEff(err) {
    return _sfIsStaleLimit(err) ? null : _sfLimitClass(err);
  }
  // 限额行尾部公共片段：提示 + 升级按钮（daily/total 文案分型）。sf-line2 是 nowrap flex，
  // 内联塞入会在 780px 弹窗被压成竖排——独立 sf-line3 行（manager.css）。
  function _sfLimitExtras(limitCls) {
    if (!limitCls) return '';
    return '<div class="sf-line3">'
      + '<span class="sf-limit-hint">' + _escapeHtml(getMessage(limitCls === 'daily' ? 'sfLimitHintDaily' : 'sfLimitHintTotal')) + '</span>'
      + '<button class="card-action-btn" data-sf-action="upgrade">' + _escapeHtml(getMessage('sfUpgradeGo')) + '</button>'
      + '</div>';
  }
  // ---- 同步失败查看器：类型徽标 / 内容预览（D17 增补）----
  // 失败项必须让用户一眼看出"是哪条标注没同步上去"：类型徽标（箭头/页面矩形/高亮/...）
  // + 内容预览（文字片段 or 缩略图），而非展示无意义的 MARK_INFO_ID 或 TITLE 样式代码（高亮的
  // TITLE="bjs" 是高亮样式，不是标题）。pages/folders 行沿用各自标题。
  function _sfMarkType(m) {
    if (m.kind === 'page') return 'page';
    if (m.kind === 'folder') return 'folder';
    if (m.kind === 'document') return 'document';
    if (m.kind === 'snapshot') return 'snapshot';
    return getAnnotationType({ END_XPATH: m.endXPath || '' });
  }
  var _SF_TYPE_BADGE_EXTRA = {
    page: { i18nKey: 'kindLabelPage', icon: '📄', bg: '#e3f2fd' },
    folder: { i18nKey: 'kindLabelFolder', icon: '📁', bg: '#f3e5f5' },
    document: { i18nKey: 'kindLabelDocument', icon: '📝', bg: '#e8f5e9' },
    snapshot: { i18nKey: 'kindLabelSnapshot', icon: '📸', bg: '#fff3e0' }
  };
  Object.keys(_SF_TYPE_BADGE_EXTRA).forEach(function (k) {
    Object.defineProperty(_SF_TYPE_BADGE_EXTRA[k], 'label', {
      get: function () { return getMessage(this.i18nKey); }
    });
  });
  function _sfTypeBadge(type) {
    if (_SF_TYPE_BADGE_EXTRA[type]) return _SF_TYPE_BADGE_EXTRA[type];
    return TYPE_MAP[type] || { icon: '?', label: getMessage('typeAnnotation'), bg: '#f1f5f9' };
  }
  var _SF_TYPE_FALLBACK = {
    arrow: getMessage('sfLabelArrow'), flag: getMessage('sfLabelFlag'),
    rect: getMessage('sfLabelRect'), freehand: getMessage('sfLabelFreehand')
  };
  // 图片类缩略图异步加载：pageRect 复用 wpzl_loadPageRectThumb（4 分支：本地 localThumbnails →
  // objectKey 云端签名 → dataUrl → 占位）；图片矩形(rect)/图片标记(imgAnno) 共用图片源解析
  // （CONTEXT 内嵌 dataUrl/img: 优先，否则 END_TAG_NAME 原始 URL）。须在 marksEl.innerHTML 落地后调用。
  function _loadSfThumbs() {
    var marks = (state.syncFailures && state.syncFailures.marks) || [];
    for (var i = 0; i < marks.length; i++) {
      var m = marks[i];
      if (m.kind !== 'annotation') continue;
      var type = _sfMarkType(m);
      var id = String(m.id);
      if (type === 'pageRect') {
        if (document.getElementById('sf-pr-' + id)) {
          wpzl_loadPageRectThumb({
            MARK_INFO_ID: id, THUMBNAIL: m.thumb || '', MARK_COLOR: m.color || '',
            ANCHOR_WIDTH: m.anchorW || 0, ANCHOR_HEIGHT: m.anchorH || 0
          }, 'sf-pr-' + id);
        }
      } else if (type === 'rect' || type === 'imgAnno') {
        var src = '';
        if (m.context && m.context.indexOf('data:') === 0) src = m.context;
        else if (m.context && m.context.indexOf('img:') === 0) src = m.context.substring(4);
        else if (m.endTagName) src = m.endTagName;
        if (src) {
          var iaEl = document.getElementById('sf-ia-' + id);
          if (iaEl) iaEl.src = src;
        }
      }
    }
  }
  function _sfMarkRow(m) {
    var id = String(m.id);
    var type = _sfMarkType(m);
    var badge = _sfTypeBadge(type);
    var _limitCls = _sfLimitClassEff(m.lastError);
    // 终态行不渲染失败原因后缀：状态列已写明「本地截图已丢失」，再挂一条同义的原因是冗余，
    // 而且 _sfReasonLabel 的 `|| reason` 兜底会把 local_thumbnail_missing 这个裸 token 漏到界面上。
    var err = (m.lastError && !m.terminal) ? ' · <span title="' + _escapeHtml(m.lastError) + '">' + _escapeHtml(_truncate(_sfReasonLabel(m.lastError), 40)) + '</span>' : '';
    var url = m.webUri || m.url || '';

    // 内容预览（按类型）：
    //   文字类（高亮/文字批注）→ 截取开头文字；图片类（页面矩形/图片矩形/图片标记）→ 缩略图占位，
    //   渲染后由 _loadSfThumbs 异步回填；文档/快照/页面/目录 → 标题；其余（箭头/旗帜/自由线条）→ 类型描述。
    var _SF_TYPE_LABEL = { page: 'kindLabelPage', folder: 'kindLabelFolder', document: 'kindLabelDocument', snapshot: 'kindLabelSnapshot' };
    var preview = '';
    if (type === 'page' || type === 'folder' || type === 'document' || type === 'snapshot') {
      var ttl = m.title ? _truncate(m.title, 60) : '';
      preview = ttl
        ? '<span class="sf-preview-text" title="' + _escapeHtml(m.title) + '">' + _escapeHtml(ttl) + '</span>'
        : '<span class="sf-preview-mute">' + _escapeHtml(getMessage('noKindTitle', [getMessage(_SF_TYPE_LABEL[type])])) + '</span>';
    } else if (type === 'highlight' || type === 'text') {
      var txt = m.context ? _truncate(m.context, 60) : (m.comment ? _truncate(m.comment, 60) : '');
      preview = txt
        ? '<span class="sf-preview-text" title="' + _escapeHtml(txt) + '">' + _escapeHtml(txt) + '</span>'
        : '<span class="sf-preview-mute">' + _escapeHtml(getMessage('noTextContent')) + '</span>';
    } else if (type === 'pageRect') {
      // 终态行不挂 <img id="sf-pr-...">：本地与云端都没有截图，_loadSfThumbs 会去追一个永远
      // 取不到的 id，留下一堆破图占位。也不放文字——状态列已经写明原因，同句重复两遍更吵。
      preview = m.terminal
        ? ''
        : '<img id="sf-pr-' + _escapeHtml(id) + '" alt="' + _escapeHtml(getMessage('altAreaScreenshot')) + '" class="sf-thumb">'
          + ((m.anchorW && m.anchorH) ? '<span class="sf-size">' + m.anchorW + '×' + m.anchorH + '</span>' : '');
    } else if (type === 'rect' || type === 'imgAnno') {
      preview = '<img id="sf-ia-' + _escapeHtml(id) + '" alt="' + _escapeHtml(getMessage('altImage')) + '" class="sf-thumb">';
    } else {
      preview = '<span class="sf-preview-mute">' + _escapeHtml(_SF_TYPE_FALLBACK[type] || getMessage('typeAnnotation')) + '</span>';
    }

    return '<div class="sf-row">'
      + '<div class="sf-line1">'
      + '<span class="sf-badge" style="background:' + badge.bg + ';">' + _escapeHtml(badge.icon) + ' ' + _escapeHtml(badge.label) + '</span>'
      + '<span class="sf-preview">' + preview + '</span>'
      + '<span class="sf-retry">' + ((m.thumbPending || _limitCls) ? '—' : _sfRetryTxt(m.retryCount)) + '</span>'
      + '</div>'
      + '<div class="sf-line2">'
      + '<span class="sf-url" title="' + _escapeHtml(url) + '">' + _escapeHtml(_truncate(url, 70)) + '</span>'
      + '<span class="sf-status">' + _sfStatusLabel(m) + err + '</span>'
      + (m.updateTime ? '<span class="sf-time" title="' + _escapeHtml(chrome.i18n.getMessage('syncFailuresItemTime') || 'Last updated') + '">' + _escapeHtml(formatTime(m.updateTime)) + '</span>' : '')
      // 终态行不给「重传」：本地字节已不存在，重传必失败，留个点了没反应的按钮等于说谎。
      // 恢复途径是重新框选截图（saveLocalThumbnail 会复位终态），不是这个按钮。
      + ((!_limitCls && !m.terminal && !_sfIsSizeTerminal(m.lastError)) ? '<button class="card-action-btn" data-sf-action="retry" data-kind="' + _escapeHtml(m.kind) + '" data-id="' + _escapeHtml(id) + '" data-store="' + _escapeHtml(m.store || '') + '"' + (m.thumbPending ? ' data-thumbpending="1"' : '') + '>' + _escapeHtml(chrome.i18n.getMessage('reupload') || 'Retry') + '</button>' : '')
      + '<button class="card-action-btn" data-sf-action="discard" data-kind="' + _escapeHtml(m.kind) + '" data-id="' + _escapeHtml(id) + '" data-store="' + _escapeHtml(m.store || '') + '"' + (m.thumbPending ? ' data-thumbpending="1"' : '') + ' title="' + _escapeHtml(chrome.i18n.getMessage('discardUploadTip') || '放弃上传，保留本地数据') + '">' + _escapeHtml(chrome.i18n.getMessage('discardUpload') || '放弃') + '</button>'
      + '</div>'
      + _sfLimitExtras(_limitCls)
      + '</div>';
  }
  // 从图片源 URL 派生域名（imageUrl 恒有值，作为身份回退链第 4 档，孤儿图也能识别）。
  function _sfImgSrcDomain(url) {
    if (!url) return '';
    try { return new URL(url).hostname; } catch (e) { return ''; }
  }
  function _sfImageRow(im) {
    // 身份回退链（用户永不再见裸哈希）：title → domain → pageUrl → 图片源域名 → 哈希
    var title = im.title ? _truncate(im.title, 60) : '';
    var domain = im.domain || '';
    var pageUrl = im.pageUrl || '';
    var imgSrcDomain = _sfImgSrcDomain(im.imageUrl);
    var hashFallback = im.imageKey || im.pageKey || String(im.id);

    var display, titleAttr;
    if (title) {
      display = title; titleAttr = im.title;
    } else if (domain) {
      display = domain; titleAttr = pageUrl || domain;
    } else if (pageUrl) {
      display = _truncate(pageUrl, 60); titleAttr = pageUrl;
    } else if (imgSrcDomain) {
      display = '🖼 ' + imgSrcDomain; titleAttr = (im.imageUrl || '') + getMessage('syncImgSrcDomainNote');
    } else {
      display = _truncate(hashFallback, 16); titleAttr = hashFallback;
    }

    var _limitCls = _sfLimitClassEff(im.lastError);
    var err = im.lastError ? ' · <span title="' + _escapeHtml(im.lastError) + '">' + _escapeHtml(_truncate(im.lastError, 40)) + '</span>' : '';
    var srcUrl = pageUrl || im.imageUrl || '';   // line2 来源 URL，完整可追溯
    return '<div class="sf-row">'
      + '<div class="sf-line1">'
      + '<span class="sf-badge" style="background:#ede7f6;">♽ ' + _escapeHtml(getMessage('syncBadgeImage')) + '</span>'
      + '<span class="sf-preview"><span class="sf-preview-text" title="' + _escapeHtml(titleAttr) + '">' + _escapeHtml(display) + '</span></span>'
      + '<span class="sf-retry">' + (_limitCls ? '—' : _sfRetryTxt(im.retryCount)) + '</span>'
      + '</div>'
      + '<div class="sf-line2">'
      + (srcUrl ? '<span class="sf-url" title="' + _escapeHtml(srcUrl) + '">' + _escapeHtml(_truncate(srcUrl, 70)) + '</span>' : '')
      + '<span class="sf-status">' + _sfStatusLabel(im) + err + '</span>'
      + (im.updateTime ? '<span class="sf-time" title="' + _escapeHtml(chrome.i18n.getMessage('syncFailuresItemTime') || 'Last updated') + '">' + _escapeHtml(formatTime(im.updateTime)) + '</span>' : '')
      + (!_limitCls ? '<button class="card-action-btn" data-sf-action="retry" data-kind="image" data-id="' + _escapeHtml(String(im.id)) + '">' + _escapeHtml(chrome.i18n.getMessage('reupload') || 'Retry') + '</button>' : '')
      + '<button class="card-action-btn" data-sf-action="discard" data-kind="image" data-id="' + _escapeHtml(String(im.id)) + '" title="' + _escapeHtml(chrome.i18n.getMessage('discardUploadTip') || '放弃上传，保留本地数据') + '">' + _escapeHtml(chrome.i18n.getMessage('discardUpload') || '放弃') + '</button>'
      + '</div>'
      + _sfLimitExtras(_limitCls)
      + '</div>';
  }
  function renderSyncFailures() {
    var sf = state.syncFailures || { marks: [], images: [] };
    var marksEl = document.getElementById('syncFailuresMarks');
    var imagesEl = document.getElementById('syncFailuresImages');
    var summaryEl = document.getElementById('syncFailuresSummary');
    var markCount = (sf.marks || []).length;
    var imgCount = (sf.images || []).length;
    var exhausted = ((sf.marks || []).filter(function (m) { return m.exhausted; }).length)
      + ((sf.images || []).filter(function (m) { return m.exhausted; }).length);
    if (summaryEl) {
      summaryEl.textContent = chrome.i18n.getMessage('syncFailuresSummary', [String(markCount + imgCount), String(exhausted), String(sf.maxRetries)]) || ((markCount + imgCount) + ' pending');
    }
    var _emptyLbl = _escapeHtml(chrome.i18n.getMessage('syncFailuresEmpty') || 'None');
    if (marksEl) {
      marksEl.innerHTML = markCount > 0
        ? sf.marks.map(_sfMarkRow).join('')
        : '<div class="sf-empty">' + _emptyLbl + '</div>';
      // 列表落地后再异步加载图片类（页面矩形/图片标记）的缩略图——img 元素此时才存在于 DOM。
      if (markCount > 0) _loadSfThumbs();
    }
    if (imagesEl) {
      imagesEl.innerHTML = imgCount > 0
        ? sf.images.map(_sfImageRow).join('')
        : '<div class="sf-empty">' + _emptyLbl + '</div>';
    }
    updateSyncFailuresBadge();
  }
  function retryUploadItem(payload) {
    return sendDirectMessage('retry-upload', { payload: payload }).then(function () {
      return loadSyncFailures();
    });
  }
  // 放弃单项上传：保留本地数据，仅清除脏同步状态使其离开失败队列（引擎不再尝试上传）。
  function discardUploadItem(payload) {
    return sendDirectMessage('discard-upload', { payload: payload }).then(function () {
      return loadSyncFailures();
    });
  }
  function retryUploadAllFn(kinds) {
    return sendDirectMessage('retry-upload-all', { payload: { kinds: kinds || [] } }).then(function () {
      return loadSyncFailures();
    });
  }

  function computeAuthors(annotations) {
    var map = {};
    annotations.forEach(function (a) {
      var aid = a.AUTHOR_ID || '';
      if (!aid) return;
      if (!map[aid]) map[aid] = { authorId: aid, authorName: a.AUTHOR_NAME || '', count: 0 };
      map[aid].count++;
    });
    var arr = [];
    for (var k in map) arr.push(map[k]);
    arr.sort(function (a, b) {
      if (state.currentAuthor && a.authorId === state.currentAuthor.authorId) return -1;
      if (state.currentAuthor && b.authorId === state.currentAuthor.authorId) return 1;
      return b.count - a.count;
    });
    return arr;
  }

  function isMultiAuthor() {
    if (state.authors.length >= 2) return true;
    if (state.authors.length === 1 && state.currentAuthor) {
      return state.authors[0].authorId !== state.currentAuthor.authorId;
    }
    return false;
  }

  function renderAuthorBar() {
    var bar = document.getElementById('authorBar');
    // 清除文档分支（renderDocumentContent）设置的 inline display:none 残留：
    // 普通页清理块（renderContent）漏列了 authorBar，class=visible 但内联 none 会让
    // 用户筛选条在「访问过文档页后再回普通页」时视觉消失。此处统一复位让 CSS 接管。
    if (bar.style.display) bar.style.display = '';
    state.authors = computeAuthors(state.annotations);
    state.hiddenAuthorIds.clear();

    if (!isMultiAuthor()) {
      bar.className = 'author-bar';
      bar.innerHTML = '';
      return;
    }

    bar.className = 'author-bar visible';
    var html = '<span class="author-bar-label">' + getMessage('mgAuthorFilter') + '</span>';
    state.authors.forEach(function (author) {
      var isSelf = state.currentAuthor && author.authorId === state.currentAuthor.authorId;
      var label = isSelf
        ? (author.authorName ? author.authorName + getMessage('suffixMe') : getMessage('me'))
        : (author.authorName || getMessage('unknownUser'));
      html += '<label class="author-toggle-item' + (isSelf ? ' is-self' : '') + '" data-author-id="' + escapeHtml(author.authorId) + '">';
      html += '<span class="toggle-switch">';
      html += '<input type="checkbox" class="author-toggle-check" data-author-id="' + escapeHtml(author.authorId) + '" checked>';
      html += '<span class="toggle-track"></span>';
      html += '</span>';
      html += '<span class="author-toggle-name">' + escapeHtml(label) + '</span>';
      html += '<span class="author-toggle-count">' + author.count + '</span>';
      html += '</label>';
    });
    bar.innerHTML = html;
  }

  // Get the annotation's Y position offset within its anchor element.
  // Used as secondary sort key when multiple annotations share the same ANCHOR_Y_RATIO.
  function getAnnotationYOffset(a) {
    var ex = a.END_XPATH || '';
    var so = parseInt(a.START_OFFSET) || 0;
    var eo = parseInt(a.END_OFFSET) || 0;

    if (ex === '$pageRect') {
      // START_OFFSET = x_percent * 1000000 + y_offset (percentage)
      var y1 = so % 1000000;
      if (y1 >= 900000) y1 = -(y1 - 900000);
      return y1;
    }
    if (ex === '$pic' || ex === '$imgAnno') {
      // START_OFFSET = x_ratio * 1000 + y_ratio (0-999)
      return so % 1000;
    }
    if (ex === '$arrow' || ex === '$flag') {
      // START_OFFSET = y_pixel_offset (percentage * 1000)
      return so % 1000;
    }
    if (ex === '$picLine') {
      // START_OFFSET = y_pixel_offset
      return so % 1000;
    }
    // For highlight and text: use character offset
    return so;
  }

  // Check if annotation should be grouped into an image group card
  // For rect/arrow/flag/freehand: requires END_TAG_NAME (image URL)
  // For text ($char): END_TAG_NAME may not be set — matched via START_XPATH in buildRenderItems
  function isImageGroupAnnotation(a) {
    var type = getAnnotationType(a);
    if (type === 'rect' || type === 'arrow' || type === 'flag' ||
        type === 'freehand' || type === 'rectFrame') {
      return !!a.END_TAG_NAME && !isVideoUrl(a.END_TAG_NAME);
    }
    // text type: has END_TAG_NAME → direct match; otherwise will try START_XPATH matching
    if (type === 'text') {
      return !!a.END_TAG_NAME || !!a.START_XPATH;
    }
    return false;
  }

  // Group key for image-based annotations — END_TAG_NAME (image URL)
  function getImageGroupKey(a) {
    return a.END_TAG_NAME || '';
  }

  function getAnnotationLabel(type) {
    return (TYPE_MAP[type] || {}).label || type;
  }

  function escapeHtml(str) {
    if (!str) return '';
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // 云端资产读路径（B1）：objectKey → 签名 URL → img.src
  function wpzl_loadCloudAsset(objectKey, imgId) {
    chrome.runtime.sendMessage(
      { type: 'getSignedAssetUrl', objectKey: objectKey },
      function (resp) {
        if (resp && resp.success && resp.signedUrl) {
          var img = document.getElementById(imgId);
          if (img) img.src = resp.signedUrl;
        } else if (resp && resp.error) {
          console.warn('[thumb] sign failed:', resp.error);
        }
      }
    );
  }

  // 判断 src 是否为 R2 objectKey（data:/blob: 锚点图上云后写入 END_TAG_NAME 的 cloudUrl 形如 u/{uid}/{pageKey}/{imageKey}.webp）
  function wpzl_isObjectKeySrc(s) {
    return !!(s && s.indexOf('u/') === 0 && s.indexOf('.webp') > 0);
  }

  // 对 objectKey 签名后赋给指定 <img> 元素（卡片/详情显示 data:/blob: 锚点图用）
  function wpzl_signObjectKeyImg(imgEl, objectKey) {
    if (!imgEl || !objectKey) return;
    chrome.runtime.sendMessage(
      { type: 'getSignedAssetUrl', objectKey: objectKey },
      function (resp) {
        if (resp && resp.success && resp.signedUrl) imgEl.src = resp.signedUrl;
        else if (resp && resp.error) console.warn('[img-objkey] sign failed:', resp.error);
      }
    );
  }

  // imageData 三级回退读图（任务5）：
  //   ① 本地 data 命中 → img.src = data（最快，无网络）
  //   ② 本地无 data 但有 cloudUrl → 优先用原始 URL 显示 + SW 抓取回填 IDB；
  //      失败（onerror 或 SW fetch 失败）→ fallback 到 cloudUrl 签名 URL（限流队列）。
  //   ③ 都无 → 原始 imageUrl 兜底（可能因 CORS/失效而失败，但保留旧行为）
  // localRec 为 null/undefined 时直接走 ③。
  function wpzl_loadImageDataWithFallback(img, pageUrl, imageUrl, localRec, statusEl) {
    if (!img || !imageUrl) return;
    if (localRec && localRec.data) {
      img.src = localRec.data;
      img.dataset.localSaved = 'true';
      return;
    }
    if (localRec && localRec.cloudUrl) {
      // ② 优先用原始 URL 显示 + 回填（不限并发，SW fetch 无 CORS 限制）
      img.src = imageUrl;
      img.dataset.origUrlInflight = 'true';
      // 显示回退：onerror 立即切 cloudUrl（不等 IDB 回填完成）
      img.addEventListener('error', function _onErr() {
        if (img.dataset.origUrlDone === 'true') return; // SW fetch 已成功，无需 fallback
        img.dataset.origUrlError = 'true';
        console.warn('[imgData] <img> load failed for original URL, fallback to cloudUrl:', imageUrl);
        _enqueueCloudUrlBackfill(img, pageUrl, imageUrl, localRec, statusEl, { preferDisplay: true });
      }, { once: true });
      // IDB 回填（独立路径，与显示回退并行）
      _backfillFromOriginalUrl(img, pageUrl, imageUrl, localRec, statusEl);
      return;
    }
    img.src = imageUrl;
  }

  // ②-a 原始 URL 回填 IDB（无并发限制，所有图同时跑）
  // 通过 SW message backfillImageDataFromUrl（SW 端 fetch 绕过 CORS）
  // 失败 fallback 到 cloudUrl 队列（与 onerror 路径去重）
  var _origBackfillInflight = {};
  function _backfillFromOriginalUrl(img, pageUrl, imageUrl, localRec, statusEl) {
    if (!imageUrl || !pageUrl) return;
    var bk = pageUrl + '\x00' + imageUrl;
    if (_origBackfillInflight[bk]) return;
    _origBackfillInflight[bk] = true;

    if (statusEl && img && !img.dataset.origUrlError) {
      statusEl.innerHTML = '<span style="color:#0ea5e9;font-size:13px;">' + getMessage('ivDownloadingOrig') + '</span>';
    }

    // 通过 sendMessage 包装成 {type:'db-operation', operation:'backfillImageDataFromUrl', params}
    // SW 端 case 在 db-operation dispatcher 内部，直接发 type:'backfillImageDataFromUrl' 不会被路由
    sendMessage('backfillImageDataFromUrl', { pageUrl: pageUrl, imageUrl: imageUrl, timeoutMs: 10000 })
      .then(function (data) {
        delete _origBackfillInflight[bk];
        if (data && data.success) {
          if (img) img.dataset.origUrlDone = 'true';
          if (statusEl) {
            statusEl.innerHTML = '<span style="color:#22c55e;font-size:13px;">' + getMessage('ivSavedLocal') + '</span>';
          }
          if (img) {
            getImageData(pageUrl, imageUrl).then(function (rec) {
              if (rec && rec.data && img && img.dataset.localSaved !== 'true') {
                img.src = rec.data;
                img.dataset.localSaved = 'true';
              }
            });
          }
        } else {
          console.warn('[imgData] original URL backfill SW failed:', (data && data.error) || 'unknown');
          if (!img || img.dataset.origUrlError !== 'true') {
            _enqueueCloudUrlBackfill(img, pageUrl, imageUrl, localRec, statusEl, { preferDisplay: true });
          }
        }
      })
      .catch(function (e) {
        // 失败：清标记
        delete _origBackfillInflight[bk];
        console.warn('[imgData] original URL backfill failed, queueing cloudUrl:', (e && e.message) || 'unknown');
        // 仅在 <img> 未单独触发 onerror 时入队（避免双重入队）
        if (!img || img.dataset.origUrlError !== 'true') {
          _enqueueCloudUrlBackfill(img, pageUrl, imageUrl, localRec, statusEl, { preferDisplay: true });
        }
      });
  }

  // ②-b cloudUrl 回填队列：最多 3 个同时进行（保护 R2 流量限额）；fetch 加 15s 超时
  // options.preferDisplay = true 时（来自 onerror 路径），优先用签名 URL 显示（救活 broken image）
  var CLOUD_BACKFILL_CONCURRENCY = 3;
  var CLOUD_BACKFILL_TIMEOUT_MS = 15000;
  var _cloudQueue = [];
  var _cloudActive = 0;
  var _cloudBackfillInflight = {};

  function _enqueueCloudUrlBackfill(img, pageUrl, imageUrl, localRec, statusEl, options) {
    if (!localRec || !localRec.cloudUrl) return;
    var bk = pageUrl + '\x00' + imageUrl;
    if (_cloudBackfillInflight[bk]) return;
    _cloudBackfillInflight[bk] = true;
    _cloudQueue.push({
      img: img, pageUrl: pageUrl, imageUrl: imageUrl,
      localRec: localRec, statusEl: statusEl, bk: bk,
      preferDisplay: !!(options && options.preferDisplay)
    });
    if (statusEl) {
      statusEl.innerHTML = '<span style="color:#0ea5e9;font-size:13px;">' + getMessage('ivCloudSyncing') + '</span>';
    }
    _drainCloudQueue();
  }

  function _drainCloudQueue() {
    while (_cloudActive < CLOUD_BACKFILL_CONCURRENCY && _cloudQueue.length > 0) {
      var job = _cloudQueue.shift();
      _cloudActive++;
      _doCloudBackfill(job);
    }
  }

  function _doCloudBackfill(job) {
    chrome.runtime.sendMessage(
      { type: 'getSignedAssetUrl', objectKey: job.localRec.cloudUrl },
      function (resp) {
        if (!resp || !resp.success || !resp.signedUrl) {
          _finishCloudBackfill(job, false);
          return;
        }
        // 显示优先：preferDisplay 时立刻切签名 URL 显示（不等 fetch blob 完成）
        // 但若 _backfillFromOriginalUrl 已通过 getImageData 设置了本地 data，则不再覆盖
        if (job.preferDisplay && job.img && job.img.dataset.localSaved !== 'true') {
          job.img.src = resp.signedUrl;
        }
        // fetch 签名 URL 加超时（AbortController 15s），用于回填 IDB
        var controller = new AbortController();
        var timer = setTimeout(function () { controller.abort(); }, CLOUD_BACKFILL_TIMEOUT_MS);
        fetch(resp.signedUrl, { signal: controller.signal })
          .then(function (r) { return r.blob(); })
          .then(function (blob) {
            return new Promise(function (resolve, reject) {
              var reader = new FileReader();
              reader.onloadend = function () { resolve(reader.result); };
              reader.onerror = function () { reject(reader.error); };
              reader.readAsDataURL(blob);
            });
          })
          .then(function (b64) {
            chrome.runtime.sendMessage(
              {
                type: 'db-operation',
                operation: 'updateImageDataField',
                params: { pageUrl: job.pageUrl, imageUrl: job.imageUrl, field: 'data', value: b64 }
              },
              function (r2) {
                clearTimeout(timer);
                _finishCloudBackfill(job, !!(r2 && r2.success));
              }
            );
          })
          .catch(function (e) {
            clearTimeout(timer);
            console.warn('[imgData] cloudUrl fetch failed:', e && e.message);
            _finishCloudBackfill(job, false);
          });
      }
    );
  }

  function _finishCloudBackfill(job, success) {
    _cloudActive--;
    if (success) {
      if (job.statusEl) {
        job.statusEl.innerHTML = '<span style="color:#22c55e;font-size:13px;">' + getMessage('ivSavedLocal') + '</span>';
      }
      if (job.img) {
        // 用本地 data 替换 src（脱离签名 URL，更稳定）
        getImageData(job.pageUrl, job.imageUrl).then(function (rec) {
          if (rec && rec.data && job.img) {
            job.img.src = rec.data;
            job.img.dataset.localSaved = 'true';
          }
        });
      }
      // 成功才保留 inflight 标记（避免重复）；下次刷新页面会走 ① 分支
    } else {
      // 失败：清标记，允许下次重试；状态保持"同步中"，依赖 SW 后台 alarm 兜底
      delete _cloudBackfillInflight[job.bk];
    }
    _drainCloudQueue();
  }

  // ③ 自动抓取补存：本地无记录的图，渲染即触发 SW 直 fetch（不绕防盗链，被拒则截图兜底）+ 存本地 + 上云。
  // 与详情手动按钮同逻辑（saveImageFromUrlToSW），只是自动触发；带节流避免同图重复抓。
  // 适用：历史标注创建时 autoSave 关未存图、或本地 IDB 无记录的图，manager 渲染时补存。
  var _imgAutoSaveInflight = {};
  function _autoSaveImageFromOriginalUrl(pageUrl, imageUrl, statusEl, img) {
    if (!imageUrl || !pageUrl) return;
    var bk = pageUrl + '\x00' + imageUrl;
    if (_imgAutoSaveInflight[bk]) return; // 已在自动保存中
    _imgAutoSaveInflight[bk] = true;
    saveImageFromUrlToSW(imageUrl, pageUrl).then(function () {
      // 成功：本地已有记录，刷新状态走①（按钮消失）
      if (statusEl) {
        statusEl.innerHTML = '<span style="color:#22c55e;font-size:13px;">' + getMessage('ivSavedLocal') + '</span>';
      }
      if (img) {
        getImageData(pageUrl, imageUrl).then(function (rec) {
          wpzl_loadImageDataWithFallback(img, pageUrl, imageUrl, rec);
        });
      }
    }).catch(function (e) {
      delete _imgAutoSaveInflight[bk]; // 失败：清除标记，允许下次重试
      console.warn('[imgData] auto-save from original URL failed:', e && e.message);
    });
  }

  // 详情页"保存到本地"按钮绑定（原 openDetailViewer 内联逻辑抽出，三级回退后两个分支共用）
  function _bindDetailSaveBtn(img, pageUrl, imageUrl, statusEl) {
    setTimeout(function () {
      var btn = document.getElementById('detailSaveLocalBtn');
      if (!btn) return;
      btn.addEventListener('click', function () {
        btn.textContent = getMessage('saving');
        btn.disabled = true;
        saveImageFromUrlToSW(imageUrl, pageUrl).then(function () {
          if (statusEl) statusEl.innerHTML = '<span style="color:#22c55e;font-size:13px;">' + getMessage('ivSavedLocal') + '</span>';
          // 更新 img 为本地数据
          getImageData(pageUrl, imageUrl).then(function (rec) {
            wpzl_loadImageDataWithFallback(img, pageUrl, imageUrl, rec);
          });
        }).catch(function (err) {
          var msg = getMessage('savingFailed');
          if (err && err.message) {
            if (err.message.indexOf('fetch') >= 0 || err.message.indexOf('Failed to fetch') >= 0 || err.message.indexOf('NetworkError') >= 0) {
              msg = getMessage('ivSaveFailedNoAccess');
            } else {
              msg = getMessage('savingFailed') + ': ' + err.message;
            }
          }
          btn.textContent = msg;
          btn.title = msg;
          btn.style.borderColor = 'var(--danger)';
          btn.style.color = 'var(--danger)';
          btn.disabled = false;
        });
      });
    }, 0);
  }

  // 本地 thumbnail 读路径（B1）：annId → SW IDB localThumbnails → img.src
  // manager.js 在扩展页面上下文，走 chrome.runtime db-operation 桥（不走 .do 注入桥）
  function wpzl_loadLocalThumbnail(annId, imgId) {
    sendMessage('getLocalThumbnail', { annId: annId })
      .then(function (data) {
        if (data && data.dataURL) {
          var img = document.getElementById(imgId);
          if (img) img.src = data.dataURL;
        }
      })
      .catch(function (e) { console.warn('[thumb] local load failed:', e.message); });
  }

  // pageRect 缩略图统一加载：本地优先（localThumbnails），未命中再走云端签名 / dataUrl。
  // 本机画的图本地有缓存 → 直接命中；跨设备首次本地无 → objectKey 走云端签名；
  // 本地存储的图命中 → 直显；老 dataUrl 数据本地无 → 直显。
  function wpzl_loadPageRectThumb(a, imgId) {
    var annId = a.MARK_INFO_ID;
    // 图片加载完成后用真实位图像素(naturalWidth×naturalHeight)回填「原始像素」标签：
    // 存的 ANCHOR_WIDTH/HEIGHT 是屏幕 CSS 像素，而截图位图按 devicePixelRatio 抓（HiDPI 下 2×），
    // 标签若直接显示 CSS 像素会比真实位图小 DPR 倍。各 dataUrl/objectKey 分支最终都会给 img.src
    // 赋值，统一在 load 后取 natural 值更新；加载失败/无位图则保留原 ANCHOR 值。
    var infoImg = document.getElementById(imgId);
    if (infoImg) {
      var infoId = 'page-rect-info-' + annId;
      var updateInfoFromNatural = function () {
        if (infoImg.naturalWidth && infoImg.naturalHeight) {
          var infoEl = document.getElementById(infoId);
          if (infoEl) infoEl.textContent = getMessage('ivOriginalPixels', [String(infoImg.naturalWidth), String(infoImg.naturalHeight)]);
        }
      };
      infoImg.addEventListener('load', updateInfoFromNatural);
      if (infoImg.complete && infoImg.naturalWidth) updateInfoFromNatural();
    }

    var thumb = a.THUMBNAIL || '';
    // 规范化脏字符串：wpzl_saveAnnotation 提交 ann.THUMBNAIL=null 时 ajax-bridge formatParams
    // 会序列化成字符串 "null" 写入 IDB。把 "null"/"undefined" 当空 → 占位 img + localThumbnails 兜底
    if (thumb === 'null' || thumb === 'undefined') thumb = '';
    var isObjectKey = thumb && thumb.indexOf('u/') === 0 && thumb.indexOf('.webp') > 0;
    var isDataUrl = thumb && thumb.indexOf('data:') === 0;

    function applyFallback() {
      if (isObjectKey) {
        // 本地优先原则：本地未命中 → SW 下载云端图回填 localThumbnails 并返回 dataURL 显示
        // （下次本地命中；SW fetch 绕过注入页 CORS）。失败降级签名 URL 直显。
        sendMessage('backfillThumbnailFromCloud', { annId: annId, objectKey: thumb })
          .then(function (data) {
            if (data && data.dataURL) {
              var img = document.getElementById(imgId);
              if (img) img.src = data.dataURL;
            } else {
              wpzl_loadCloudAsset(thumb, imgId);
            }
          })
          .catch(function () { wpzl_loadCloudAsset(thumb, imgId); });
      } else if (isDataUrl) {
        var img = document.getElementById(imgId);
        if (img) img.src = thumb;
      }
    }

    sendMessage('getLocalThumbnail', { annId: annId })
      .then(function (data) {
        if (data && data.dataURL) {
          var img = document.getElementById(imgId);
          if (img) img.src = data.dataURL;   // 本地命中
        } else {
          applyFallback();                    // 本地未命中 → 云端/dataUrl
        }
      })
      .catch(function () { applyFallback(); });
  }

  // Bug B（同步时区轴统一）：存储时间一律 UTC-naive "yyyy-MM-dd HH:mm:ss"（或 ISO）。
  // 解析时无 T 的 naive 串按 UTC 解析，再经本地 getter 渲染 = 本地墙上钟。
  function parseStoredTime(ts) {
    if (!ts) return new Date(NaN);
    var s = String(ts).trim();
    // 绝对时间（末尾 Z 或显式 ±HH:MM / ±HHMM）→ 按原样解析
    if (/[zZ]$/.test(s) || /[+-]\d{2}:?\d{2}$/.test(s)) {
      if (!/[zZ]$/.test(s) && /[+-]\d{2}$/.test(s)) s = s.slice(0, -2) + ':' + s.slice(-2); // "+0800"→"+08:00"
      return new Date(s);
    }
    // 无时区 naive（空格或 T 分隔、可含毫秒尾）→ 视为 UTC（客户端存 UTC-naive、服务端 LocalDateTime 亦为 UTC）
    var n = s.replace(/\.\d+$/, '').replace('T', ' ');
    if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/.test(n)) return new Date(NaN);
    return new Date(n.replace(' ', 'T') + 'Z');
  }

  function formatTime(ts) {
    if (!ts) return '';
    var d = parseStoredTime(ts);
    if (isNaN(d.getTime())) {
      // 解析失败（历史脏值）回退：naive 串原样截断
      var raw = String(ts);
      if (raw.indexOf('T') < 0) {
        var parts = raw.split(' ');
        if (parts.length >= 2) return parts[0].substring(5) + ' ' + parts[1].substring(0, 5);
      }
      return raw;
    }
    // 始终显示月-日 时:分（本地）
    var monthDay = pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
    var timeStr = pad2(d.getHours()) + ':' + pad2(d.getMinutes());
    return monthDay + ' ' + timeStr;
  }

  function pad2(n) { return n < 10 ? '0' + n : '' + n; }

  // Bug B 展示本地化：存储时间(UTC-naive/ISO) → 本地墙上钟文本（分钟/秒）。解析失败原样返回。
  function _tsMin(ts) {
    var d = parseStoredTime(ts);
    if (!ts || isNaN(d.getTime())) return (ts == null) ? '' : String(ts);
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate())
      + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }
  function _tsSec(ts) {
    var d = parseStoredTime(ts);
    if (!ts || isNaN(d.getTime())) return (ts == null) ? '' : String(ts);
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate())
      + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
  }
  // 仅本地日期（yyyy-MM-dd），用于服务端时间戳轴的列表分组日期
  function _tsDate(ts) {
    var d = parseStoredTime(ts);
    if (!ts || isNaN(d.getTime())) return (ts == null) ? '' : String(ts).substring(0, 10);
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  }

  function getTimeGroup(ts) {
    if (!ts) return 'older';
    var d = parseStoredTime(ts);
    if (isNaN(d.getTime())) return 'older';
    var now = new Date();
    var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var diff = today.getTime() - d.getTime();
    if (diff < 0) return 'today';
    if (diff === 0) return 'today';
    if (diff <= 86400000) return 'yesterday';
    if (diff <= 6 * 86400000) return 'thisWeek';
    return 'older';
  }

  var GROUP_ORDER = ['today', 'yesterday', 'thisWeek', 'older'];
  var GROUP_LABELS = { today: getMessage('grpToday'), yesterday: getMessage('grpYesterday'), thisWeek: getMessage('grpThisWeek'), older: getMessage('grpEarlier') };

  function generateFaviconSvg(domain, kind) {
    if (kind === 'document') {
      // 自建文档：固定文档图标（紫色文档+横线），不用字母色块
      return 'data:image/svg+xml,' + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32">' +
        '<rect width="32" height="32" rx="6" fill="#6366f1"/>' +
        '<path d="M9 4h8l6 6v14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" fill="#fff"/>' +
        '<path d="M17 4v6h6z" fill="#c7d2fe"/>' +
        '<line x1="11" y1="14" x2="19" y2="14" stroke="#6366f1" stroke-width="1.5"/>' +
        '<line x1="11" y1="18" x2="19" y2="18" stroke="#6366f1" stroke-width="1.5"/>' +
        '<line x1="11" y1="22" x2="16" y2="22" stroke="#6366f1" stroke-width="1.5"/>' +
        '</svg>'
      );
    }
    if (kind === 'snapshot') {
      // 网页快照：固定相机图标（青色），与文档图标并列区分
      return 'data:image/svg+xml,' + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32">' +
        '<rect width="32" height="32" rx="6" fill="#0d9488"/>' +
        '<path d="M10 11h3l1.5-2h3L19 11h3a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z" fill="#fff"/>' +
        '<circle cx="16" cy="16.5" r="3.2" fill="#0d9488"/>' +
        '</svg>'
      );
    }
    var letter = (domain ? domain.charAt(0).toUpperCase() : '?');
    var colors = ['#ff3c82','#3c82ff','#82ff3c','#ff823c','#823cff','#3cfff0','#f03c82','#82c83c'];
    var colorIdx = 0;
    for (var i = 0; i < domain.length; i++) colorIdx += domain.charCodeAt(i);
    var bg = colors[colorIdx % colors.length];
    return 'data:image/svg+xml,' + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32">' +
      '<rect width="32" height="32" rx="6" fill="' + bg + '"/>' +
      '<text x="16" y="22" text-anchor="middle" fill="#fff" font-size="16" font-family="sans-serif" font-weight="600">' + letter + '</text>' +
      '</svg>'
    );
  }

  function truncate(str, len) {
    if (!str) return '';
    return str.length > len ? str.slice(0, len) + '...' : str;
  }

  // 页面显示标题：用户自定义（CUSTOM_TITLE）优先于自动抓取的 title。
  // page 可能为 null/undefined；CUSTOM_TITLE 空串视为未设置。
  function displayPageTitle(page) {
    if (!page) return '';
    if (page.CUSTOM_TITLE) return page.CUSTOM_TITLE;
    return page.title || '';
  }

  // ---- 自建文档（Phase 7）----
  // 文档独立于 state.pages：仅以 page-like 视图参与 sidebar 渲染 + selectPage 查找。
  // 不写回 IDB；不参与 refreshPageCounts 的过滤（避免新建无标注文档被误删）、search/export/batch。
  // 把文档页 URL 归一到当前服务端 base：旧文档 webUri 可能是创建时的 https://127.0.0.1（旧 netty
  // proxy 443），而本机 webpz-server 是 http://127.0.0.1:8080，原样打开会连不上。批注按
  // hostname+pathname 绑定（见 content.js wpzlNormalizeWebpath，不含端口/协议），故归一后批注仍命中。
  function _rebaseDocUrl(url, base) {
    if (!base) return url;
    var m = /\/d\/(doc-[^/?#]+)/.exec(url);
    if (m) return base.replace(/\/+$/, '') + '/d/' + m[1];
    var s = /\/snap\/(snap-[^/?#]+)/.exec(url);
    if (s) return base.replace(/\/+$/, '') + '/snap/' + s[1];
    return url;
  }

  // 导出可见链接的 URL 协议修正：/d/doc- 文档页用真实服务端 base 重写（与 openPage 同源），
  // 其余原样返回（普通网页无可信协议源）。base 缺失/非文档页 → 原样，由 mdClickableUrl 补 https:// 兜底。
  function _resolveDocUrlForExport(url, base) {
    return (url && base && /\/d\/doc-/.test(url)) ? _rebaseDocUrl(url, base) : (url || '');
  }

  function docToPageLike(doc, base) {
    var url = _rebaseDocUrl(doc.webUri || '', base);
    return {
      kind: 'document',
      docId: doc.docId,
      url: url,
      webUri: url,   // Phase 9: local-first 刷新用（与 url 同值；url 供 sidebar/selectPage）
      domain: doc.domain || '',
      title: doc.title || '',
      bodyHtml: doc.bodyHtml || '',
      bodyObjectKey: doc.bodyObjectKey || null, // Change 3：本地无 body 但云端有时走 REST 兜底
      FOLDER_ID: doc.folderId || null,
      SORT_ORDER: (typeof doc.sortOrder === 'number') ? doc.sortOrder : null,
      tags: doc.tags || '',   // 分号串（与 annotations.TAGS 同语义）
      pageWidth: doc.pageWidth || '820px',   // 页面宽度：编辑/预览/渲染三视图一致
      isReadOnly: !!doc.isReadOnly,          // 只读文档（只读导入）：详情视图隐藏编辑入口
      FAVORITE: false,
      annotationCount: 0,      // MVP：sidebar badge 显示 0（文档批注在 /d/{docId} 页，详情视图不展开列表）
      lastVisited: doc.updatedAt || '',
      CUSTOM_TITLE: ''
    };
  }

  // P1-8（dbVersion 25）：body 与元数据分仓后，列表（state.documents/snapshots 的 page-like）
  // 不再内联 bodyHtml——需要正文的消费点经此懒加载：优先会话缓存（对象上的 bodyHtml 字段），
  // 未命中走 SW getDocumentBody（docBodies 本地优先 → REST 回拉并落库，之后同会话零网络）。
  // 入参 docLike/snapLike 为 page-like 或原始记录（docId/snapId 在）；返回 bodyHtml（缺失 ''）。
  function ensureDocBody(docLike) {
    if (!docLike || !docLike.docId) return Promise.resolve('');
    if (docLike.bodyHtml && String(docLike.bodyHtml).trim()) return Promise.resolve(docLike.bodyHtml);
    return sendMessage('getDocumentBody', { docId: docLike.docId }).then(function (body) {
      if (body) docLike.bodyHtml = body;   // 会话缓存（镜像详情页既有回填模式）
      return body || '';
    }).catch(function () { return ''; });
  }

  // 快照正文：本地 snapBodies 单体读取（快照无 REST 单体 body 端点——查看走服务端渲染
  // /snap/{snapId}；跨设备快照本就无本地 body，返回 ''，与分仓前导出行为一致）。
  function ensureSnapBody(snapLike) {
    if (!snapLike || !snapLike.snapId) return Promise.resolve('');
    if (snapLike.bodyHtml && String(snapLike.bodyHtml).trim()) return Promise.resolve(snapLike.bodyHtml);
    return sendMessage('getSnapshotBody', { snapId: snapLike.snapId }).then(function (body) {
      if (body) snapLike.bodyHtml = body;
      return body || '';
    }).catch(function () { return ''; });
  }

  // 嗅探快照 bodyHtml 内 <meta name="webpz-snap-type"> 判定精简/完整（真值来源，跨设备一致）。
  // 侧栏渲染频繁，用正则而非 DOMParser（轻量）。无 meta → null（调用方回退 'full'）。
  function _sniffSnapType(bodyHtml) {
    try {
      var m = /<meta\s+name=["']webpz-snap-type["']\s+content=["']([^"']+)["']/i.exec(bodyHtml || '');
      return m ? m[1] : null;
    } catch (e) { return null; }
  }

  // 快照 → 侧栏 page-like（镜像 docToPageLike）。kind='snapshot'，badge 用「快」/「精」字，独立图标。
  function snapshotToPageLike(snap, base) {
    var url = _rebaseDocUrl(snap.webUri || '', base) || (base.replace(/\/+$/, '') + '/snap/' + snap.snapId);
    // 域名显示服务器 host（/snap/{snapId} 所在服务器），而非采集时的源页域名——
    // 快照 URL 在服务器上，显示源域会让人误以为这是源站页面。url 解析失败时回退 snap.domain。
    var serverHost = snap.domain || '';
    try { var _su = new URL(url); if (_su.host) serverHost = _su.host; } catch (e) { /* 保留 snap.domain */ }
    return {
      kind: 'snapshot',
      snapId: snap.snapId,
      url: url,
      webUri: url,
      domain: serverHost,
      title: snap.title || '',
      bodyHtml: snap.bodyHtml || '',
      snapType: snap.snapType || _sniffSnapType(snap.bodyHtml) || 'full',
      sourceUrlMd5: snap.sourceUrlMd5 || '',
      FOLDER_ID: snap.folderId || null,
      SORT_ORDER: (typeof snap.sortOrder === 'number') ? snap.sortOrder : null,
      FAVORITE: false,
      annotationCount: 0,
      lastVisited: snap.updatedAt || '',
      CUSTOM_TITLE: ''
    };
  }

  // 加载文档 + 快照到 state：构建 state.documents / state.snapshots、快照覆盖集合，并从 state.pages
  // 回填带批注快照的批注数与最近访问时间（供侧栏 badge「快·N」与按批注时间排序）。
  // 与渲染解耦：refreshDocuments 调本函数后再 renderSidebar；开机首屏也在首渲前调本函数，确保
  // 首屏已具备快照去重能力——否则 /snap/{snapId} 的 pages 记录会先以普通页闪现，约 2s 后被
  // refreshDocuments 去重为快照条目，用户感知"刷新后条目自动消失"。
  function _loadDocsAndSnapshotsIntoState() {
    return Promise.all([loadAllDocuments(), loadAllSnapshots(), sendMessage('getServerBase')]).then(function (vals) {
      var docs = vals[0] || [];
      var snaps = vals[1] || [];
      var base = vals[2] || '';
      state.documents = docs.map(function (d) { return docToPageLike(d, base); });
      state.snapshots = snaps.map(function (s) { return snapshotToPageLike(s, base); });
      // 快照覆盖集合（供侧栏去重：被快照覆盖的 pages 记录不单列，避免与快照条目重复）
      // _snapSnapPathSet: /snap/{snapId} 路径（路径命中即覆盖，与协议/host 无关，最稳健）
      // _snapSourceMd5Set: 快照源页 urlMd5（源页 stub 的 URL_MD5 与之相等；仅当源页无用户数据时覆盖）
      state._snapSnapPathSet = {};
      state._snapSourceMd5Set = {};
      state.snapshots.forEach(function (s) {
        if (s.url) { var m = /\/snap\/snap-[^\/?#]+/.exec(s.url); if (m) state._snapSnapPathSet[m[0]] = true; }
        if (s.sourceUrlMd5) state._snapSourceMd5Set[s.sourceUrlMd5] = true;
      });
      // 带批注的快照：批注画在 /snap/{snapId} 会生成同 URL 的 pages 记录（其 url_md5 与快照自身不同）。
      // 去重后 pages 记录被快照条目覆盖；此处把批注数与最近访问时间回填到快照条目，使其 badge 显示
      // 「快·N」并按最近批注时间排序靠前，避免被去重为裸「快」后用户感知"批注过的快照消失"。
      if (state.pages && state.pages.length) {
        var _snapAnn = {};  // snapId -> { count, lastVisited }
        state.pages.forEach(function (p) {
          var pm = /\/snap\/(snap-[^\/?#]+)/.exec(p.url || '');
          if (!pm) return;
          var sid = pm[1];
          var c = p.annotationCount || 0;
          var lv = p.lastVisited || p.LAST_VISITED || '';
          if (!_snapAnn[sid]) _snapAnn[sid] = { count: 0, lastVisited: '' };
          if (c > _snapAnn[sid].count) _snapAnn[sid].count = c;
          if (lv && lv > _snapAnn[sid].lastVisited) _snapAnn[sid].lastVisited = lv;  // 同格式 ISO 串可直接比较
        });
        state.snapshots.forEach(function (s) {
          var a = _snapAnn[s.snapId];
          if (!a) return;
          if (a.count > 0) s.annotationCount = a.count;
          if (a.lastVisited && a.lastVisited > (s.lastVisited || '')) s.lastVisited = a.lastVisited;
        });
      }
    });
  }

  // 加载文档 + 快照到 state 并刷新 sidebar（合并视图渲染）。
  // 快照与文档同构（一类实体），侧栏混排；复用 refreshDocuments 的所有调用点，避免遗漏刷新。
  function refreshDocuments() {
    return _loadDocsAndSnapshotsIntoState().then(function () {
      renderSidebar();
    }).catch(function (err) {
      console.error('loadAllDocuments/Snapshots failed:', err);
    });
  }

  // 快照覆盖判断：该 pages 记录是否被某个快照「覆盖」，从而无需在侧栏单列。
  // (1) pages 记录位于某快照自身路径 /snap/{snapId}（在快照页画过批注会生成同 URL pages 记录）→ 由快照条目覆盖。
  // (2) pages 记录是某快照的源页（URL_MD5 命中 snapshot.sourceUrlMd5）且无任何用户数据
  //     （无标注/摘要/收藏/目录/整页批注）→ 由快照条目覆盖；源页若有用户数据则保留（用户在源页本身有操作）。
  function _isPageShadowedBySnapshot(p) {
    if (!p || p.kind === 'document' || p.kind === 'snapshot') return false;
    if (p.url && state._snapSnapPathSet) {
      var m = /\/snap\/snap-[^\/?#]+/.exec(p.url);
      if (m && state._snapSnapPathSet[m[0]]) return true;
    }
    var md5 = p.URL_MD5 || p.urlMd5;
    if (md5 && state._snapSourceMd5Set && state._snapSourceMd5Set[md5]) {
      var hasUserData = (p.annotationCount > 0)
        || (p.summaryBlocks && p.summaryBlocks.length > 0)
        || p.FAVORITE
        || !!getPageFolderId(p)
        || !!(p.PAGE_NOTE);
      if (!hasUserData) return true;
    }
    return false;
  }

  // 取服务端 base（异步，经 SW 消息读 WPZL_SERVER_BASE，单一来源）。供构造文档 webUri。
  function getServerBase() {
    return sendMessage('getServerBase').then(function (b) {
      return b || 'https://app.webnoteshub.com';
    }).catch(function () { return 'https://app.webnoteshub.com'; });
  }
  // 由 base + docId 构造文档 webUri；批注按此 WEB_URI 绑定，须与服务端 /d/{docId} 渲染页同源。
  function composeDocWebUri(base, docId) { return base.replace(/\/+$/, '') + '/d/' + docId; }
  function hostOf(url) { try { return new URL(url).host; } catch (e) { return ''; } }

  // 渲染 summary/page-note blocks（heading/text/image）为 HTML。summary modal 与整页批注展示共用。
  var PAGE_BLOCK_HEADING_STYLES = {
    1: 'font-size:20px;font-weight:700;color:#1e293b;margin:20px 0 8px;padding-bottom:6px;border-bottom:2px solid #e2e8f0;',
    2: 'font-size:17px;font-weight:700;color:#1e293b;margin:16px 0 6px;padding-bottom:4px;border-bottom:1px solid #e2e8f0;',
    3: 'font-size:15px;font-weight:600;color:#334155;margin:12px 0 4px;',
    4: 'font-size:14px;font-weight:600;color:#475569;margin:10px 0 4px;',
    5: 'font-size:13px;font-weight:600;color:#475569;margin:8px 0 4px;',
    6: 'font-size:13px;font-weight:600;color:#64748b;margin:8px 0 4px;'
  };
  function renderSummaryBlocks(blocks) {
    if (!blocks || blocks.length === 0) return '';
    var html = '';
    blocks.forEach(function (block) {
      if (block.type === 'heading') {
        var style = PAGE_BLOCK_HEADING_STYLES[block.level] || PAGE_BLOCK_HEADING_STYLES[3];
        html += '<div style="' + style + '">' + escapeHtml(block.content) + '</div>';
      } else if (block.type === 'text') {
        html += '<div style="font-size:14px;line-height:1.8;color:#334155;white-space:pre-wrap;margin-bottom:10px;">' + escapeHtml(block.content) + '</div>';
      } else if (block.type === 'image') {
        html += '<div style="margin-bottom:12px;"><img src="' + escapeHtml(block.url) + '" style="max-width:100%;border-radius:6px;border:1px solid #e2e8f0;" data-error-hide="true"></div>';
      }
    });
    return html;
  }

  function showToast(msg) {
    var el = document.getElementById('toast');
    el.textContent = msg;
    el.style.display = 'block';
    setTimeout(function () { el.style.display = 'none'; }, 2500);
  }

  // ---- 悬浮提示框（含「不再显示」复选框）----
  // 与页面侧 hint-box.js 行为一致：单槽（同时最多一个）、标题栏拖动、视口钳制；
  // 勾选「不再显示」并关闭后持久化到 chrome.storage.local 键 wpzl_hint_dismissed
  // （{ hintKey: true }，与 bundle 侧共用同键同格式），未勾选直接关闭则下次触发再显示。
  // 现有调用方：H1（新建文档保存成功）/ H2（打开未同步文档），文案走 chrome.i18n。
  var MGR_HINT_DISMISSED_KEY = 'wpzl_hint_dismissed';
  var _mgrHintBoxEl = null;

  function mgrIsHintDismissed(key) {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get([MGR_HINT_DISMISSED_KEY], function (r) {
          void chrome.runtime.lastError;
          var map = (r && r[MGR_HINT_DISMISSED_KEY]) || {};
          resolve(map[key] === true);
        });
      } catch (e) { resolve(false); }
    });
  }

  function mgrDismissHint(key) {
    try {
      chrome.storage.local.get([MGR_HINT_DISMISSED_KEY], function (r) {
        void chrome.runtime.lastError;
        var map = (r && r[MGR_HINT_DISMISSED_KEY]) || {};
        map[key] = true;
        chrome.storage.local.set({ wpzl_hint_dismissed: map }, function () { void chrome.runtime.lastError; });
      });
    } catch (e) { /* ignore */ }
  }

  function _mgrHideHintBox() {
    if (_mgrHintBoxEl && _mgrHintBoxEl.parentNode) _mgrHintBoxEl.parentNode.removeChild(_mgrHintBoxEl);
    _mgrHintBoxEl = null;
  }

  function mgrShowHintBox(key, message) {
    mgrIsHintDismissed(key).then(function (dismissed) {
      if (dismissed) return;
      _mgrHideHintBox();
      var box = document.createElement('div');
      box.className = 'wpzl-hint-box';

      var head = document.createElement('div');
      head.className = 'wpzl-hint-box-head';
      // 品牌标（与页头 logo 同源 icon48.png），让用户知道提示来自本扩展
      var logo = document.createElement('img');
      logo.className = 'wpzl-hint-box-logo';
      logo.src = '../icons/icon48.png';
      logo.alt = '';
      logo.width = 20;
      logo.height = 20;
      var title = document.createElement('span');
      title.className = 'wpzl-hint-box-title';
      title.textContent = getMessage('hintTitle');
      var closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = 'wpzl-hint-box-close';
      closeBtn.title = getMessage('close');
      closeBtn.setAttribute('aria-label', getMessage('close'));
      closeBtn.textContent = '✕';
      head.appendChild(logo);
      head.appendChild(title);
      head.appendChild(closeBtn);

      var body = document.createElement('div');
      body.className = 'wpzl-hint-box-body';
      body.textContent = message;

      var label = document.createElement('label');
      label.className = 'wpzl-hint-box-dismiss';
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      var cbText = document.createElement('span');
      cbText.textContent = getMessage('hintDontShowAgain');
      label.appendChild(cb);
      label.appendChild(cbText);

      box.appendChild(head);
      box.appendChild(body);
      box.appendChild(label);

      closeBtn.addEventListener('click', function () {
        if (cb.checked) mgrDismissHint(key);
        _mgrHideHintBox();
      });

      // 拖动（标题栏，✕ 排除）：首次拖动 right/bottom → left/top 换算；钳制保留至少 60px 宽 / 40px 高在视口内
      head.addEventListener('mousedown', function (e) {
        if (e.target === closeBtn) return;
        e.preventDefault();
        if (isNaN(parseInt(box.style.left, 10))) {
          var rect = box.getBoundingClientRect();
          box.style.left = rect.left + 'px';
          box.style.top = rect.top + 'px';
          box.style.right = 'auto';
          box.style.bottom = 'auto';
        }
        var startX = e.clientX, startY = e.clientY;
        var startLeft = parseInt(box.style.left, 10) || 0;
        var startTop = parseInt(box.style.top, 10) || 0;
        function onMove(e2) {
          var vw = window.innerWidth, vh = window.innerHeight;
          box.style.left = Math.max(0, Math.min(startLeft + (e2.clientX - startX), vw - 60)) + 'px';
          box.style.top = Math.max(0, Math.min(startTop + (e2.clientY - startY), vh - 40)) + 'px';
        }
        function onUp() {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);
        }
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
      });

      document.body.appendChild(box);
      _mgrHintBoxEl = box;
    }).catch(function () { /* ignore */ });
  }

  function copyText(text) {
    try { navigator.clipboard.writeText(text); return true; } catch (e) {}
    try {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(ta);
      ta.select();
      var ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return ok;
    } catch (e2) { return false; }
  }

  function showExportProgress(title) {
    var overlay = document.getElementById('exportProgressOverlay');
    document.getElementById('exportProgressTitle').textContent = title || getMessage('exportInProgress');
    document.getElementById('exportProgressBar').style.width = '0%';
    document.getElementById('exportProgressText').textContent = '';
    overlay.style.display = 'flex';
  }

  function updateExportProgress(current, total) {
    var pct = total > 0 ? Math.round(current / total * 100) : 0;
    document.getElementById('exportProgressBar').style.width = pct + '%';
    document.getElementById('exportProgressText').textContent = current + ' / ' + total;
  }

  function hideExportProgress() {
    document.getElementById('exportProgressOverlay').style.display = 'none';
  }

  // ---- G-2 导入进度（复用导出覆盖层；NDJSON 头无总量 → 隐藏百分比条，仅显示已写入计数） ----
  function showImportProgress() {
    showExportProgress(getMessage('importData'));
    var track = document.querySelector('.export-progress-bar-track');
    if (track) track.style.visibility = 'hidden';
  }
  function updateImportProgress(count) {
    var el = document.getElementById('exportProgressText');
    if (el) el.textContent = getMessage('importInProgress', [String(count)]);
  }
  function hideImportProgress() {
    var track = document.querySelector('.export-progress-bar-track');
    if (track) track.style.visibility = '';
    hideExportProgress();
  }
  // G-2：读每日导入额度（wpzl_pro_cache 现成缓存，SW 写入形状 {data:{limits},cachedAt}；读不到返回 -1 跳过提示）
  function _readDailyImportLimit() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(['wpzl_pro_cache'], function (c) {
          var lim = c && c.wpzl_pro_cache && c.wpzl_pro_cache.data && c.wpzl_pro_cache.data.limits;
          resolve((lim && typeof lim.dailyImportLimit === 'number') ? lim.dailyImportLimit : -1);
        });
      } catch (e) { resolve(-1); }
    });
  }

  // ---- Render Sidebar ----

  // ---- 同步中遮罩：登录后首次同步期间居中显示大字 + 旋转动画，醒目提示 ----
  var _syncOverlay = null;
  function _ensureSyncOverlay() {
    if (_syncOverlay) return _syncOverlay;
    if (!document.getElementById('wpzl-sync-overlay-style')) {
      var style = document.createElement('style');
      style.id = 'wpzl-sync-overlay-style';
      style.textContent = '.wpzl-sync-overlay{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;pointer-events:none;}'
        + '.wpzl-sync-spinner{width:56px;height:56px;border:5px solid #e5e7eb;border-top-color:#ff3c82;border-radius:50%;animation:wpzl-spin .8s linear infinite;margin-bottom:22px;}'
        + '.wpzl-sync-text{font-size:22px;font-weight:600;color:#1e293b;letter-spacing:.5px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;}'
        + '@keyframes wpzl-spin{to{transform:rotate(360deg);}}';
      document.head.appendChild(style);
    }
    _syncOverlay = document.createElement('div');
    _syncOverlay.className = 'wpzl-sync-overlay';
    _syncOverlay.innerHTML = '<div class="wpzl-sync-spinner"></div><div class="wpzl-sync-text">' + getMessage('syncConnecting') + '</div>';
    _syncOverlay.style.display = 'none';
    document.body.appendChild(_syncOverlay);
    return _syncOverlay;
  }
  function _showSyncOverlay() {
    var o = _ensureSyncOverlay();
    // 每次显示时重置文字（上次同步可能已更新为进度文字）
    var textEl = o.querySelector('.wpzl-sync-text');
    if (textEl) textEl.textContent = getMessage('syncConnecting');
    o.style.display = 'flex';
  }
  function _hideSyncOverlay() { if (_syncOverlay) _syncOverlay.style.display = 'none'; }

  // ---- D3：后台下载提示条（左下角；文档 body + 图片 blob 下载进度）----
  // 固定定位、非阻塞；不动 document.body 的 position（硬约束）。镜像 _ensureSyncOverlay 的 CSS 注入模式。
  var _downloadBar = null;
  var _bgPollTimer = null;
  var _bgEmptyStreak = 0;
  var _bgDownloadDismissed = false;   // 用户已关闭提示条：本次会话不再自动弹出（刷新页面后由 _wpzlAfterAuth re-arm）
  function _ensureDownloadBar() {
    if (_downloadBar) return _downloadBar;
    if (!document.getElementById('wpzl-dl-bar-style')) {
      var style = document.createElement('style');
      style.id = 'wpzl-dl-bar-style';
      style.textContent = '.wpzl-dl-bar{position:fixed;bottom:12px;left:12px;z-index:99998;background:#1e293b;color:#fff;padding:8px 14px;border-radius:8px;font-size:13px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.18);pointer-events:auto;max-width:480px;display:none;cursor:default;}'
        + '.wpzl-dl-bar .spin{display:inline-block;width:12px;height:12px;border:2px solid #94a3b8;border-top-color:#ff3c82;border-radius:50%;animation:wpzl-dl-spin .7s linear infinite;vertical-align:middle;margin-right:8px;}'
        + '.wpzl-dl-bar .dl-close{pointer-events:auto;cursor:pointer;margin-left:10px;padding:0 4px;font-size:15px;line-height:1;opacity:.6;border-radius:4px;}'
        + '.wpzl-dl-bar .dl-close:hover{opacity:1;background:rgba(255,255,255,.15);}'
        + '@keyframes wpzl-dl-spin{to{transform:rotate(360deg);}}';
      document.head.appendChild(style);
    }
    _downloadBar = document.createElement('div');
    _downloadBar.className = 'wpzl-dl-bar';
    _downloadBar.setAttribute('abc18980900', '');   // 扩展创建的 DOM，带标记
    _downloadBar.innerHTML = '<span class="spin"></span><span class="wpzl-dl-bar-text">…</span><span class="dl-close" title="' + _escapeHtml(chrome.i18n.getMessage('close') || '关闭') + '">×</span>';
    document.body.appendChild(_downloadBar);
    var _closeBtn = _downloadBar.querySelector('.dl-close');
    if (_closeBtn) _closeBtn.addEventListener('click', _dismissBgDownloadBar);
    return _downloadBar;
  }
  // 用户主动关闭提示条：停轮询、隐藏、置 dismissed 守卫（_applyBgDownloadData/_startBgDownloadWatch 据此跳过）。
  // 仅 _wpzlAfterAuth 初始化时 re-arm，避免同步周期内 progress tick 把关掉的条又弹回来。
  function _dismissBgDownloadBar() {
    _bgDownloadDismissed = true;
    if (_bgPollTimer) { clearInterval(_bgPollTimer); _bgPollTimer = null; }
    if (_downloadBar) _downloadBar.style.display = 'none';
  }
  // 2026-10-04 进度重做：旧 X/Y 分母是"批"作用域（图片 total=本批≤8 每批重置；文档 total 每批
  // 按 due 重算，pull 落地期间持续增长 → 用户实测 7/9→7/12）。新数据形状 {done, remaining, backing}：
  // done=本轮会话累计已下载（单调递增），remaining=IDB 真值实时待下载。显示"已下 X · 待 Y"，
  // 无分母——新数据到达时只有 remaining 变化，不再出现比例回跳。
  function _bgDlRowText(label, k) {
    if (!k || (k.remaining <= 0 && k.done <= 0)) return '';
    if (k.remaining > 0) {
      return label + ' ' + (chrome.i18n.getMessage('bgDlCounts', [String(k.done), String(k.remaining)]) || ('已下 ' + k.done + ' · 待 ' + k.remaining));
    }
    return label + ' ' + (chrome.i18n.getMessage('bgDlDone', [String(k.done)]) || ('已下 ' + k.done + ' · 完成'));
  }
  function _formatBgProgress(d) {
    var parts = [];
    var imgRow = d && d.image ? _bgDlRowText(chrome.i18n.getMessage('bgDownloadImages') || '图片', d.image) : '';
    var docRow = d && d.doc ? _bgDlRowText(chrome.i18n.getMessage('bgDownloadDocs') || '文档', d.doc) : '';
    if (imgRow) parts.push(imgRow);
    if (docRow) parts.push(docRow);
    return parts.length ? ((chrome.i18n.getMessage('bgDownloading') || '正在后台下载') + ' ' + parts.join(' · ')) : '';
  }
  // hover 完整明细（native title，多行）：各类已下/待下/退避中，快照说明（在线渲染不占本地下载）
  function _bgDlTooltip(d) {
    var lines = [chrome.i18n.getMessage('bgDlTipTitle') || '后台下载详情'];
    function row(label, k) {
      if (!k || (k.remaining <= 0 && k.done <= 0)) return;
      var s = (chrome.i18n.getMessage('bgDlTipRow', [label, String(k.done), String(k.remaining)]) || (label + '：已下 ' + k.done + ' · 待下 ' + k.remaining));
      if (k.backing > 0) s += (chrome.i18n.getMessage('bgDlTipBacking', [String(k.backing)]) || '（其中 ' + k.backing + ' 个重试等待中）');
      lines.push(s);
    }
    row(chrome.i18n.getMessage('bgDownloadImages') || '图片', d && d.image);
    row(chrome.i18n.getMessage('bgDownloadDocs') || '文档', d && d.doc);
    lines.push(chrome.i18n.getMessage('bgDlTipSnap') || '快照：在线渲染，无需本地下载');
    if ((d && d.image && d.image.backing > 0) || (d && d.doc && d.doc.backing > 0)) {
      lines.push(chrome.i18n.getMessage('bgDlTipRetryNote') || '重试等待 = 下载失败后退避中，稍后自动重试');
    }
    return lines.join('\n');
  }
  function _applyBgDownloadData(data) {
    if (_bgDownloadDismissed) return;   // 用户已关闭，本次会话不再自动弹出
    var bar = _ensureDownloadBar();
    var text = _formatBgProgress(data);
    if (text) {
      bar.querySelector('.wpzl-dl-bar-text').textContent = text;
      bar.title = _bgDlTooltip(data);   // hover 完整明细
      bar.style.display = 'block';
    } else {
      bar.style.display = 'none';
      bar.title = '';
    }
  }
  function _refreshBgDownloadBar() {
    if (document.hidden) return;   // P1-7：隐藏页不轮询（回前台由 visibilitychange 立即补拉）
    try {
      chrome.runtime.sendMessage({ type: 'bg-download-progress' }, function (r) {
        if (chrome.runtime.lastError) return;   // SW 未就绪，忽略
        var data = r && r.success && r.data;
        _applyBgDownloadData(data);
        if (_formatBgProgress(data)) {
          _bgEmptyStreak = 0;
        } else {
          _bgEmptyStreak++;
          if (_bgEmptyStreak >= 2 && _bgPollTimer) { clearInterval(_bgPollTimer); _bgPollTimer = null; }
        }
      });
    } catch (e) { /* ignore */ }
  }
  function _startBgDownloadWatch() {
    if (_bgDownloadDismissed) return;   // dismissed 后不启轮询（直到刷新页面 re-arm）
    if (_bgPollTimer) return;
    _bgEmptyStreak = 0;
    _refreshBgDownloadBar();
    _bgPollTimer = setInterval(_refreshBgDownloadBar, 2000);   // 2s：与导出门禁同频（SW 侧已 O(清单) 数学 + 1s 缓存）
  }

  // P1-7（2026-10-05）：可见性门控——隐藏时停 2s 轮询（后台标签本就会被 Chrome 节流，主动停更省；
  // 也避免多 manager 页叠加放大 SW 轮询），回前台立即补拉并恢复节奏。空队列时补拉走既有
  // _bgEmptyStreak≥2 自停，不会常驻。
  document.addEventListener('visibilitychange', function () {
    if (_bgDownloadDismissed) return;
    if (document.hidden) {
      if (_bgPollTimer) { clearInterval(_bgPollTimer); _bgPollTimer = null; }
    } else if (_bgPollTimer) {
      _refreshBgDownloadBar();
    } else {
      _startBgDownloadWatch();
    }
  });

  // 侧栏条目 badge 文本：文档「文」；快照「快/精」，带批注则「快·N」（保留类型标记 + 显示批注数，
  // 使带批注的快照一眼可辨、与同源未批注快照区分）；普通页为批注数。page-list 与目录树共用。
  function _badgeTextFor(p) {
    if (!p) return '0';
    if (p.kind === 'document') return getMessage('mgBadgeDoc');
    if (p.kind === 'snapshot') {
      var _st = p.snapType === 'lite' ? getMessage('mgBadgeSnapLite') : getMessage('mgBadgeSnapFull');
      return (p.annotationCount > 0) ? (_st + '·' + p.annotationCount) : _st;
    }
    return (p.annotationCount > 0) ? String(p.annotationCount) : '0';
  }

  function renderSidebar() {
    var listEl = document.getElementById('pageList');
    var emptyEl = document.getElementById('sidebarEmpty');
    var countEl = document.getElementById('totalPageCount');

    // 目录联动过滤：同步页面列表标题/「显示全部」按钮（搜索/收藏模式下也保持）
    updatePageListHeader();

    if (state.searchMode) {
      renderSearchSidebar();
      // Hide folder tree during search
      var ftp = document.getElementById('folderTreePanel');
      if (ftp) ftp.style.display = 'none';
      return;
    }

    // Show folder tree（收藏过滤模式下隐藏目录树，仅展示收藏页面列表）。
    // 即使 folders 为空也保留显示：新建目录/新建文档按钮位于面板头部，若按空集合隐藏会让
    // 新用户/被清空用户找不到创建入口，陷入"无目录→面板隐藏→无法创建→永无目录"死锁。
    // 空集合时由 renderFolderTree 渲染空态提示引导用户点 + 创建。
    var ftp = document.getElementById('folderTreePanel');
    if (ftp && !state.showFavoritesOnly) {
      ftp.style.display = 'flex';
      renderFolderTree();
    } else if (ftp) {
      ftp.style.display = 'none';
    }

    var pages = state.showFavoritesOnly
      ? state.pages.filter(function (p) { return p.FAVORITE === true; })
      : state.pages;

    // 快照覆盖去重：被快照覆盖的 pages 记录（/snap/{snapId} 页 或 无用户数据的源页 stub）不单列，
    // 避免与快照条目重复。所有视图模式均生效；详见 _isPageShadowedBySnapshot。
    if (state._snapSnapPathSet || state._snapSourceMd5Set) {
      pages = pages.filter(function (p) { return !_isPageShadowedBySnapshot(p); });
    }

    // 目录联动过滤（含子孙目录；'' = 未分类）
    if (state.activeFolderId !== null) {
      if (state.activeFolderId === '') {
        pages = pages.filter(function (p) { return !getPageFolderId(p); });
      } else {
        // 防御：目录可能已被删除 → 回退为全部（deleteFolder 后自然收敛）
        var stillExists = state.folders.some(function (f) { return f.id === state.activeFolderId; });
        if (!stillExists) {
          state.activeFolderId = null;
        } else {
          var descIds = getDescendantFolderIds(state.activeFolderId); // 含自身
          pages = pages.filter(function (p) { return descIds.indexOf(getPageFolderId(p)) >= 0; });
        }
      }
    }

    // Phase 7: 合并自建文档（独立 state.documents，按同样目录过滤）
    // 收藏过滤视图不含文档（文档无收藏）；批量模式下也并入，以便选中与批量删除/移动/导出。
    if (!state.showFavoritesOnly) {
      var docs = state.documents.slice();
      if (state.activeFolderId !== null) {
        if (state.activeFolderId === '') {
          docs = docs.filter(function (d) { return !getPageFolderId(d); });
        } else if (state.folders.some(function (f) { return f.id === state.activeFolderId; })) {
          var docDescIds = getDescendantFolderIds(state.activeFolderId);
          docs = docs.filter(function (d) { return docDescIds.indexOf(getPageFolderId(d)) >= 0; });
        }
      }
      // 去重：在 /d/{docId} 页画过批注会生成同 URL 的 pages 记录，侧栏仅保留文档条目
      // （批注仍按该 URL 绑定，在 /d/{docId} 页查看），避免「文档 + 页面」双条目。
      var _docUrlSet = {};
      docs.forEach(function (d) { if (d.url) _docUrlSet[d.url] = true; });
      if (Object.keys(_docUrlSet).length) {
        pages = pages.filter(function (p) { return !_docUrlSet[p.url]; });
      }
      pages = pages.concat(docs);
      // 快照：与文档同构的一类实体，纳入侧栏管理（独立 url /snap/{snapId}，与 pages/docs 无碰撞，无需去重）。
      // 目录联动过滤镜像 docs；state.snapshots 仍由 refreshDocuments() 加载。
      var snaps = state.snapshots.slice();
      if (state.activeFolderId !== null) {
        if (state.activeFolderId === '') {
          snaps = snaps.filter(function (s) { return !getPageFolderId(s); });
        } else if (state.folders.some(function (f) { return f.id === state.activeFolderId; })) {
          var snapDescIds = getDescendantFolderIds(state.activeFolderId);
          snaps = snaps.filter(function (s) { return snapDescIds.indexOf(getPageFolderId(s)) >= 0; });
        }
      }
      pages = pages.concat(snaps);
    }

    countEl.textContent = pages.length;
    if (pages.length > 0) {
      state.awaitingFirstSync = false;
      _hideSyncOverlay();  // 有数据，隐藏同步遮罩
    }

    if (pages.length === 0) {
      listEl.innerHTML = '';
      // 首次同步未完成：居中遮罩（大字 + 旋转动画），隐藏角落 empty；同步完成仍空则显示"无页面"。
      // 仅对有 cloudSync 权限的用户显示——无同步权限的用户不会有数据到来，直接显示"无页面"，
      // 避免空账号长时间停在"正在同步"让人以为也能同步。
      if (state.awaitingFirstSync && _cloudSyncEnabled()) {
        _showSyncOverlay();
        emptyEl.style.display = 'none';
      } else {
        _hideSyncOverlay();
        emptyEl.style.display = 'flex';
        var _emptyP = emptyEl.querySelector('p');
        if (_emptyP) _emptyP.textContent = chrome.i18n.getMessage('noPages') || '暂无标注页面';
        var _emptySvg = emptyEl.querySelector('svg');
        if (_emptySvg) _emptySvg.style.display = '';
      }
      return;
    }
    emptyEl.style.display = 'none';
    _hideSyncOverlay();

    // Sort by lastVisited desc
    pages.sort(function (a, b) {
      return (b.lastVisited || '').localeCompare(a.lastVisited || '');
    });

    // Group by time
    var groups = {};
    GROUP_ORDER.forEach(function (g) { groups[g] = []; });
    pages.forEach(function (p) {
      var g = getTimeGroup(p.lastVisited);
      groups[g].push(p);
    });

    var html = '';
    GROUP_ORDER.forEach(function (g) {
      if (groups[g].length === 0) return;
      html += '<div class="time-group">';
      html += '<div class="time-group-label">' + GROUP_LABELS[g] + '</div>';
      groups[g].forEach(function (p) {
        var isActive = state.currentPage && state.currentPage.url === p.url;
        var isBatchSelected = state.batchSelectedUrls.has(p.url);
        var displayTitle = displayPageTitle(p) || p.domain || p.url || 'Unknown';
        var title = escapeHtml(displayTitle);
        var domain = p.domain || '';
        var itemClasses = 'page-item';
        if (isActive) itemClasses += ' active';
        if (p.kind === 'document') itemClasses += ' page-item-doc';
        if (p.kind === 'snapshot') itemClasses += ' page-item-snapshot';
        if (state.batchMode && isBatchSelected) itemClasses += ' batch-selected';
        html += '<div class="' + itemClasses + '" data-url="' + escapeHtml(p.url) + '" data-domain="' + escapeHtml(domain) + '"' + (p.kind === 'document' ? ' data-kind="document"' : '') + (p.kind === 'snapshot' ? ' data-kind="snapshot"' : '') + '>';
        if (state.batchMode) {
          html += '<input type="checkbox" class="page-item-checkbox" data-url="' + escapeHtml(p.url) + '"' + (isBatchSelected ? ' checked' : '') + '>';
        }
        html += '<img class="page-favicon" src="' + generateFaviconSvg(domain || '?', p.kind) + '" alt="">';
        html += '<div class="page-item-info">';
        html += '<div class="page-item-title" title="' + title + '">' + truncate(title, 36) + '</div>';
        html += '<div class="page-item-domain">' + escapeHtml(domain) + '</div>';
        html += '</div>';
        // 自建文档/网页快照不显示收藏星标；badge 用「文」/「快」标识类型
        if (p.kind !== 'document' && p.kind !== 'snapshot') {
          html += '<span class="page-item-fav' + (p.FAVORITE ? ' active' : '') + '" data-fav-url="' + escapeHtml(p.url) + '" title="' + (p.FAVORITE ? getMessage('favRemove') : getMessage('favAdd')) + '">' + (p.FAVORITE ? '★' : '☆') + '</span>';
        }
        var badgeText = _badgeTextFor(p);
        var badgeCls = (p.kind === 'document' || p.kind === 'snapshot') ? 'page-item-badge badge-summary' : 'page-item-badge';
        html += '<span class="' + badgeCls + '">' + badgeText + '</span>';
        html += '</div>';
      });
      html += '</div>';
    });

    listEl.innerHTML = html;
    // 批量模式下给 list 加 class，触发 checkbox 显示
    listEl.classList.toggle('batch-mode', !!state.batchMode);
  }

  function renderSearchSidebar() {
    var listEl = document.getElementById('pageList');
    var emptyEl = document.getElementById('sidebarEmpty');
    var countEl = document.getElementById('totalPageCount');
    var results = state.searchResults;

    // 自建文档按 title/url/domain/body 匹配搜索词；标签搜索时也纳入含该标签的文档
    // （文档无标注，annotation 命中覆盖不到，单独匹配）。标签与关键词同时存在取 AND。
    var q = (state.searchQuery || '').toLowerCase();
    var activeTag = state.activeTag || '';
    var docMatches = [];
    if (q || activeTag) {
      docMatches = (state.documents || []).filter(function (d) {
        // 标签约束：文档 tags（分号串）包含当前标签即命中（大小写不敏感，与 db.searchByTag 一致）
        if (activeTag) {
          var tagArr = (d.tags && String(d.tags).split(';')) || [];
          var tagHit = tagArr.some(function (t) { return t && t.trim().toLowerCase() === activeTag.toLowerCase(); });
          if (!tagHit) return false;
        }
        // 关键词约束：title/url/domain/body 命中。
        // P1-8 分仓：body 命中改用 SW 侧 searchDocBodies 结果集（bodyText 预计算，规则与旧
        // 本地剥标签搜索一致）；命中集缺失（异常/老 SW）时退化为 title/url/domain 匹配，
        // 不再逐键剥 8MB HTML（旧实现每键正则全量 body，bulktest 库下逐键卡顿）。
        if (q) {
          var bodyHit = !!(state.docBodyHitSet && state.docBodyHitSet.has(d.docId));
          return ((d.title || '').toLowerCase().indexOf(q) >= 0)
            || ((d.url || d.webUri || '').toLowerCase().indexOf(q) >= 0)
            || ((d.domain || '').toLowerCase().indexOf(q) >= 0)
            || bodyHit;
        }
        return true;   // 仅标签约束（无关键词）：标签命中即入选
      });
    }

    // 快照命中：仅关键词匹配 title/url/domain（快照无标签；不扫 bodyHtml——体可达 2MB，逐键扫描会卡顿）
    var snapMatches = [];
    if (q) {
      snapMatches = (state.snapshots || []).filter(function (s) {
        return ((s.title || '').toLowerCase().indexOf(q) >= 0)
          || ((s.url || s.webUri || '').toLowerCase().indexOf(q) >= 0)
          || ((s.domain || '').toLowerCase().indexOf(q) >= 0);
      });
    }

    var totalResults = results.length + docMatches.length + snapMatches.length;
    countEl.textContent = getMessage('mgSearchResultCount', [String(totalResults)]);

    if (totalResults === 0) {
      listEl.innerHTML = '';
      emptyEl.style.display = 'flex';
      emptyEl.querySelector('p').textContent = getMessage('mgNoMatches');
      return;
    }
    emptyEl.style.display = 'none';

    // Group annotation hits by page
    var pageMap = {};
    results.forEach(function (a) {
      var key = a.WEB_URI || '__unknown__';
      if (!pageMap[key]) {
        var pageRecord = state.pages.find(function (p) { return p.url === key; });
        pageMap[key] = { url: a.WEB_URI, domain: a.DOMAIN, title: pageRecord ? displayPageTitle(pageRecord) : '', count: 0, FAVORITE: pageRecord ? !!pageRecord.FAVORITE : false };
      }
      pageMap[key].count++;
    });

    var html = '<div class="time-group">';
    html += '<div class="time-group-label">' + getMessage('mgSearchResults') + '</div>';
    Object.keys(pageMap).forEach(function (key) {
      var p = pageMap[key];
      var isActive = state.currentPage && state.currentPage.url === p.url;
      var domain = p.domain || '';
      html += '<div class="page-item' + (isActive ? ' active' : '') + '" data-url="' + escapeHtml(p.url) + '" data-domain="' + escapeHtml(domain) + '">';
      html += '<img class="page-favicon" src="' + generateFaviconSvg(domain || '?') + '" alt="">';
      html += '<div class="page-item-info">';
      var pTitle = displayPageTitle(p) || p.domain || p.url || 'Unknown';
      html += '<div class="page-item-title" title="' + escapeHtml(pTitle) + '">' + escapeHtml(pTitle) + '</div>';
      html += '<div class="page-item-domain">' + escapeHtml(domain) + '</div>';
      html += '</div>';
      html += '<span class="page-item-fav' + (p.FAVORITE ? ' active' : '') + '" data-fav-url="' + escapeHtml(p.url) + '" title="' + (p.FAVORITE ? getMessage('favRemove') : getMessage('favAdd')) + '">' + (p.FAVORITE ? '★' : '☆') + '</span>';
      html += '<span class="page-item-badge">' + p.count + '</span>';
      html += '</div>';
    });
    // 自建文档命中：文 badge、无星标（点击 selectPage 已支持文档）
    docMatches.forEach(function (d) {
      var dUrl = d.url || d.webUri || '';
      var isActive = state.currentPage && state.currentPage.url === dUrl;
      var domain = d.domain || '';
      var dFullTitle = displayPageTitle(d) || d.title || dUrl || 'Document';
      var dTitle = truncate(dFullTitle, 36);
      html += '<div class="page-item page-item-doc' + (isActive ? ' active' : '') + '" data-url="' + escapeHtml(dUrl) + '" data-domain="' + escapeHtml(domain) + '" data-kind="document">';
      html += '<img class="page-favicon" src="' + generateFaviconSvg(domain || '?', 'document') + '" alt="">';
      html += '<div class="page-item-info">';
      html += '<div class="page-item-title" title="' + escapeHtml(dFullTitle) + '">' + escapeHtml(dTitle) + '</div>';
      html += '<div class="page-item-domain">' + escapeHtml(domain) + '</div>';
      html += '</div>';
      html += '<span class="page-item-badge badge-summary">' + getMessage('mgBadgeDoc') + '</span>';
      html += '</div>';
    });
    // 网页快照命中：快 badge、相机图标、无星标（点击 selectPage 已支持快照）
    snapMatches.forEach(function (s) {
      var sUrl = s.url || s.webUri || '';
      var isActive = state.currentPage && state.currentPage.url === sUrl;
      var domain = s.domain || '';
      var sFullTitle = displayPageTitle(s) || s.title || sUrl || chrome.i18n.getMessage('snapshotUntitled') || '网页快照';
      var sTitle = truncate(sFullTitle, 36);
      html += '<div class="page-item page-item-snapshot' + (isActive ? ' active' : '') + '" data-url="' + escapeHtml(sUrl) + '" data-domain="' + escapeHtml(domain) + '" data-kind="snapshot">';
      html += '<img class="page-favicon" src="' + generateFaviconSvg(domain || '?', 'snapshot') + '" alt="">';
      html += '<div class="page-item-info">';
      html += '<div class="page-item-title" title="' + escapeHtml(sFullTitle) + '">' + escapeHtml(sTitle) + '</div>';
      html += '<div class="page-item-domain">' + escapeHtml(domain) + '</div>';
      html += '</div>';
      html += '<span class="page-item-badge badge-summary">' + _badgeTextFor(s) + '</span>';
      html += '</div>';
    });
    html += '</div>';
    listEl.innerHTML = html;
  }

  // ---- Render Content Panel ----

  function renderContent() {
    var emptyEl = document.getElementById('contentEmpty');
    var pageEl = document.getElementById('contentPage');
    var listEl = document.getElementById('annotationList');
    var filterEmptyEl = document.getElementById('contentFilterEmpty');
    var batchBar = document.getElementById('batchBar');

    if (!state.currentPage) {
      emptyEl.style.display = 'flex';
      pageEl.style.display = 'none';
      return;
    }
    emptyEl.style.display = 'none';
    pageEl.style.display = 'flex';

    // Page header
    var page = state.currentPage;

    // Phase 7: 自建文档分支（标题 + 只读预览 + 批注/编辑按钮；不展开批注列表）
    if (page.kind === 'document') {
      renderDocumentContent(page);
      return;
    }

    // 网页快照分支（标题 + 信息 + 「打开页面」入口；不展开批注列表）
    if (page.kind === 'snapshot') {
      renderSnapshotContent(page);
      return;
    }

    // 普通页面：清除 document 分支可能设的 inline display:none 残留，让 CSS 重新接管
    var _docEditBtn = document.getElementById('docEditBtn'); if (_docEditBtn) _docEditBtn.style.display = 'none';
    var _docTags = document.getElementById('docDetailTags'); if (_docTags) { _docTags.style.display = 'none'; _docTags.innerHTML = ''; }
    var _ftEl = document.getElementById('filterTabs'); if (_ftEl) _ftEl.style.display = '';
    var _sbEl = document.querySelector('.sort-bar'); if (_sbEl) _sbEl.style.display = '';
    _applyGuestOpenBtnState(false);   // 普通网页游客可打开，复位按钮

    document.getElementById('pageFavicon').src = generateFaviconSvg(page.domain || '?');
    document.getElementById('pageTitle').textContent = displayPageTitle(page) || page.domain || page.url || 'Unknown';
    var urlLink = document.getElementById('pageUrl');
    // 显示文本也带端口（与 href 一致；无 port 字段的记录原样显示）
    urlLink.textContent = _applyUrlPort(page.url || '', page.port);
    var _pageScheme = (page.scheme === 'http' || page.scheme === 'https') ? page.scheme : 'https';
    // 身份 url 无端口，非默认端口从 page.port 补（存量记录无此字段则维持原链接行为）
    urlLink.href = page.url ? (_pageScheme + '://' + _applyUrlPort(page.url.replace(/^https?:\/\//, ''), page.port)) : '#';
    _fillPageGenTime(page);

    // Snapshot button（普通网页详情：查看本页快照）
    var snapshotBtn = document.getElementById('snapshotBtn');
    if (snapshotBtn) {
      snapshotBtn.style.display = 'inline-flex';
      _refreshSnapshotBtnState(page.url);
    }

    // Author toggle bar (multi-user)
    renderAuthorBar();

    // 整页批注展示（只读 + 内嵌编辑器入口）。从 state.currentPage.PAGE_NOTE 直接读，
    // 避免额外异步加载（state.pages 来自 getAllPages 全字段）。
    renderPageNoteSection(page);

    // Update filter tab counts
    var typeCounts = {};
    state.annotations.forEach(function (a) {
      var t = getAnnotationType(a);
      typeCounts[t] = (typeCounts[t] || 0) + 1;
    });
    var totalCount = state.annotations.length;
    document.querySelectorAll('.filter-tab').forEach(function (tab) {
      var type = tab.dataset.type;
      var label = tab.getAttribute('data-i18n') ? tab.textContent.replace(/\s*\d+$/, '') : tab.textContent.replace(/\s*\d+$/, '');
      var count = type === 'all' ? totalCount : (typeCounts[type] || 0);
      tab.textContent = '';
      tab.appendChild(document.createTextNode(label + ' '));
      var countSpan = document.createElement('span');
      countSpan.className = 'filter-count';
      countSpan.textContent = count;
      tab.appendChild(countSpan);
    });

    // Filter
    applyFilter();

    // Batch bar
    state.selectedIds.clear();
    batchBar.style.display = 'none';
    document.getElementById('selectAllCheckbox').checked = false;
  }

  // Phase 7: 自建文档详情视图。隐藏批注相关 UI；page-header 显示文档信息 + 编辑按钮；
  // annotationList 区注入只读 HTML 预览。注：manager 页未加载 KaTeX，数学节点以 LaTeX 源显示
  // （仅速览；真实渲染在 /d/{docId} 服务端页）。
  function renderDocumentContent(page) {
    document.getElementById('pageFavicon').src = generateFaviconSvg(page.domain || '?', 'document');
    document.getElementById('pageTitle').textContent = displayPageTitle(page) || chrome.i18n.getMessage('docUntitled') || '未命名文档';
    var urlLink = document.getElementById('pageUrl');
    // 显示文本也带端口（与 href 一致；无 port 字段的记录原样显示）
    urlLink.textContent = _applyUrlPort(page.url || '', page.port);
    urlLink.href = page.url || '#';
    _fillPageGenTime(page);
    _applyGuestOpenBtnState(true);
    // 只读标签条：page.tags 为分号串（docToPageLike 带出），按 ';' split 渲染 chip
    var _tagsBox = document.getElementById('docDetailTags');
    if (_tagsBox) {
      var _tagArr = (page.tags && String(page.tags).split(';').map(function (s) { return s.trim(); }).filter(Boolean)) || [];
      if (_tagArr.length) {
        _tagsBox.innerHTML = _tagArr.map(function (t) {
          return '<span class="doc-detail-tag">' + escapeHtml(t) + '</span>';
        }).join('');
        _tagsBox.style.display = 'flex';
      } else {
        _tagsBox.innerHTML = '';
        _tagsBox.style.display = 'none';
      }
    }
    // 文档渲染页不再把 token 写进 href（GET 会泄漏到 URL/历史/Referer）；href 仅保留 page.url 供
    // 显示/复制，左键点击由 #pageUrl 拦截走 openPage（POST，见 openPageBtn 初始化处注册）。
    // 文档页支持快照（需求：自建文档也可生成/查看快照）
    var _docSnapBtn = document.getElementById('snapshotBtn');
    if (_docSnapBtn) { _docSnapBtn.style.display = 'inline-flex'; _refreshSnapshotBtnState(page.url); }
    var editBtn = document.getElementById('docEditBtn');
    if (editBtn) editBtn.style.display = page.isReadOnly ? 'none' : 'inline-flex';
    // 只读文档：标题后追加「只读」标识，让用户明白为何无编辑入口
    if (page.isReadOnly) {
      document.getElementById('pageTitle').textContent =
        (displayPageTitle(page) || chrome.i18n.getMessage('docUntitled') || '未命名文档') +
        ' (' + (chrome.i18n.getMessage('docReadOnlyBadge') || '只读') + ')';
    }
    // 隐藏批注相关区
    ['pageNoteSection', 'authorBar', 'filterTabs', 'batchBar', 'contentFilterEmpty'].forEach(function (id) {
      var e = document.getElementById(id); if (e) e.style.display = 'none';
    });
    var sb = document.querySelector('.sort-bar'); if (sb) sb.style.display = 'none';
    // 只读预览注入 annotationList
    var listEl = document.getElementById('annotationList');
    // 页面宽度：跟随文档保存的 pageWidth（编辑器工具栏设置）；none = 全宽不留白
    var pw = page.pageWidth || '820px';
    var pwStyle = pw === 'none' ? '' : ('max-width:' + pw + ';');
    var emptyMsg = chrome.i18n.getMessage('docEmptyPreview') || '（空文档，点击「编辑」添加内容）';
    // 把 bodyHtml 写入预览容器（.doc-preview 包装 + 刷新图片/数学渲染）。同步回拉拿到 body 后复用重渲染。
    function applyBody(bodyHtml) {
      var inner = bodyHtml
        ? bodyHtml
        : '<p style="color:#94a3b8;font-size:14px;">' + emptyMsg + '</p>';
      listEl.innerHTML = '<div class="doc-preview" style="' + pwStyle + '">' + inner + '</div>';
      refreshDocPreviewImages(listEl, page.webUri);
      renderDocPreviewMath(listEl);
      enhanceDocPreviewCallouts(listEl);
    }
    // P1-35: 回拉失败占位——红字提示 + 「重试」链接（点击重入 fetch+render 闭包）。
    // 旧逻辑把 SW 吞掉的错误当空 body 渲染「空文档」，R2 瞬时故障被伪装成内容丢失。
    function renderBodyLoadFailed(retryFn) {
      var failMsg = chrome.i18n.getMessage('docBodyLoadFailed') || '文档正文加载失败';
      var retryLabel = chrome.i18n.getMessage('retry') || '重试';
      listEl.innerHTML = '<div class="doc-preview" style="' + pwStyle + '">' +
        '<p abc18980900="aaa" style="color:#ef4444;font-size:14px;">' + failMsg + '</p>' +
        '<a abc18980900="aaa" href="#" style="color:#2563eb;cursor:pointer;font-size:13px;display:inline-block;">' + retryLabel + '</a></div>';
      var retryLink = listEl.querySelector('.doc-preview > a');
      if (retryLink) {
        retryLink.addEventListener('click', function (ev) {
          ev.preventDefault();
          if (typeof retryFn === 'function') retryFn();
        });
      }
    }
    var body = page.bodyHtml && String(page.bodyHtml).trim();
    if (body) {
      applyBody(body);
    } else if (page.docId) {
      // Change 3：本地无 body → getDocumentBody 回拉渲染（先占位「加载中」，拿到后原地重渲染；
      // 回填 state.documents 内存 + 当前 page，不落 IDB 避免触发 bodyDirty 误重传）。
      // 2026-10-14 修复：不能以 bodyObjectKey 为前置条件（曾致本机创建/编辑过的文档详情恒显
      // 「空文档」）——上传成功处理器不回写 key（指望下载合并回填），而本机创建的记录在下载
      // 合并里被 pull-loop guard / _isServerNewer 跳过（SERVER_UPDATE_TIME 本地墙钟 vs 服务端
      // DTO UTC 差 8h），key 长期为 null。与 openDocEditor 同口径（见下方 openDocEditor 注释）：
      // 先本地 docBodies 直读（未同步/本机文档的 body 只在本地）；仅云端确有 key 才允许 REST
      // 回拉——无 key 且本地无 body 的纯空文档保持「空文档」占位，不误报加载失败（localOnly）。
      var _detailDocId = page.docId;
      var _detailPageUrl = page.url;
      var _detailLocalOnly = !page.bodyObjectKey;
      var _fetchAndRenderBody = function () {
        applyBody('<p style="color:#94a3b8;font-size:14px;">' + (chrome.i18n.getMessage('docDetailLoading') || '正在加载文档正文…') + '</p>');
        sendMessage('getDocumentBody', { docId: _detailDocId, localOnly: _detailLocalOnly }).then(function (fetched) {
          // race 守护：用户已切到别的页面则不覆盖当前 DOM
          if (!state.currentPage || state.currentPage.url !== _detailPageUrl) return;
          if (fetched === null) { renderBodyLoadFailed(_fetchAndRenderBody); return; }
          var fb = fetched && String(fetched).trim();
          applyBody(fb || '');
          if (fb) {
            var _bd = (state.documents || []).find(function (x) { return x.docId === _detailDocId; });
            if (_bd) _bd.bodyHtml = fetched;   // 回填内存，同会话避免重复回拉
            page.bodyHtml = fetched;            // 当前页对象也更新，避免本会话内重复触发
          }
        }).catch(function () {
          if (!state.currentPage || state.currentPage.url !== _detailPageUrl) return;
          renderBodyLoadFailed(_fetchAndRenderBody);   // 回拉失败（离线/网络）→ 失败占位+可重试
        });
      };
      _fetchAndRenderBody();
    } else {
      applyBody('');
    }
  }

  // 网页快照详情视图（镜像 renderDocumentContent，但不渲染 body 预览——快照是完整网页 HTML，
  // 内联渲染会污染 manager 布局；仅显示信息，openPageBtn 复用为「打开 /snap/{snapId} 批注页」入口）。
  // 网页快照详情视图。快照 bodyHtml 是完整网页，不在 manager 内联渲染（会污染布局）；
  // 但快照的批注（绑定在 /snap/{snapId}）需在此展示为标注卡片列表（与普通页批注渲染一致）。
  // openPageBtn 复用为「打开 /snap/{snapId} 批注页」入口（在快照页上可视化地看/画标注）。
  function renderSnapshotContent(page) {
    document.getElementById('pageFavicon').src = generateFaviconSvg(page.domain || '?', 'snapshot');
    document.getElementById('pageTitle').textContent = displayPageTitle(page) || chrome.i18n.getMessage('snapshotUntitled') || '网页快照';
    var urlLink = document.getElementById('pageUrl');
    // 显示文本也带端口（与 href 一致；无 port 字段的记录原样显示）
    urlLink.textContent = _applyUrlPort(page.url || '', page.port);
    urlLink.href = page.url || '#';
    _fillPageGenTime(page);
    _applyGuestOpenBtnState(true);
    // 快照无快照按钮/文档编辑/整页批注；隐藏。openPageBtn 保留。
    ['snapshotBtn', 'docEditBtn'].forEach(function (id) {
      var e = document.getElementById(id); if (e) e.style.display = 'none';
    });
    var _docTags = document.getElementById('docDetailTags'); if (_docTags) { _docTags.style.display = 'none'; _docTags.innerHTML = ''; }
    ['pageNoteSection'].forEach(function (id) { var e = document.getElementById(id); if (e) e.style.display = 'none'; });
    // 展示该快照的批注列表：显示筛选 tabs + authorBar + sort-bar（复用普通页批注渲染管线）
    ['filterTabs', 'authorBar'].forEach(function (id) { var e = document.getElementById(id); if (e) e.style.display = ''; });
    var sb = document.querySelector('.sort-bar'); if (sb) sb.style.display = '';
    // 批注计数 + 筛选 tab 渲染（镜像普通页 renderContent 尾段）
    var typeCounts = {};
    state.annotations.forEach(function (a) {
      var t = getAnnotationType(a);
      typeCounts[t] = (typeCounts[t] || 0) + 1;
    });
    var totalCount = state.annotations.length;
    document.querySelectorAll('.filter-tab').forEach(function (tab) {
      var type = tab.dataset.type;
      var label = tab.getAttribute('data-i18n') ? tab.textContent.replace(/\s*\d+$/, '') : tab.textContent.replace(/\s*\d+$/, '');
      var count = type === 'all' ? totalCount : (typeCounts[type] || 0);
      tab.textContent = '';
      tab.appendChild(document.createTextNode(label + ' '));
      var countSpan = document.createElement('span');
      countSpan.className = 'filter-count';
      countSpan.textContent = count;
      tab.appendChild(countSpan);
    });
    applyFilter();  // 渲染批注卡片到 #annotationList；无批注时由 renderAnnotationCards 显示 contentFilterEmpty 空态
    // 批量条复位
    state.selectedIds.clear();
    var _batchBar = document.getElementById('batchBar'); if (_batchBar) _batchBar.style.display = 'none';
    var _allChk = document.getElementById('selectAllCheckbox'); if (_allChk) _allChk.checked = false;
  }

  // Phase 9: doc-preview 图片 local-first 刷新（img[data-image-key] → getImageDataByPageAndKey → signAsset / data 兜底）
  function refreshDocPreviewImages(container, webUri) {
    var imgs = container.querySelectorAll('img[data-image-key]');
    Array.prototype.forEach.call(imgs, function (img) {
      var imageKey = img.getAttribute('data-image-key');
      if (!imageKey) return;
      sendMessage('getImageDataByPageAndKey', { pageUrl: webUri, imageKey: imageKey }).then(function (rec) {
        if (rec && rec.data) {
          // ① 本地 data 命中 → 直显（零网络：不打签名接口、不访问 R2）
          img.src = rec.data;
        } else if (rec && rec.cloudUrl) {
          // ② 本地无 data 但已上云 → 签名 URL 显示（本地优先，云端兜底）
          return sendMessage('signAsset', { objectKey: rec.cloudUrl }).then(function (sr) {
            if (sr && sr.signedUrl) img.src = sr.signedUrl;
          });
        }
      }).catch(function () {});
    });
  }

  // —— KaTeX 懒加载（详情页只读渲染数学）——
  // doc-editor.js 把 KaTeX 打进编辑器 bundle（~400KB+），详情页只读场景不复用编辑器 bundle，
  // 单独懒加载 katex.min.js（~270KB）+ katex.min.css。失败则保留 .math-inline/.math-display 的
  // CSS 兜底（紫色斜体显示 LaTeX 源），不阻断详情页。
  var _katexLoaded = false;
  var _katexLoading = null;
  function ensureKaTeX() {
    if (_katexLoaded && window.katex) return Promise.resolve();
    if (_katexLoading) return _katexLoading;
    _katexLoading = new Promise(function (resolve, reject) {
      if (!document.getElementById('wpzl-katex-css')) {
        var l = document.createElement('link');
        l.id = 'wpzl-katex-css'; l.rel = 'stylesheet'; l.href = 'katex/katex.min.css';
        document.head.appendChild(l);
      }
      if (window.katex) { _katexLoaded = true; _katexLoading = null; return resolve(); }
      var s = document.createElement('script');
      s.src = 'katex/katex.min.js';
      s.onload = function () {
        if (window.katex) { _katexLoaded = true; _katexLoading = null; resolve(); }
        else { _katexLoading = null; reject(new Error('katex global missing after load')); }
      };
      s.onerror = function () { _katexLoading = null; reject(new Error('load katex.min.js failed')); };
      document.head.appendChild(s);
    });
    return _katexLoading;
  }

  // doc-preview 数学节点只读渲染：.math-inline / .math-display（带 data-latex）→ katex.render。
  // 无数学节点时直接跳过（不触发 ensureKaTeX，避免无谓下载）。幂等：已渲染的跳过。
  function renderDocPreviewMath(container) {
    var nodes = container.querySelectorAll('.math-inline, .math-display');
    if (nodes.length === 0) return;
    ensureKaTeX().then(function () {
      Array.prototype.forEach.call(nodes, function (el) {
        if (el.classList.contains('math-rendered')) return;
        var latex = el.getAttribute('data-latex') || '';
        var displayMode = el.classList.contains('math-display');
        try {
          window.katex.render(latex, el, { displayMode: displayMode, throwOnError: false });
          el.classList.add('math-rendered');
        } catch (e) { /* 渲染异常：保留 CSS 兜底（原始 LaTeX 源） */ }
      });
    }).catch(function () { /* KaTeX 加载失败：保留 CSS 兜底 */ });
  }

  // doc-preview Obsidian callout 增强（客户端版，与服务端 HtmlSanitizer.enhanceCallouts 同规则）：
  // 块引用首段以字面 [!type] 开头 → 加 wpz-callout / wpz-callout-{type} class 供 CSS 上色。
  // manager 预览用本地 bodyHtml（未经服务端消毒），故需客户端补这一趟。仅加 class，不动 DOM。
  function enhanceDocPreviewCallouts(container) {
    var bqs = container.querySelectorAll('blockquote');
    Array.prototype.forEach.call(bqs, function (bq) {
      if (bq.classList.contains('wpz-callout')) return;
      var firstP = null;
      for (var i = 0; i < bq.children.length; i++) {
        if (bq.children[i].nodeName.toUpperCase() === 'P') { firstP = bq.children[i]; break; }
      }
      if (!firstP) return;
      var m = /^\[!([A-Za-z][\w-]*)\]/.exec((firstP.textContent || '').trim());
      if (!m) return;
      var type = m[1].toLowerCase().replace(/[^a-z0-9-]/g, '');
      if (!type) return;
      bq.classList.add('wpz-callout');
      bq.classList.add('wpz-callout-' + type);
    });
  }

  // ---- Phase 7: 文档编辑器 overlay 控制 ----
  var _docEditorLoaded = false;
  var _docEditorEditingDocId = null;
  var _docEditorWebUri = '';        // Phase 8：mount 前算好，图片云链路 pageKey = md5(docWebUri)
  var _docEditorCurrentTags = [];   // 文档标签（与标注标签同语义：分号串；编辑期内存态）
  var _docEditorAllTags = [];       // 标签字典（getAllTags，与标注共用 tags store）
  var _docEditorTagWired = false;   // 标签输入框事件只绑一次
  var _docEditorImportedTitle = ''; // 记住「上次导入文件时填入的标题」。连续导入时，若当前标题仍等于此值
                                    // （说明用户未手改）则跟随更新为新文件名；一旦用户手动编辑过标题就不再覆盖。

  function generateDocId() {
    try { return 'doc-' + crypto.randomUUID(); } catch (e) {
      return 'doc-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
    }
  }

  // 懒注入 doc-editor.js（once flag）；manager.js 顶层绝不 import 编辑器（懒加载硬约束）。
  function ensureDocEditorScript() {
    if (window.WPZL_docEditor) return Promise.resolve();
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = 'doc-editor.js';
      s.onload = function () {
        _docEditorLoaded = true;
        window.WPZL_docEditor ? resolve() : reject(new Error('WPZL_docEditor missing'));
      };
      s.onerror = function () { reject(new Error('load doc-editor.js failed')); };
      document.head.appendChild(s);
    });
  }

  // 目录下拉（含「未分类」，扁平缩进）
  function populateDocFolderSelect(selectedFolderId) {
    var sel = document.getElementById('docEditorFolderSelect');
    if (!sel) return;
    var html = '<option value="">' + (chrome.i18n.getMessage('folderUncategorized') || '未分类') + '</option>';
    (function walk(parentId, depth) {
      state.folders.filter(function (f) { return f.parentId === parentId; })
        .sort(function (a, b) { return (a.order || 0) - (b.order || 0); })
        .forEach(function (f) {
          var indent = new Array(depth + 1).join('  ');
          html += '<option value="' + escapeHtml(f.id) + '"' + (f.id === selectedFolderId ? ' selected' : '') + '>' + indent + escapeHtml(f.name) + '</option>';
          walk(f.id, depth + 1);
        });
    })(null, 0);
    sel.innerHTML = html;
  }

  function openDocEditor(opts) {
    opts = opts || {};
    // 只读文档（只读导入）不可编辑：防御性拦截（即便绕过隐藏的编辑按钮也不 mount 编辑器）
    if (opts.docId) {
      var _ro = (state.documents || []).find(function (x) { return x.docId === opts.docId; });
      if (_ro && _ro.isReadOnly) {
        showToast(chrome.i18n.getMessage('docReadOnlyCannotEdit') || '该文档为只读文档，不可编辑');
        return;
      }
    }
    var docId = opts.docId || generateDocId();   // 新建先生成（mount 即用，图片 pageKey 依赖 webUri）
    _docEditorEditingDocId = docId;
    var overlay = document.getElementById('docEditorOverlay');
    var host = document.getElementById('docEditorHost');
    var titleInput = document.getElementById('docEditorTitleInput');
    var initialHtml = '<p></p>';
    var initialFolder = (opts.folderId != null) ? opts.folderId : null;
    var needBodyFetch = false;   // 本地无 body（仅从其它设备同步过来的文档）→ 经 REST 从 R2 回拉
    if (opts.docId) {   // 编辑已有
      var doc = (state.documents || []).find(function (d) { return d.docId === opts.docId; });
      if (doc) {
        titleInput.value = doc.title || '';
        _docEditorImportedTitle = '';   // 打开已有文档：标题来自文档记录而非导入，清导入名基准
        initialHtml = doc.bodyHtml || '<p></p>';
        // P1-8 分仓：列表不再内联 body——会话缓存空即回拉（SW getDocumentBody 本地 docBodies
        // 优先 → REST 兜底；未同步文档的 body 只在本地，故不再以 bodyObjectKey 为前置条件）
        needBodyFetch = !doc.bodyHtml || !String(doc.bodyHtml).trim();
        initialFolder = doc.FOLDER_ID || null;
        opts.docPageWidth = doc.pageWidth || null;   // 编辑已有文档：恢复保存的页面宽度
        var _tagSrc = doc.tags ? String(doc.tags).split(';') : [];
        _docEditorCurrentTags = _tagSrc.map(function (s) { return s.trim(); }).filter(Boolean);
      } else {
        _docEditorCurrentTags = [];
      }
    } else {
      titleInput.value = '';
      _docEditorImportedTitle = '';   // 新建文档：标题为空，清导入名基准
      _docEditorCurrentTags = [];
    }
    var _tagInput = document.getElementById('docEditorTagInput');
    if (_tagInput) _tagInput.value = '';
    docEditorRenderTagChips();
    _wireDocEditorTagInput();
    getAllTags().then(function (tags) { _docEditorAllTags = tags || []; })
      .catch(function () { _docEditorAllTags = []; });
    populateDocFolderSelect(initialFolder);
    // Phase 8：mount 前算 webUri（图片云链路 pageKey = md5(docWebUri)，编辑期间粘贴图片即用）
    getServerBase().then(function (base) {
      _docEditorWebUri = composeDocWebUri(base, docId);
      overlay.style.display = 'flex';
      if (!needBodyFetch) return ensureDocEditorScript();
      // 本地无 body：经 SW 从服务端 R2 回拉（owner JWT 鉴权），编辑器无感载入。
      // 回填 state.documents 内存（同会话避免重复回拉；不落 IDB，避免触发 bodyDirty 误重传）。
      // P1-35: SW 失败回传 null——显式 toast 提示（键已补入三语），不再与"空 body"混同静默。
      return sendMessage('getDocumentBody', { docId: docId }).then(function (body) {
        if (body === null) {
          showToast(chrome.i18n.getMessage('docEditorBodyLoadFailed') || '未能加载文档正文（离线或网络异常），请连网后重试');
          return ensureDocEditorScript();
        }
        if (body) {
          initialHtml = body;
          var _bd = (state.documents || []).find(function (x) { return x.docId === docId; });
          if (_bd) _bd.bodyHtml = body;
        }
        return ensureDocEditorScript();
      }).catch(function () {
        // 回拉失败（离线/网络）不阻塞编辑器：兜底 <p></p>，提示用户本次未取到正文
        showToast(chrome.i18n.getMessage('docEditorBodyLoadFailed') || '未能加载文档正文（离线或网络异常），请连网后重试');
        return ensureDocEditorScript();
      });
    }).then(function () {
      window.WPZL_docEditor.mount(host, {
        initialHtml: initialHtml,
        docWebUri: _docEditorWebUri,
        initialPageWidth: opts.docPageWidth || null,
        onSave: handleDocEditorSave,
        onCancel: requestCloseDocEditor
      });
      // 从图片新建：mount 完成后批量导入（编辑器已就绪，无竞态）。
      // 新建文档标题为空且 _docEditorImportedTitle 已清 → _maybeAutoFillDocTitle 门控必过。
      if (opts.initialImageFiles && opts.initialImageFiles.length) {
        _importEditorImages(opts.initialImageFiles);
      }
      setTimeout(function () { if (titleInput) titleInput.focus(); }, 50);
    }).catch(function (e) {
      showToast((chrome.i18n.getMessage('docEditorLoadFailed') || '编辑器加载失败') + ': ' + e.message);
      closeDocEditor();
    });
  }

  function closeDocEditor() {
    var overlay = document.getElementById('docEditorOverlay');
    if (overlay) overlay.style.display = 'none';
    if (window.WPZL_docEditor) { try { window.WPZL_docEditor.destroy(); } catch (e) {} }
    _docEditorEditingDocId = null;
    var _tagInput = document.getElementById('docEditorTagInput');
    if (_tagInput) _tagInput.value = '';
    _docEditorCurrentTags = [];
    docEditorRenderTagChips();
    docEditorHideTagDropdown();
  }

  // #4：关闭编辑器统一入口（× 按钮 / Esc / Cancel 共用）。有未保存改动时先确认；
  // 关闭后回到该文档详情视图并刷新为最新内容（保存已不再自动关闭编辑器）。
  function requestCloseDocEditor() {
    var webUri = _docEditorWebUri;
    var dirty = (window.WPZL_docEditor && typeof window.WPZL_docEditor.isDirty === 'function')
      ? window.WPZL_docEditor.isDirty() : false;
    if (dirty && !confirm(chrome.i18n.getMessage('docUnsavedCloseConfirm') || '有未保存的修改，确定关闭？')) {
      return;   // 用户取消，留在编辑器
    }
    closeDocEditor();
    if (webUri) selectPage(webUri, hostOf(webUri));   // 刷新详情视图为最新内容
  }

  // ---- 文档标签（与标注标签 UX 一致：chip 展示 + 输入框可选拉取字典/输入新标签）----
  // 复用标注的 tags IDB store（keyPath=name，按 USER_ID 隔离），故文档与标注共享同一字典。
  function docEditorRenderTagChips() {
    var chipsEl = document.getElementById('docEditorTagChips');
    if (!chipsEl) return;
    chipsEl.innerHTML = '';
    _docEditorCurrentTags.forEach(function (tag) {
      var chip = document.createElement('span');
      chip.className = 'doc-editor-tag-chip';
      var label = document.createElement('span');
      label.textContent = tag;
      label.style.overflow = 'hidden';
      label.style.textOverflow = 'ellipsis';
      var remove = document.createElement('span');
      remove.className = 'doc-editor-tag-chip-remove';
      remove.textContent = '×';
      remove.addEventListener('click', function () {
        var idx = _docEditorCurrentTags.indexOf(tag);
        if (idx >= 0) _docEditorCurrentTags.splice(idx, 1);
        docEditorRenderTagChips();
      });
      chip.appendChild(label);
      chip.appendChild(remove);
      chipsEl.appendChild(chip);
    });
  }

  function docEditorHideTagDropdown() {
    var dropdown = document.getElementById('docEditorTagDropdown');
    if (dropdown) dropdown.classList.remove('show');
  }

  function docEditorRenderTagDropdown(filter) {
    var dropdown = document.getElementById('docEditorTagDropdown');
    if (!dropdown) return;
    var f = (filter || '').trim().toLowerCase();
    var candidates = (_docEditorAllTags || []).filter(function (t) {
      var name = (t && t.name) || '';
      if (!name) return false;
      if (_docEditorCurrentTags.indexOf(name) >= 0) return false;  // 排除已选
      return f ? name.toLowerCase().indexOf(f) >= 0 : true;
    });
    // 按 lastUsed 倒序（最近用过优先），与标注面板一致；lastUsed 可能为数值时间戳或日期串
    candidates.sort(function (a, b) {
      var la = a.lastUsed, lb = b.lastUsed;
      if (la == null && lb == null) return 0;
      if (la == null) return 1;
      if (lb == null) return -1;
      return lb > la ? 1 : (lb < la ? -1 : 0);
    });
    candidates = candidates.slice(0, 10);
    dropdown.innerHTML = '';
    if (candidates.length === 0) {
      docEditorHideTagDropdown();
      return;
    }
    candidates.forEach(function (t) {
      var item = document.createElement('div');
      item.className = 'doc-editor-tag-dropdown-item';
      item.textContent = t.name;
      // mousedown 而非 click：先于 input blur 触发，避免失焦收起下拉后再选中
      item.addEventListener('mousedown', function (e) {
        e.preventDefault();
        docEditorAddTag(t.name);
        var input = document.getElementById('docEditorTagInput');
        if (input) { input.value = ''; input.focus(); }
        docEditorRenderTagDropdown('');
      });
      dropdown.appendChild(item);
    });
    dropdown.classList.add('show');
  }

  function docEditorAddTag(tagName) {
    var name = (tagName || '').trim();
    if (!name) return;
    if (name.indexOf(';') >= 0) {   // ';' 为分隔符，禁止出现
      showToast(chrome.i18n.getMessage('tagsValidationError') || '标签不能包含分号');
      return;
    }
    if (_docEditorCurrentTags.indexOf(name) >= 0) return;  // 去重
    _docEditorCurrentTags.push(name);
    docEditorRenderTagChips();
    saveTag(name).catch(function () {});   // 存入共享字典，供后续自动补全
  }

  function docEditorConfirmTagInput() {
    var input = document.getElementById('docEditorTagInput');
    if (!input) return;
    var val = (input.value || '').trim();
    if (val) {
      docEditorAddTag(val);
      input.value = '';
    }
    docEditorHideTagDropdown();
  }

  // 标签输入框事件只绑一次（输入框为静态 DOM，不随编辑器开关重建）
  function _wireDocEditorTagInput() {
    if (_docEditorTagWired) return;
    var input = document.getElementById('docEditorTagInput');
    if (!input) return;
    _docEditorTagWired = true;
    input.addEventListener('input', function () { docEditorRenderTagDropdown(input.value); });
    input.addEventListener('focus', function () { docEditorRenderTagDropdown(input.value); });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.keyCode === 13) {
        e.preventDefault();
        docEditorConfirmTagInput();
      } else if ((e.key === 'Backspace' || e.keyCode === 8) && !(input.value || '').length && _docEditorCurrentTags.length) {
        _docEditorCurrentTags.pop();   // 空输入按退格删最后一个标签
        docEditorRenderTagChips();
      }
    });
    input.addEventListener('blur', function () {
      // 延迟以允许下拉项 mousedown 先触发；失焦时把残留文本加为标签（与标注一致）
      setTimeout(function () {
        docEditorConfirmTagInput();
        docEditorHideTagDropdown();
      }, 150);
    });
  }

  // 等级限额强制（创建文档时）：单文档大小 docSizeLimit、每日新建数 docLimit。
  // 约定同服务端：-1=不限制；0=不可用→拒；正数=上限。limits 未加载时按不限制处理（服务端同步仍权威）。
  // 返回 Promise<null|errorMsg>。
  // 当前登录账号 id（wpzl_auth 权威源，与 SW 侧 _currentUid 同源）。取不到返回 ''，
  // 调用方须按"不过滤"处理——绝不因读不到身份而误判额度。
  function _getAuthUid() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(['wpzl_auth'], function (r) {
          var a = r && r.wpzl_auth;
          resolve(a && a.user && a.user.id != null ? String(a.user.id) : '');
        });
      } catch (e) { resolve(''); }
    });
  }

  function _todayDatePrefix() {
    var d = new Date();
    var mm = String(d.getMonth() + 1).padStart(2, '0');
    var dd = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + mm + '-' + dd;
  }

  function _enforceDocQuota(html, docId) {
    var lim = state.limits || {};
    var sizeLimit = (lim.docSizeLimit != null) ? Number(lim.docSizeLimit) : -1;
    var dailyLimit = (lim.docLimit != null) ? Number(lim.docLimit) : -1;
    var bodyLen = (html || '').length;
    var isExisting = !!(docId && (state.documents || []).some(function (d) { return d.docId === docId; }));

    // 1) 0=不可用：当前等级不允许创建文档
    if (sizeLimit === 0 || dailyLimit === 0) {
      return Promise.resolve(getMessage('docFeatureUnavailable'));
    }
    // 2) 单文档大小（正数上限）——P2-15 双段判定：
    //    a. raw ≤ limit → 消毒只缩不涨，服务端必过，直接放行（省一次往返）；
    //    b. raw > limit → raw 口径偏严（服务端按消毒后长度计量），调服务端 size-check
    //       拿同口径（HtmlSanitizer.sanitize → length）精确判定，消除误拒；
    //    c. 端点失败（网络/服务端）→ 保守拦截：放行会把必然失败的保存推到 sync 才被拒，
    //       文档进 EXHAUSTED 队列、用户产生已保存错觉，需手动复位。
    var sizeCheckPromise;
    if (sizeLimit > 0 && bodyLen > sizeLimit) {
      if (state.isLoggedIn) {
        sizeCheckPromise = sendDirectMessage('doc-size-check', { html: html }).then(function (r) {
          if (!r || typeof r.length !== 'number') return { exceeded: true, networkError: true };
          return { exceeded: !!(r.exceeded || (r.limit > 0 && r.length > r.limit)), limit: r.limit };
        }).catch(function () { return { exceeded: true, networkError: true }; });
      } else {
        // 本地模式（游客档）：无 JWT，doc-size-check 端点不可用 → 本地 raw 口径直接判定
        //（raw 偏严可接受；游客档 docSizeLimit=-1 时本就不进此分支，仅防御性兜底）。
        sizeCheckPromise = Promise.resolve({ exceeded: true, limit: sizeLimit });
      }
    } else {
      sizeCheckPromise = Promise.resolve({ exceeded: false });
    }
    // 3) 每日新建数量（仅新建文档；-1 不限制）
    return sizeCheckPromise.then(function (r) {
      if (r.exceeded) {
        if (r.networkError) {
          return getMessage('docSizeCheckUnavailable');
        }
        var shownLimit = (r.limit != null && r.limit > 0) ? r.limit : sizeLimit;
        return getMessage('docSizeExceeded', [String(shownLimit)]);
      }
      if (dailyLimit > 0 && !isExisting) {
        var todayPrefix = _todayDatePrefix();
        return Promise.all([loadAllDocuments(), _getAuthUid()]).then(function (res) {
          var docs = res[0], uid = res[1];
          // createdAt 为 UTC-naive 存储，须换算成本地日期再与本地"今天"比较（Bug B）
          var todayCount = (docs || []).filter(function (d) {
            if (!d || typeof d.createdAt !== 'string') return false;
            // 按 USER_ID 过滤：本地可能残留其他账号的记录（备份导入/认领残留），不过滤会把
            // 免费用户的当日额度算爆，直接拦住创建入口。uid 取不到时不过滤（保守）。
            if (uid && d.USER_ID && String(d.USER_ID) !== uid) return false;
            var dd = parseStoredTime(d.createdAt);
            if (isNaN(dd.getTime())) return false;
            var mm = String(dd.getMonth() + 1).padStart(2, '0');
            var day = String(dd.getDate()).padStart(2, '0');
            return dd.getFullYear() + '-' + mm + '-' + day === todayPrefix;
          }).length;
          if (todayCount >= dailyLimit) {
            return getMessage('docDailyLimitExceeded', [String(dailyLimit)]);
          }
          return null;
        }).catch(function () { return null; });
      }
      return null;
    });
  }

  function handleDocEditorSave(html) {
    var titleInput = document.getElementById('docEditorTitleInput');
    var folderSelect = document.getElementById('docEditorFolderSelect');
    var title = (titleInput.value || '').trim() || (chrome.i18n.getMessage('docUntitled') || '未命名文档');
    var folderId = folderSelect.value || null;
    var tags = _docEditorCurrentTags.join(';');
    var docId = _docEditorEditingDocId;
    var webUri = _docEditorWebUri || composeDocWebUri('https://app.webnoteshub.com', docId);
    // 先做等级限额强制，再走批注影响检查与保存
    _enforceDocQuota(html, docId).then(function (errMsg) {
      if (errMsg) {
        showToast(errMsg);
        _resetDocEditorSaveBtn();
        return;
      }
      _checkDocEditImpactThenSave(docId, webUri, html, title, folderId, tags);
    });
  }

  // 图片文件判定（与 doc-editor 包内 _sniffImageMime 语义一致：type 以 image/ 开头，或扩展名属常见图片）。
  // 📥 多选导入时用于把选择拆成「图片（追加末尾）/ 文档文件（替换导入）」两组。
  var _DOC_IMAGE_EXTS = { png: 1, jpg: 1, jpeg: 1, jfif: 1, webp: 1, gif: 1, bmp: 1, avif: 1, heic: 1, heif: 1, tif: 1, tiff: 1, svg: 1 };
  function _isImageFileLike(f) {
    if (!f) return false;
    if (f.type && String(f.type).indexOf('image/') === 0) return true;
    var ext = String(f.name || '').toLowerCase().split('.').pop();
    return !!_DOC_IMAGE_EXTS[ext];
  }

  // 导入后标题自动回填（文件导入与批量图片导入共用）。
  // 标题跟随导入文件名（去扩展名）。
  // 门控：仅当标题为空、或标题仍等于上次导入填的名（用户未手改）时才更新 ——
  // 这样既支持「连续导入不同文件时标题跟着变」，又不会冲掉用户手动输入的标题。
  function _maybeAutoFillDocTitle(baseName) {
    var titleInput = document.getElementById('docEditorTitleInput');
    if (!titleInput || !baseName) return;
    var cur = titleInput.value.trim();
    if (!cur || cur === _docEditorImportedTitle) {
      titleInput.value = baseName;
      _docEditorImportedTitle = baseName;
    }
  }

  // 批量导入图片（📥 多选 / 侧边栏「从图片新建」共用）：转换在 doc-editor 包内
  // （WPZL_docEditor.importImages：本地处理 + MIME 规范化，非白名单类型 canvas 重编码），
  // 这里负责：按钮 disable/restore、先弹尺寸选择（chooseImageImportOptions，每次导入都问）、
  // 标题回填、结果/超限预警 toast。追加语义（图片加到文档末尾，不替换已有内容）→ 不弹替换确认。
  function _importEditorImages(files) {
    var impBtn = document.getElementById('docEditorImportBtn');
    var restoreBtn = function () { if (impBtn) impBtn.disabled = false; };
    if (impBtn) impBtn.disabled = true;
    // 限额自适应：把 docSizeLimit（字符数）传给编辑器做预算兜底（用户选择了缩放时按质量/分辨率阶梯降级）。
    // -1000 留标题/段落等标签余量（下限 100 保证小限额仍生效）；≤0 = 不限制。
    var lim = (state.limits || {}).docSizeLimit;
    var sizeBudget = (lim != null && Number(lim) > 0) ? Math.max(100, Number(lim) - 1000) : 0;
    // 每次导入先弹窗让用户选择：是否「等比缩小像素」（最大宽度/高度 px，任一可留空）或保留原始尺寸（高清批注）
    return window.WPZL_docEditor.chooseImageImportOptions().then(function (choice) {
      if (!choice) return null;   // 用户取消：静默恢复按钮
      return window.WPZL_docEditor.importImages(files, {
        sizeBudget: sizeBudget,
        maxWidth: choice.maxWidth,
        maxHeight: choice.maxHeight
      });
    }).then(function (r) {
      if (!r) return;   // 用户取消
      r = r || { inserted: 0, skipped: [], firstName: '' };
      if (r.firstName) _maybeAutoFillDocTitle(r.firstName);
      if (r.inserted > 0) {
        showToast(getMessage('docImportImagesDone', [String(r.inserted)]));
      }
      if (r.skipped && r.skipped.length) {
        var names = r.skipped.map(function (s) { return s.name || '?'; }).join(', ');
        if (names.length > 80) names = names.slice(0, 80) + '…';
        showToast(getMessage('docImportImagesSkipped', [String(r.skipped.length), names]));
      } else if (!r.inserted) {
        showToast(getMessage('docImportImagesEmpty'));
      }
      // 超限预警（仅提示，不拦截；真正的精确拦截在保存时 _enforceDocQuota 的服务端精查）
      var lim = (state.limits || {}).docSizeLimit;
      if (lim > 0 && r.inserted > 0
        && window.WPZL_docEditor && typeof window.WPZL_docEditor.getHTML === 'function'
        && String(window.WPZL_docEditor.getHTML() || '').length > lim) {
        showToast(getMessage('docSizeExceeded', [String(lim)]));
      }
    }).catch(function (err) {
      console.error('[docEditor] 批量图片导入失败', err);
      showToast(getMessage('docEditorImportFailed', [String((err && err.message) || err)]));
    }).then(restoreBtn, restoreBtn);
  }

  // 导入本地文件（PDF/HTML/HTM/MARKDOWN/MD）→ 本地转 HTML → 写入编辑器。
  // 全程在本地完成，原文件不上传服务端。转换逻辑在 doc-editor 包内（WPZL_docEditor.importFile），
  // 这里只负责：文件选择、替换确认、按钮 disable/restore、标题自动填充、结果 toast。
  // 返回 Promise（📥 多选编排时串行 await：文档文件先替换、图片后追加）。
  function handleDocEditorImport(file) {
    var impBtn = document.getElementById('docEditorImportBtn');
    // 编辑器已有实质内容 → 替换前二次确认（导入语义=用文件内容覆盖）
    var currentHtml = (window.WPZL_docEditor && typeof window.WPZL_docEditor.getHTML === 'function')
      ? window.WPZL_docEditor.getHTML() : '';
    // 「有内容」判定：既看文字，也看图片/表格/分隔线等非文字节点
    // （纯图片型 PDF 导入后正文没有文字，否则会被误判为空、漏掉覆盖确认）
    var nonEmpty = (function (h) {
      h = String(h || '');
      if (h.replace(/<\/?[^>]+>/g, '').replace(/\s/g, '').length > 0) return true; // 有可见文字
      return /<(img|hr|table|video|svg|canvas|iframe)\b/i.test(h);                  // 有非文字内容节点
    })(currentHtml);
    if (nonEmpty) {
      var confirmMsg = getMessage('docEditorImportConfirmReplace');
      if (!window.confirm(confirmMsg)) return;
    }
    var restoreBtn = function () { if (impBtn) impBtn.disabled = false; };
    if (impBtn) impBtn.disabled = true;
    return window.WPZL_docEditor.importFile(file).then(function (result) {
      var baseName = String(file.name || '').replace(/\.[^.]+$/, '').trim();
      // 只读导入：检测到不支持元素且用户选择「只读」→ 不写编辑器，直接以只读文档入库。
      if (result && result.mode === 'readonly') {
        var roTitle = baseName || getMessage('docUntitled');
        return _doPutReadOnlyDocument(roTitle, result.html).then(function () {
          showToast(getMessage('docImportReadOnlyDone'));
        });
      }
      if (result && result.mode === 'cancel') return;   // 用户取消：不导入、静默恢复按钮
      // mode === 'edit'（或无 mode，兼容旧返回）→ 标题自动填充（门控见 _maybeAutoFillDocTitle）+ 已导入 toast
      _maybeAutoFillDocTitle(baseName);
      showToast(getMessage('docEditorImportDone'));
    }).catch(function (err) {
      var reason = (err && err.message) ? err.message : String(err);
      // manager 侧 toast 仅显示 2.5s（一闪即逝）；把完整错误（含堆栈/文件名）落到控制台便于排查。
      console.error('[docEditor] 导入失败', { fileName: file.name, fileSize: file.size, fileType: file.type, error: err });
      if (reason === 'unsupported') {
        showToast(getMessage('docEditorImportUnsupported'));
      } else if (reason === 'empty') {
        showToast(getMessage('docEditorImportEmpty'));
      } else {
        showToast(getMessage('docEditorImportFailed', [reason]));
      }
    }).then(restoreBtn, restoreBtn);
  }

  // Phase 10: 编辑已存在文档时的批注影响检查（软警告）。
  // 启发式：loadAnnotations → 检查每条批注的 CONTEXT（被标注文本）在新 bodyHtml 纯文本中是否仍存在；
  // 缺失则 confirm 软警告（仍要保存/取消）。新建文档无批注，跳过。启发式本质有假阳/假阴（CONTEXT 可能含
  // 扩展上下文/格式化差异），故为软警告（不硬阻断）。
  function _checkDocEditImpactThenSave(docId, webUri, html, title, folderId, tags) {
    // 仅编辑已存在文档（state.documents 含 docId）才检查；新建直接保存
    var isExisting = docId && (state.documents || []).some(function (d) { return d.docId === docId; });
    if (!isExisting) { _doPutDocument(docId, webUri, html, title, folderId, tags, { isNew: true }); return; }
    // 正文有实质改动才提醒（复用编辑器脏检测，已按 img src 归一化，签名回填不误判）
    var dirty = (window.WPZL_docEditor && typeof window.WPZL_docEditor.isDirty === 'function')
      ? window.WPZL_docEditor.isDirty() : true;
    checkAnnotationImpact(webUri).then(function (impact) {
      // 文档有批注且正文被改动 → 提醒（无法精确计算受影响条数，笼统提醒，见 checkAnnotationImpact 注释）
      if (impact && impact.total > 0 && dirty) {
        var msg = getMessage('editWarningBody', [String(impact.total)]);
        if (!confirm(msg)) {
          _resetDocEditorSaveBtn();   // 取消：恢复 Save 按钮可点
          return;
        }
      }
      _doPutDocument(docId, webUri, html, title, folderId, tags);
    }).catch(function () {
      _doPutDocument(docId, webUri, html, title, folderId, tags);   // 检查失败不阻塞保存
    });
  }

  function _doPutDocument(docId, webUri, html, title, folderId, tags, opts) {
    var pageWidth = (window.WPZL_docEditor && typeof window.WPZL_docEditor.getPageWidth === 'function')
      ? window.WPZL_docEditor.getPageWidth() : '820px';
    sendMessage('putDocument', {
      doc: {
        docId: docId,
        webUri: webUri,
        domain: hostOf(webUri),
        title: title,
        bodyHtml: html,
        folderId: folderId,
        tags: tags != null ? tags : '',
        pageWidth: pageWidth
        // urlMd5 由 SW putDocument handler 补算（wpzl_md5(webUri)）
      }
    }).then(function () {
      // #4: 保存不再自动关闭编辑器；通知编辑器更新脏标记基线（仅成功才视为 clean）
      if (window.WPZL_docEditor && typeof window.WPZL_docEditor.markSaved === 'function') {
        try { window.WPZL_docEditor.markSaved(); } catch (e) { /* ignore */ }
      }
      showToast(chrome.i18n.getMessage('docSaved') || '文档已保存');
      // H1 悬浮提示：新建文档保存成功后引导「打开页面」批注（游客的打开按钮被禁用，不提示）
      if (opts && opts.isNew && state.isLoggedIn) {
        mgrShowHintBox('h1', getMessage('hintDocSavedBody'));
      }
      return refreshDocuments();
    }).catch(function (err) {
      showToast((chrome.i18n.getMessage('docSaveFailed') || '保存失败') + ': ' + (err && err.message || err));
      _resetDocEditorSaveBtn();
    });
  }

  function _resetDocEditorSaveBtn() {
    var b = document.querySelector('#docEditorHost .wpzl-doc-tb-primary');
    if (b) { b.disabled = false; b.textContent = chrome.i18n.getMessage('docEditorSave') || '保存'; }
  }

  // 只读导入：把导入文件的原始（安全富元素保留）HTML 直接建为只读文档，不经过 TipTap 编辑器。
  // 只读文档不可再编辑（编辑入口被隐藏），故新建独立 docId + webUri；保存成功后关编辑器并刷新列表。
  function _doPutReadOnlyDocument(title, html) {
    var docId = generateDocId();
    var folderSelect = document.getElementById('docEditorFolderSelect');
    var folderId = folderSelect && folderSelect.value ? folderSelect.value : null;
    return getServerBase().then(function (base) {
      var webUri = composeDocWebUri(base, docId);
      return sendMessage('putDocument', {
        doc: {
          docId: docId,
          webUri: webUri,
          domain: hostOf(webUri),
          title: title,
          bodyHtml: html,
          folderId: folderId,
          tags: '',
          pageWidth: '820px',
          isReadOnly: true
        }
      });
    }).then(function () {
      closeDocEditor();
      return refreshDocuments();
    });
  }

  // Phase 10: 批注影响检查。返回 { total }（文档现有批注数），用于编辑保存前软提醒。
  // 不再计算「标注文本已找不到」的条数：该启发式无法准确反映受影响批注数——非文本批注
  // （矩形/画线/图片，CONTEXT 为空/坐标/img）依赖正文 DOM 结构定位，改正文即错位却被跳过；
  // 文本批注即使标注文字仍在，XPath 锚点也可能因正文结构变化而错位，而 manager 页无原 DOM
  // 无法重解析 XPath。报不准的数字反而误导，故改为笼统提醒「修改正文可能影响批注定位与显示」。
  function checkAnnotationImpact(webUri) {
    // 批注由 content.js 按 hostname + pathname（无端口/无协议）键化，而 webUri 是完整 URL
    // （http://host:port/d/docId），须归一化为同款 hostname+pathname 才能查到批注。
    var u;
    try { u = new URL(webUri); } catch (e) { return Promise.resolve({ total: 0 }); }
    var domain = u.hostname;
    var normUri = u.hostname + u.pathname;
    return loadAnnotations(domain, normUri).then(function (markList) {
      var list = Array.isArray(markList) ? markList : Object.values(markList || {});
      return { total: list.length };
    });
  }

  function _stripTags(html) {
    var div = document.createElement('div');
    div.innerHTML = html || '';
    return (div.textContent || '').replace(/\s+/g, ' ');
  }

  // 整页批注区块渲染：有 PAGE_NOTE.blocks 则展示只读内容 + 编辑按钮；否则仅显示「添加」入口（紧凑）。
  function renderPageNoteSection(page) {
    var section = document.getElementById('pageNoteSection');
    if (!section) return;
    var hasNote = !!(page && page.PAGE_NOTE && page.PAGE_NOTE.blocks && page.PAGE_NOTE.blocks.length > 0);
    var bodyEl = document.getElementById('pageNoteBody');
    var editBtn = document.getElementById('pageNoteEditBtn');
    var addBtn = document.getElementById('pageNoteAddBtn');
    section.style.display = 'block';
    if (hasNote) {
      if (bodyEl) { bodyEl.innerHTML = renderSummaryBlocks(page.PAGE_NOTE.blocks); bodyEl.style.display = 'block'; }
      if (editBtn) editBtn.style.display = 'inline-flex';
      if (addBtn) addBtn.style.display = 'none';
    } else {
      // 无批注：隐藏内容区，仅保留「＋ 添加」入口（紧凑，避免占位）
      if (bodyEl) { bodyEl.innerHTML = ''; bodyEl.style.display = 'none'; }
      if (editBtn) editBtn.style.display = 'none';
      if (addBtn) addBtn.style.display = 'inline-flex';
    }
  }

  // 整页批注编辑弹层（textarea，与 control-panel 风格一致）→ savePageNote → 刷新 state.currentPage + 重渲染区块
  function openPageNoteEditorModal() {
    if (!state.currentPage) return;
    var existing = document.getElementById('pageNoteModal');
    if (existing) existing.remove();

    var overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.id = 'pageNoteModal';
    overlay.style.display = 'flex';
    var modal = document.createElement('div');
    modal.className = 'modal';
    modal.style.width = '560px';
    modal.style.maxHeight = '80vh';
    modal.style.display = 'flex';
    modal.style.flexDirection = 'column';
    modal.style.overflow = 'hidden';

    var title = document.createElement('h3');
    title.className = 'modal-title';
    title.textContent = getMessage('pageNoteTitle');
    modal.appendChild(title);

    var hint = document.createElement('div');
    hint.style.cssText = 'font-size:12px;color:var(--text-muted);margin-bottom:8px;';
    hint.textContent = getMessage('pnHint');
    modal.appendChild(hint);

    var textarea = document.createElement('textarea');
    textarea.className = 'modal-textarea';
    textarea.rows = 8;
    textarea.style.minHeight = '200px';
    textarea.placeholder = getMessage('pnPlaceholder');
    // 预填已有 text blocks
    var note = state.currentPage.PAGE_NOTE;
    if (note && note.blocks) {
      textarea.value = note.blocks
        .filter(function (b) { return b.type === 'text'; })
        .map(function (b) { return b.content || ''; })
        .join('\n');
    }
    modal.appendChild(textarea);

    var actions = document.createElement('div');
    actions.className = 'modal-actions';
    actions.style.marginTop = '12px';
    var cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn btn-cancel';
    cancelBtn.textContent = getMessage('cancel');
    cancelBtn.addEventListener('click', function () { overlay.remove(); });
    var saveBtn = document.createElement('button');
    saveBtn.className = 'btn btn-primary';
    saveBtn.textContent = getMessage('save');
    saveBtn.addEventListener('click', function () {
      var text = textarea.value.trim();
      var noteData = text ? {
        title: displayPageTitle(state.currentPage) || '',
        blocks: [{ type: 'text', content: text }],
        timestamp: new Date().toISOString()
      } : null;
      saveBtn.disabled = true;
      saveBtn.textContent = getMessage('saving');
      sendMessage('savePageNote', { url: state.currentPage.url, noteData: noteData }).then(function () {
        // 刷新 state.currentPage 的 PAGE_NOTE（重载 pages 记录）
        return sendMessage('getPageNote', { url: state.currentPage.url });
      }).then(function (pageRecord) {
        if (pageRecord && state.currentPage) {
          state.currentPage.PAGE_NOTE = pageRecord.PAGE_NOTE || null;
          state.currentPage.PAGE_NOTE_UPDATED_AT = pageRecord.PAGE_NOTE_UPDATED_AT || null;
        }
        overlay.remove();
        renderPageNoteSection(state.currentPage);
        showToast(noteData ? getMessage('pnSaved') : getMessage('pnCleared'));
      }).catch(function (err) {
        saveBtn.disabled = false;
        saveBtn.textContent = getMessage('save');
        showToast(getMessage('pnSaveFailed', [(err && err.message ? err.message : '')]));
      });
    });
    actions.appendChild(cancelBtn);
    actions.appendChild(saveBtn);
    modal.appendChild(actions);

    overlay.appendChild(modal);
    overlay.addEventListener('click', function (e) { if (e.target === overlay) overlay.remove(); });
    document.body.appendChild(overlay);
    setTimeout(function () { try { textarea.focus(); } catch (e) { /* ignore */ } }, 50);
  }

  // Build render items by grouping image annotations
  // data:/blob: 内联锚点图上云后，标注 END_TAG_NAME 应统一为 objectKey（u/...）。上云回写失败
  // 的窗口期产物会仍留 data:/blob:，导致同一张图在详情页按组键拆成多张组卡。自愈：data:/blob: 键
  // 的图片组标注，若同 START_XPATH（同锚点元素=同一张图）的其它标注已有 objectKey 键，改写为该
  // objectKey 并回存——显示当次即合并，数据持久归一，下次加载即为干净数据。
  function _isInlineImgKey(k) { return k.indexOf('data:') === 0 || k.indexOf('blob:') === 0; }
  function _isCloudObjectKey(k) { return k.indexOf('u/') === 0 && k.lastIndexOf('.webp') === k.length - 5; }
  function _reconcileImageGroupKeys(annotations) {
    if (!annotations || annotations.length < 2) return;
    var cloudByXpath = {};
    annotations.forEach(function (a) {
      var k = a.END_TAG_NAME || '';
      if (!k || !a.START_XPATH || !_isCloudObjectKey(k)) return;
      if (!cloudByXpath[a.START_XPATH]) cloudByXpath[a.START_XPATH] = k;
    });
    annotations.forEach(function (a) {
      var k = a.END_TAG_NAME || '';
      if (!k || !a.START_XPATH || !_isInlineImgKey(k)) return;
      if (!isImageGroupAnnotation(a)) return;  // pageRect/imgAnno 等非图片组类型不参与
      var cloudKey = cloudByXpath[a.START_XPATH];
      if (!cloudKey || cloudKey === k) return;
      a.END_TAG_NAME = cloudKey;
      updateAnnotation(a.MARK_INFO_ID, { END_TAG_NAME: cloudKey }).catch(function (e) {
        console.warn('[Sagitnote] 图片组键自愈回存失败:', e && e.message);
      });
    });
  }

  function buildRenderItems() {
    var annotations = state.filteredAnnotations;
    _reconcileImageGroupKeys(annotations);
    var seen = {};  // groupKey (imageUrl) → { kind:'group', ... }
    var xpathToGroupKey = {};  // START_XPATH → imageUrl (for text matching)
    var items = [];
    var pendingText = [];  // text annotations without END_TAG_NAME, need START_XPATH matching

    // First pass: group annotations with END_TAG_NAME
    annotations.forEach(function (a) {
      var type = getAnnotationType(a);
      if (type === 'text' && !a.END_TAG_NAME && a.START_XPATH) {
        // Defer text annotations without END_TAG_NAME for START_XPATH matching
        pendingText.push(a);
        return;
      }
      if (isImageGroupAnnotation(a)) {
        var key = getImageGroupKey(a);
        if (!seen[key]) {
          var group = {
            kind: 'group',
            imageUrl: key,
            annotations: [a],
            firstTime: a.UPDATE_TIME || '',
            anchorYRatio: a.ANCHOR_Y_RATIO || 0
          };
          seen[key] = group;
          items.push(group);
        } else {
          var g = seen[key];
          g.annotations.push(a);
          var t = a.UPDATE_TIME || '';
          if (t && t < g.firstTime) g.firstTime = t;
        }
        // Map START_XPATH → groupKey for later text matching
        if (a.START_XPATH) xpathToGroupKey[a.START_XPATH] = key;
      } else {
        items.push({ kind: 'single', annotation: a });
      }
    });

    // Second pass: match text annotations by START_XPATH
    pendingText.forEach(function (a) {
      var xpath = a.START_XPATH || '';
      var matchedKey = xpathToGroupKey[xpath];
      if (matchedKey && seen[matchedKey]) {
        var g = seen[matchedKey];
        g.annotations.push(a);
        var t = a.UPDATE_TIME || '';
        if (t && t < g.firstTime) g.firstTime = t;
      } else {
        items.push({ kind: 'single', annotation: a });
      }
    });

    state.renderItems = items;
  }

  function applyFilter() {
    var filter = state.activeFilter;
    var annotations;

    if (state.searchMode && state.currentPage) {
      // In search mode, show search results for this page
      annotations = state.searchResults.filter(function (a) {
        return a.WEB_URI === state.currentPage.url;
      });
    } else {
      annotations = state.annotations;
    }

    if (filter === 'all') {
      state.filteredAnnotations = annotations;
    } else {
      state.filteredAnnotations = annotations.filter(function (a) {
        return getAnnotationType(a) === filter;
      });
    }

    // Author visibility filter
    if (state.hiddenAuthorIds.size > 0) {
      state.filteredAnnotations = state.filteredAnnotations.filter(function (a) {
        return !state.hiddenAuthorIds.has(a.AUTHOR_ID || '');
      });
    }

    // Sort
    var dir = state.sortOrder === 'desc' ? -1 : 1;
    if (state.sortBy === 'time') {
      state.filteredAnnotations.sort(function (a, b) {
        var ta = (a.UPDATE_TIME || '').toString();
        var tb = (b.UPDATE_TIME || '').toString();
        return dir * ta.localeCompare(tb);
      });
    } else {
      state.filteredAnnotations.sort(function (a, b) {
        // Primary: anchor element position on page
        var ya = a.ANCHOR_Y_RATIO || 0;
        var yb = b.ANCHOR_Y_RATIO || 0;
        if (ya !== yb) return dir * (ya - yb);
        // Secondary: annotation Y offset within anchor element
        var oa = getAnnotationYOffset(a);
        var ob = getAnnotationYOffset(b);
        if (oa !== ob) return dir * (oa - ob);
        // Tertiary: creation time
        var ta2 = (a.UPDATE_TIME || '').toString();
        var tb2 = (b.UPDATE_TIME || '').toString();
        return dir * ta2.localeCompare(tb2);
      });
    }

    buildRenderItems();
    renderAnnotationCards();
  }

  function renderAnnotationCards() {
    var listEl = document.getElementById('annotationList');
    var filterEmptyEl = document.getElementById('contentFilterEmpty');
    var items = state.renderItems;

    if (!items || items.length === 0) {
      listEl.innerHTML = '';
      filterEmptyEl.style.display = 'flex';
      return;
    }
    filterEmptyEl.style.display = 'none';

    var html = '';
    items.forEach(function (item) {
      if (item.kind === 'group') {
        html += renderImageGroupCard(item);
      } else {
        html += renderAnnotationCard(item.annotation);
      }
    });
    listEl.innerHTML = html;

    // Post-render: objectKey 图片本地优先（data:/blob: 锚点图上云后 END_TAG_NAME=objectKey 作 img src）。
    // 先批量查本地 imageData：有 data → 直显（零网络，不打签名接口/不访问 R2）；无 data → 签名走 R2
    // （本地没有但已上云才下载显示）。覆盖图片组卡片 / 箭头旗帜 / 矩形等所有用 END_TAG_NAME 作图源的
    // 卡片——loadLocalImagesForCards 的批量回填只覆盖 imgAnno/group 且晚于此处，旧逻辑"先签名后替换"
    // 会在本地已有 data 时白白打一次签名接口并触发 R2 下载。
    var _objKeyImgs = listEl.querySelectorAll('img');
    var _okIdx = [];
    var _okUrls = [];
    for (var _oi = 0; _oi < _objKeyImgs.length; _oi++) {
      var _okRaw = _objKeyImgs[_oi].getAttribute('src') || '';
      if (!wpzl_isObjectKeySrc(_okRaw)) continue;
      _okIdx.push(_oi);
      if (_okUrls.indexOf(_okRaw) < 0) _okUrls.push(_okRaw);
    }
    var _okPageUrl = state.currentPage ? state.currentPage.url : '';
    if (_okIdx.length > 0 && _okPageUrl) {
      getImageDataBatch(_okPageUrl, _okUrls).then(function (localMap) {
        _okIdx.forEach(function (i2) {
          var img2 = _objKeyImgs[i2];
          var key2 = img2.getAttribute('src') || '';
          // 批量解析期间 src 可能已被 loadLocalImagesForCards 换成 data:（同图多卡片）→ 只处理仍是 objectKey 的
          if (!wpzl_isObjectKeySrc(key2)) return;
          var rec2 = localMap[key2];
          if (rec2 && rec2.data) {
            img2.src = rec2.data;
            img2.dataset.localSaved = 'true';
          } else {
            wpzl_signObjectKeyImg(img2, key2);
          }
        });
      }).catch(function () {
        // IDB 读失败兜底：全部签名显示（保持旧行为）
        _okIdx.forEach(function (i3) {
          var k3 = _objKeyImgs[i3].getAttribute('src') || '';
          if (wpzl_isObjectKeySrc(k3)) wpzl_signObjectKeyImg(_objKeyImgs[i3], k3);
        });
      });
    } else if (_okIdx.length > 0) {
      // 无 currentPage（不应发生）兜底：签名显示
      _okIdx.forEach(function (i3) {
        var k3 = _objKeyImgs[i3].getAttribute('src') || '';
        wpzl_signObjectKeyImg(_objKeyImgs[i3], k3);
      });
    }

    // Post-render: draw group overlays
    items.forEach(function (item) {
      if (item.kind === 'group') drawImageGroupOverlay(item);
    });

    // Post-render: draw canvases for single freehand cards
    items.forEach(function (item) {
      if (item.kind === 'single') {
        var a = item.annotation;
        var t = getAnnotationType(a);
        if (t === 'freehand') drawFreehandPreview(a);
      }
    });

    // Post-render: draw arrow SVGs for single cards
    items.forEach(function (item) {
      if (item.kind === 'single') {
        var a2 = item.annotation;
        var t2 = getAnnotationType(a2);
        if (t2 === 'arrow' || t2 === 'flag') drawArrowPreview(a2);
      }
    });

    // Post-render: position image rect overlays for single rect cards
    positionImageRectOverlays();

    // Post-render: load local image data for group cards
    loadLocalImagesForCards(items);
  }

  // ---- Load local image data for image group cards and imgAnno cards ----
  function loadLocalImagesForCards(items) {
    if (!state.currentPage) return;
    var pageUrl = state.currentPage.url;
    var imageUrls = [];
    var seen = {};
    items.forEach(function (item) {
      var url = null;
      if (item.kind === 'group' && item.imageUrl) {
        url = item.imageUrl;
      } else if (item.kind === 'single' && item.annotation) {
        var t = getAnnotationType(item.annotation);
        if (t === 'imgAnno' && item.annotation.END_TAG_NAME) {
          url = item.annotation.END_TAG_NAME;
        }
      }
      if (url && !seen[url]) {
        seen[url] = true;
        imageUrls.push(url);
      }
    });
    if (imageUrls.length === 0) return;

    getImageDataBatch(pageUrl, imageUrls).then(function (localDataMap) {
      var statusEls = document.querySelectorAll('.image-local-status');
      for (var i = 0; i < statusEls.length; i++) {
        var el = statusEls[i];
        var imgUrl = el.dataset.imageUrl;
        if (!imgUrl) continue;
        var localRec = localDataMap[imgUrl];
        var wrapper = el.parentElement;
        var img = wrapper ? wrapper.querySelector('img') : null;
        if (localRec && localRec.data) {
          // ① 本地 data 命中
          el.innerHTML = '<span class="status-indicator saved" style="color:#22c55e;font-size:12px;">' + getMessage('ivSavedLocal') + '</span>';
          if (img) wpzl_loadImageDataWithFallback(img, pageUrl, imgUrl, localRec);
        } else if (localRec && localRec.cloudUrl) {
          // ② 本地无 data，但 cloudUrl 已同步（Pro 跨设备 pull 后；image-sync-downloader 后台拉 blob 期间用签名 URL 兜底显示）
          el.innerHTML = '<span class="status-indicator cloud" style="color:#0ea5e9;font-size:12px;">' + getMessage('ivCloudSyncing') + '</span>';
          if (img) wpzl_loadImageDataWithFallback(img, pageUrl, imgUrl, localRec, el);
        } else {
          // ③ 未保存：渲染即自动抓取补存（SW 直 fetch，不绕防盗链，被拒则截图兜底 + 存本地 + 上云），成功后走①、按钮消失
          el.innerHTML = '<span class="status-indicator not-saved" style="color:#94a3b8;font-size:12px;">' + getMessage('ivNotSavedLocal') + '</span>' +
            '<button class="save-local-btn" data-image-url="' + escapeHtml(imgUrl) + '" style="margin-left:8px;font-size:12px;color:#4f46e5;background:none;border:1px solid #4f46e5;border-radius:4px;padding:2px 8px;cursor:pointer;">' + getMessage('ivSaveToLocal') + '</button>';
          _autoSaveImageFromOriginalUrl(pageUrl, imgUrl, el, img);
        }
      }
      // 重绘 overlay（图片 src 变更后需要重新绘制）
      items.forEach(function (item) {
        if (item.kind === 'group') drawImageGroupOverlay(item);
      });
    }).catch(function () {
      // 静默失败，保持 URL 加载
      var statusEls = document.querySelectorAll('.image-local-status');
      for (var i = 0; i < statusEls.length; i++) {
        statusEls[i].innerHTML = '';
      }
    });
  }

  function renderTags(tagsString) {
    if (!tagsString) return '';
    var tags = tagsString.split(';').filter(function (t) { return t.trim(); });
    if (tags.length === 0) return '';
    var html = '<div class="card-tags">';
    tags.forEach(function (tag) {
      html += '<span class="tag-badge">' + escapeHtml(tag.trim()) + '</span>';
    });
    html += '</div>';
    return html;
  }

  function renderTagsInline(tagsString) {
    if (!tagsString) return '';
    var tags = tagsString.split(';').filter(function (t) { return t.trim(); });
    if (tags.length === 0) return '';
    var html = '';
    tags.forEach(function (tag) {
      html += '<span class="tag-badge">' + escapeHtml(tag.trim()) + '</span>';
    });
    return html;
  }

  function renderAnnotationCard(a) {
    var type = getAnnotationType(a);
    var info = TYPE_MAP[type] || {};
    var color = a.MARK_COLOR || '#ff3c82';
    var time = a.UPDATE_TIME || '';
    var id = a.MARK_INFO_ID || '';
    var comment = a.COMMENT_TEXT || '';
    var selected = state.selectedIds.has(id);

    var html = '<div class="annotation-card" data-id="' + escapeHtml(id) + '">';
    html += '<div class="card-color-bar" style="background:' + escapeHtml(color) + '"></div>';
    html += '<div class="card-checkbox"><input type="checkbox" class="card-select" data-id="' + escapeHtml(id) + '"' + (selected ? ' checked' : '') + '></div>';
    html += '<div class="card-body">';

    // Header
    html += '<div class="card-header">';
    html += '<span class="card-type-icon" style="background:' + info.bg + '">' + (info.icon || '?') + '</span>';
    html += '<span class="card-type-label">' + (info.label || type) + '</span>';
    html += '<span class="card-time">' + escapeHtml(formatTime(time)) + '</span>';
    if (isMultiAuthor() && a.AUTHOR_NAME) {
      var isOwn = state.currentAuthor && a.AUTHOR_ID === state.currentAuthor.authorId;
      if (!isOwn) {
        html += '<span class="card-author-label">' + escapeHtml(a.AUTHOR_NAME) + '</span>';
      }
    }
    html += '</div>';

    // Preview (type-specific)
    html += '<div class="card-preview">';
    html += renderTypePreview(a, type);
    html += '</div>';

    // Comment
    if (comment) {
      html += '<div class="card-comment">';
      html += '<div class="card-comment-label">' + getMessage('detailNote') + '</div>';
      html += escapeHtml(comment);
      html += '</div>';
    }

    // Tags
    html += renderTags(a.TAGS);

    // Actions
    html += '<div class="card-actions">';
    if (isOwnOrAllowed(a)) {
      html += '<button class="card-action-btn edit-note-btn" data-id="' + escapeHtml(id) + '">✎ ' + getMessage('editAnnotation') + '</button>';
      html += '<button class="card-action-btn danger delete-btn" data-id="' + escapeHtml(id) + '">✕ ' + getMessage('delete') + '</button>';
    }
    html += '<button class="card-action-btn goto-btn" data-url="' + escapeHtml(a.WEB_URI || '') + '">↗ ' + getMessage('openPage') + '</button>';
    html += '</div>';

    html += '</div>'; // card-body
    html += '</div>'; // annotation-card
    return html;
  }

  // ---- Type-specific preview renderers ----

  function renderTypePreview(a, type) {
    switch (type) {
      case 'highlight': return renderHighlightPreview(a);
      case 'arrow':
      case 'flag': return renderArrowPreview(a);
      case 'rect': return renderImageRectPreview(a);
      case 'pageRect': return renderPageRectPreview(a);
      case 'rectFrame': return renderFramePreview(a, 'dashed');
      case 'elementMark': return renderElementMarkPreview(a);
      case 'freehand': return renderFreehandPreview(a);
      case 'text': return renderTextNotePreview(a);
      case 'imgAnno': return renderImgAnnoPreview(a);
      default: return '<span style="color:#999">' + getMessage('mgUnknownType') + '</span>';
    }
  }

  function renderHighlightPreview(a) {
    var text = a.CONTEXT || getMessage('noTextContent');
    var color = a.MARK_COLOR || '#ff3c82';
    var style = a.TITLE || 'bjs';
    var cssStyle = '';

    switch (style) {
      case 'bjs': cssStyle = 'background-color:' + color + '30'; break;
      case 'bk': cssStyle = 'border:2px solid ' + color; break;
      case 'xhx': cssStyle = 'border-bottom:2px solid ' + color + ';background:transparent'; break;
      case 'blx': cssStyle = 'text-decoration:underline wavy ' + color + ';background:transparent'; break;
      case 'zjys': cssStyle = 'color:' + color + ';background:transparent'; break;
      default: cssStyle = 'background-color:' + color + '30';
    }

    return '<div class="highlight-text" style="' + cssStyle + '">' + escapeHtml(text) + '</div>';
  }

  function renderFramePreview(a, borderStyle) {
    // 创建时提取的矩形区域文本（rect-frame-drawing.js 写 CONTEXT）；无文本回退形状预览
    if (a.CONTEXT) return renderRegionTextPreview(a.CONTEXT, a.MARK_COLOR);
    var color = a.MARK_COLOR || '#ff3c82';
    // 线宽 = 选中尺寸+1，与页面 rect-frame-drawing.js 的 effStroke=text_size+1 一致
    var lw = (parseInt(a.END_MD5) || 2) + 1;
    return '<div style="border:' + lw + 'px ' + borderStyle + ' ' + escapeHtml(color) + ';box-sizing:border-box;height:44px;border-radius:2px;"></div>';
  }

  // 几何工具（矩形框/自由划线）提取的区域文本预览，与 renderTextNotePreview 同构
  function renderRegionTextPreview(text, color) {
    return '<div class="text-note-preview" style="border-left-color:' + escapeHtml(color || '#ff3c82') + '">' +
      escapeHtml(text) + '</div>';
  }

  // 元素标记预览：展示锚点元素的 tagName + 文本 + 媒体缩略图（图片/视频）
  // 字段来源（创建时采集，见 element-mark-drawing.js）：START_TAG_NAME=tagName, CONTEXT=文本, END_TAG_NAME=媒体src
  function renderElementMarkPreview(a) {
    var tag = a.START_TAG_NAME || '';
    var text = a.CONTEXT || '';
    var mediaSrc = a.END_TAG_NAME || '';
    var color = a.MARK_COLOR || '#ff3c82';
    var lw = parseInt(a.END_MD5) || 2;

    // 旧数据无任何信息 → 回退到原边框预览
    if (!tag && !text && !mediaSrc) {
      return '<div style="border:' + lw + 'px solid ' + escapeHtml(color) + ';box-sizing:border-box;height:44px;border-radius:2px;"></div>';
    }

    var html = '<div class="elem-mark-preview" style="font-size:13px;">';
    if (tag) {
      html += '<span style="display:inline-block;padding:1px 8px;border-radius:10px;background:#eef2ff;color:#3730a3;font-family:monospace;font-size:12px;margin-bottom:4px;">' + escapeHtml(tag) + '</span>';
    }
    if (text) {
      html += '<div style="color:#475569;margin:4px 0;white-space:pre-wrap;word-break:break-word;">' + escapeHtml(text) + '</div>';
    }
    if (mediaSrc) {
      html += renderAnchorMediaHtml(mediaSrc);
    }
    html += '</div>';
    return html;
  }

  // 定位元素信息块（详情侧栏：元素标记/箭头/旗帜 共用）
  function renderAnchorInfo(a) {
    var tag = a.START_TAG_NAME || '';
    var text = a.CONTEXT || '';
    var mediaSrc = a.END_TAG_NAME || '';
    if (!tag && !text && !mediaSrc) return '';
    var html = '<div class="detail-anchor-info" style="margin:6px 0;font-size:13px;background:#f8fafc;padding:6px 8px;border-radius:4px;">';
    if (tag) {
      html += '<span style="display:inline-block;padding:1px 8px;border-radius:10px;background:#eef2ff;color:#3730a3;font-family:monospace;font-size:12px;margin-right:6px;">' + escapeHtml(tag) + '</span>';
    }
    if (text) {
      html += '<div style="color:#475569;margin:4px 0;white-space:pre-wrap;word-break:break-word;">' + escapeHtml(text) + '</div>';
    }
    if (mediaSrc) {
      html += renderAnchorMediaHtml(mediaSrc);
    }
    html += '</div>';
    return html;
  }

  // 判断 URL 是否为视频（视频不进图片组叠加，仅在详情侧栏以 <video> 展示）
  function isVideoUrl(url) {
    if (!url) return false;
    return /\.(mp4|webm|ogg|mov|m4v)(\?|#|$)/i.test(url);
  }

  // 媒体缩略图 HTML（图片用 <img>，视频 URL 用 <video>）
  function renderAnchorMediaHtml(mediaSrc) {
    if (isVideoUrl(mediaSrc)) {
      return '<video src="' + escapeHtml(mediaSrc) + '" controls style="max-width:100%;max-height:160px;border-radius:4px;display:block;"></video>';
    }
    return '<img src="' + escapeHtml(mediaSrc) + '" alt="' + getMessage('altAnchorElement') + '" class="preview-zoomable" data-original-src="' + escapeHtml(mediaSrc) + '" data-image-url="' + escapeHtml(mediaSrc) + '" data-error-placeholder="img-anno-placeholder" style="max-width:100%;max-height:160px;border-radius:4px;display:block;">';
  }

  // 箭头/旗帜卡片预览：重点展示定位元素内容（文本/媒体），箭头/旗帜图形仅保留小图标，不喧宾夺主
  function renderArrowPreview(a) {
    var info = TYPE_MAP[getAnnotationType(a)] || {};
    var icon = info.icon || '↗';
    var text = a.CONTEXT || '';
    var mediaSrc = a.END_TAG_NAME || '';
    var html = '<div style="display:flex;align-items:flex-start;gap:6px;min-height:20px;padding:2px 0;">';
    html += '<span style="font-size:15px;line-height:1.2;color:' + escapeHtml(a.MARK_COLOR || '#4f46e5') + ';">' + icon + '</span>';
    html += '<div style="flex:1;min-width:0;font-size:13px;">';
    if (mediaSrc) {
      html += renderAnchorMediaHtml(mediaSrc);
    }
    if (text) {
      html += '<div style="color:#475569;' + (mediaSrc ? 'margin-top:4px;' : '') + 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + escapeHtml(text) + '</div>';
    }
    if (!text && !mediaSrc) {
      html += '<div style="color:#999;">' + escapeHtml(info.label || '') + '</div>';
    }
    html += '</div></div>';
    return html;
  }

  function drawArrowPreview(a) {
    var id = a.MARK_INFO_ID || '';
    var canvas = document.getElementById('arrow-' + id);
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    var color = a.MARK_COLOR || '#ff3c82';
    var isFlag = (a.END_XPATH === '$flag');

    ctx.clearRect(0, 0, 64, 48);

    if (isFlag) {
      // Flag shape
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.moveTo(10, 40);
      ctx.lineTo(10, 8);
      ctx.lineTo(50, 14);
      ctx.lineTo(10, 22);
      ctx.fill();
      // Pole
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(10, 40);
      ctx.lineTo(10, 6);
      ctx.stroke();
    } else {
      // Arrow shape
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.moveTo(8, 38);
      ctx.lineTo(50, 10);
      ctx.lineTo(40, 8);
      ctx.lineTo(54, 6);
      ctx.lineTo(52, 20);
      ctx.lineTo(48, 12);
      ctx.lineTo(8, 38);
      ctx.fill();
    }
  }

  function renderImageRectPreview(a) {
    var imgUrl = a.END_TAG_NAME || '';
    var color = a.MARK_COLOR || '#ff3c82';
    var id = a.MARK_INFO_ID || '';

    if (!imgUrl) {
      return '<div class="image-rect-placeholder">' + getMessage('mgImageUnavailable') + '</div>';
    }

    // Decode rect coords
    var so = parseInt(a.START_OFFSET) || 0;
    var eo = parseInt(a.END_OFFSET) || 0;
    var x1 = Math.floor(so / 1000);
    var y1 = so % 1000;
    var x2 = Math.floor(eo / 1000);
    var y2 = eo % 1000;

    var lineWidth = parseInt(a.END_MD5) || 2;

    // Toolbar + image wrapper (overlay positioned relative to image only)
    var html = '<div class="image-rect-preview">';
    html += '<div class="image-rect-toolbar">';
    html += '<label class="image-rect-toggle">';
    html += '<input type="checkbox" class="rect-visibility-toggle" checked> ' + getMessage('mgShowRect');
    html += '</label>';
    html += '</div>';
    html += '<div class="image-rect-image-wrapper">';
    html += '<img src="' + escapeHtml(imgUrl) + '" alt="' + getMessage('altAnnoImage') + '" class="preview-zoomable" data-rect-x1="' + x1 + '" data-rect-y1="' + y1 + '" data-rect-x2="' + x2 + '" data-rect-y2="' + y2 + '" data-rect-color="' + escapeHtml(color) + '" data-rect-lw="' + lineWidth + '" data-rect-id="' + escapeHtml(id) + '" data-error-placeholder="image-rect-placeholder">';
    html += '<div class="image-rect-overlay" style="display:none"></div>';
    html += '</div>';
    html += '</div>';
    return html;
  }

  function positionImageRectOverlays() {
    var imgs = document.querySelectorAll('.image-rect-image-wrapper img[data-rect-x1]');
    imgs.forEach(function (img) {
      if (!img.complete || img.naturalWidth === 0) {
        img.addEventListener('load', function () {
          requestAnimationFrame(function () { positionSingleRectOverlay(img); });
        });
        return;
      }
      // Defer to next frame so layout is settled
      requestAnimationFrame(function () { positionSingleRectOverlay(img); });
    });
  }

  function positionSingleRectOverlay(img) {
    var wrapper = img.parentElement;
    var overlay = wrapper.querySelector('.image-rect-overlay');
    if (!overlay) return;

    var x1 = parseInt(img.dataset.rectX1) || 0;
    var y1 = parseInt(img.dataset.rectY1) || 0;
    var x2 = parseInt(img.dataset.rectX2) || 0;
    var y2 = parseInt(img.dataset.rectY2) || 0;
    var color = img.dataset.rectColor || '#ff3c82';
    var lineWidth = parseInt(img.dataset.rectLw) || 2;

    var w = img.clientWidth;
    var h = img.clientHeight;
    if (w === 0 || h === 0) return;

    // Coordinates are ratio-based 0-999 (x * 1000 + y packed in offset)
    var left = Math.min(x1, x2) / 1000 * w;
    var top = Math.min(y1, y2) / 1000 * h;
    var right = Math.max(x1, x2) / 1000 * w;
    var bottom = Math.max(y1, y2) / 1000 * h;

    overlay.style.display = 'block';
    overlay.style.left = left + 'px';
    overlay.style.top = top + 'px';
    overlay.style.width = (right - left) + 'px';
    overlay.style.height = (bottom - top) + 'px';
    overlay.style.border = lineWidth + 'px solid ' + color;
  }

  function renderPageRectPreview(a) {
    var color = a.MARK_COLOR || '#ff3c82';
    var lineWidth = parseInt(a.END_MD5) || 2;
    var anchorW = a.ANCHOR_WIDTH || 0;
    var anchorH = a.ANCHOR_HEIGHT || 0;

    var html = '<div class="page-rect-preview">';
    // 原始像素（截图覆盖的页面区域尺寸 ANCHOR_WIDTH×ANCHOR_HEIGHT）：显示在图片上方、类型标题之后。
    // 原"页面位置/区域尺寸/锚点"三行技术信息已移除（对用户无意义）。
    if (anchorW && anchorH) {
      html += '<div class="page-rect-info" id="page-rect-info-' + a.MARK_INFO_ID + '">' + getMessage('ivOriginalPixels', [String(anchorW), String(anchorH)]) + '</div>';
    }

    // THUMBNAIL 四分支读路径（B1）：
    // ① objectKey（已上云）→ 异步签名 URL
    // ② base64 dataURL（旧数据兼容）
    // ③ THUMBNAIL_LOCAL 标志（本地存储 IDB）→ 异步从 SW 拉
    // ④ 无图占位
    var thumb = a.THUMBNAIL || '';
    // 规范化脏字符串：wpzl_saveAnnotation 提交 ann.THUMBNAIL=null 时 ajax-bridge formatParams
    // 会序列化成字符串 "null" 写入 IDB。把 "null"/"undefined" 当空 → 占位 img + localThumbnails 兜底
    if (thumb === 'null' || thumb === 'undefined') thumb = '';
    var isObjectKey = thumb && thumb.indexOf('u/') === 0 && thumb.indexOf('.webp') > 0;
    var isDataUrl = thumb && thumb.indexOf('data:') === 0;

    // 本地优先读路径（原则 3/4）：本地缓存/objectKey 与本地存储统一先查 localThumbnails，
    // 本地未命中再走云端签名 / dataUrl。有潜在图源即放占位 img，异步回填。
    if (isObjectKey || isDataUrl || !thumb) {
      var placeholderId = 'page-rect-thumb-' + a.MARK_INFO_ID;
      html += '<div class="page-rect-screenshot">';
      html += '<img id="' + placeholderId + '" alt="' + getMessage('altAreaScreenshot') + '" class="preview-zoomable">';
      html += '<div class="page-rect-screenshot-border" style="border-color:' + escapeHtml(color) + ';border-width:' + lineWidth + 'px"></div>';
      html += '</div>';
      wpzl_loadPageRectThumb(a, placeholderId);
    } else {
      html += '<div class="page-rect-box" style="border-color:' + escapeHtml(color) + ';border-width:' + lineWidth + 'px;background:' + color + '0D"></div>';
    }

    html += '</div>';
    return html;
  }

  function renderFreehandPreview(a) {
    // 创建时提取的划线区域文本（freehand-drawing.js 写 TEXT_SNAPSHOT）；无文本回退折线 canvas
    if (a.TEXT_SNAPSHOT) return renderRegionTextPreview(a.TEXT_SNAPSHOT, a.MARK_COLOR);
    var id = a.MARK_INFO_ID || '';
    return '<canvas class="freehand-preview" id="freehand-' + escapeHtml(id) + '" width="240" height="120"></canvas>';
  }

  function drawFreehandPreview(a) {
    var id = a.MARK_INFO_ID || '';
    var canvas = document.getElementById('freehand-' + id);
    if (!canvas) return;

    var ctx = canvas.getContext('2d');
    var color = a.MARK_COLOR || '#ff3c82';
    var lineWidth = parseInt(a.END_MD5) || 2;

    ctx.clearRect(0, 0, 240, 120);

    var context = a.CONTEXT;
    if (!context) return;

    var points;
    try {
      points = typeof context === 'string' ? JSON.parse(context) : context;
    } catch (e) {
      // Compressed format - show placeholder
      ctx.fillStyle = '#ccc';
      ctx.font = '12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(getMessage('ivCompressedDataNote'), 120, 65);
      return;
    }

    if (!points || points.length < 2) return;

    // Normalize to canvas
    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    points.forEach(function (p) {
      if (p.x < minX) minX = p.x;
      if (p.y < minY) minY = p.y;
      if (p.x > maxX) maxX = p.x;
      if (p.y > maxY) maxY = p.y;
    });

    var rangeX = maxX - minX || 1;
    var rangeY = maxY - minY || 1;
    var pad = 10;
    var drawW = 240 - pad * 2;
    var drawH = 120 - pad * 2;
    var scale = Math.min(drawW / rangeX, drawH / rangeY);

    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1, lineWidth);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();

    points.forEach(function (p, i) {
      var x = pad + (p.x - minX) * scale + (drawW - rangeX * scale) / 2;
      var y = pad + (p.y - minY) * scale + (drawH - rangeY * scale) / 2;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
  }

  function renderTextNotePreview(a) {
    var color = a.MARK_COLOR || '#ff3c82';
    var text = a.CONTEXT || getMessage('noContent');
    return '<div class="text-note-preview" style="border-left-color:' + escapeHtml(color) + '">' + escapeHtml(text) + '</div>';
  }

  function renderImgAnnoPreview(a) {
    var context = a.CONTEXT || '';
    var imgUrl = a.END_TAG_NAME || '';
    var color = a.MARK_COLOR || '#ef4444';
    var comment = a.COMMENT_TEXT || '';

    // Determine thumbnail source: CONTEXT may be a data URL or 'img:xxx'
    var thumbSrc = '';
    if (context && context.indexOf('data:') === 0) {
      thumbSrc = context;
    } else if (context && context.indexOf('img:') === 0) {
      thumbSrc = context.substring(4);
    } else if (imgUrl) {
      thumbSrc = imgUrl;
    }

    if (!thumbSrc) {
      return '<div class="img-anno-placeholder">' + getMessage('mgImageUnavailable') + '</div>';
    }

    var html = '<div class="img-anno-preview">';
    html += '<div class="img-anno-thumb-wrapper">';
    html += '<img src="' + escapeHtml(thumbSrc) + '" alt="' + getMessage('altMarkImage') + '" class="preview-zoomable" data-original-src="' + escapeHtml(imgUrl || thumbSrc) + '" data-image-url="' + escapeHtml(imgUrl || thumbSrc) + '" data-error-placeholder="img-anno-placeholder">';
    html += '</div>';
    // 图片本地保存状态
    if (imgUrl) {
      html += '<div class="image-local-status" data-image-url="' + escapeHtml(imgUrl) + '">';
      html += '<span class="status-indicator checking" style="font-size:12px;">' + getMessage('ivChecking') + '</span>';
      html += '</div>';
    }
    if (comment) {
      html += '<div class="img-anno-comment" style="border-left-color:' + escapeHtml(color) + '">' + escapeHtml(comment) + '</div>';
    }
    html += '</div>';
    return html;
  }

  // ---- Image Group Card ----

  function renderImageGroupCard(group) {
    var key = group.imageUrl;
    var escapedKey = escapeHtml(key);
    var annotations = group.annotations;

    var html = '<div class="annotation-card image-group-card" data-group-key="' + escapedKey + '">';
    html += '<div class="card-body">';

    // Image preview with canvas overlay
    html += '<div class="image-group-preview">';
    html += '<div class="image-group-image-wrapper">';
    html += '<img src="' + escapedKey + '" alt="' + getMessage('altAnnoImage') + '" class="preview-zoomable" data-original-src="' + escapedKey + '" data-image-url="' + escapedKey + '" data-error-placeholder="image-rect-placeholder">';
    html += '<canvas class="image-group-overlay-canvas" data-group-key="' + escapedKey + '"></canvas>';
    html += '</div>';
    // 图片本地保存状态
    html += '<div class="image-local-status" data-image-url="' + escapedKey + '">';
    html += '<span class="status-indicator checking">' + getMessage('ivChecking') + '</span>';
    html += '</div>';
    html += '</div>';

    // Select all checkbox
    html += '<div class="image-group-select-all">';
    html += '<input type="checkbox" class="group-select-all" data-group-key="' + escapedKey + '" checked>';
    html += '<span>' + getMessage('selectAll') + '</span>';
    html += '</div>';

    // Per-annotation rows — 按标记时间正序排列（CREATE_TIME 缺失回退 UPDATE_TIME）
    html += '<div class="image-group-annotation-list">';
    annotations.slice().sort(function (x, y) {
      return (x.CREATE_TIME || x.UPDATE_TIME || '').localeCompare(y.CREATE_TIME || y.UPDATE_TIME || '');
    }).forEach(function (a) {
      var type = getAnnotationType(a);
      var info = TYPE_MAP[type] || {};
      var id = a.MARK_INFO_ID || '';
      var comment = a.COMMENT_TEXT || '';
      var color = a.MARK_COLOR || '#ff3c82';
      var rowTime = formatTime(a.CREATE_TIME || a.UPDATE_TIME || '');

      html += '<div class="image-group-annotation-row" data-id="' + escapeHtml(id) + '">';
      html += '<input type="checkbox" class="group-annotation-toggle" data-id="' + escapeHtml(id) + '" data-group-key="' + escapedKey + '" checked>';
      html += '<span class="annotation-type-icon" style="background:' + info.bg + '">' + (info.icon || '?') + '</span>';
      if (isMultiAuthor() && a.AUTHOR_NAME) {
        var _isOwn = state.currentAuthor && a.AUTHOR_ID === state.currentAuthor.authorId;
        if (!_isOwn) {
          html += '<span class="card-author-label">' + escapeHtml(a.AUTHOR_NAME) + '</span>';
        }
      }
      html += '<span class="annotation-comment-text">' + escapeHtml(comment || '(' + (info.label || type) + ')') + '</span>';
      if (rowTime) {
        html += '<span class="group-row-time" title="' + escapeHtml(_tsSec(a.CREATE_TIME || a.UPDATE_TIME || '')) + '">' + escapeHtml(rowTime) + '</span>';
      }
      html += '<div class="group-row-tags">' + renderTagsInline(a.TAGS) + '</div>';
      if (isOwnOrAllowed(a)) {
        html += '<button class="card-action-btn edit-note-btn" data-id="' + escapeHtml(id) + '">✎ ' + getMessage('edit') + '</button>';
        html += '<button class="card-action-btn danger delete-btn" data-id="' + escapeHtml(id) + '">✕ ' + getMessage('delete') + '</button>';
      }
      html += '</div>';
    });
    html += '</div>';

    html += '</div>'; // card-body
    html += '</div>'; // annotation-card
    return html;
  }

  function findCanvasByGroupKey(key) {
    var canvases = document.querySelectorAll('.image-group-overlay-canvas');
    for (var i = 0; i < canvases.length; i++) {
      if (canvases[i].dataset.groupKey === key) return canvases[i];
    }
    return null;
  }

  function findToggleById(id) {
    var toggles = document.querySelectorAll('.group-annotation-toggle');
    for (var i = 0; i < toggles.length; i++) {
      if (toggles[i].dataset.id === id) return toggles[i];
    }
    return null;
  }

  function drawImageGroupOverlay(group) {
    var key = group.imageUrl;
    var canvas = findCanvasByGroupKey(key);
    if (!canvas) return;
    var wrapper = canvas.parentElement;
    var img = wrapper.querySelector('img');
    if (!img) return;

    function doDraw() {
      var w = img.clientWidth;
      var h = img.clientHeight;
      if (w === 0 || h === 0) return;

      canvas.width = w;
      canvas.height = h;
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';

      // Scale factor: how much the image is scaled down in the preview
      var nw = img.naturalWidth || w;
      var nh = img.naturalHeight || h;
      var scale = Math.min(w / nw, h / nh);

      var ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, w, h);

      group.annotations.forEach(function (a) {
        // Check checkbox state
        var id = a.MARK_INFO_ID || '';
        var cb = findToggleById(id);
        if (cb && !cb.checked) return;

        var type = getAnnotationType(a);
        var color = a.MARK_COLOR || '#ff3c82';
        var lineWidth = parseInt(a.END_MD5) || 2;

        if (type === 'rect') {
          drawGroupRect(ctx, a, w, h, color, lineWidth, scale);
        } else if (type === 'rectFrame') {
          drawGroupRectFrame(ctx, a, w, h, color, lineWidth, scale);
        } else if (type === 'arrow') {
          drawGroupArrow(ctx, a, w, h, color, lineWidth, scale);
        } else if (type === 'flag') {
          drawGroupFlag(ctx, a, w, h, color, lineWidth, scale);
        } else if (type === 'freehand') {
          drawGroupFreehand(ctx, a, w, h, color, lineWidth, scale);
        } else if (type === 'text') {
          drawGroupText(ctx, a, w, h, color, scale);
        }
      });
    }

    if (!img.complete || img.naturalWidth === 0) {
      img.addEventListener('load', function () {
        requestAnimationFrame(doDraw);
      });
    } else {
      requestAnimationFrame(doDraw);
    }
  }

  // Draw individual shape types on group canvas
  function drawGroupRect(ctx, a, w, h, color, lineWidth, scale) {
    var so = parseInt(a.START_OFFSET) || 0;
    var eo = parseInt(a.END_OFFSET) || 0;
    var x1 = Math.floor(so / 1000);
    var y1 = so % 1000;
    var x2 = Math.floor(eo / 1000);
    var y2 = eo % 1000;

    var left = Math.min(x1, x2) / 1000 * w;
    var top = Math.min(y1, y2) / 1000 * h;
    var rw = Math.abs(x2 - x1) / 1000 * w;
    var rh = Math.abs(y2 - y1) / 1000 * h;

    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1, lineWidth * scale);
    ctx.strokeRect(left, top, rw, rh);
  }

  // rectFrame（$rectFrame）: 圆点虚线矩形；坐标编码与 arrow 一致（START 百分比 / END 千分比）
  function drawGroupRectFrame(ctx, a, w, h, color, lineWidth, scale) {
    var so = parseInt(a.START_OFFSET) || 0;
    var eo = parseInt(a.END_OFFSET) || 0;

    var x_offset = parseInt(so / 1000000);
    var y_offset = Math.abs(so % 1000000);
    if (y_offset >= 900000) y_offset = -(y_offset - 900000);
    var x2_offset = parseInt(eo / 1000000);
    var y2_offset = Math.abs(eo % 1000000);
    if (y2_offset >= 900000) y2_offset = -(y2_offset - 900000);

    // START 为百分比(/100)，END 为千分比(/1000)，与 arrow-drawing.js 一致
    var x1 = x_offset / 100 * w;
    var y1 = y_offset / 100 * h;
    var x2 = x2_offset / 1000 * w;
    var y2 = y2_offset / 1000 * h;

    var left = Math.min(x1, x2);
    var top = Math.min(y1, y2);
    var rw = Math.abs(x2 - x1);
    var rh = Math.abs(y2 - y1);

    // 短密虚线呼应扩展页（butt 平头 + 短线段[effStroke+1, effStroke]，区别于 pageRect 长虚线）；
    // 线宽 = 选中尺寸+1（与 rect-frame-drawing.js 一致）
    var effStroke = Math.max(1, (lineWidth + 1) * scale);
    ctx.strokeStyle = color;
    ctx.lineWidth = effStroke;
    ctx.lineCap = 'butt';
    ctx.setLineDash([effStroke + 1, effStroke]);
    ctx.strokeRect(left, top, rw, rh);
    ctx.setLineDash([]);
  }

  function drawGroupArrow(ctx, a, w, h, color, lineWidth, scale) {
    var so = parseInt(a.START_OFFSET) || 0;
    var eo = parseInt(a.END_OFFSET) || 0;

    // Arrow coordinates: START in centipercent, END in permille (same as arrow-drawing.js)
    var x_offset = parseInt(so / 1000000);
    var y_offset = Math.abs(so % 1000000);
    if (y_offset >= 900000) y_offset = -(y_offset - 900000);
    var x2_offset = parseInt(eo / 1000000);
    var y2_offset = Math.abs(eo % 1000000);
    if (y2_offset >= 900000) y2_offset = -(y2_offset - 900000);

    // Convert to canvas pixels
    var left = x_offset / 100 * w;
    var top = y_offset / 100 * h;
    var left2 = x2_offset / 1000 * w;
    var top2 = y2_offset / 1000 * h;

    // Scale text_size by image scale factor so shape proportions match the page
    var text_size = (parseInt(a.END_MD5) || 2) * scale;
    var svgMod = managerConvertSvgModual([[4, 10], [2, 10], [0, 0], [-2, 10], [-4, 10]], text_size);

    var points = [];
    // Arrow: tip is (left2, top2), base is (left, top)
    points.push([left2, top2]);
    svgMod.forEach(function (mt) {
      if (mt[1] === 0) {
        points.push([left, top]);
      } else {
        var sss = managerConvertSvg(left, top, left2, top2, mt[0], mt[1]);
        sss[0] = parseInt(left2 - sss[0]);
        sss[1] = parseInt(top2 - sss[1]);
        points.push(sss);
      }
    });

    // Draw filled polygon
    ctx.fillStyle = color;
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(points[0][0], points[0][1]);
    for (var i = 1; i < points.length; i++) {
      ctx.lineTo(points[i][0], points[i][1]);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  // Helper: same as injected arrow-drawing.js sdbw_convert_svg
  function managerConvertSvg(x1, y1, x2, y2, st_hd, st_xx) {
    var base_hd = Math.atan2((y2 - y1), (x2 - x1));
    var tp_hd = base_hd + st_hd;
    var x_new = st_xx * Math.cos(tp_hd);
    var y_new = st_xx * Math.sin(tp_hd);
    return [x_new, y_new];
  }

  // Helper: same as injected arrow-drawing.js sdbw_convertSvgModual
  function managerConvertSvgModual(mod_arr, m) {
    var newArr = [];
    Array.from(mod_arr).forEach(function (mt) {
      var m0 = mt[0] * m;
      var m1 = mt[1] * m;
      if (m1 === 0) {
        newArr.push([0, 0]);
      } else {
        var st_hd = Math.atan(m0 / m1);
        var st_xx = Math.sqrt(m0 * m0 + m1 * m1);
        newArr.push([st_hd, st_xx]);
      }
    });
    return newArr;
  }

  function drawGroupFlag(ctx, a, w, h, color, lineWidth, scale) {
    var so = parseInt(a.START_OFFSET) || 0;
    var eo = parseInt(a.END_OFFSET) || 0;

    // Decode START coordinates: centipercent
    var x_offset = parseInt(so / 1000000);
    var y_offset = Math.abs(so % 1000000);
    if (y_offset >= 900000) y_offset = -(y_offset - 900000);

    // Decode END coordinates: permille
    var x2_offset = parseInt(eo / 1000000);
    var y2_offset = Math.abs(eo % 1000000);
    if (y2_offset >= 900000) y2_offset = -(y2_offset - 900000);

    // Convert to canvas pixels
    var left = x_offset / 100 * w;
    var top = y_offset / 100 * h;
    var left2 = x2_offset / 1000 * w;
    var top2 = y2_offset / 1000 * h;

    // Scale text_size by image scale factor so shape proportions match the page
    var text_size = (parseInt(a.END_MD5) || 2) * scale;
    var svgMod = managerConvertSvgModual([[-20, 14], [0, 14], [0, 0], [0, 14]], text_size);

    var points = [];
    // Flag: anchor point is (left, top), target is (left2, top2)
    points.push([left, top]);
    svgMod.forEach(function (mt) {
      if (mt[1] === 0) {
        points.push([left2, top2]);
      } else {
        var sss = managerConvertSvg(left2, top2, left, top, mt[0], mt[1]);
        sss[0] = parseInt(left - sss[0]);
        sss[1] = parseInt(top - sss[1]);
        points.push(sss);
      }
    });

    // Draw filled polygon
    ctx.fillStyle = color;
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(points[0][0], points[0][1]);
    for (var i = 1; i < points.length; i++) {
      ctx.lineTo(points[i][0], points[i][1]);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  function drawGroupFreehand(ctx, a, w, h, color, lineWidth, scale) {
    var context = a.CONTEXT;
    if (!context) return;

    var points;
    try {
      points = typeof context === 'string' ? JSON.parse(context) : context;
    } catch (e) {
      return;
    }
    if (!points || points.length < 2) return;

    // Points are in thousandths of image dimensions — already ratio-based, scale with canvas
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1, lineWidth * scale);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();

    points.forEach(function (p, i) {
      var x = p.x / 1000 * w;
      var y = p.y / 1000 * h;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
  }

  function drawGroupText(ctx, a, w, h, color, scale) {
    var so = parseInt(a.START_OFFSET) || 0;
    var eo = parseInt(a.END_OFFSET) || 0;

    // Text coordinates: same decoding as text-annotation.js
    var _raw_x = parseInt(so / 1000000);
    var _raw_y = so % 1000000;
    // sign-bit: raw >= 1000 means negative offset
    var x_offset = _raw_x >= 1000 ? -(_raw_x - 1000) : _raw_x;
    var y_offset = _raw_y >= 1000 ? -(_raw_y - 1000) : _raw_y;

    var px = x_offset / 1000 * w;
    var py = y_offset / 1000 * h;

    // Text dimensions: END_OFFSET = width * 100000 + height (pixels)
    var tw = parseInt(eo / 100000);
    var th = eo % 100000;
    var boxW = tw / 1000 * w;
    var boxH = th / 1000 * h;

    var text = a.CONTEXT || '';
    if (!text) return;

    // Font size scaled with image
    var fontSize = Math.max(8, Math.round(14 * scale));
    ctx.font = fontSize + 'px sans-serif';
    ctx.fillStyle = color;
    ctx.textBaseline = 'top';

    // Truncate text to fit, padding scaled with image
    var pad = Math.max(2, 4 * scale);
    var displayText = text.length > 50 ? text.substring(0, 50) + '...' : text;
    ctx.fillText(displayText, px + pad, py + pad);
  }

  function redrawImageGroup(groupKey) {
    var item = null;
    for (var i = 0; i < state.renderItems.length; i++) {
      if (state.renderItems[i].kind === 'group' && state.renderItems[i].imageUrl === groupKey) {
        item = state.renderItems[i];
        break;
      }
    }
    if (!item) return;
    drawImageGroupOverlay(item);
  }

  // ---- Event Handlers ----

  // 可拖动分割线：调整 folder-tree-panel 高度，持久化到 chrome.storage.local
  function initSidebarResizer() {
    var resizer = document.getElementById('sidebarResizer');
    if (!resizer) return;

    // 启动时恢复持久化的高度
    chrome.storage.local.get(['sidebarFolderHeight'], function (result) {
      var h = result && result.sidebarFolderHeight;
      if (typeof h === 'number' && h >= 100) {
        document.documentElement.style.setProperty('--sidebar-folder-h', h + 'px');
      }
    });

    resizer.addEventListener('mousedown', function (e) {
      e.preventDefault();
      e.stopPropagation();
      resizer.classList.add('dragging');
      var startY = e.clientY;
      var panel = document.getElementById('folderTreePanel');
      var startH = panel ? panel.getBoundingClientRect().height : 280;

      function onMove(ev) {
        // 向下拖 → 分割线下移 → 上区变大；向上拖 → 分割线上移 → 上区变小
        var newH = startH + (ev.clientY - startY);
        var maxH = window.innerHeight * 0.8;
        if (newH < 100) newH = 100;
        if (newH > maxH) newH = maxH;
        document.documentElement.style.setProperty('--sidebar-folder-h', newH + 'px');
      }

      function onUp() {
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
        resizer.classList.remove('dragging');
        var cur = parseInt(document.documentElement.style.getPropertyValue('--sidebar-folder-h'), 10);
        if (cur && cur >= 100) {
          chrome.storage.local.set({ sidebarFolderHeight: cur });
        }
      }

      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
    });
  }

  // 可拖动分割线：调整 sidebar 宽度，持久化到 chrome.storage.local
  function initSidebarWidthResizer() {
    var resizer = document.getElementById('sidebarVResizer');
    if (!resizer) return;

    // 启动时恢复持久化的宽度
    chrome.storage.local.get(['sidebarWidth'], function (result) {
      var w = result && result.sidebarWidth;
      if (typeof w === 'number' && w >= 200) {
        document.documentElement.style.setProperty('--sidebar-w', w + 'px');
      }
    });

    resizer.addEventListener('mousedown', function (e) {
      e.preventDefault();
      e.stopPropagation();
      resizer.classList.add('dragging');
      var startX = e.clientX;
      var sidebar = document.getElementById('sidebar');
      var startW = sidebar ? sidebar.getBoundingClientRect().width : 300;

      function onMove(ev) {
        // 向右拖 → sidebar 变宽；向左拖 → sidebar 变窄
        var newW = startW + (ev.clientX - startX);
        var maxW = window.innerWidth * 0.6;   // 上限：视口 60%
        if (newW < 200) newW = 200;           // 下限：200px
        if (newW > maxW) newW = maxW;
        document.documentElement.style.setProperty('--sidebar-w', newW + 'px');
      }

      function onUp() {
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
        resizer.classList.remove('dragging');
        var cur = parseInt(document.documentElement.style.getPropertyValue('--sidebar-w'), 10);
        if (cur && cur >= 200) {
          chrome.storage.local.set({ sidebarWidth: cur });
        }
      }

      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
    });
  }

  // 分享管理打开钩子：SM 状态对象在 DOMContentLoaded 作用域内（initEvents 不可见），
  // 由 DOMContentLoaded 侧把打开函数赋到这里，功能菜单点击时调用。
  var mgrOpenShareManagerFn = null;

  // 我的信息打开钩子（同上模式）：登录→userPanel 账号面板；未登录→游客信息弹窗（限额/使用/限制）。
  var mgrOpenMyInfoFn = null;


  function initEvents() {
    // Sidebar page click (event delegation)
    document.getElementById('pageList').addEventListener('click', function (e) {
      // 收藏星标点击：切换收藏，不触发页面切换（批量模式下也保留）
      var favEl = e.target.closest('.page-item-fav');
      if (favEl) {
        e.stopPropagation();
        toggleFavorite(favEl.dataset.favUrl);
        return;
      }
      var item = e.target.closest('.page-item');
      if (!item) return;
      var url = item.dataset.url;
      var domain = item.dataset.domain;

      // 批量模式：点击 item 或 checkbox 切换选中，不导航
      if (state.batchMode) {
        if (state.batchSelectedUrls.has(url)) {
          state.batchSelectedUrls.delete(url);
        } else {
          state.batchSelectedUrls.add(url);
        }
        updateBatchUI();
        return;
      }

      selectPage(url, domain);
    });

    // Sidebar page right-click (context menu)
    document.getElementById('pageList').addEventListener('contextmenu', function (e) {
      var item = e.target.closest('.page-item');
      if (!item) return;
      e.preventDefault();
      showPageContextMenu(e, item.dataset.url, item.dataset.domain);
    });

    // Page context menu click dispatcher
    document.getElementById('pageContextMenu').addEventListener('click', function (e) {
      var menuItem = e.target.closest('.context-menu-item');
      if (!menuItem) return;
      var action = menuItem.dataset.action;
      var url = menuItem.dataset.url;
      var domain = menuItem.dataset.domain;
      hideContextMenu();
      // Phase 7: 文档走专属路径（rename/delete 不调 renamePage/deletePage）
      var _isDoc = (state.documents || []).some(function (d) { return d.url === url; });
      if (_isDoc) {
        if (action === 'rename') promptRenameDocument(url);
        else if (action === 'delete') confirmDeleteDocument(url);
        return;
      }
      // 快照走专属路径（与文档同构，rename/delete 不调 renamePage/deletePage）
      var _isSnap = (state.snapshots || []).some(function (s) { return s.url === url; });
      if (_isSnap) {
        if (action === 'rename') promptRenameSnapshot(url);
        else if (action === 'delete') confirmDeleteSnapshot(url);
        return;
      }
      if (action === 'delete') {
        confirmDeletePage(url, domain);
      } else if (action === 'rename') {
        promptRenamePage(url, domain);
      }
    });

    // 收藏过滤按钮：只看收藏页面
    var favFilterBtn = document.getElementById('favFilterBtn');
    if (favFilterBtn) {
      favFilterBtn.addEventListener('click', function () {
        state.showFavoritesOnly = !state.showFavoritesOnly;
        favFilterBtn.textContent = state.showFavoritesOnly ? '★' : '☆';
        favFilterBtn.classList.toggle('active', state.showFavoritesOnly);
        // 收藏过滤时隐藏目录树（避免与树视图冲突）
        var ftp = document.getElementById('folderTreePanel');
        if (ftp) ftp.style.display = state.showFavoritesOnly ? 'none' : 'flex';
        renderSidebar();
      });
    }

    // 「显示全部」按钮：清除目录过滤，回到完整列表
    var showAllBtn = document.getElementById('showAllBtn');
    if (showAllBtn) {
      showAllBtn.addEventListener('click', function () {
        setActiveFolder(null);
      });
    }

    // 整页批注编辑/添加按钮 → 内嵌编辑器弹层
    var pageNoteEditBtn = document.getElementById('pageNoteEditBtn');
    if (pageNoteEditBtn) pageNoteEditBtn.addEventListener('click', openPageNoteEditorModal);
    var pageNoteAddBtn = document.getElementById('pageNoteAddBtn');
    if (pageNoteAddBtn) pageNoteAddBtn.addEventListener('click', openPageNoteEditorModal);

    // Folder tree click (event delegation)
    document.getElementById('folderTreeContent').addEventListener('click', function (e) {
      var moveBtn = e.target.closest('.tree-page-move');
      if (moveBtn) {
        var pageUrl = moveBtn.dataset.moveUrl;
        showMoveToFolderDropdown(e, pageUrl);
        return;
      }
      var arrow = e.target.closest('.tree-node-arrow');
      if (arrow && !arrow.classList.contains('empty')) {
        var row = arrow.closest('.tree-node-row');
        if (row) toggleFolderExpand(row.dataset.folderId);
        return;
      }
      var pageItem = e.target.closest('.tree-page-item');
      if (pageItem) {
        selectPage(pageItem.dataset.url, pageItem.dataset.domain);
        return;
      }
      // 未分类标签：点击 → 过滤未分类页面（activeFolderId=''）
      var unclassLabel = e.target.closest('.tree-unclassified-label');
      if (unclassLabel) {
        setActiveFolder('');
        return;
      }
      var nodeRow = e.target.closest('.tree-node-row');
      if (nodeRow) {
        // 点击目录行 → 按该目录(含子孙)过滤下方页面列表；展开/折叠仍由 ▶ 箭头控制
        setActiveFolder(nodeRow.dataset.folderId);
      }
    });

    // Folder tree right-click context menu
    document.getElementById('folderTreeContent').addEventListener('contextmenu', function (e) {
      // 优先匹配页面节点（复用 pageList 的右键菜单：重命名 + 删除）
      var pageItem = e.target.closest('.tree-page-item');
      if (pageItem) {
        showPageContextMenu(e, pageItem.dataset.url, pageItem.dataset.domain);
        return;
      }
      var nodeRow = e.target.closest('.tree-node-row');
      if (nodeRow) {
        showFolderContextMenu(e, nodeRow.dataset.folderId);
      }
    });

    // 目录树拖拽手动排序（dragstart/dragover/drop/dragend 委托，与上方 click/contextmenu 同容器）
    _initTreeDragReorder();

    // Context menu click actions
    document.getElementById('folderContextMenu').addEventListener('click', function (e) {
      var item = e.target.closest('.context-menu-item');
      if (!item || item.classList.contains('disabled')) return;
      var action = item.dataset.action;
      var folderId = item.dataset.folderId;
      hideContextMenu();
      if (action === 'new-doc') {
        openDocEditor({ folderId: folderId || null });
      } else if (action === 'new-sub') {
        showFolderModal(getMessage('folNewSubfolder'), '', function (name) {
          createFolder(name, folderId);
        });
      } else if (action === 'rename') {
        var folder = state.folders.find(function (f) { return f.id === folderId; });
        if (folder) {
          showFolderModal(getMessage('folRenameFolder'), folder.name, function (name) {
            renameFolder(folderId, name);
          });
        }
      } else if (action === 'delete') {
        if (confirm(getMessage('folDeleteConfirm'))) {
          deleteFolder(folderId);
        }
      }
    });

    // Move to folder dropdown click
    document.getElementById('moveToFolderDropdown').addEventListener('click', function (e) {
      var item = e.target.closest('.move-to-folder-item');
      if (!item) return;
      var pageUrl = item.dataset.movePage;
      var folderId = item.dataset.targetFolder || null;
      hideContextMenu();
      assignPageToFolder(pageUrl, folderId);
    });

    // Folder modal buttons
    document.getElementById('folderModalCancelBtn').addEventListener('click', closeFolderModal);
    document.getElementById('folderModalConfirmBtn').addEventListener('click', function () {
      var name = document.getElementById('folderNameInput').value.trim();
      if (!name) return;
      var action = pendingFolderAction;
      closeFolderModal();
      if (action) action(name);
    });
    document.getElementById('folderNameInput').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') document.getElementById('folderModalConfirmBtn').click();
      if (e.key === 'Escape') closeFolderModal();
    });
    document.getElementById('folderModal').addEventListener('click', function (e) {
      if (e.target === this) closeFolderModal();
    });

    // 新建文档按钮 / 文档编辑器 overlay 控制（Phase 7）
    // 入口提取为具名函数：目录树头部按钮与功能菜单（新建文档/图片文档）共用同一创建路径。
    function mgrOpenNewDoc() {
      var fid = (state.activeFolderId && state.activeFolderId !== '') ? state.activeFolderId : null;
      openDocEditor({ folderId: fid });
    }
    // 从图片新建文档：多选图片 → 新建空白文档并自动填入（openDocEditor initialImageFiles → importImages）
    function mgrOpenNewDocFromImages() {
      var input = document.createElement('input');
      input.type = 'file';
      input.multiple = true;
      input.accept = 'image/*';
      input.addEventListener('change', function () {
        if (!input.files || !input.files.length) return;
        var files = Array.prototype.slice.call(input.files).filter(_isImageFileLike);
        if (!files.length) return;
        var fid = (state.activeFolderId && state.activeFolderId !== '') ? state.activeFolderId : null;
        openDocEditor({ folderId: fid, initialImageFiles: files });
      });
      input.click();
    }
    var newDocBtn = document.getElementById('newDocBtn');
    if (newDocBtn) {
      newDocBtn.addEventListener('click', mgrOpenNewDoc);
    }
    var newDocFromImagesBtn = document.getElementById('newDocFromImagesBtn');
    if (newDocFromImagesBtn) {
      newDocFromImagesBtn.addEventListener('click', mgrOpenNewDocFromImages);
    }
    var docEditBtnEl = document.getElementById('docEditBtn');
    if (docEditBtnEl) {
      docEditBtnEl.addEventListener('click', function () {
        if (state.currentPage && state.currentPage.kind === 'document' && state.currentPage.docId) {
          openDocEditor({ docId: state.currentPage.docId });
        }
      });
    }
    var docEditorCloseBtn = document.getElementById('docEditorCloseBtn');
    if (docEditorCloseBtn) {
      docEditorCloseBtn.addEventListener('click', requestCloseDocEditor);
    }
    var docEditorImportBtn = document.getElementById('docEditorImportBtn');
    if (docEditorImportBtn) {
      // applyI18n 不处理 data-i18n-title，须命令式设置 tooltip（与 close 按钮硬编码 title 同理）
      var impTip = chrome.i18n.getMessage('docEditorImport');
      if (impTip) docEditorImportBtn.title = impTip;
      docEditorImportBtn.addEventListener('click', function () {
        var input = document.createElement('input');
        input.type = 'file';
        input.multiple = true;   // 多选：图片批量追加（_importEditorImages），文档文件仍单文件替换导入
        input.accept = '.pdf,.docx,.xlsx,.xls,.html,.htm,.markdown,.md,image/*';
        input.addEventListener('change', function () {
          if (!input.files || !input.files.length) return;
          var files = Array.prototype.slice.call(input.files);
          var images = files.filter(_isImageFileLike);
          var others = files.filter(function (f) { return !_isImageFileLike(f); });
          // 顺序：先文档文件（保留替换确认语义）、后图片（追加末尾）——
          // 反过来会让替换确认/内容替换把刚插入的图片清掉
          var chain = Promise.resolve();
          if (others.length) {
            chain = chain.then(function () { return handleDocEditorImport(others[0]); });
          }
          if (images.length) {
            chain = chain.then(function () { return _importEditorImages(images); });
          }
        });
        input.click();
      });
    }
    // ESC 关闭文档编辑器 overlay
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        // 数学公式弹层打开时，Esc 仅交给弹层自身关闭，不触发编辑器关闭确认
        if (document.querySelector('.wpzl-math-modal-overlay')) return;
        var deOverlay = document.getElementById('docEditorOverlay');
        if (deOverlay && deOverlay.style.display !== 'none') requestCloseDocEditor();
      }
    });

    // Folder tree add button (top level)
    document.getElementById('folderTreeAddBtn').addEventListener('click', function () {
      showFolderModal(getMessage('newFolder'), '', function (name) {
        createFolder(name, null);
      });
    });

    // Close context menus on outside click
    document.addEventListener('click', function (e) {
      if (!e.target.closest('.context-menu') && !e.target.closest('.tree-node-row')) {
        document.getElementById('folderContextMenu').style.display = 'none';
      }
      // pageContextMenu：右键 page item 弹出，点击菜单项以外区域关闭
      if (!e.target.closest('#pageContextMenu') && !e.target.closest('.page-item')) {
        var pcm = document.getElementById('pageContextMenu');
        if (pcm) pcm.style.display = 'none';
      }
      if (!e.target.closest('.move-to-folder-dropdown') && !e.target.closest('.tree-page-move')) {
        document.getElementById('moveToFolderDropdown').style.display = 'none';
      }
      if (!e.target.closest('.feature-menu-wrapper')) {
        var _fmDd = document.getElementById('featureMenuDropdown');
        if (_fmDd) _fmDd.style.display = 'none';
        document.getElementById('importExportDropdown').style.display = 'none';
      }
      if (!e.target.closest('.user-menu-wrapper')) {
        var _upPanel = document.getElementById('userPanel');
        if (_upPanel) _upPanel.style.display = 'none';
      }
    });

    // 滚动时关闭所有 context menu（菜单是 position:fixed，滚动会视觉错位）
    window.addEventListener('wheel', function () { hideContextMenu(); }, { passive: true });
    window.addEventListener('scroll', function () { hideContextMenu(); }, { capture: true, passive: true });

    // Search
    var searchInput = document.getElementById('searchInput');
    var searchClear = document.getElementById('searchClear');
    var searchTimer = null;

    searchInput.addEventListener('input', function () {
      var q = searchInput.value.trim();
      searchClear.classList.toggle('visible', q.length > 0);

      clearTimeout(searchTimer);
      searchTimer = setTimeout(function () {
        if (q.length === 0) {
          if (state.activeTag) {
            // Only tag filter active, redo tag-only search
            state.searchQuery = '';
            performTagSearch(state.activeTag);
          } else {
            state.searchMode = false;
            state.searchQuery = '';
            state.searchResults = [];
            state.currentPage = null;
            renderSidebar();
            renderContent();
          }
          return;
        }
        performSearch(q);
      }, 300);
    });

    searchClear.addEventListener('click', function () {
      searchInput.value = '';
      searchClear.classList.remove('visible');
      state.searchQuery = '';

      if (state.activeTag) {
        // Keep tag filter, redo tag-only search
        performTagSearch(state.activeTag);
      } else if (state.currentPage) {
        state.searchMode = false;
        state.searchResults = [];
        var page = state.currentPage;
        loadAnnotations(page.domain, page.url).then(function (markList) {
          state.annotations = Object.values(markList);
          renderSidebar();
          renderContent();
        }).catch(function () {
          state.annotations = [];
          renderSidebar();
          renderContent();
        });
      } else {
        state.searchMode = false;
        state.searchResults = [];
        renderSidebar();
        renderContent();
      }
    });

    // Tag filter dropdown
    var tagFilterBtn = document.getElementById('tagFilterBtn');
    var tagDropdown = document.getElementById('tagDropdown');
    var tagDropdownClose = document.getElementById('tagDropdownClose');

    tagFilterBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      var isVisible = tagDropdown.style.display !== 'none';
      tagDropdown.style.display = isVisible ? 'none' : 'flex';
      tagFilterBtn.classList.toggle('active', !isVisible);
      if (!isVisible) initTagDropdown();
    });

    tagDropdownClose.addEventListener('click', function () {
      tagDropdown.style.display = 'none';
      tagFilterBtn.classList.remove('active');
    });

    document.addEventListener('click', function (e) {
      if (!tagDropdown.contains(e.target) && e.target !== tagFilterBtn) {
        tagDropdown.style.display = 'none';
        tagFilterBtn.classList.remove('active');
      }
    });

    document.getElementById('tagDropdownList').addEventListener('click', function (e) {
      var item = e.target.closest('.tag-dropdown-item');
      if (!item) return;
      var tagName = item.dataset.tag;

      tagDropdown.style.display = 'none';
      tagFilterBtn.classList.remove('active');

      if (!tagName) {
        // Clear tag, keep keyword if any
        state.activeTag = null;
        updateActiveTagBadge();
        renderTagDropdown();

        var keyword = (document.getElementById('searchInput').value || '').trim();
        if (keyword) {
          performSearch(keyword);
        } else if (state.currentPage) {
          state.searchMode = false;
          state.searchResults = [];
          var page = state.currentPage;
          loadAnnotations(page.domain, page.url).then(function (markList) {
            state.annotations = Object.values(markList);
            renderSidebar();
            renderContent();
          }).catch(function () {
            state.annotations = [];
            renderSidebar();
            renderContent();
          });
        } else {
          state.searchMode = false;
          state.searchResults = [];
          renderSidebar();
          renderContent();
        }
        return;
      }

      performTagSearch(tagName);
    });

    // Active tag badge clear button
    document.getElementById('activeTagClear').addEventListener('click', function (e) {
      e.stopPropagation();
      state.activeTag = null;
      updateActiveTagBadge();
      renderTagDropdown();

      var keyword = (document.getElementById('searchInput').value || '').trim();
      if (keyword) {
        // Keep keyword search, redo without tag
        performSearch(keyword);
      } else if (state.currentPage) {
        state.searchMode = false;
        state.searchResults = [];
        var page = state.currentPage;
        loadAnnotations(page.domain, page.url).then(function (markList) {
          state.annotations = Object.values(markList);
          renderSidebar();
          renderContent();
        }).catch(function () {
          state.annotations = [];
          renderSidebar();
          renderContent();
        });
      } else {
        state.searchMode = false;
        state.searchResults = [];
        renderSidebar();
        renderContent();
      }
    });

    // Filter tabs
    document.getElementById('filterTabs').addEventListener('click', function (e) {
      var tab = e.target.closest('.filter-tab');
      if (!tab) return;
      document.querySelectorAll('.filter-tab').forEach(function (t) { t.classList.remove('active'); });
      tab.classList.add('active');
      state.activeFilter = tab.dataset.type;
      applyFilter();
    });

    // Author toggle bar
    document.getElementById('authorBar').addEventListener('change', function (e) {
      if (!e.target.classList.contains('author-toggle-check')) return;
      var authorId = e.target.dataset.authorId;
      var label = e.target.closest('.author-toggle-item');
      if (e.target.checked) {
        state.hiddenAuthorIds.delete(authorId);
        if (label) label.classList.remove('off');
      } else {
        state.hiddenAuthorIds.add(authorId);
        if (label) label.classList.add('off');
      }
      applyFilter();
    });

    // Sort controls
    document.getElementById('sortField').addEventListener('change', function () {
      state.sortBy = this.value;
      applyFilter();
      updateSortDirectionLabel();
    });
    document.getElementById('sortOrderBtn').addEventListener('click', function () {
      state.sortOrder = state.sortOrder === 'asc' ? 'desc' : 'asc';
      updateSortDirectionLabel();
      applyFilter();
    });

    // Image viewer (click to zoom preview images)
    document.getElementById('annotationList').addEventListener('click', function (e) {
      if (e.target.classList.contains('preview-zoomable')) {
        // Check if this is an image group card (multiple annotations on same image)
        var groupCard = e.target.closest('.image-group-card');
        if (groupCard) {
          var groupKey = groupCard.dataset.groupKey;
          var group = null;
          for (var i = 0; i < state.renderItems.length; i++) {
            if (state.renderItems[i].kind === 'group' && state.renderItems[i].imageUrl === groupKey) {
              group = state.renderItems[i];
              break;
            }
          }
          if (group) {
            openDetailViewer(group.imageUrl, group.annotations);
            return;
          }
        }

        // Check if this is a single rect annotation with an image
        var annCard = e.target.closest('.annotation-card:not(.image-group-card)');
        if (annCard) {
          var annId = annCard.dataset.id;
          var annotation = null;
          for (var j = 0; j < state.annotations.length; j++) {
            if (state.annotations[j].MARK_INFO_ID === annId) {
              annotation = state.annotations[j];
              break;
            }
          }
          if (annotation) {
            var annType = getAnnotationType(annotation);
            if (annType === 'rect' || annType === 'imgAnno') {
              var imgUrl = annotation.END_TAG_NAME || '';
              if (imgUrl) {
                openDetailViewer(imgUrl, [annotation]);
                return;
              }
            }
          }
        }

        // Default: simple image viewer
        var src = e.target.dataset.originalSrc || e.target.src;
        openImageViewer(src);
      }
    });
    document.getElementById('viewerCloseBtn').addEventListener('click', closeImageViewer);
    document.getElementById('imageViewer').addEventListener('click', function (e) {
      if (e.target.classList.contains('viewer-backdrop') || e.target.id === 'imageViewer') {
        closeImageViewer();
      }
    });
    // 图片显示模式（适应页面/原始尺寸）：读持久化初值 + radio 切换即时生效
    chrome.storage.local.get([WPZL_IMG_VIEW_MODE_KEY], function (r) {
      _applyImageViewMode(r && r[WPZL_IMG_VIEW_MODE_KEY]);
    });
    var _fitRadio = document.getElementById('imgViewModeFit');
    var _origRadio = document.getElementById('imgViewModeOriginal');
    if (_fitRadio) _fitRadio.addEventListener('change', function () {
      if (!_fitRadio.checked) return;
      var patch = {}; patch[WPZL_IMG_VIEW_MODE_KEY] = 'fit';
      chrome.storage.local.set(patch);
      _applyImageViewMode('fit');
    });
    if (_origRadio) _origRadio.addEventListener('change', function () {
      if (!_origRadio.checked) return;
      var patch = {}; patch[WPZL_IMG_VIEW_MODE_KEY] = 'original';
      chrome.storage.local.set(patch);
      _applyImageViewMode('original');
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeImageViewer();
    });

    // Annotation list events (delegation)
    document.getElementById('annotationList').addEventListener('click', function (e) {
      var target = e.target.closest('button');
      if (!target) {
        // Check for checkbox
        var cb = e.target.closest('.card-select');
        return;
      }

      if (target.classList.contains('delete-btn')) {
        confirmDelete(target.dataset.id);
      } else if (target.classList.contains('edit-note-btn')) {
        openEditNote(target.dataset.id);
      } else if (target.classList.contains('goto-btn')) {
        openPage(target.dataset.url, state.currentPage && state.currentPage.scheme, state.currentPage && state.currentPage.port);
      } else if (target.classList.contains('save-local-btn')) {
        // 保存图片到本地
        var imgUrl = target.dataset.imageUrl;
        if (!imgUrl || !state.currentPage) return;
        target.textContent = getMessage('saving');
        target.disabled = true;
        var pageUrl = state.currentPage.url;
        saveImageFromUrlToSW(imgUrl, pageUrl).then(function () {
          // 获取本地数据
          return getImageData(pageUrl, imgUrl).then(function (rec) {
            if (!rec || !rec.data) return;
            // 更新页面上所有引用此图片的卡片状态和 img src
            var allStatus = document.querySelectorAll('.image-local-status[data-image-url]');
            for (var si = 0; si < allStatus.length; si++) {
              if (allStatus[si].dataset.imageUrl === imgUrl) {
                allStatus[si].innerHTML = '<span class="status-indicator saved" style="color:#22c55e;font-size:12px;">' + getMessage('ivSavedLocal') + '</span>';
                var wrapper = allStatus[si].parentElement;
                if (wrapper) {
                  var img = wrapper.querySelector('img');
                  if (img) {
                    img.src = rec.data;
                    img.dataset.localSaved = 'true';
                  }
                }
              }
            }
            // 重绘所有引用此图片的 group overlay
            var items = state.renderItems;
            items.forEach(function (item) {
              if (item.kind === 'group' && item.imageUrl === imgUrl) drawImageGroupOverlay(item);
            });
          });
        }).catch(function (err) {
          var msg = getMessage('savingFailed');
          if (err && err.message) {
            if (err.message.indexOf('fetch') >= 0 || err.message.indexOf('Failed to fetch') >= 0 || err.message.indexOf('NetworkError') >= 0) {
              msg = getMessage('ivSaveFailedNoAccess');
            } else {
              msg = getMessage('savingFailed') + ': ' + err.message;
            }
          }
          target.textContent = msg;
          target.title = msg;
          target.style.borderColor = 'var(--danger)';
          target.style.color = 'var(--danger)';
          target.disabled = false;
        });
      }
    });

    // Checkbox changes
    document.getElementById('annotationList').addEventListener('change', function (e) {
      // Image group: individual annotation toggle
      if (e.target.classList.contains('group-annotation-toggle')) {
        var groupKey = e.target.dataset.groupKey;
        redrawImageGroup(groupKey);
        // Update "select all" checkbox state
        var card = e.target.closest('.image-group-card');
        if (card) {
          var allToggles = card.querySelectorAll('.group-annotation-toggle');
          var allChecked = Array.prototype.every.call(allToggles, function (cb) { return cb.checked; });
          var selectAll = card.querySelector('.group-select-all');
          if (selectAll) selectAll.checked = allChecked;
        }
        return;
      }
      // Image group: select all toggle
      if (e.target.classList.contains('group-select-all')) {
        var groupKey2 = e.target.dataset.groupKey;
        var checked = e.target.checked;
        var card2 = e.target.closest('.image-group-card');
        if (card2) {
          card2.querySelectorAll('.group-annotation-toggle[data-group-key]').forEach(function (cb) {
            cb.checked = checked;
          });
        }
        redrawImageGroup(groupKey2);
        return;
      }
      if (e.target.classList.contains('rect-visibility-toggle')) {
        var preview = e.target.closest('.image-rect-preview');
        if (preview) {
          var overlay = preview.querySelector('.image-rect-overlay');
          if (overlay) overlay.style.display = e.target.checked ? 'block' : 'none';
        }
        return;
      }
      if (!e.target.classList.contains('card-select')) return;
      var id = e.target.dataset.id;
      if (e.target.checked) state.selectedIds.add(id);
      else state.selectedIds.delete(id);
      updateBatchBar();
    });

    // Select all
    document.getElementById('selectAllCheckbox').addEventListener('change', function (e) {
      var checked = e.target.checked;
      document.querySelectorAll('.card-select').forEach(function (cb) {
        cb.checked = checked;
        if (checked) state.selectedIds.add(cb.dataset.id);
        else state.selectedIds.delete(cb.dataset.id);
      });
      updateBatchBar();
    });

    // Batch delete
    document.getElementById('batchDeleteBtn').addEventListener('click', function () {
      if (state.selectedIds.size === 0) return;
      confirmBatchDelete(Array.from(state.selectedIds));
    });

    // Open page button
    document.getElementById('openPageBtn').addEventListener('click', function () {
      if (state.currentPage) openPage(state.currentPage.url, state.currentPage.scheme, state.currentPage.port);
    });
    // 文档详情页 <a id="pageUrl"> 左键点击 → 走 openPage（POST token），避免 GET ?token= 泄漏到 URL/历史/Referer。
    // 非文档直接 return 走原生链接（普通网页不需要 token）。
    var _pageUrlLink = document.getElementById('pageUrl');
    if (_pageUrlLink) {
      _pageUrlLink.addEventListener('click', function (e) {
        if (!state.currentPage || state.currentPage.kind !== 'document') return;
        e.preventDefault();
        openPage(state.currentPage.url);
      });
    }

    // ---- Feature menu（功能菜单）：导入导出/分享管理/设置/标注开关/反馈与建议/退出并清空 ----
    var featureMenuBtn = document.getElementById('featureMenuBtn');
    var featureMenuDropdown = document.getElementById('featureMenuDropdown');
    var importExportDropdown = document.getElementById('importExportDropdown');

    // applyI18n 不处理 data-i18n-title，图标按钮的 tooltip 须命令式设置
    [ ['syncNowBtn', 'syncNow'], ['syncFailuresBtn', 'syncFailures'], ['featureMenuBtn', 'featureMenu'] ].forEach(function (pair) {
      var el = document.getElementById(pair[0]);
      var tip = chrome.i18n.getMessage(pair[1]);
      if (el && tip) el.title = tip;
    });

    function closeFeatureMenu() {
      featureMenuDropdown.style.display = 'none';
      importExportDropdown.style.display = 'none';
    }

    // 标注开关：与 popup 同一存储键；manager 非当前活动页，须广播到所有 tab 的 content script
    function refreshAnnotationToggleState() {
      chrome.storage.local.get(['wpzl_annotationEnabled'], function (result) {
        var enabled = result.wpzl_annotationEnabled;
        if (enabled === undefined) enabled = true;
        var check = document.getElementById('featureAnnToggleState');
        if (check) check.textContent = enabled ? '✓' : '';
      });
    }

    function toggleAnnotationEnabled() {
      chrome.storage.local.get(['wpzl_annotationEnabled'], function (result) {
        var enabled = result.wpzl_annotationEnabled;
        if (enabled === undefined) enabled = true;
        enabled = !enabled;
        chrome.storage.local.set({ wpzl_annotationEnabled: enabled });
        chrome.tabs.query({}, function (tabs) {
          (tabs || []).forEach(function (tab) {
            if (!tab || !tab.id) return;
            chrome.tabs.sendMessage(tab.id, { type: 'wpzl-annotation-toggle', enabled: enabled })
              .catch(function () { /* content script 未加载的页面（chrome:// 等）忽略 */ });
          });
        });
        var check = document.getElementById('featureAnnToggleState');
        if (check) check.textContent = enabled ? '✓' : '';
      });
    }

    // 退出/清空等危险操作已收敛到设置页（settings → 数据管理），manager 功能菜单不再提供入口。

    featureMenuBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (featureMenuDropdown.style.display === 'none') {
        refreshAnnotationToggleState();
        featureMenuDropdown.style.display = 'block';
      } else {
        closeFeatureMenu();
      }
    });

    featureMenuDropdown.addEventListener('click', function (e) {
      var item = e.target.closest('.feature-menu-item');
      if (!item) return;
      var action = item.dataset.featureAction;
      if (action === 'import-export') {
        // 子菜单：在"导入导出"项左侧弹出（与主菜单同级定位，均相对 feature-menu-wrapper）
        e.stopPropagation();
        if (importExportDropdown.style.display === 'none') {
          importExportDropdown.innerHTML =
            '<div class="context-menu-item" data-action="export-current">📤 ' + getMessage('expCurrentPage') + '</div>' +
            '<div class="context-menu-item" data-action="export-all">📤 ' + getMessage('expAll') + '</div>' +
            '<div class="context-menu-item" data-action="incremental-export">📁 ' + getMessage('expIncremental') + '</div>' +
            '<div class="context-menu-item" data-action="import">📥 ' + getMessage('mgImport') + '</div>';
          importExportDropdown.style.right = '100%';
          importExportDropdown.style.marginRight = '4px';
          importExportDropdown.style.marginTop = '0';
          importExportDropdown.style.top = (featureMenuDropdown.offsetTop + item.offsetTop + 2) + 'px';
          importExportDropdown.style.display = 'block';
        } else {
          importExportDropdown.style.display = 'none';
        }
        return;
      }
      closeFeatureMenu();
      if (action === 'my-info') {
        // 我的信息：登录→账号面板；未登录→游客信息弹窗（与点右上角用户名一致；钩子见 mgrOpenMyInfoFn）
        // stopPropagation：否则本次 click 冒泡到 document 的「点击外部关闭 userPanel」处理器
        // （.user-menu-wrapper 豁免名单不含功能菜单），刚打开的账号面板会在同一事件派发内被立即置回 none。
        e.stopPropagation();
        if (typeof mgrOpenMyInfoFn === 'function') mgrOpenMyInfoFn();
      } else if (action === 'new-doc') {
        mgrOpenNewDoc();
      } else if (action === 'new-doc-from-images') {
        mgrOpenNewDocFromImages();
      } else if (action === 'share-manage') {
        if (typeof mgrOpenShareManagerFn === 'function') mgrOpenShareManagerFn();
      } else if (action === 'settings') {
        chrome.tabs.create({ url: chrome.runtime.getURL('settings/settings.html') });
      } else if (action === 'annotation-toggle') {
        toggleAnnotationEnabled();
      } else if (action === 'feedback') {
        // SSO 自动登录到问题反馈系统（SW 负责写会话 cookie + 开连接器登录入口），与 popup 一致
        chrome.runtime.sendMessage({ type: 'openFeedback' }).catch(function () {});
      } else if (action === 'help') {
        // 帮助文档：URL 由 SW 统一持有（开发占位，发布由 apply-env 按 WEBPZ_DOCS_BASE 注入）
        chrome.runtime.sendMessage({ type: 'wpzl-open-docs' }).catch(function () {});
      }
    });

    importExportDropdown.addEventListener('click', function (e) {
      var item = e.target.closest('.context-menu-item');
      if (!item) return;
      closeFeatureMenu();
      var action = item.dataset.action;
      if (action === 'export-current') openExportModal('current');
      else if (action === 'export-all') openExportModal('all');
      else if (action === 'incremental-export') incrementalExport();
      else if (action === 'import') openImportModal();
    });

    // Modal buttons
    document.getElementById('deleteCancelBtn').addEventListener('click', closeDeleteModal);
    document.getElementById('deleteConfirmBtn').addEventListener('click', executeDelete);
    document.getElementById('editCancelBtn').addEventListener('click', closeEditModal);
    document.getElementById('editSaveBtn').addEventListener('click', executeEditNote);
    initEditTagBindings();

    // Batch mode toolbar buttons
    var batchToggleBtn = document.getElementById('batchToggleBtn');
    if (batchToggleBtn) batchToggleBtn.addEventListener('click', toggleBatchMode);
    var batchExitBtn = document.getElementById('batchExitBtn');
    if (batchExitBtn) batchExitBtn.addEventListener('click', toggleBatchMode);
    var batchSelectAllChk = document.getElementById('batchSelectAllChk');
    if (batchSelectAllChk) batchSelectAllChk.addEventListener('change', batchSelectAllToggle);
    var batchDeleteBtn = document.getElementById('batchDeleteBtn');
    if (batchDeleteBtn) batchDeleteBtn.addEventListener('click', batchDeleteSelected);
    var batchExportBtn = document.getElementById('batchExportBtn');
    if (batchExportBtn) batchExportBtn.addEventListener('click', batchExportSelected);
    var batchMoveBtn = document.getElementById('batchMoveBtn');
    if (batchMoveBtn) batchMoveBtn.addEventListener('click', batchMoveSelected);

    // Move pages modal
    var movePagesCancelBtn = document.getElementById('movePagesCancelBtn');
    if (movePagesCancelBtn) movePagesCancelBtn.addEventListener('click', closeMovePagesModal);
    var movePagesConfirmBtn = document.getElementById('movePagesConfirmBtn');
    if (movePagesConfirmBtn) movePagesConfirmBtn.addEventListener('click', confirmMovePages);
    var movePagesModal = document.getElementById('movePagesModal');
    if (movePagesModal) {
      movePagesModal.addEventListener('click', function (e) {
        if (e.target === this) closeMovePagesModal();
      });
      // Tree click → 选中目录
      var movePagesTree = document.getElementById('movePagesTree');
      if (movePagesTree) {
        movePagesTree.addEventListener('click', function (e) {
          var item = e.target.closest('.folder-picker-item');
          if (!item) return;
          var targetFolder = item.dataset.targetFolder;
          pendingMovePagesSelection = targetFolder === '' ? '' : targetFolder;
          // 高亮选中项
          Array.prototype.slice.call(movePagesTree.querySelectorAll('.folder-picker-item')).forEach(function (el) {
            el.classList.toggle('selected', el === item);
          });
          if (movePagesConfirmBtn) movePagesConfirmBtn.disabled = false;
        });
      }
    }

    // Close modals on overlay click
    document.getElementById('deleteModal').addEventListener('click', function (e) {
      if (e.target === this) closeDeleteModal();
    });
    document.getElementById('editModal').addEventListener('click', function (e) {
      if (e.target === this) closeEditModal();
    });
    document.getElementById('exportModal').addEventListener('click', function (e) {
      if (e.target === this) closeExportModal();
    });

    // Import modal
    document.getElementById('importModal').addEventListener('click', function (e) {
      if (e.target === this) closeImportModal();
    });
    document.getElementById('importCancelBtn').addEventListener('click', closeImportModal);
    document.getElementById('importFileBtn').addEventListener('click', function () {
      var strategy = document.querySelector('#importModal input[name="importStrategy"]:checked').value;
      closeImportModal();
      var input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json,.json.gz,.ndjson.gz';
      input.addEventListener('change', function () {
        if (input.files && input.files[0]) restoreFromFile(input.files[0], strategy);
      });
      input.click();
    });

    // Export modal buttons
    document.getElementById('exportCancelBtn').addEventListener('click', closeExportModal);
    document.getElementById('exportConfirmBtn').addEventListener('click', executeExport);
    document.querySelectorAll('.export-format-pill').forEach(function (pill) {
      pill.addEventListener('click', function () {
        document.querySelectorAll('.export-format-pill').forEach(function (p) { p.classList.remove('active'); });
        pill.classList.add('active');
        _syncExportFormatHint();
      });
    });

    // Snapshot 按钮：弹出该源页的快照列表（按时间倒序），逐条打开 /snap/{snapId} 或删除。
    document.getElementById('snapshotBtn').addEventListener('click', function (e) {
      // 同步捕获锚按钮：Event.currentTarget 在监听器同步执行结束后会被置 null，
      // 而下方 sendMessage().then 是异步微任务，到那时 e.currentTarget 已为 null，
      // 会导致 _openSnapshotPopover 内 getBoundingClientRect() 抛错 → 误报「加载快照失败」。
      var anchorEl = e.currentTarget;
      if (!state.currentPage || anchorEl.disabled) return;
      var url = state.currentPage.url;
      sendMessage('getSnapshotsBySourceUrl', { url: url }).then(function (list) {
        if (!list || list.length === 0) {
          showToast(chrome.i18n.getMessage('snapshotEmptyToast') || '该页面暂无快照');
          return;
        }
        _openSnapshotPopover(anchorEl, list);
      }).catch(function () { showToast(chrome.i18n.getMessage('snapshotLoadFail') || '加载快照失败'); });
    });

    // Initial sort direction label
    updateSortDirectionLabel();
  }

  function updateSortDirectionLabel() {
    var btn = document.getElementById('sortOrderBtn');
    btn.textContent = state.sortOrder === 'asc' ? '↑' : '↓';
    btn.title = state.sortOrder === 'asc' ? getMessage('sortAsc') : getMessage('sortDesc');
  }

  function updateBatchBar() {
    var bar = document.getElementById('batchBar');
    var countEl = document.getElementById('batchCount');
    if (state.selectedIds.size > 0) {
      bar.style.display = 'flex';
      countEl.textContent = getMessage('batchSelected', [String(state.selectedIds.size)]);
    } else {
      bar.style.display = 'none';
    }
  }

  // ---- Page Selection ----

  // ---- 收藏（FAVORITE）----

  function toggleFavorite(url) {
    var page = state.pages.find(function (p) { return p.url === url; });
    if (!page) return;
    var newFav = !page.FAVORITE;
    // 乐观更新本地状态，立即刷新星标
    page.FAVORITE = newFav;
    renderSidebar();
    sendMessage('setFavorite', { url: url, isFavorite: newFav }).then(function () {
      return refreshPageCounts();
    }).then(function () {
      renderSidebar();
    }).catch(function () {
      // 回滚
      page.FAVORITE = !newFav;
      renderSidebar();
    });
  }

  function selectPage(url, domain) {
    var page = state.pages.find(function (p) { return p.url === url; });
    if (!page) {
      // Phase 7: 文档在独立 state.documents（不混入 state.pages）
      var doc = (state.documents || []).find(function (d) { return d.url === url; });
      if (doc) page = doc;
    }
    if (!page) {
      // 网页快照在独立 state.snapshots（与文档同构的一类实体）
      var snap = (state.snapshots || []).find(function (s) { return s.url === url; });
      if (snap) page = snap;
    }
    if (!page && state.searchMode) {
      page = { url: url, domain: domain, title: url };
    }
    if (!page) return;

    state.currentPage = page;
    state.activeFilter = 'all';
    document.querySelectorAll('.filter-tab').forEach(function (t) {
      t.classList.toggle('active', t.dataset.type === 'all');
    });

    // Highlight in sidebar
    document.querySelectorAll('.page-item').forEach(function (el) {
      el.classList.toggle('active', el.dataset.url === url);
    });

    if (page.kind === 'document') {
      // 自建文档：不加载批注列表（文档批注在 /d/{docId} 页，详情视图不展开标注卡片）
      state.annotations = [];
      state.filteredAnnotations = [];
      renderContent();
      renderSidebar();
      return;
    }
    if (page.kind === 'snapshot') {
      // 网页快照：加载其批注（绑定在 /snap/{snapId} 的 url_md5），在详情视图展开标注卡片。
      // 批注的 WEB_URI 归一化为 hostname(无端口) + /snap/{snapId}（与注入 bundle 一致），
      // 故不能用展示用的 page.url（含协议端口）/page.domain（源域）查询，否则取不到批注。
      var _u; try { _u = new URL(page.url); } catch (e) { _u = null; }
      var _annDomain = _u ? _u.hostname : '127.0.0.1';
      var _annWebUri = _u ? (_u.hostname + '/snap/' + page.snapId) : page.url;
      loadAnnotations(_annDomain, _annWebUri).then(function (markList) {
        state.annotations = markList ? Object.values(markList) : [];
        state.filteredAnnotations = state.annotations.slice();
        state.activeFilter = 'all';
        renderContent();
        renderSidebar();
      }).catch(function () {
        state.annotations = [];
        state.filteredAnnotations = [];
        renderContent();
        renderSidebar();
      });
      return;
    }

    if (state.searchMode) {
      // Filter search results for this page
      renderContent();
    } else {
      // Load annotations
      loadAnnotations(domain, url).then(function (markList) {
        state.annotations = Object.values(markList);
        renderContent();
        renderSidebar();
      }).catch(function (err) {
        console.error('Failed to load annotations:', err);
        state.annotations = [];
        renderContent();
      });
    }
  }

  // ---- Search ----

  function performSearch(query) {
    state.searchMode = true;
    state.searchQuery = query;
    // P1-8 分仓：文档正文命中集在 SW 侧流式计算（bodyText 预计算，规则与旧本地搜索一致），
    // 渲染等它完成（renderSearchSidebar 只认 state.docBodyHitSet）；纯标签搜索（无关键词）跳过。
    var bodyHitsP = query
      ? sendMessage('searchDocBodies', { q: query }).then(function (r) {
          state.docBodyHitSet = new Set((r && r.docIds) || []);
        }).catch(function () { state.docBodyHitSet = new Set(); })
      : Promise.resolve().then(function () { state.docBodyHitSet = null; });
    var _renderAfterBodyHits = function () {
      bodyHitsP.then(function () {
        renderSidebar();
        renderContent();
      });
    };

    if (state.activeTag) {
      // AND: first filter by tag, then by keyword
      searchByTag(state.activeTag).then(function (tagResults) {
        var q = query.toLowerCase();
        var filtered = tagResults.filter(function (a) {
          var contextMatch = false;
          if (a.CONTEXT) {
            var ctx = a.CONTEXT;
            if (ctx.indexOf('data:') !== 0 && ctx.indexOf('[{') !== 0 && ctx.indexOf('img:') !== 0) {
              contextMatch = ctx.toLowerCase().includes(q);
            }
          }
          return contextMatch ||
                 (a.COMMENT_TEXT && a.COMMENT_TEXT.toLowerCase().includes(q)) ||
                 (a.TAGS && a.TAGS.toLowerCase().includes(q)) ||
                 (a.DOMAIN && a.DOMAIN.toLowerCase().includes(q));
        });
        state.searchResults = filtered;
        state.annotations = [];
        if (!state.currentPage) {
          state.currentPage = null;
        }
        _renderAfterBodyHits();
      }).catch(function (err) {
        console.error('Search failed:', err);
      });
    } else {
      searchAnnotations(query).then(function (results) {
        state.searchResults = results;
        state.annotations = [];
        if (!state.currentPage) {
          state.currentPage = null;
        }
        _renderAfterBodyHits();
      }).catch(function (err) {
        console.error('Search failed:', err);
      });
    }
  }

  // ---- Tag Dropdown ----

  function initTagDropdown() {
    getAllTags().then(function (tags) {
      state.allTags = tags || [];
      renderTagDropdown();
    }).catch(function (err) {
      console.error('Failed to load tags:', err);
    });
  }

  function updateActiveTagBadge() {
    var badge = document.getElementById('activeTagBadge');
    var nameEl = document.getElementById('activeTagName');
    if (!badge || !nameEl) return;
    if (state.activeTag) {
      nameEl.textContent = state.activeTag;
      badge.style.display = 'inline-flex';
      badge.title = state.activeTag;
    } else {
      nameEl.textContent = '';
      badge.style.display = 'none';
    }
  }

  // 合并「字典标签」+「文档内嵌标签」。跨设备同步下来的文档 tags 不在本地 tags 字典 store
  // （字典只本地缓存，不同步），补齐后这些标签才能在下拉里出现、可点选/可按标签搜索。
  // 去重按 name；排序：有 lastUsed 的字典项在前（按 lastUsed 倒序），纯文档标签按名次在后。
  function mergeDocumentTags(dictTags) {
    var seen = {};
    var merged = [];
    (dictTags || []).forEach(function (t) {
      if (t && t.name && !seen[t.name]) { seen[t.name] = true; merged.push(t); }
    });
    (state.documents || []).forEach(function (d) {
      if (!d || !d.tags) return;
      String(d.tags).split(';').forEach(function (raw) {
        var name = raw.trim();
        if (name && !seen[name]) { seen[name] = true; merged.push({ name: name }); }
      });
    });
    merged.sort(function (a, b) {
      var la = a.lastUsed, lb = b.lastUsed;
      if (la && lb) return lb > la ? 1 : (lb < la ? -1 : 0);
      if (la) return -1;
      if (lb) return 1;
      return (a.name || '').localeCompare(b.name || '');
    });
    return merged;
  }

  function renderTagDropdown() {
    var listEl = document.getElementById('tagDropdownList');
    var emptyEl = document.getElementById('tagDropdownEmpty');
    var tags = mergeDocumentTags(state.allTags);

    if (!tags || tags.length === 0) {
      listEl.innerHTML = '';
      emptyEl.style.display = 'block';
      return;
    }
    emptyEl.style.display = 'none';

    var html = '';
    html += '<div class="tag-dropdown-item' + (!state.activeTag ? ' active' : '') + '" data-tag="">';
    html += '<span class="tag-color-dot" style="background:#999"></span>';
    html += '<span>' + getMessage('tagAll') + '</span>';
    html += '</div>';
    tags.forEach(function (t) {
      var name = t.name || '';
      var isActive = state.activeTag === name;
      html += '<div class="tag-dropdown-item' + (isActive ? ' active' : '') + '" data-tag="' + escapeHtml(name) + '">';
      html += '<span class="tag-color-dot"></span>';
      html += '<span>' + escapeHtml(name) + '</span>';
      html += '</div>';
    });
    listEl.innerHTML = html;
  }

  function performTagSearch(tagName) {
    state.searchMode = true;
    state.activeTag = tagName;
    updateActiveTagBadge();
    renderTagDropdown();

    var keyword = (document.getElementById('searchInput').value || '').trim();
    // P1-8 分仓：同 performSearch——关键词存在时正文命中集 SW 侧计算，渲染等它
    var bodyHitsP = keyword
      ? sendMessage('searchDocBodies', { q: keyword }).then(function (r) {
          state.docBodyHitSet = new Set((r && r.docIds) || []);
        }).catch(function () { state.docBodyHitSet = new Set(); })
      : Promise.resolve().then(function () { state.docBodyHitSet = null; });

    searchByTag(tagName).then(function (tagResults) {
      if (keyword) {
        // AND: filter tag results by keyword
        state.searchQuery = keyword;
        var q = keyword.toLowerCase();
        var filtered = tagResults.filter(function (a) {
          var contextMatch = false;
          if (a.CONTEXT) {
            var ctx = a.CONTEXT;
            if (ctx.indexOf('data:') !== 0 && ctx.indexOf('[{') !== 0 && ctx.indexOf('img:') !== 0) {
              contextMatch = ctx.toLowerCase().includes(q);
            }
          }
          return contextMatch ||
                 (a.COMMENT_TEXT && a.COMMENT_TEXT.toLowerCase().includes(q)) ||
                 (a.TAGS && a.TAGS.toLowerCase().includes(q)) ||
                 (a.DOMAIN && a.DOMAIN.toLowerCase().includes(q));
        });
        state.searchResults = filtered;
      } else {
        state.searchQuery = '';
        state.searchResults = tagResults;
      }
      state.annotations = [];
      if (!state.currentPage) {
        state.currentPage = null;
      }
      bodyHitsP.then(function () {
        renderSidebar();
        renderContent();
      });
    }).catch(function (err) {
      console.error('Tag search failed:', err);
    });
  }

  // ---- Delete ----

  var pendingDeleteIds = [];

  function confirmDelete(id) {
    pendingDeleteIds = [id];
    document.getElementById('deleteModalText').textContent = getMessage('mgDeleteAnnotationConfirm');
    document.getElementById('deleteModal').style.display = 'flex';
  }

  function confirmBatchDelete(ids) {
    pendingDeleteIds = ids;
    document.getElementById('deleteModalText').textContent = getMessage('mgDeleteAnnotationsConfirm', [String(ids.length)]);
    document.getElementById('deleteModal').style.display = 'flex';
  }

  function closeDeleteModal() {
    document.getElementById('deleteModal').style.display = 'none';
    pendingDeleteIds = [];
    pendingPageDeleteItems = null;
  }

  function executeDelete() {
    // Page-level delete (right-click or batch) → 路由到 page 删除路径
    if (pendingPageDeleteItems && pendingPageDeleteItems.length > 0) {
      executePageDelete();
      return;
    }
    var ids = pendingDeleteIds;
    closeDeleteModal();

    // 收集被删标注中引用的图片 URL，用于后续清理
    var deletedImageUrls = [];
    ids.forEach(function (id) {
      var a = state.annotations.find(function (x) { return x.MARK_INFO_ID === id; });
      if (a && a.END_TAG_NAME && deletedImageUrls.indexOf(a.END_TAG_NAME) === -1) {
        deletedImageUrls.push(a.END_TAG_NAME);
      }
    });

    var promises = ids.map(function (id) { return deleteAnnotation(id); });
    Promise.all(promises).then(function () {
      showToast(getMessage('mgAnnotationsDeleted', [String(ids.length)]));
      state.selectedIds.clear();

      // Remove from detail viewer annotations
      _detailAnnotations = _detailAnnotations.filter(function (a) {
        return ids.indexOf(a.MARK_INFO_ID) === -1;
      });

      // Refresh
      if (state.currentPage) {
        var page = state.currentPage;
        return loadAnnotations(page.domain, page.url).then(function (markList) {
          state.annotations = Object.values(markList);
          applyFilter();
          updateBatchBar();
          // 检查被删图片是否还有其他标注引用，无引用则清理图片数据
          deletedImageUrls.forEach(function (imgUrl) {
            cleanupImageReferences(page.url, imgUrl).catch(function () {});
          });
          // Reload all pages to refresh annotation counts across sidebar
          return loadAllPages().then(function (pages) {
            state.pages = pages || [];
            // 即时校正当前页徽标：服务端 _scheduleRecountAnnotationCount 有 500ms 节流，
            // 此处 loadAllPages 可能读到旧 annotationCount；用刚重载（已过滤软删）的标注数覆盖
            var _cur = state.pages.find(function (p) { return p.url === page.url; });
            if (_cur) _cur.annotationCount = state.annotations.length;
            renderSidebar();
          });
        });
      }
    }).then(function () {
      refreshDetailViewer();
    }).catch(function (err) {
      showToast(getMessage('deletingFailed', [String(err.message)]));
    });
  }

  // ---- Edit Note ----

  var editingId = null;
  var editCurrentTags = [];

  function openEditNote(id) {
    editingId = id;
    var a = state.annotations.find(function (x) { return x.MARK_INFO_ID === id; });
    if (!a) {
      a = state.searchResults.find(function (x) { return x.MARK_INFO_ID === id; });
    }
    document.getElementById('editNoteTextarea').value = (a && a.COMMENT_TEXT) || '';

    // 回填标签（与互联网页面批注框一致：TAGS 为 ';' 分隔串）
    editCurrentTags = [];
    if (a && a.TAGS) {
      var tagArr = a.TAGS.split(';');
      for (var i = 0; i < tagArr.length; i++) {
        if (tagArr[i].trim()) editCurrentTags.push(tagArr[i].trim());
      }
    }
    renderEditTagChips();
    var tagInput = document.getElementById('editTagInput');
    if (tagInput) tagInput.value = '';
    var tagDropdown = document.getElementById('editTagDropdown');
    if (tagDropdown) tagDropdown.classList.remove('show');
    // 确保标签字典已加载，供输入时的下拉建议
    if (!state.allTags || state.allTags.length === 0) {
      initTagDropdown();
    }

    document.getElementById('editModal').style.display = 'flex';
    document.getElementById('editNoteTextarea').focus();
  }

  function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
    editingId = null;
  }

  function executeEditNote() {
    if (!editingId) return;
    var text = document.getElementById('editNoteTextarea').value;
    var tags = editCurrentTags.join(';');
    var id = editingId;
    closeEditModal();

    updateAnnotation(id, { COMMENT_TEXT: text, TAGS: tags }).then(function () {
      showToast(getMessage('mgAnnotationUpdated'));
      // Update local state
      var a = state.annotations.find(function (x) { return x.MARK_INFO_ID === id; });
      if (a) { a.COMMENT_TEXT = text; a.TAGS = tags; }
      var sa = state.searchResults.find(function (x) { return x.MARK_INFO_ID === id; });
      if (sa) { sa.COMMENT_TEXT = text; sa.TAGS = tags; }
      // Update detail viewer annotation
      var da = _detailAnnotations.find(function (x) { return x.MARK_INFO_ID === id; });
      if (da) { da.COMMENT_TEXT = text; da.TAGS = tags; }
      applyFilter();
      refreshDetailViewer();
    }).catch(function (err) {
      showToast(getMessage('updatingFailed', [String(err.message)]));
    });
  }

  // ---- Edit Note: 标签编辑区（与互联网页面 wpzl 标签交互一致）----

  function renderEditTagChips() {
    var container = document.getElementById('editTagChips');
    if (!container) return;
    container.innerHTML = '';
    for (var i = 0; i < editCurrentTags.length; i++) {
      (function (tagText) {
        var chip = document.createElement('span');
        chip.className = 'edit-tag-chip';
        var textSpan = document.createElement('span');
        textSpan.textContent = tagText;
        var removeBtn = document.createElement('span');
        removeBtn.className = 'edit-tag-chip-remove';
        removeBtn.textContent = '×';
        removeBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          var idx = editCurrentTags.indexOf(tagText);
          if (idx !== -1) editCurrentTags.splice(idx, 1);
          renderEditTagChips();
        });
        chip.appendChild(textSpan);
        chip.appendChild(removeBtn);
        container.appendChild(chip);
      })(editCurrentTags[i]);
    }
  }

  function addEditTag(tagName) {
    tagName = (tagName || '').trim();
    if (!tagName) return;
    if (tagName.indexOf(';') !== -1) {
      showToast(getMessage('tagsValidationError'));
      return;
    }
    if (editCurrentTags.indexOf(tagName) !== -1) return;
    editCurrentTags.push(tagName);
    renderEditTagChips();
    // 同步到标签字典，供后续下拉建议（与互联网页面 saveTag 行为一致）
    saveTag(tagName).then(function (saved) {
      if (saved && saved.name) {
        state.allTags = state.allTags || [];
        var exists = false;
        for (var i = 0; i < state.allTags.length; i++) {
          if (state.allTags[i].name === saved.name) { exists = true; break; }
        }
        if (!exists) state.allTags.push(saved);
      }
    }).catch(function () {});
  }

  function confirmEditTagInput() {
    var tagInput = document.getElementById('editTagInput');
    if (!tagInput) return;
    var val = tagInput.value;
    if (val.trim()) {
      addEditTag(val.trim());
      tagInput.value = '';
      renderEditTagDropdown('');
    }
  }

  function renderEditTagDropdown(filterText) {
    var dropdown = document.getElementById('editTagDropdown');
    if (!dropdown) return;
    dropdown.innerHTML = '';
    var tags = state.allTags || [];
    var filter = (filterText || '').toLowerCase();
    var filtered = [];
    for (var i = 0; i < tags.length; i++) {
      var name = tags[i].name;
      if (!name) continue;
      if (editCurrentTags.indexOf(name) !== -1) continue;
      if (filter && name.toLowerCase().indexOf(filter) === -1) continue;
      filtered.push(name);
      if (filtered.length >= 10) break;
    }
    if (filtered.length === 0) {
      dropdown.classList.remove('show');
      return;
    }
    for (var j = 0; j < filtered.length; j++) {
      (function (tagName) {
        var item = document.createElement('div');
        item.className = 'edit-tag-dropdown-item';
        item.textContent = tagName;
        item.addEventListener('mousedown', function (e) {
          e.preventDefault();
          addEditTag(tagName);
          var input = document.getElementById('editTagInput');
          if (input) input.value = '';
          renderEditTagDropdown('');
        });
        dropdown.appendChild(item);
      })(filtered[j]);
    }
    dropdown.classList.add('show');
  }

  function initEditTagBindings() {
    var tagInput = document.getElementById('editTagInput');
    var tagConfirmBtn = document.getElementById('editTagConfirm');
    if (!tagInput) return;

    tagInput.addEventListener('input', function () {
      renderEditTagDropdown(tagInput.value);
    });
    tagInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.keyCode === 13) {
        e.preventDefault();
        confirmEditTagInput();
      } else if (e.key === 'Backspace' || e.keyCode === 8) {
        if (!tagInput.value && editCurrentTags.length > 0) {
          editCurrentTags.pop();
          renderEditTagChips();
        }
      }
    });
    tagInput.addEventListener('blur', function () {
      // blur 时若有未确认的文字自动添加为标签
      var val = tagInput.value;
      if (val.trim()) {
        addEditTag(val.trim());
        tagInput.value = '';
      }
      var dropdown = document.getElementById('editTagDropdown');
      if (dropdown) setTimeout(function () { dropdown.classList.remove('show'); }, 150);
    });
    tagInput.addEventListener('focus', function () {
      renderEditTagDropdown(tagInput.value);
    });

    if (tagConfirmBtn) {
      tagConfirmBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
      tagConfirmBtn.addEventListener('click', function () {
        confirmEditTagInput();
        tagInput.focus();
      });
    }

    // 点击下拉外部关闭
    document.addEventListener('mousedown', function (e) {
      var dropdown = document.getElementById('editTagDropdown');
      if (!dropdown || !dropdown.classList.contains('show')) return;
      if (dropdown.contains(e.target)) return;
      var inputEl = document.getElementById('editTagInput');
      var confirmEl = document.getElementById('editTagConfirm');
      if (e.target === inputEl || e.target === confirmEl) return;
      dropdown.classList.remove('show');
    });
  }

  // ---- Image Viewer ----

  var _detailAnnotations = [];

  // 图片显示模式：'fit'（适应页面，默认）| 'original'（原始尺寸），持久化 wpzl_image_view_mode。
  var _imgViewMode = 'fit';
  var WPZL_IMG_VIEW_MODE_KEY = 'wpzl_image_view_mode';

  function _applyImageViewMode(mode) {
    _imgViewMode = (mode === 'original') ? 'original' : 'fit';
    var wrapper = document.getElementById('detailImageWrapper');
    if (wrapper) wrapper.classList.toggle('img-fit', _imgViewMode === 'fit');
    var fitR = document.getElementById('imgViewModeFit');
    var origR = document.getElementById('imgViewModeOriginal');
    if (fitR) fitR.checked = (_imgViewMode === 'fit');
    if (origR) origR.checked = (_imgViewMode === 'original');
    // 模式切换改变图片渲染尺寸 → 重绘标注 overlay（仅查看器打开时有意义）
    var viewer = document.getElementById('imageViewer');
    if (viewer && viewer.style.display !== 'none') {
      requestAnimationFrame(drawDetailOverlay);
    }
  }

  function openImageViewer(src) {
    document.getElementById('viewerSimple').style.display = 'block';
    document.getElementById('viewerDetail').style.display = 'none';
    document.getElementById('viewerImage').src = src;
    document.getElementById('imageViewer').style.display = 'flex';
  }

  function openDetailViewer(imageUrl, annotations) {
    // 按标记时间正序排列（CREATE_TIME 缺失时回退 UPDATE_TIME，再保持原相对顺序）
    _detailAnnotations = annotations.slice().sort(function (a, b) {
      return (a.CREATE_TIME || a.UPDATE_TIME || '').localeCompare(b.CREATE_TIME || b.UPDATE_TIME || '');
    });
    document.getElementById('viewerSimple').style.display = 'none';
    document.getElementById('viewerDetail').style.display = 'flex';
    _applyImageViewMode(_imgViewMode);   // 每次打开保持当前显示模式一致

    var img = document.getElementById('detailImage');
    var statusEl = document.getElementById('detailImageStatus');

    // 先尝试从本地加载
    var pageUrl = state.currentPage ? state.currentPage.url : '';
    var _isDetailObjKey = wpzl_isObjectKeySrc(imageUrl);
    if (_isDetailObjKey) {
      // objectKey（data:/blob: 锚点图上云后的 cloudUrl，形如 u/{uid}/{pageKey}/{imageKey}.webp）。
      // 先查本地缓存（saveImageFromUrl 的 objectKey 分支用 md5(pageUrl)+md5(objectKey) 存）：
      // 命中 data → 本地直显（免签名请求）；未命中 → 签名显示 + 渲染"保存到本地"（缓存云端图到本地）。
      if (pageUrl) {
        getImageData(pageUrl, imageUrl).then(function (objRec) {
          if (objRec && objRec.data) {
            // ① 本地缓存命中
            img.src = objRec.data;
            img.dataset.localSaved = 'true';
            if (statusEl) statusEl.innerHTML = '<span style="color:#22c55e;font-size:13px;">' + getMessage('ivSavedLocal') + '</span>';
          } else {
            // ② 本地无缓存：签名显示 + 提供缓存按钮（saveImageFromUrl 已支持 objectKey：签名→fetch→存）
            wpzl_signObjectKeyImg(img, imageUrl);
            img.dataset.localSaved = '';
            if (statusEl) statusEl.innerHTML = '<span style="color:#0ea5e9;font-size:13px;">' + getMessage('ivCloud') + '</span>' +
              '<button id="detailSaveLocalBtn" style="margin-left:8px;font-size:13px;color:#4f46e5;background:none;border:1px solid #4f46e5;border-radius:4px;padding:4px 12px;cursor:pointer;">' + getMessage('ivSaveToLocal') + '</button>';
            _bindDetailSaveBtn(img, pageUrl, imageUrl, statusEl);
          }
        }).catch(function () {
          wpzl_signObjectKeyImg(img, imageUrl);
          if (statusEl) statusEl.innerHTML = '';
        });
      } else {
        wpzl_signObjectKeyImg(img, imageUrl);
        if (statusEl) statusEl.innerHTML = '';
      }
    } else if (pageUrl && imageUrl) {
      getImageData(pageUrl, imageUrl).then(function (localRec) {
        if (localRec && localRec.data) {
          // ① 本地 data 命中
          wpzl_loadImageDataWithFallback(img, pageUrl, imageUrl, localRec);
          if (statusEl) statusEl.innerHTML = '<span style="color:#22c55e;font-size:13px;">' + getMessage('ivSavedLocal') + '</span>';
        } else if (localRec && localRec.cloudUrl) {
          // ② 本地无 data，但 cloudUrl 已同步（Pro 跨设备）
          wpzl_loadImageDataWithFallback(img, pageUrl, imageUrl, localRec, statusEl);
          img.dataset.localSaved = '';
          if (statusEl) statusEl.innerHTML = '<span style="color:#0ea5e9;font-size:13px;">' + getMessage('ivCloudSyncing') + '</span>' +
            '<button id="detailSaveLocalBtn" style="margin-left:8px;font-size:13px;color:#4f46e5;background:none;border:1px solid #4f46e5;border-radius:4px;padding:4px 12px;cursor:pointer;">' + getMessage('ivSaveToLocal') + '</button>';
          _bindDetailSaveBtn(img, pageUrl, imageUrl, statusEl);
        } else {
          // ③ 未保存：渲染即自动抓取补存（与手动按钮同逻辑），成功后走①、按钮消失
          img.src = imageUrl;
          img.dataset.localSaved = '';
          if (statusEl) statusEl.innerHTML = '<span style="color:#94a3b8;font-size:13px;">' + getMessage('ivNotSavedLocal') + '</span>' +
            '<button id="detailSaveLocalBtn" style="margin-left:8px;font-size:13px;color:#4f46e5;background:none;border:1px solid #4f46e5;border-radius:4px;padding:4px 12px;cursor:pointer;">' + getMessage('ivSaveToLocal') + '</button>';
          _bindDetailSaveBtn(img, pageUrl, imageUrl, statusEl);
          _autoSaveImageFromOriginalUrl(pageUrl, imageUrl, statusEl, img);
        }
      }).catch(function () {
        img.src = imageUrl;
        if (statusEl) statusEl.innerHTML = '';
      });
    } else {
      img.src = imageUrl;
      if (statusEl) statusEl.innerHTML = '';
    }

    renderDetailSidebar();

    // Inject AI prompt generation button below the image
    var existingBtn = document.getElementById('detailGenAIPromptBtn');
    if (existingBtn) existingBtn.remove();
    var promptBtn = document.createElement('button');
    promptBtn.id = 'detailGenAIPromptBtn';
    promptBtn.className = 'detail-ai-prompt-btn';
    promptBtn.textContent = chrome.i18n.getMessage('detailGenerateAIPrompt') || '根据标记生成AI提示词';
    promptBtn.addEventListener('click', generateAIPromptFromMarks);
    var wrapper = document.getElementById('detailImageWrapper');
    wrapper.appendChild(promptBtn);

    document.getElementById('imageViewer').style.display = 'flex';

    function onImageLoad() {
      drawDetailOverlay();
    }

    if (!img.complete || img.naturalWidth === 0) {
      img.addEventListener('load', onImageLoad);
    } else {
      requestAnimationFrame(onImageLoad);
    }
  }

  function renderDetailSidebar() {
    var panel = document.getElementById('detailSidebar');
    var annotations = _detailAnnotations;
    var html = '';

    html += '<div class="detail-select-all">';
    html += '<input type="checkbox" id="detailSelectAll" checked>';
    html += '<span>' + getMessage('ivSelectAllCount', [String(annotations.length)]) + '</span>';
    html += '</div>';

    html += '<div class="detail-annotation-list">';
    annotations.forEach(function (a) {
      var type = getAnnotationType(a);
      var info = TYPE_MAP[type] || {};
      var id = a.MARK_INFO_ID || '';
      var comment = a.COMMENT_TEXT || '';
      var color = a.MARK_COLOR || '#ff3c82';

      html += '<div class="detail-anno-item" data-id="' + escapeHtml(id) + '">';
      html += '<div class="detail-anno-header">';
      html += '<input type="checkbox" class="detail-anno-toggle" id="detail-toggle-' + escapeHtml(id) + '" data-id="' + escapeHtml(id) + '" checked>';
      html += '<span class="detail-anno-icon" style="background:' + info.bg + '">' + (info.icon || '?') + '</span>';
      html += '<span class="detail-anno-type">' + (info.label || type) + '</span>';
      if (isMultiAuthor() && a.AUTHOR_NAME) {
        var isOwnDA = state.currentAuthor && a.AUTHOR_ID === state.currentAuthor.authorId;
        if (!isOwnDA) {
          html += '<span class="detail-anno-author">' + escapeHtml(a.AUTHOR_NAME) + '</span>';
        }
      }
      var markTime = a.CREATE_TIME || a.UPDATE_TIME || '';
      if (markTime) {
        var markDisp = _tsMin(markTime); // UTC-naive 存储 → 本地展示（Bug B）
        html += '<span class="detail-anno-time" title="' + escapeHtml(markDisp) + '">' + escapeHtml(markDisp) + '</span>';
      }
      html += '</div>';
      // 仅元素标记展示锚点元素信息块；箭头/旗帜的宿主图已在左侧大图展示，右侧不再重复带整图缩略图
      if (type === 'elementMark') {
        html += renderAnchorInfo(a);
      }
      if (comment) {
        html += '<div class="detail-anno-comment" style="border-left-color:' + escapeHtml(color) + '">' + escapeHtml(comment) + '</div>';
      }
      html += renderTags(a.TAGS);
      html += '<div class="detail-anno-actions">';
      if (isOwnOrAllowed(a)) {
        html += '<button class="detail-action-btn" data-action="edit" data-id="' + escapeHtml(id) + '">✎ ' + getMessage('edit') + '</button>';
        html += '<button class="detail-action-btn danger" data-action="delete" data-id="' + escapeHtml(id) + '">✕ ' + getMessage('delete') + '</button>';
      }
      html += '</div>';
      html += '</div>';
    });
    html += '</div>';

    panel.innerHTML = html;

    // Events: select all
    document.getElementById('detailSelectAll').addEventListener('change', function () {
      var checked = this.checked;
      var toggles = panel.querySelectorAll('.detail-anno-toggle');
      toggles.forEach(function (cb) { cb.checked = checked; });
      drawDetailOverlay();
    });

    // Events: individual toggles
    panel.addEventListener('change', function (e) {
      if (e.target.classList.contains('detail-anno-toggle')) {
        // Update select all state
        var allToggles = panel.querySelectorAll('.detail-anno-toggle');
        var allChecked = Array.prototype.every.call(allToggles, function (cb) { return cb.checked; });
        document.getElementById('detailSelectAll').checked = allChecked;
        drawDetailOverlay();
      }
    });

    // Events: edit / delete buttons
    panel.addEventListener('click', function (e) {
      var btn = e.target.closest('.detail-action-btn');
      if (!btn) return;
      var action = btn.dataset.action;
      var id = btn.dataset.id;
      if (action === 'edit') {
        openEditNote(id);
      } else if (action === 'delete') {
        confirmDelete(id);
      }
    });
  }

  function drawDetailOverlay() {
    var img = document.getElementById('detailImage');
    var canvas = document.getElementById('detailCanvas');
    var annotations = _detailAnnotations;
    if (!annotations || annotations.length === 0) return;

    var w = img.clientWidth;
    var h = img.clientHeight;
    if (w === 0 || h === 0) return;

    canvas.width = w;
    canvas.height = h;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';

    var nw = img.naturalWidth || w;
    var nh = img.naturalHeight || h;
    var scale = Math.min(w / nw, h / nh);

    var ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, w, h);

    annotations.forEach(function (a) {
      var id = a.MARK_INFO_ID || '';
      var cb = document.getElementById('detail-toggle-' + id);
      if (cb && !cb.checked) return;

      var type = getAnnotationType(a);
      var color = a.MARK_COLOR || '#ff3c82';
      var lineWidth = parseInt(a.END_MD5) || 2;

      if (type === 'rect') {
        drawGroupRect(ctx, a, w, h, color, lineWidth, scale);
      } else if (type === 'rectFrame') {
        drawGroupRectFrame(ctx, a, w, h, color, lineWidth, scale);
      } else if (type === 'arrow') {
        drawGroupArrow(ctx, a, w, h, color, lineWidth, scale);
      } else if (type === 'flag') {
        drawGroupFlag(ctx, a, w, h, color, lineWidth, scale);
      } else if (type === 'freehand') {
        drawGroupFreehand(ctx, a, w, h, color, lineWidth, scale);
      } else if (type === 'text') {
        drawGroupText(ctx, a, w, h, color, scale);
      }
    });
  }

  function generateAIPromptFromMarks() {
    var img = document.getElementById('detailImage');
    var all = _detailAnnotations || [];
    // 只取详情侧栏勾选（即绘制在图片上）的标记——与 drawDetailOverlay 同一口径：
    // 未勾选 = 未在图片上展示，不应出现在提示词里（复选框缺失时按可见处理，与绘制端一致）。
    var annotations = all.filter(function (a) {
      var cb = document.getElementById('detail-toggle-' + (a.MARK_INFO_ID || ''));
      return !cb || cb.checked;
    });
    if (annotations.length === 0) {
      showToast(all.length === 0
        ? (chrome.i18n.getMessage('toastAIPromptNoMarks') || 'No marks to generate prompt from')
        : (chrome.i18n.getMessage('toastModPromptNoVisible') || 'All marks are hidden'));
      return;
    }

    var nw = img.naturalWidth || img.clientWidth || 0;
    var nh = img.naturalHeight || img.clientHeight || 0;
    if (nw === 0 || nh === 0) {
      showToast('Image not loaded yet');
      return;
    }

    var lines = [];
    lines.push('You are analyzing an image with the following dimensions: ' + nw + ' x ' + nh + ' pixels.');
    lines.push('On this image, the user has placed several annotation marks. Each mark defines a region and may include a comment (question, observation, or modification request).');
    lines.push('');
    lines.push('--- Marks ---');
    lines.push('');

    var markNum = 0;
    annotations.forEach(function (a) {
      markNum++;
      var type = getAnnotationType(a);
      var info = TYPE_MAP[type] || {};
      var typeLabel = (info.label || type);
      var color = a.MARK_COLOR || '#ff3c82';
      var comment = a.COMMENT_TEXT || '';
      var lw = parseInt(a.END_MD5) || 2;

      lines.push('[Mark ' + markNum + ']');
      lines.push('Type: ' + typeLabel + ' (' + type + ')');
      lines.push('Color: ' + color + ', Line width: ' + lw + 'px');

      if (type === 'rect') {
        var so = parseInt(a.START_OFFSET) || 0;
        var eo = parseInt(a.END_OFFSET) || 0;
        var x1 = Math.floor(so / 1000), y1 = so % 1000;
        var x2 = Math.floor(eo / 1000), y2 = eo % 1000;
        var left = Math.min(x1, x2), top = Math.min(y1, y2);
        var rw = Math.abs(x2 - x1), rh = Math.abs(y2 - y1);
        lines.push('Region (absolute pixels): left=' + Math.round(left / 1000 * nw) + ', top=' + Math.round(top / 1000 * nh) + ', width=' + Math.round(rw / 1000 * nw) + ', height=' + Math.round(rh / 1000 * nh));
        lines.push('Region (relative %): left=' + (left / 10).toFixed(1) + '%, top=' + (top / 10).toFixed(1) + '%, width=' + (rw / 10).toFixed(1) + '%, height=' + (rh / 10).toFixed(1) + '%');
      }
      else if (type === 'arrow' || type === 'flag') {
        var so2 = parseInt(a.START_OFFSET) || 0;
        var eo2 = parseInt(a.END_OFFSET) || 0;
        var xOff = parseInt(so2 / 1000000);
        var yOff = Math.abs(so2 % 1000000);
        if (yOff >= 900000) yOff = -(yOff - 900000);
        var x2Off = parseInt(eo2 / 1000000);
        var y2Off = Math.abs(eo2 % 1000000);
        if (y2Off >= 900000) y2Off = -(y2Off - 900000);
        if (so2 < 0) xOff = -xOff;
        if (eo2 < 0) x2Off = -x2Off;
        var baseX = Math.round(xOff / 100 * nw);
        var baseY = Math.round(yOff / 100 * nh);
        var tipX = Math.round(x2Off / 1000 * nw);
        var tipY = Math.round(y2Off / 1000 * nh);
        var angle = Math.atan2(tipY - baseY, tipX - baseX) * 180 / Math.PI;
        if (type === 'arrow') {
          lines.push('Arrow: base -> tip');
        } else {
          lines.push('Flag: anchor -> target');
        }
        lines.push('  Base/Anchor (absolute): x=' + baseX + ', y=' + baseY);
        lines.push('  Tip/Target (absolute): x=' + tipX + ', y=' + tipY);
        lines.push('  Base/Anchor (relative %): x=' + (xOff / 100).toFixed(2) + '%, y=' + (yOff / 100).toFixed(2) + '%');
        lines.push('  Tip/Target (relative %): x=' + (x2Off / 1000).toFixed(2) + '%, y=' + (y2Off / 1000).toFixed(2) + '%');
        lines.push('  Direction angle: ' + angle.toFixed(1) + ' degrees');
      }
      else if (type === 'freehand') {
        var ctx = a.CONTEXT;
        try {
          var pts = typeof ctx === 'string' ? JSON.parse(ctx) : ctx;
          if (pts && pts.length > 0) {
            var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
            var absPts = [];
            pts.forEach(function (p) {
              var px = p.x / 1000 * nw, py = p.y / 1000 * nh;
              absPts.push({ x: Math.round(px), y: Math.round(py) });
              if (px < minX) minX = px; if (py < minY) minY = py;
              if (px > maxX) maxX = px; if (py > maxY) maxY = py;
            });
            lines.push('Freehand stroke: ' + pts.length + ' consecutive points');
            // Output all points if ≤30, otherwise sample ~30 evenly
            var outPts = absPts;
            if (absPts.length > 30) {
              outPts = [];
              var step = (absPts.length - 1) / 29;
              for (var si = 0; si < 30; si++) {
                outPts.push(absPts[Math.round(si * step)]);
              }
              lines.push('Points (sampled ' + outPts.length + ' from ' + absPts.length + '):');
            } else {
              lines.push('Points (' + absPts.length + '):');
            }
            // Build compact point list: each point as (x, y)
            var ptStrs = [];
            outPts.forEach(function (p) {
              ptStrs.push('(' + p.x + ',' + p.y + ')');
            });
            lines.push(ptStrs.join(' '));
            lines.push('Bounding box (absolute): left=' + Math.round(minX) + ', top=' + Math.round(minY) + ', width=' + Math.round(maxX - minX) + ', height=' + Math.round(maxY - minY));
            lines.push('Bounding box (relative %): left=' + (minX / nw * 100).toFixed(1) + '%, top=' + (minY / nh * 100).toFixed(1) + '%, width=' + ((maxX - minX) / nw * 100).toFixed(1) + '%, height=' + ((maxY - minY) / nh * 100).toFixed(1) + '%');
          }
        } catch (e) {}
      }
      else if (type === 'text') {
        var so3 = parseInt(a.START_OFFSET) || 0;
        var eo3 = parseInt(a.END_OFFSET) || 0;
        if (Number(a.ANCHOR_WIDTH) === -1) {
          // absChild 模式：偏移为相对锚点的 px（负值 +1000000 编码，见 text-annotation.js），非千分比
          var absRawX = Math.floor(so3 / 1000000), absRawY = so3 % 1000000;
          var absX = absRawX > 500000 ? absRawX - 1000000 : absRawX;
          var absY = absRawY > 500000 ? absRawY - 1000000 : absRawY;
          lines.push('Text annotation at (pixel offset from anchor element): x=' + absX + ', y=' + absY + ' px');
        } else {
          // 旧千分比编码（负值 |v|+1000）
          var rawX = parseInt(so3 / 1000000), rawY = so3 % 1000000;
          var tx = rawX >= 1000 ? -(rawX - 1000) : rawX;
          var ty = rawY >= 1000 ? -(rawY - 1000) : rawY;
          var tw2 = parseInt(eo3 / 100000), th2 = eo3 % 100000;
          var textX = Math.round(tx / 1000 * nw);
          var textY = Math.round(ty / 1000 * nh);
          var textW = Math.round(tw2 / 1000 * nw);
          var textH = Math.round(th2 / 1000 * nh);
          lines.push('Text annotation at (absolute): x=' + textX + ', y=' + textY + ', approx_width=' + textW + ', approx_height=' + textH);
          lines.push('Text annotation at (relative %): x=' + (tx / 10).toFixed(1) + '%, y=' + (ty / 10).toFixed(1) + '%');
        }
        if (a.CONTEXT) {
          lines.push('Text content: "' + a.CONTEXT + '"');
        }
      }
      else if (type === 'rectFrame' || type === 'pageRect') {
        // 与 arrow 同源联合编码：START 百分比(/100)、END 千分比(/1000)，y 负值哨兵 900000（见 rect-frame-drawing.js / page-rect-drawing.js）
        var so4 = parseInt(a.START_OFFSET) || 0;
        var eo4 = parseInt(a.END_OFFSET) || 0;
        var fx1 = parseInt(Math.abs(so4) / 1000000), fy1 = Math.abs(so4) % 1000000;
        if (fy1 >= 900000) fy1 = -(fy1 - 900000);
        var fx2 = parseInt(Math.abs(eo4) / 1000000), fy2 = Math.abs(eo4) % 1000000;
        if (fy2 >= 900000) fy2 = -(fy2 - 900000);
        if (so4 < 0) fx1 = -fx1;
        if (eo4 < 0) fx2 = -fx2;
        var frL = Math.min(fx1 / 100, fx2 / 1000), frT = Math.min(fy1 / 100, fy2 / 1000);
        var frR = Math.max(fx1 / 100, fx2 / 1000), frB = Math.max(fy1 / 100, fy2 / 1000);
        var regionLabel = (type === 'rectFrame') ? 'Rect frame' : 'Page rect';
        lines.push(regionLabel + ' region corners (absolute): left=' + Math.round(frL * nw) + ', top=' + Math.round(frT * nh) + ', right=' + Math.round(frR * nw) + ', bottom=' + Math.round(frB * nh));
        lines.push(regionLabel + ' region corners (relative %): left=' + (frL * 100).toFixed(1) + '%, top=' + (frT * 100).toFixed(1) + '%, right=' + (frR * 100).toFixed(1) + '%, bottom=' + (frB * 100).toFixed(1) + '%');
      }
      else if (type === 'elementMark') {
        lines.push('Region: entire anchored element (element-level mark, no local pixel offsets)');
      }
      else if (type === 'imgAnno') {
        lines.push('Region: image-annotation badge pinned near the top-right corner of this image');
        if (a.END_TAG_NAME) lines.push('Image src: "' + a.END_TAG_NAME + '"');
      }
      else {
        // highlight — 文本选区标记，图片上无像素级区域
        lines.push('(No pixel-level region data for this mark type)');
      }

      if (comment) {
        lines.push('Comment: "' + comment + '"');
      }
      lines.push('--- End Mark ' + markNum + ' ---');
      lines.push('');
    });

    lines.push('--- Instructions ---');
    lines.push('The marks above were drawn by a user on a screenshot/image. Each mark highlights a specific region of the image that the user wants you to focus on. The comments may be:');
    lines.push('- Questions about what is in that region');
    lines.push('- Statements describing an issue or observation');
    lines.push('- Modification requests (e.g., "change this color", "move this element", "remove this")');
    lines.push('Please analyze the image considering these ' + markNum + ' marks and respond to each one individually.');

    var promptText = lines.join('\n');
    showAIPromptPreviewModal(promptText, markNum);
  }

  // AI 提示词预览弹窗：与页面侧 wpzl_openModificationPromptPreview 同范式——先展示全文，用户确认后再手动复制。
  // 扩展页面禁用 window.prompt/alert/confirm（见 webpz-lite-reference.md §14.5），一律 DOM 自绘弹层。
  function showAIPromptPreviewModal(promptText, count) {
    var existing = document.getElementById('aiPromptPreviewModal');
    if (existing) existing.remove();

    var overlay = document.createElement('div');
    overlay.id = 'aiPromptPreviewModal';
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:5000;display:flex;align-items:center;justify-content:center;';

    var card = document.createElement('div');
    // 弹窗自带浅色配色，color 必须显式钉死：不写会继承 manager 主题（dark 下 --text 为白），
    // 白字铺在 #fafafa textarea 上 = 视觉"空弹框"（2026-11-02 用户报告，截图实锤）。
    card.style.cssText = 'background:#fff;color:#1a1a2e;border-radius:12px;width:720px;max-width:92vw;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,0.3);overflow:hidden;';

    var header = document.createElement('div');
    header.style.cssText = 'padding:16px 20px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center;';
    var titleEl = document.createElement('div');
    titleEl.textContent = (chrome.i18n.getMessage('detailAIPromptTitle') || 'AI Prompt Preview') + '（' + count + '）';
    titleEl.style.cssText = 'font-size:15px;font-weight:600;color:#222;';
    header.appendChild(titleEl);
    var closeX = document.createElement('button');
    closeX.textContent = '×';
    closeX.style.cssText = 'border:none;background:none;font-size:24px;color:#999;cursor:pointer;padding:0 4px;line-height:1;';
    closeX.addEventListener('click', closeAIPromptModal);
    header.appendChild(closeX);

    var body = document.createElement('div');
    body.style.cssText = 'padding:12px 16px;flex:1;overflow:auto;';
    var textarea = document.createElement('textarea');
    textarea.readOnly = true;
    textarea.value = promptText;
    textarea.style.cssText = 'width:100%;height:55vh;border:1px solid #ddd;border-radius:8px;padding:10px;font-size:12px;resize:none;box-sizing:border-box;font-family:Menlo,Consolas,monospace;line-height:1.5;background:#fafafa;color:#1a1a2e;';
    body.appendChild(textarea);

    var footer = document.createElement('div');
    footer.style.cssText = 'padding:12px 16px;border-top:1px solid #eee;display:flex;justify-content:flex-end;gap:8px;';
    var copyBtn = document.createElement('button');
    copyBtn.textContent = chrome.i18n.getMessage('modPromptCopy') || 'Copy';
    copyBtn.style.cssText = 'background:#4f46e5;color:#fff;border:none;border-radius:8px;padding:8px 16px;font-size:14px;cursor:pointer;';
    copyBtn.addEventListener('click', function () {
      var ok = copyText(promptText);
      showToast(ok
        ? (chrome.i18n.getMessage('toastAIPromptCopied') || 'AI prompt copied to clipboard')
        : (chrome.i18n.getMessage('toastExportFailed') || 'Copy failed'));
    });
    footer.appendChild(copyBtn);
    var closeBtn = document.createElement('button');
    closeBtn.textContent = chrome.i18n.getMessage('close') || 'Close';
    closeBtn.style.cssText = 'background:#f5f5f5;color:#333;border:none;border-radius:8px;padding:8px 16px;font-size:14px;cursor:pointer;';
    closeBtn.addEventListener('click', closeAIPromptModal);
    footer.appendChild(closeBtn);

    function closeAIPromptModal() {
      document.removeEventListener('keydown', onKeydown);
      if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
    }
    function onKeydown(e) { if (e.key === 'Escape') closeAIPromptModal(); }

    card.appendChild(header);
    card.appendChild(body);
    card.appendChild(footer);
    overlay.appendChild(card);
    overlay.addEventListener('click', function (e) { if (e.target === overlay) closeAIPromptModal(); });
    document.addEventListener('keydown', onKeydown);
    document.body.appendChild(overlay);
  }

  function refreshDetailViewer() {
    var viewer = document.getElementById('imageViewer');
    if (viewer.style.display === 'none') return;
    if (document.getElementById('viewerDetail').style.display === 'none') return;

    // If no annotations left, close the viewer
    if (_detailAnnotations.length === 0) {
      closeImageViewer();
      return;
    }

    renderDetailSidebar();
    drawDetailOverlay();
  }

  function closeImageViewer() {
    document.getElementById('imageViewer').style.display = 'none';
    document.getElementById('viewerImage').src = '';
    document.getElementById('detailImage').src = '';
    var canvas = document.getElementById('detailCanvas');
    canvas.width = 0;
    canvas.height = 0;
    document.getElementById('detailSidebar').innerHTML = '';
    _detailAnnotations = [];
    var promptBtn = document.getElementById('detailGenAIPromptBtn');
    if (promptBtn) promptBtn.remove();
  }

  // ---- Navigate ----

  // page.url 身份键 = hostname+path（wpzlNormalizeWebpath 归一化，不含端口），非默认端口
  // （如 127.0.0.1:8080）单独存 page.port。补端口：仅当 host 部分无冒号时插入（已带端口或
  // IPv6 字面量 [::1] 不动，避免拼出畸形 host），port 非数字/缺失原样返回。
  // 已带协议的输入必须保留协议（m[1] 捕获组重建时回拼）——否则 "http://host/path" 会被
  // 拼成 "host:port/path"，无协议串交给 chrome.tabs.create 会被按当前扩展源相对解析成
  // chrome-extension://<id>/host:port/path（2026-11-02 openPage 实测翻车）。
  function _applyUrlPort(url, port) {
    if (!url || !/^\d+$/.test(port || '')) return url;
    var m = /^(https?:\/\/)?([^\/?#]+)(.*)$/.exec(url);
    if (!m || !m[2] || m[2].indexOf(':') >= 0) return url;
    return (m[1] || '') + m[2] + ':' + port + m[3];
  }

  function openPage(webUri, scheme, port) {
    if (!webUri) return;
    var url = webUri;
    // 无协议时按记录的 scheme（http 老站点）拼接，缺省 https（与原行为兼容）
    if (!/^https?:\/\//i.test(url)) url = ((scheme === 'http' || scheme === 'https') ? scheme : 'https') + '://' + url;
    // 非默认端口补进 host（scheme 配套设计，见 _applyUrlPort）；文档页后续 _resolveDocToken
    // 会重写为服务端 base，此处插入对文档分支无影响
    url = _applyUrlPort(url, port);
    // 本地模式（游客档，2026-09-29）：文档批注页（/d/|/snap/）走服务端 token POST，
    // 未登录无 token 打不开 → 拦截 + toast（普通网页照常打开）。
    if (!state.isLoggedIn && _isDocPageUrl(url)) {
      showToast(chrome.i18n.getMessage('guestDocOpenDisabled') || '本地模式无法打开文档批注页，请登录后使用');
      return;
    }
    // 普通网页：直接 GET 打开（绝不带 JWT，避免泄漏给第三方站点）。
    if (!_isDocPageUrl(url)) { chrome.tabs.create({ url: url }); return; }
    // H2 悬浮提示：打开尚未同步到服务器的自建文档时提示「等几秒自动同步，或点『立即同步』后再打开」。
    // 实时查询记录 SYNC_STATUS，无内存状态——同步完成后自然不再弹；异步不阻塞打开。
    var _dm = /\/d\/(doc-[^/?#]+)/.exec(url);
    if (_dm) _maybeShowDocSyncHint(_dm[1]);
    // 自建文档渲染页 /d/{docId}：token 走 POST 表单体（DocumentController 同时接受 GET ?token= 与
    // POST 表单体 token），避免 JWT 出现在 URL/历史/Referer。浏览器导航无法带 Authorization 头，
    // 故用隐藏 form POST。先在用户点击手势内同步开一个具名空白标签（规避弹窗拦截），异步取到 token
    // 后再把表单 POST 进该具名标签（不再开新窗，故不受手势失效影响）。
    var winName = 'wpzl_doc_' + Date.now();
    var win = window.open('about:blank', winName);
    if (!win) {
      // 弹窗被拦截（极少见，window.open 在点击手势内同步调用）——退回 GET（无 token，服务端 404）
      chrome.tabs.create({ url: url });
      return;
    }
    _resolveDocToken(url).then(function (r) {
      if (r && r.token) {
        _postOpenDocPage(r.url, r.token, winName);
      } else {
        // 无 token / host 不匹配 —— 关掉空白标签，原样 GET 打开（服务端 404，与现状一致）
        try { win.close(); } catch (e) { /* ignore */ }
        chrome.tabs.create({ url: r ? r.url : url });
      }
    });
  }

  // 服务端渲染页（/d/{docId} 文档 或 /snap/{snapId} 快照）走鉴权 token POST 分支。
  function _isDocPageUrl(url) {
    try { return /^\/(d\/doc-|snap\/snap-)/.test(new URL(url).pathname); } catch (e) { return false; }
  }

  // H2 辅助：文档未同步（SYNC_STATUS !== 'synced' 或 bodyDirty）→ 弹「请先同步」悬浮提示。
  // 门控与同步按钮同判据（updateSyncButtonVisibility：cloudSync 权限 + syncEnabled），
  // 无同步能力的用户不弹；查询失败保守不弹。注：SYNC_STATUS 常量在 SW 侧（sync-engine.js），
  // 此处用字符串字面量对齐；bodyObjectKey 不可作判据（本机文档长期为 null）。
  function _maybeShowDocSyncHint(docId) {
    if (!_cloudSyncEnabled() || !state.syncEnabled) return;
    mgrIsHintDismissed('h2').then(function (dismissed) {
      if (dismissed) return;
      sendMessage('getDocument', { docId: docId }).then(function (doc) {
        if (doc && (doc.SYNC_STATUS !== 'synced' || doc.bodyDirty)) {
          mgrShowHintBox('h2', getMessage('hintDocNeedsSyncBody'));
        }
      }).catch(function () { /* 查询失败保守不弹 */ });
    }).catch(function () { /* ignore */ });
  }

  // 本地模式（游客档，2026-09-29）：详情页「打开」按钮置灰/复位。
  // serverKind=true 表示当前详情是服务端渲染页（文档/快照）——未登录时禁用 + tooltip 同
  // guestDocOpenDisabled 文案（与 openPage 拦截同条件）；普通网页详情一律复位。
  function _applyGuestOpenBtnState(serverKind) {
    var btn = document.getElementById('openPageBtn');
    if (!btn) return;
    if (serverKind && !state.isLoggedIn) {
      btn.disabled = true;
      btn.title = chrome.i18n.getMessage('guestDocOpenDisabled') || '本地模式无法打开文档批注页，请登录后使用';
    } else {
      btn.disabled = false;
      btn.title = chrome.i18n.getMessage('openPage') || '';
    }
  }

  // 解析文档页 URL 对应的 token，并把 URL 归一到当前服务端 base（旧文档 webUri 可能是
  // https://127.0.0.1，本机服务端是 http://127.0.0.1:8080）。仅当 base 已知且为文档页才附 token
  // （rebased URL 由 base 构造，必在服务端 host 上，不会把 JWT 误带给第三方站点）；
  // 无 token / base 缺失 / 非文档页 → { url, token: '' }。
  function _resolveDocToken(url) {
    return Promise.all([sendMessage('getServerBase'), sendMessage('getAccessToken')]).then(function (vals) {
      var base = vals[0] || '';
      var token = vals[1] || '';
      if (!token) return { url: url, token: '' };
      if (!base || !/\/(d\/doc-|snap\/snap-)/.test(url)) return { url: url, token: '' };
      return { url: _rebaseDocUrl(url, base), token: token };
    }).catch(function () { return { url: url, token: '' }; });
  }

  // 以隐藏 form POST 把 token 提交到文档渲染页，target 指向已开的具名标签（winName）。
  // enctype 默认 application/x-www-form-urlencoded，token 在表单体里；服务端 @RequestParam("token") 读 form body。
  function _postOpenDocPage(docUrl, token, winName) {
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = docUrl;
    form.target = winName;
    form.style.display = 'none';
    var input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'token';
    input.value = token;
    form.appendChild(input);
    document.body.appendChild(form);
    form.submit();
    setTimeout(function () { if (form.parentNode) form.parentNode.removeChild(form); }, 3000);
  }

  // ---- 快照列表 Popover（详情页「快照」按钮：列出源页全部快照，逐条打开/删除）----
  var _snapshotPopoverOutsideHandler = null;

  // 异步查源页快照列表 → 置灰/启用 snapshotBtn + 染色（普通页 & 文档页共用）。
  function _refreshSnapshotBtnState(url) {
    var btn = document.getElementById('snapshotBtn');
    if (!btn) return;
    btn.classList.remove('snapshot-has');
    btn.disabled = true;
    btn.title = chrome.i18n.getMessage('snapshotBtnTitleEmpty') || '该页面暂无快照';
    if (!url) return;
    sendMessage('getSnapshotsBySourceUrl', { url: url }).then(function (list) {
      if (list && list.length > 0) {
        btn.disabled = false;
        btn.classList.add('snapshot-has');
        btn.title = getMessage('snapshotBtnTitleHas', [String(list.length)]);
      }
    }).catch(function () { /* 留置灰 */ });
  }

  function _closeSnapshotPopover() {
    var pop = document.getElementById('snapshotPopover');
    if (pop && pop.parentNode) pop.parentNode.removeChild(pop);
    if (_snapshotPopoverOutsideHandler) {
      document.removeEventListener('mousedown', _snapshotPopoverOutsideHandler, true);
      _snapshotPopoverOutsideHandler = null;
    }
  }

  // 时间格式化：兼容 "yyyy-MM-dd HH:mm:ss"（UTC-naive 存储）与 ISO，输出本地 "yyyy-MM-dd HH:mm"。
  // 用本地 getter 规避 Date.format polyfill 的 HH bug；解析失败则原样去秒兜底。
  function _formatSnapshotTime(ts) {
    if (!ts) return '';
    try {
      var d = parseStoredTime(ts);
      if (!isNaN(d.getTime())) {
        var pad = function (n) { return (n < 10 ? '0' : '') + n; };
        return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())
          + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
      }
    } catch (e) {}
    return String(ts).replace(/:\d{2}$/, '');
  }

  // 时间格式化（到秒）：详情页「生成于」用。镜像 _formatSnapshotTime 的解析逻辑，末尾保留秒。
  function _formatTimeSec(ts) {
    if (!ts) return '';
    try {
      var d = parseStoredTime(ts);
      if (!isNaN(d.getTime())) {
        var pad = function (n) { return (n < 10 ? '0' : '') + n; };
        return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())
          + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
      }
    } catch (e) {}
    return String(ts);
  }

  // 详情页 header「生成于 yyyy-MM-dd HH:mm:ss」：取 page.lastVisited（快照=采集时间、文档=更新时间、普通页=最后访问）。
  function _fillPageGenTime(page) {
    var el = document.getElementById('pageGenTime');
    if (!el) return;
    var ts = page && page.lastVisited;
    if (ts) {
      el.textContent = (chrome.i18n.getMessage('pageGenTimePrefix') || '生成于') + ' ' + _formatTimeSec(ts);
      el.style.display = '';
    } else {
      el.style.display = 'none';
    }
  }

  // 以隐藏 form POST 打开快照批注页 /snap/{snapId}（token 走 form body，避免泄漏 URL/Referer；与 /d/{docId} 同模式）。
  function _openSnapshotPage(snapId) {
    // 本地模式（游客档，2026-09-29）：快照批注页在服务端、需 token，未登录拦截 + toast
    if (!state.isLoggedIn) {
      showToast(chrome.i18n.getMessage('guestDocOpenDisabled') || '本地模式无法打开文档批注页，请登录后使用');
      return;
    }
    Promise.all([sendMessage('getServerBase'), sendMessage('getAccessToken')]).then(function (vals) {
      var base = (vals[0] || '').replace(/\/+$/, '');
      var token = vals[1] || '';
      if (!base) { showToast(chrome.i18n.getMessage('snapshotOpenFail') || '打开快照失败'); return; }
      var snapUrl = base + '/snap/' + snapId;
      if (!token) { chrome.tabs.create({ url: snapUrl }); return; } // 退回 GET（服务端 401/404 提示登录）
      var winName = 'wpzl_snap_' + Date.now();
      var win = window.open('about:blank', winName);
      if (!win) { showToast(chrome.i18n.getMessage('popupBlocked') || '请允许本扩展弹窗以查看快照'); return; }
      _postOpenDocPage(snapUrl, token, winName);
    }).catch(function () { showToast(chrome.i18n.getMessage('snapshotOpenFail') || '打开快照失败'); });
  }

  // 从 popover 删除一条快照（softDeleteSnapshot：SW 自动判同步开关走软删/硬删，多设备一致）。
  function _deleteSnapshotFromPopover(snapId) {
    if (!snapId) return;
    if (!confirm(chrome.i18n.getMessage('snapshotDeleteConfirm') || '确定删除此快照？同步设备也会删除。')) return;
    sendMessage('softDeleteSnapshot', { snapId: snapId }).then(function () {
      showToast(chrome.i18n.getMessage('snapshotDeletedToast') || '快照已删除');
      var item = document.querySelector('#snapshotPopover .snapshot-popover-item[data-snap-id="' + snapId + '"]');
      if (item && item.parentNode) item.parentNode.removeChild(item);
      if (document.querySelectorAll('#snapshotPopover .snapshot-popover-item').length === 0) {
        _closeSnapshotPopover();
        if (state.currentPage) _refreshSnapshotBtnState(state.currentPage.url);
      }
    }).catch(function () { showToast(chrome.i18n.getMessage('snapshotDeleteFail') || '删除快照失败'); });
  }

  function _openSnapshotPopover(anchorEl, snaps) {
    _closeSnapshotPopover();
    var pop = document.createElement('div');
    pop.id = 'snapshotPopover';
    pop.className = 'snapshot-popover';

    var header = document.createElement('div');
    header.className = 'snapshot-popover-header';
    var titleEl = document.createElement('span');
    titleEl.textContent = chrome.i18n.getMessage('snapshotListTitle') || '快照列表';
    header.appendChild(titleEl);
    var closeBtn = document.createElement('button');
    closeBtn.className = 'snapshot-popover-close';
    closeBtn.innerHTML = '&times;';
    closeBtn.title = chrome.i18n.getMessage('close') || '关闭';
    closeBtn.addEventListener('click', function () { _closeSnapshotPopover(); });
    header.appendChild(closeBtn);
    pop.appendChild(header);

    var listEl = document.createElement('div');
    listEl.className = 'snapshot-popover-list';
    if (!snaps || snaps.length === 0) {
      var empty = document.createElement('div');
      empty.className = 'snapshot-popover-empty';
      empty.textContent = chrome.i18n.getMessage('snapshotEmptyToast') || '该页面暂无快照';
      listEl.appendChild(empty);
    } else {
      snaps.forEach(function (s) {
        var item = document.createElement('div');
        item.className = 'snapshot-popover-item';
        item.setAttribute('data-snap-id', s.snapId);
        var time = document.createElement('span');
        time.className = 'snapshot-popover-time';
        time.textContent = _formatSnapshotTime(s.updatedAt);
        item.appendChild(time);
        var del = document.createElement('button');
        del.className = 'snapshot-popover-del';
        del.innerHTML = '&#128465;';
        del.title = chrome.i18n.getMessage('delete') || '删除';
        del.setAttribute('data-snap-id', s.snapId);
        item.appendChild(del);
        listEl.appendChild(item);
      });
    }
    pop.appendChild(listEl);
    document.body.appendChild(pop);

    // 定位：锚定按钮下方，viewport clamp（与 showPageContextMenu 一致）
    // anchorEl 缺省（异步调用方未同步捕获 currentTarget 等）时兜底居顶，避免 getBoundingClientRect() 抛错。
    var rect = anchorEl ? anchorEl.getBoundingClientRect()
      : { left: Math.max(8, (window.innerWidth - (pop.offsetWidth || 280)) / 2), top: 8, bottom: 8 };
    var popW = pop.offsetWidth || 280;
    var popH = pop.offsetHeight;
    var x = rect.left;
    if (x + popW > window.innerWidth - 8) x = window.innerWidth - popW - 8;
    if (x < 8) x = 8;
    var y = rect.bottom + 4;
    if (y + popH > window.innerHeight - 8) y = Math.max(8, rect.top - popH - 4);
    pop.style.left = x + 'px';
    pop.style.top = y + 'px';

    // 事件代理：点 item(非🗑) → 打开；点 🗑 → 删除
    pop.addEventListener('click', function (ev) {
      var delBtn = ev.target.closest('.snapshot-popover-del');
      if (delBtn) { ev.stopPropagation(); _deleteSnapshotFromPopover(delBtn.getAttribute('data-snap-id')); return; }
      var itemEl = ev.target.closest('.snapshot-popover-item');
      if (itemEl) { _closeSnapshotPopover(); _openSnapshotPage(itemEl.getAttribute('data-snap-id')); }
    });

    // 点 popover 外（且非锚按钮）关闭
    _snapshotPopoverOutsideHandler = function (e) {
      if (pop.contains(e.target)) return;
      if (anchorEl.contains(e.target)) return;
      _closeSnapshotPopover();
    };
    setTimeout(function () {
      document.addEventListener('mousedown', _snapshotPopoverOutsideHandler, true);
    }, 0);
  }

  // ---- Export ----

  var pendingExportScope = 'current';

  function openExportModal(scope) {
    pendingExportScope = scope;
    if (scope === 'current') {
      if (!state.currentPage) {
        showToast(getMessage('expNoPageSelected'));
        return;
      }
      // 自建文档无标注但可导出为 HTML；仅页面需要标注守卫
      if (state.currentPage.kind !== 'document' && state.annotations.length === 0) {
        showToast(getMessage('expNoAnnotations'));
        return;
      }
      if (state.currentPage.kind === 'document') {
        document.getElementById('exportScopeLabel').textContent =
          getMessage('expScopeDoc', [String(state.currentPage.title || state.currentPage.docId || '')]);
      } else {
        document.getElementById('exportScopeLabel').textContent =
          getMessage('expScopePage', [String(state.currentPage.domain || ''), String(state.annotations.length)]);
      }
    } else {
      var pageCount = state.pages.length;
      document.getElementById('exportScopeLabel').textContent =
        getMessage('expScopeAll', [String(pageCount)]);
    }
    // Reset format selection to JSON
    document.querySelectorAll('.export-format-pill').forEach(function (p) { p.classList.remove('active'); });
    document.querySelector('.export-format-pill[data-fmt="json"]').classList.add('active');
    _syncExportFormatHint();
    document.getElementById('exportModal').style.display = 'flex';
  }

  function closeExportModal() {
    document.getElementById('exportModal').style.display = 'none';
    pendingBatchExportUrls = null;   // 取消/关闭导出弹窗：丢弃未执行的批量选择，防误路由旧子集
  }

  // 导出格式备注：仅 JSON（数据备份/导入唯一格式）时显示（spec 2026-09-30-export-pending-download-gate）
  function _syncExportFormatHint() {
    var hint = document.getElementById('exportFormatHint');
    if (!hint) return;
    var jsonPill = document.querySelector('.export-format-pill[data-fmt="json"]');
    hint.style.display = (jsonPill && jsonPill.classList.contains('active')) ? 'block' : 'none';
  }

  // ---- 导出门禁：后台下载未完成时提示（导出全部/批量/增量共用，spec 2026-09-30-export-pending-download-gate）----
  var _pendingGateTimer = null;
  var _pendingGateGen = 0;   // 世代守卫：旧门禁的迟到轮询回调不得拆新门禁（快速重入场景）
  function _stopPendingGatePolling() {
    if (_pendingGateTimer) { clearInterval(_pendingGateTimer); _pendingGateTimer = null; }
  }
  // 实时查询 SW 后台待下载数；失败 resolve(null)——调用方区分：门禁入口按 0 直通（fail-open 不堵导出），
  // 等待态轮询单次失败忽略本轮待重试，绝不当作「归零」静默放行（spec §6）。
  function _queryBgPending() {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ type: 'bg-download-pending-count' }, function (r) {
          if (chrome.runtime.lastError || !(r && r.success)) return resolve(null);
          resolve({ doc: (r.data && r.data.doc) || 0, image: (r.data && r.data.image) || 0 });
        });
      } catch (e) { resolve(null); }
    });
  }
  // 门禁主体：无 pending → true 直接放行；有 → 弹窗让用户决定。
  // 等待态：kick 立即跑一批 + 2s 轮询；归零/3 分钟到点 → 转完成态，由用户点「开始导出」续跑——
  // 不自动 resolve：showDirectoryPicker 需要瞬时用户激活，定时器路径自动续跑会 SecurityError（质量审查 Critical#1）。
  // 立即导出（提示态/等待态均可）：立即续跑 + toast；取消/点遮罩：清 timer，exportModal 保持打开。
  // 倒计时与进度同 tick 渲染（2s 步进，spec「独立 span」意图达成，不追求每秒刷新）。
  function _pendingExportGate() {
    return _queryBgPending().then(function (p) {
      if (!p || p.doc + p.image <= 0) return true;
      var gen = ++_pendingGateGen;
      return new Promise(function (resolve) {
        var modal = document.getElementById('exportPendingModal');
        var bodyEl = document.getElementById('exportPendingBody');
        var waitWrapEl = document.getElementById('exportPendingWaiting');
        var waitTextEl = document.getElementById('exportPendingWaitingText');
        var countdownEl = document.getElementById('exportPendingCountdown');
        var waitBtn = document.getElementById('exportPendingWaitBtn');
        var nowBtn = document.getElementById('exportPendingNowBtn');
        var startBtn = document.getElementById('exportPendingStartBtn');
        var cancelBtn = document.getElementById('exportPendingCancelBtn');
        var deadline = Date.now() + 3 * 60 * 1000;   // 最长等待 3 分钟
        var done = false;        // 本门禁内 _finish 幂等
        var doneTimedOut = false;   // 完成态成因：true=3 分钟到点（点开始导出时要带 toast）

        function _cleanup() {
          _stopPendingGatePolling();
          modal.style.display = 'none';
        }
        function _finish(ok, withToast) {
          if (done || gen !== _pendingGateGen) return;   // 世代守卫：迟到回调/重复收口直接忽略
          done = true;
          _cleanup();
          if (ok && withToast) showToast(getMessage('expPendingTimeoutToast') || '部分后台下载未完成，导出文件可能缺少这些数据');
          resolve(ok);
        }
        function _renderWait(p2) {
          waitTextEl.textContent = getMessage('expPendingWaiting', [String(p2.doc), String(p2.image)]) ||
            ('等待后台下载完成…剩余：文档 ' + p2.doc + ' · 图片 ' + p2.image);
          countdownEl.textContent = '(' + Math.max(0, Math.ceil((deadline - Date.now()) / 1000)) + 's)';
        }
        function _enterDone(timedOut) {
          // 完成态：等待归零或到点。不自动 resolve——点击「开始导出」恢复用户激活后续跑。
          _stopPendingGatePolling();
          doneTimedOut = !!timedOut;
          bodyEl.textContent = getMessage('expPendingReadyBody') || '后台下载已完成，可以开始导出。';
          bodyEl.style.display = 'block';
          waitWrapEl.style.display = 'none';
          waitBtn.style.display = 'none';
          nowBtn.style.display = 'none';
          startBtn.style.display = '';
        }
        function _enterWait() {
          // kick：立即跑一批下载（不等 1min alarm）；批处理器自带重入守卫
          try {
            chrome.runtime.sendMessage({ type: 'bg-download-kick' }, function () { void chrome.runtime.lastError; });
          } catch (e) { /* ignore */ }
          bodyEl.style.display = 'none';
          waitWrapEl.style.display = 'block';
          waitBtn.style.display = 'none';
          deadline = Date.now() + 3 * 60 * 1000;
          _renderWait(p);   // 立即渲染一次，不等首个 2s tick
          _stopPendingGatePolling();
          _pendingGateTimer = setInterval(function () {
            _queryBgPending().then(function (p2) {
              if (done || gen !== _pendingGateGen) return;
              if (!p2) return;   // 单次查询失败：忽略本轮，2s 后重试（3 分钟兜底仍兜住）
              if (p2.doc + p2.image <= 0) { _enterDone(false); return; }   // 归零 → 完成态
              if (Date.now() >= deadline) { _enterDone(true); return; }     // 3 分钟到点 → 完成态（点击时带 toast）
              _renderWait(p2);
            });
          }, 2000);
        }

        // 提示态初始化（先停残留轮询：快速双击导出可能重入门禁，上次未收口的轮询在此自愈）
        _stopPendingGatePolling();
        bodyEl.textContent = getMessage('expPendingBody', [String(p.doc), String(p.image)]) ||
          ('检测到 ' + p.doc + ' 个文档正文、' + p.image + ' 张图片仍在后台下载。现在导出，这些数据不会包含在导出文件中。');
        bodyEl.style.display = 'block';
        waitWrapEl.style.display = 'none';
        waitBtn.style.display = '';
        nowBtn.style.display = '';
        startBtn.style.display = 'none';
        modal.style.display = 'flex';

        // onclick 赋值（非 addEventListener）：门禁可多次进入，赋值天然幂等不叠 handler
        waitBtn.onclick = function () { _enterWait(); };
        nowBtn.onclick = function () { _finish(true, true); };
        startBtn.onclick = function () { _finish(true, doneTimedOut); };
        cancelBtn.onclick = function () { _finish(false, false); };
        modal.onclick = function (e) { if (e.target === modal) _finish(false, false); };
      });
    });
  }

  function openImportModal() {
    var skipRadio = document.querySelector('#importModal input[value="skip"]');
    if (skipRadio) skipRadio.checked = true;
    document.getElementById('importModal').style.display = 'flex';
  }

  function closeImportModal() {
    document.getElementById('importModal').style.display = 'none';
  }

  // 导入后统一刷新链（legacy 与流式路径共用）
  function afterImportRefresh() {
    return refreshPageCounts().then(function () {
      // 导入旧备份后强制重跑 folder 迁移（force=true），把 settings.folderTree/pageFolderMap 迁到 folders store + pages.FOLDER_ID
      return sendMessage('migrateFoldersFromSettings', {});
    }).then(function () {
      return loadFolders();
    }).then(function () {
      return refreshDocuments();   // 重载文档 + 快照（含新导入项）
    }).then(function () {
      state.currentPage = null;
      renderSidebar();
      renderContent();
    });
  }

  // ---- P1-32: 流式导入 NDJSON v8 ----
  // file.stream() →（gzip 魔数嗅探→DecompressionStream）→ TextDecoderStream → 缓冲分行。
  // 只读首行判型：v8 走流式（按 store 攒批 200 条/~8MB 调 restoreChunk，thumbIdRemap 逐块回显，
  // SW 中途被杀不丢映射）；否则返回 false 由调用方 File 重读走 legacy parseBackupFile 整文件路径。
  async function restoreFromFileStreaming(file, strategy) {
    var head = new Uint8Array(await file.slice(0, 2).arrayBuffer());
    var gz = head[0] === 0x1f && head[1] === 0x8b;
    var stream = file.stream();
    if (gz) stream = stream.pipeThrough(new DecompressionStream('gzip'));
    var reader = stream.pipeThrough(new TextDecoderStream()).getReader();
    var buf = '';
    var readerDone = false;

    async function nextLine() {
      while (true) {
        var idx = buf.indexOf('\n');
        if (idx >= 0) {
          var line = buf.slice(0, idx);
          buf = buf.slice(idx + 1);
          return line;
        }
        if (readerDone) {
          if (buf.length > 0) { var last = buf; buf = ''; return last; }
          return null;
        }
        var r = await reader.read();
        if (r.done) { readerDone = true; continue; }
        buf += r.value;
      }
    }

    // 首行判型（判型前未消费 File 本体——legacy 路径仍可整文件重读）
    var first = await nextLine();
    var meta = null;
    try { meta = first ? JSON.parse(first) : null; } catch (e) { meta = null; }
    if (!meta || !meta._meta || meta._meta.format !== 'ndjson' || meta._meta.version !== 8) {
      try { reader.cancel(); } catch (e) { /* ignore */ }
      return false;
    }

    var curStore = null;
    var batch = [];
    var batchBytes = 0;
    var thumbRemap = null;
    var preflightUid = null;
    var inserted = 0;
    var skipped = 0;
    var storesSeen = [];
    var BATCH_COUNT = 200;
    var BATCH_BYTES = 8 * 1024 * 1024;
    // G-2：导入进度 + 跨账号/额度渐进提示（NDJSON 头无总量，全部渐进判定，不做预扫描）
    showImportProgress();
    var foreignNotified = false;
    var quotaNotified = false;
    var dailyImportLimit = await _readDailyImportLimit();
    var skippedForeignSnaps = 0;

    async function flush(finalize) {
      if (batch.length > 0 || finalize) {
        // 备份属主采样：块内首条 USER_ID（导出端均匀回填；清 batch 前取）
        var ownerSample = (batch.length > 0 && batch[0] && batch[0].USER_ID) ? String(batch[0].USER_ID) : null;
        var resp = await sendMessage('restoreChunk', {
          store: curStore || 'pages',
          records: batch,
          strategy: strategy,
          thumbIdRemap: thumbRemap || undefined,
          preflightUserId: preflightUid || undefined,
          finalize: !!finalize,
          storesSeen: storesSeen
        });
        inserted += (resp && resp.inserted) || 0;
        skipped += (resp && resp.skipped) || 0;
        skippedForeignSnaps += (resp && resp.skippedForeignSnapshots) || 0;
        if (resp && resp.thumbIdRemap) thumbRemap = resp.thumbIdRemap;
        if (resp && resp.preflightUserId) preflightUid = resp.preflightUserId;
        batch = [];
        batchBytes = 0;
        updateImportProgress(inserted);
        // 跨账号明示（一次性）：备份属主 ≠ 本机属主
        if (!foreignNotified && ownerSample && preflightUid && ownerSample !== String(preflightUid)) {
          foreignNotified = true;
          showToast(getMessage('importForeignNotice'));
        }
        // 额度预告（一次性）：累计写入超每日导入额度（-1=无限不提示；读不到缓存同样不提示）
        if (!quotaNotified && dailyImportLimit > 0 && inserted > dailyImportLimit) {
          quotaNotified = true;
          showToast(getMessage('importQuotaPreview', [String(dailyImportLimit)]));
        }
        if (!finalize) console.info('[import] NDJSON chunk done, total inserted=' + inserted);
      }
    }

    var line = await nextLine();
    while (line !== null) {
      line = line.trim();
      if (line) {
        var obj = null;
        try { obj = JSON.parse(line); } catch (e) { obj = null; }
        if (obj && obj.store && obj.record) {
          if (obj.store !== curStore) {
            await flush(false);
            curStore = obj.store;
            if (storesSeen.indexOf(curStore) === -1) storesSeen.push(curStore);
          }
          batch.push(obj.record);
          batchBytes += line.length;
          if (batch.length >= BATCH_COUNT || batchBytes >= BATCH_BYTES) await flush(false);
        }
      }
      line = await nextLine();
    }
    await flush(true);
    hideImportProgress();
    showToast(getMessage('importFinished', [String(inserted), String(skipped)]));
    // G-3：外来备份快照跳过明细（元数据+body 都没导入，单独一条提示说清合规原因）
    if (skippedForeignSnaps > 0) showToast(getMessage('importForeignSnapsSkipped', [String(skippedForeignSnaps)]));
    console.info('[import] NDJSON v8 streaming done: inserted=' + inserted + ' skipped=' + skipped +
      ' foreignSnapsSkipped=' + skippedForeignSnaps);
    return true;
  }

  function restoreFromFile(file, strategy) {
    (async function () {
      // P1-32: 先尝试 NDJSON v8 流式导入；非 v8 格式（旧 .json.gz/.json/单文档导出）走下方 legacy 路径
      try {
        var streamed = await restoreFromFileStreaming(file, strategy);
        if (streamed) {
          afterImportRefresh().catch(function () { /* ignore */ });
          return;
        }
      } catch (streamErr) {
        // 流式路径异常（restoreChunk 失败/流损坏）→ 回落 legacy 整文件路径兜底
        // （skip 策略下已导入记录会被跳过，幂等无害）
        hideImportProgress();   // G-2：回退 legacy 前收起进度覆盖层（防遮罩滞留）
        console.warn('[import] streaming failed, fallback to legacy:', streamErr && streamErr.message);
      }
      try {
        var data = await parseBackupFile(file);
        if (!data._meta || [1, 2, 3, 4, 5, 6, 7].indexOf(data._meta.version) === -1) {
          // 单文档 JSON 导出格式（exportDocument fmt='json'，_meta.kind='document'）：
          // 包成 documents 数组走统一导入；document 为原始 documents 记录（含 tags），整体 put。
          if (data._meta && data._meta.kind === 'document' && data.document) {
            data = { _meta: { version: 7, exportDate: data._meta.exportDate || new Date().toISOString() },
                     documents: [data.document], annotations: [], pages: [], folders: [], settings: [] };
          } else if (data._meta && data._meta.kind === 'snapshot' && data.snapshot) {
            // 单快照 JSON 导出格式：包成 snapshots 数组走统一导入（SW restoreBackup 已支持 snapshots）。
            data = { _meta: { version: 7, exportDate: data._meta.exportDate || new Date().toISOString() },
                     snapshots: [data.snapshot], annotations: [], pages: [], folders: [], settings: [] };
          } else if (Array.isArray(data)) {
            data = { _meta: { version: 1, exportDate: new Date().toISOString() },
                     annotations: data, pages: [], settings: [] };
          } else {
            showToast(getMessage('toastInvalidBackupFile'));
            return;
          }
        }
        sendMessage('restoreBackup', {
          annotations: data.annotations || [],
          pages: data.pages || [],
          folders: data.folders || [],
          settings: data.settings || [],
          imageData: data.imageData || [],
          tags: data.tags || [],
          localThumbnails: data.localThumbnails || [],
          documents: data.documents || [],
          snapshots: data.snapshots || [],
          strategy: strategy
        }).then(function (result) {
          var ins = result.inserted || {}, skp = result.skipped || {};
          var totalInserted = (ins.annotations || 0) + (ins.pages || 0) + (ins.settings || 0) + (ins.folders || 0)
            + (ins.imageData || 0) + (ins.tags || 0) + (ins.localThumbnails || 0) + (ins.documents || 0) + (ins.snapshots || 0);
          var totalSkipped = (skp.annotations || 0) + (skp.pages || 0) + (skp.settings || 0) + (skp.folders || 0)
            + (skp.imageData || 0) + (skp.tags || 0) + (skp.localThumbnails || 0) + (skp.documents || 0) + (skp.snapshots || 0);
          var msg = getMessage('impInserted', [String(totalInserted)]);
          if (totalSkipped > 0) msg += getMessage('impSkippedPart', [String(totalSkipped)]);
          showToast(msg);
          afterImportRefresh().catch(function () { /* ignore */ });
        }).catch(function (err) {
          showToast(getMessage('importFailed', [String(err.message || 'unknown error')]));
        });
      } catch (err) {
        showToast(getMessage('expJsonParseFailed'));
      }
    })();
  }

  async function executeExport() {
    var fmtPill = document.querySelector('.export-format-pill.active');
    var fmt = fmtPill ? fmtPill.dataset.fmt : 'json';

    // 导出格式权限检查
    if (!canExportFormat(fmt)) {
      showToast(state.isLoggedIn ? getMessage('expProFormat') : getMessage('expLoginRequired'));
      return;
    }

    // 后台下载门禁：全部/批量导出为备份路径，导出前检查未完成的后台下载（文档 body/图片 blob）。
    // 插在 closeExportModal 之前：等待期间 exportModal 保持打开（spec §4.3）。
    // 批量 URL 先捕获局部副本：closeExportModal 会重置 pendingBatchExportUrls（取消清理），路由须用捕获值。
    var _batchUrls = (pendingBatchExportUrls && pendingBatchExportUrls.length > 0) ? pendingBatchExportUrls : null;
    var _isBackupScope = _batchUrls || pendingExportScope !== 'current';
    if (_isBackupScope) {
      if (!(await _pendingExportGate())) return;   // 取消：exportModal 维持打开供用户改主意
    }

    closeExportModal();

    if (!window.showDirectoryPicker) {
      showToast(getMessage('expNoFsAccess'));
      return;
    }

    try {
      var dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });

      // 批量导出（入口已捕获 _batchUrls 非空）走专用路径
      if (_batchUrls) {
        await executeBatchExport(fmt, dirHandle, _batchUrls);
      } else if (pendingExportScope === 'current' && state.currentPage && state.currentPage.kind === 'snapshot') {
        // 网页快照：按所选格式导出（Markdown / JSON / HTML）
        await exportSnapshot(state.currentPage, dirHandle, fmt);
      } else if (pendingExportScope === 'current' && state.currentPage && state.currentPage.kind === 'document') {
        // 自建文档：按所选格式导出（Markdown/JSON；html 回退 HTML）
        await exportDocument(state.currentPage, dirHandle, fmt);
      } else if (pendingExportScope === 'current') {
        await exportCurrentPage(fmt, dirHandle);
      } else {
        await exportAll(fmt, dirHandle);
      }
    } catch (err) {
      if (err.name === 'AbortError') return;
      console.error('Export error:', err);
      showToast(getMessage('expFailed', [String(err.message)]));
    }
  }

  async function exportCurrentPage(fmt, dirHandle) {
    // 自建文档按所选格式导出（Markdown/JSON；html 回退 HTML）
    if (state.currentPage && state.currentPage.kind === 'document') {
      return exportDocument(state.currentPage, dirHandle, fmt);
    }
    // 网页快照：按所选格式导出（Markdown / JSON / HTML）
    if (state.currentPage && state.currentPage.kind === 'snapshot') {
      return exportSnapshot(state.currentPage, dirHandle, fmt);
    }
    if (!state.currentPage || state.annotations.length === 0) {
      showToast(getMessage('expNoAnnotations'));
      return;
    }
    var annotations = state.annotations;
    var page = state.currentPage;
    // 补全空的 AUTHOR_ID/AUTHOR_NAME → 当前用户身份
    var exportIdentity = null;
    try { exportIdentity = await getUserIdentity(); } catch (e) { /* ignore */ }
    var exportUid = (exportIdentity && exportIdentity.userId) || (exportIdentity && exportIdentity.authorId) || '';
    var exportUname = (exportIdentity && exportIdentity.authorName) || '';
    for (var i = 0; i < annotations.length; i++) {
      var a = annotations[i];
      if (!a.USER_ID) a.USER_ID = exportUid || a.AUTHOR_ID || '';
      if (!a.AUTHOR_ID) a.AUTHOR_ID = exportUid || a.USER_ID || '';
      if (!a.AUTHOR_NAME) a.AUTHOR_NAME = exportUname;
    }

    if (fmt === 'json') {
      // 拿 page 涉及的 folder 链（含其本身）
      var folderChain = [];
      try {
        var allFolders = await sendMessage('getAllFolders', {});
        var fid = page.FOLDER_ID;
        var fidSet = new Set();
        while (fid && !fidSet.has(fid)) {
          fidSet.add(fid);
          var f = (allFolders || []).find(function (x) { return x.folderId === fid; });
          if (!f) break;
          folderChain.push(f);
          fid = f.parentFolderId;
        }
      } catch (e) { /* ignore */ }
      // localThumbnails 按 annId 只导本页标注的（全库导出会虚胖且导入污染其它页）
      var pageThumbIds = {};
      annotations.forEach(function (a) { pageThumbIds[a.MARK_INFO_ID] = true; });
      var pageThumbnails = [];
      try {
        pageThumbnails = (await getAllLocalThumbnails() || []).filter(function (th) { return th && pageThumbIds[th.annId]; });
      } catch (e) { /* ignore */ }
      // 本页图片标注的 imageData 记录（含 base64/cloudUrl），换机导入后本地图可完整还原
      var pageImageData = [];
      try {
        var pImgUrls = collectImageUrls(annotations);
        var pImgRecs = await sendMessage('getImageDataBatch', { pageUrl: page.url, imageUrls: pImgUrls });
        for (var pik in pImgRecs) if (pImgRecs[pik]) pageImageData.push(pImgRecs[pik]);
      } catch (e) { /* ignore */ }
      var exportData = {
        _meta: { version: 6, exportDate: new Date().toISOString(), stores: { annotations: annotations.length, pages: 1, folders: folderChain.length, imageData: pageImageData.length, localThumbnails: pageThumbnails.length } },
        annotations: annotations,
        pages: [page],
        folders: folderChain,
        settings: [],
        imageData: pageImageData,
        tags: [],
        localThumbnails: pageThumbnails
      };
      var gz = await compressBackupObject(exportData);
      var fileName = makeExportFilename(page, 'json.gz');
      await writeFileToDir(dirHandle, fileName, gz);
      showToast(getMessage('expExportedTo', [fileName]));
    } else if (fmt === 'csv' || fmt === 'html') {
      // CSV/HTML 表格化导出：纯本地聚合，单页 1 个 section
      var tabularContent = fmt === 'csv'
        ? generateAnnotationsCsv([{ page: page, annotations: annotations }])
        : generateAnnotationsHtmlReport([{ page: page, annotations: annotations }]);
      var tabularName = makeExportFilename(page, fmt);
      await writeFileToDir(dirHandle, tabularName, tabularContent);
      showToast(getMessage('expExportedTo', [tabularName]));
    } else {
      var imageUrls = collectImageUrls(annotations);
      var imageMap = await fetchImageData(page.url, imageUrls);
      var replyMap = await fetchPageRepliesMap(page);
      var _expBase = ''; try { _expBase = await getServerBase(); } catch (e) { /* base 缺失则 https:// 兜底 */ }
      var md = generatePageMarkdown(annotations, page, imageMap, _expBase, replyMap);
      var fileName = makeExportFilename(page, 'md');
      await writeFileToDir(dirHandle, fileName, md);
      showToast(getMessage('expExportedTo', [fileName]));
    }
  }

  // 自建文档导出为独立 HTML（bodyHtml 已含 KaTeX 渲染后的 HTML，直接落盘）
  async function exportDocumentAsHtml(doc, dirHandle) {
    var title = (doc && doc.title) ? doc.title : ((doc && doc.docId) ? doc.docId : 'document');
    var safeName = (String(title).replace(/[\\/:*?"<>|]/g, '_').slice(0, 80)) || 'document';
    var fileName = safeName + '.html';
    // 标签写入 meta keywords（分号串 → 逗号分隔，符合 HTML keywords 惯例）
    var tagList = (doc && doc.tags) ? String(doc.tags).split(';').map(function (s) { return s.trim(); }).filter(Boolean) : [];
    var keywords = tagList.join(', ');
    var html = '<!doctype html><html lang="' + (document.documentElement.lang || 'zh-CN') + '">'
      + '<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
      + (keywords ? '<meta name="keywords" content="' + escapeHtml(keywords) + '">' : '')
      + '<title>' + escapeHtml(title) + '</title></head><body>' + (doc.bodyHtml || '') + '</body></html>';
    try {
      await writeFileToDir(dirHandle, fileName, html);
      showToast(getMessage('expExportedTo', [fileName]));
    } catch (e) {
      showToast(getMessage('expFailed', [String(e.message)]));
      throw e;
    }
  }

  // 快照 Markdown 导出：独立 .md，内容 = 快照完整内容 + 标记与批注（区别于普通网页导出只有标注/批注）。
  // 完整快照保留 bodyHtml 的完整可见内容（剥 script/style 等不可见元素，不用 Readability 过滤）；
  // 精简快照 bodyHtml 本身是干净 article，同样流程、结果自然简洁。
  function generateSnapshotMarkdown(snap, annotations, imageMap) {
    imageMap = imageMap || {};
    var snapType = (snap && snap.snapType) || _sniffSnapType(snap && snap.bodyHtml) || 'full';
    var title = displayPageTitle(snap) || (snap && snap.title) || (snap && snap.snapId) || getMessage('snapshotUntitled');
    var sorted = (annotations || []).slice().sort(function (a, b) {
      var ya = parseFloat(a.ANCHOR_Y_RATIO) || 0;
      var yb = parseFloat(b.ANCHOR_Y_RATIO) || 0;
      if (ya !== yb) return ya - yb;
      return (a.CREATE_TIME || '').localeCompare(b.CREATE_TIME || '');
    });

    var lines = [];
    lines.push('---');
    lines.push('webpz_snapshot:');
    lines.push('  snap_id: ' + escapeYaml(snap && snap.snapId));
    lines.push('  source_url: ' + escapeYaml((snap && snap.sourceWebUri) || (snap && snap.url) || ''));
    lines.push('  snap_type: ' + escapeYaml(snapType));
    lines.push('  title: ' + escapeYaml(title));
    lines.push('  captured_at: ' + escapeYaml((snap && (snap.updatedAt || snap.lastVisited)) || ''));
    // snap_updated + annotations 列表：供增量导出 diff（与页面 md 的 webpz_sync.annotations 同构）
    lines.push('  snap_updated: ' + escapeYaml((snap && (snap.updatedAt || snap.lastVisited)) || ''));
    lines.push('  annotation_count: ' + sorted.length);
    lines.push('  annotations:');
    sorted.forEach(function (a) {
      lines.push('    - id: ' + escapeYaml(a.MARK_INFO_ID));
      lines.push('      type: ' + escapeYaml(getAnnotationType(a)));
      lines.push('      updated: ' + escapeYaml(a.UPDATE_TIME || ''));
    });
    lines.push('---');
    lines.push('');

    lines.push('# ' + title);
    lines.push('');
    lines.push('> ' + getMessage('expMdSourceUrl', [String((snap && snap.sourceWebUri) || (snap && snap.url) || '')]));
    lines.push('> ' + getMessage('expMdType', [String(snapType === 'lite' ? getMessage('snapshotLite') : getMessage('snapshotFull'))]));
    if (snap && (snap.updatedAt || snap.lastVisited)) {
      lines.push('> ' + getMessage('expMdCapturedAt', [String(snap.updatedAt || snap.lastVisited)]));
    }
    lines.push('');
    lines.push('---');
    lines.push('');

    // 快照完整内容
    var bodyMd = _snapshotBodyToMarkdown(snap && snap.bodyHtml);
    lines.push(bodyMd || getMessage('expMdNoBody'));
    lines.push('');

    // 标记 + 批注
    if (sorted.length > 0) {
      lines.push('---');
      lines.push('');
      lines.push('## ' + getMessage('expMdMarksSection'));
      lines.push('');
      sorted.forEach(function (a, idx) {
        var type = getAnnotationType(a);
        var typeInfo = TYPE_MAP[type] || {};
        var typeLabel = typeInfo.label || type;
        lines.push('### ' + (idx + 1) + '. ' + typeLabel);
        lines.push('');
        switch (type) {
          case 'highlight': renderHighlightMd(lines, a); break;
          case 'rect': renderRectMd(lines, a, imageMap); break;
          case 'pageRect': renderPageRectMd(lines, a); break;
          case 'arrow':
          case 'flag': renderArrowFlagMd(lines, a, typeLabel); break;
          case 'freehand': renderFreehandMd(lines, a); break;
          case 'text': renderTextNoteMd(lines, a); break;
          case 'imgAnno': renderImgAnnoMd(lines, a, imageMap); break;
          case 'rectFrame': renderRectFrameMd(lines, a, imageMap); break;
          case 'elementMark': renderElementMarkMd(lines, a); break;
          default: lines.push(''); break;
        }
        if (a.COMMENT_TEXT) {
          lines.push('');
          lines.push(getMessage('expMdComment', [String(a.COMMENT_TEXT).replace(/\n/g, '\n> ')]));
        }
        if (a.TAGS) {
          var tags = a.TAGS.split(';').filter(function (t) { return t.trim(); });
          if (tags.length > 0) {
            lines.push('');
            lines.push(tags.map(function (t) { return '#' + t.trim().replace(/\s+/g, '-'); }).join(' '));
          }
        }
        lines.push('');
        lines.push('---');
        lines.push('');
      });
    }

    return lines.join('\n');
  }

  // 快照 bodyHtml → Markdown 正文：剥除不可见/扩展元素后，按块级元素递归转 md（标题/段落/列表/图片/链接）。
  // 独立实现（不复用 htmlBodyToMarkdown）以处理整页 HTML 的 div/section 等块级换行，且不影响文档导出。
  function _snapshotBodyToMarkdown(bodyHtml) {
    if (!bodyHtml) return '';
    var dom;
    try { dom = new DOMParser().parseFromString('<body>' + bodyHtml + '</body>', 'text/html'); }
    catch (e) { return ''; }
    var body = dom.body;
    if (!body) return '';
    try {
      body.querySelectorAll('script,style,iframe,noscript,template,object,embed,svg,[abc18980900]').forEach(function (el) { el.remove(); });
    } catch (e) { /* ignore */ }

    var out = [];
    var BLOCK = { P:1, DIV:1, SECTION:1, ARTICLE:1, HEADER:1, FOOTER:1, ASIDE:1, NAV:1, BLOCKQUOTE:1, PRE:1, UL:1, OL:1, LI:1, TABLE:1, TR:1, DD:1, DL:1, FIGURE:1, FIGCAPTION:1, MAIN:1, DETAILS:1, SUMMARY:1 };

    function esc(s) {
      return String(s == null ? '' : s).replace(/^(\s{0,3})(#{1,6}\s|[-+*]\s+|\d+\.\s+|>\s?)/gm, '$1\\$2');
    }

    function inlineText(node) {
      if (node.nodeType === 3) return esc(node.nodeValue || '');
      if (node.nodeType !== 1) return '';
      var tag = node.nodeName.toUpperCase();
      if (tag === 'BR') return '\n';
      if (tag === 'IMG') {
        var src = node.getAttribute('src') || '';
        return (src && /^(https?:|data:|\/)/i.test(src)) ? '![](' + src + ')' : '';
      }
      var inner = '';
      for (var i = 0; i < node.childNodes.length; i++) inner += inlineText(node.childNodes[i]);
      if (tag === 'A') { var href = node.getAttribute('href') || ''; return (inner && href) ? '[' + inner + '](' + href + ')' : inner; }
      if (tag === 'STRONG' || tag === 'B') return inner.trim() ? '**' + inner + '**' : inner;
      if (tag === 'EM' || tag === 'I') return inner.trim() ? '*' + inner + '*' : inner;
      if (tag === 'CODE') { var ct = node.textContent; return ct ? '`' + ct + '`' : ''; }
      return inner;
    }

    function walk(node) {
      for (var i = 0; i < node.childNodes.length; i++) {
        var c = node.childNodes[i];
        if (c.nodeType === 3) {
          var t = esc(c.nodeValue || '').replace(/\s+/g, ' ');
          if (t.trim()) out.push(t);
        } else if (c.nodeType === 1) {
          var tag = c.nodeName.toUpperCase();
          if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT' || tag === 'SVG') continue;
          if (tag === 'IMG') { var src = c.getAttribute('src') || ''; if (src) out.push('![](' + src + ')'); continue; }
          if (tag === 'BR') { out.push(''); continue; }
          if (tag === 'HR') { out.push('---'); out.push(''); continue; }
          if (tag === 'UL' || tag === 'OL') {
            var items = c.children;
            for (var k = 0; k < items.length; k++) {
              if (items[k].nodeName.toUpperCase() === 'LI') out.push('- ' + inlineText(items[k]).trim());
            }
            out.push('');
            continue;
          }
          if (/^H[1-6]$/.test(tag)) {
            var lv = parseInt(tag.charAt(1), 10);
            out.push(Array(lv + 1).join('#') + ' ' + inlineText(c).trim());
            out.push('');
            continue;
          }
          if (tag === 'PRE') { out.push('    ' + String(c.textContent || '').replace(/\n$/, '')); out.push(''); continue; }
          if (tag === 'BLOCKQUOTE') { var q = inlineText(c).trim(); if (q) { q.split('\n').forEach(function (ln) { out.push('> ' + ln); }); out.push(''); } continue; }
          if (BLOCK[tag]) {
            var txt = inlineText(c).trim();
            if (txt) { out.push(txt); out.push(''); }
            else { walk(c); }   // 空块级容器 → 递归子节点（不丢内容）
          } else {
            var it = inlineText(c);
            if (it.trim()) out.push(it);
          }
        }
      }
    }

    walk(body);
    return out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  }

  // 网页快照导出：按 fmt 分发——markdown（快照完整内容 + 标记 + 批注）、json（单快照备份）、html（完整网页）。
  // 文件名统一加「（快照）」后缀：快照常与其源文档/源页同名（如对 /d/doc- 页截图），
  // 不加后缀会同目录同名互相覆盖（文档 md / 页面 md 与快照 md 均按标题命名）。
  function snapExportBaseName(snap) {
    var title = (snap && snap.title) ? snap.title : ((snap && snap.snapId) ? snap.snapId : 'snapshot');
    var safe = (String(title).replace(/[\\/:*?"<>|]/g, '_').slice(0, 80)) || 'snapshot';
    return safe + getMessage('expMdSnapshotSuffix');
  }

  async function exportSnapshot(snap, dirHandle, fmt) {
    fmt = fmt || 'html';
    var title = (snap && snap.title) ? snap.title : ((snap && snap.snapId) ? snap.snapId : 'snapshot');
    var baseName = snapExportBaseName(snap);
    // P1-8 分仓：入口物化本地 body（json 导出随之完整携带；html/md 下游直接可用）
    await ensureSnapBody(snap);

    // CSV 是标注表格格式，而快照导出的语义主体是内容本体（bodyHtml），二者不匹配 → 显式拒绝
    // （不拦截会掉进下方 html 默认分支，产出与所选格式不符的文件）
    if (fmt === 'csv') {
      showToast(getMessage('expCsvKindUnsupported'));
      return;
    }

    if (fmt === 'json') {
      var exportData = { _meta: { version: 7, kind: 'snapshot', exportDate: new Date().toISOString() }, snapshot: snap };
      var gz = await compressBackupObject(exportData);
      try { await writeFileToDir(dirHandle, baseName + '.json.gz', gz); showToast(getMessage('expExportedTo', [baseName + '.json.gz'])); }
      catch (e) { showToast(getMessage('expFailed', [String(e.message)])); throw e; }
      return;
    }

    if (fmt === 'markdown') {
      var allAnnos = [];
      try { allAnnos = await exportAllAnnotations() || []; } catch (e) { /* ignore */ }
      var snapAnnos = allAnnos.filter(function (a) {
        return String(a.WEB_URI || '').indexOf('/snap/' + (snap && snap.snapId)) >= 0;
      });
      // 图片标注内嵌本地图（此前传空 map，base64 本地图落回可能失效的原始 URL）
      var snapImgMap = await fetchImageData((snap && snap.url) || '', collectImageUrls(snapAnnos));
      var md = generateSnapshotMarkdown(snap, snapAnnos, snapImgMap);
      try { await writeFileToDir(dirHandle, baseName + '.md', md); showToast(getMessage('expExportedTo', [baseName + '.md'])); }
      catch (e) { showToast(getMessage('expFailed', [String(e.message)])); throw e; }
      return;
    }

    // html（默认）：bodyHtml 已是完整 <html> 文档，直接写为独立 .html
    var raw = (snap && snap.bodyHtml) || '';
    var html = /<html[\s>]/i.test(raw)
      ? ('<!doctype html>\n' + raw)
      : ('<!doctype html><html lang="' + (document.documentElement.lang || 'zh-CN') + '">'
        + '<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        + '<title>' + escapeHtml(title) + '</title></head><body>' + raw + '</body></html>');
    try {
      await writeFileToDir(dirHandle, baseName + '.html', html);
      showToast(getMessage('expExportedTo', [baseName + '.html']));
    } catch (e) {
      showToast(getMessage('expFailed', [String(e.message)]));
      throw e;
    }
  }

  // ---- 自建文档导出（Markdown / JSON）----
  // 文档正文 bodyHtml 是 TipTap 渲染后的 HTML。Markdown 走「纯转换」：结构/列表/代码/引用/链接/
  // 图片/数学节点 → 标准 MD 语法；字体/字号/颜色/行距等 inline 样式有损丢弃（MD 无对应）。
  // 未知节点递归取文本、不抛错（通用性，适配任意文档内容）。图片按 data-image-key 解析为可用 src。

  // 文档导出文件名（与 exportDocumentAsHtml 命名规则一致，扩展名随格式）
  function docExportFileName(doc, ext) {
    var title = (doc && doc.title) ? doc.title : ((doc && doc.docId) ? doc.docId : 'document');
    var safe = (String(title).replace(/[\\/:*?"<>|]/g, '_').slice(0, 80)) || 'document';
    return safe + '.' + ext;
  }

  // HTML → Markdown（覆盖 TipTap StarterKit + Link + Image + 数学 + textStyle 子集）。
  // imgMap: { imageKey → 可用 src }，由 fetchDocumentImages 预解析；调用方传入。
  function htmlBodyToMarkdown(bodyHtml, imgMap, fmSink) {
    imgMap = imgMap || {};
    var dom;
    try { dom = new DOMParser().parseFromString('<body>' + (bodyHtml || '') + '</body>', 'text/html'); }
    catch (e) { return String(bodyHtml || ''); }
    var out = [];

    // 行首语法字符最小转义（避免正文被误判为标题/列表/引用/代码块）；inline code / 代码块用 raw textContent 不走此处
    function escText(s) {
      return String(s == null ? '' : s).replace(/^(\s{0,3})(#{1,6}\s|[-+*]\s+|\d+\.\s+|>\s?|```)/gm, '$1\\$2');
    }

    // 行内节点 → markdown 片段（不含块级空行）
    function inline(node) {
      if (node.nodeType === 3) return escText(node.nodeValue);   // text node
      if (node.nodeType !== 1) return '';
      var tag = node.nodeName.toUpperCase();
      // 数学节点：取 data-latex，忽略渲染后的 KaTeX 子节点
      if (tag === 'SPAN' && (node.className || '').indexOf('math-inline') >= 0) {
        var il = node.getAttribute('data-latex'); return il ? '$' + il + '$' : '';
      }
      if (tag === 'DIV' && (node.className || '').indexOf('math-display') >= 0) {
        var bl = node.getAttribute('data-latex'); return bl ? '$$' + bl + '$$' : '';
      }
      // inline code：用 raw textContent（不再转义/递归，保留字面）
      if (tag === 'CODE') { var ct = node.textContent; return ct ? '`' + ct + '`' : ''; }
      // 图片：优先 imageKey 解析出的 src，其次 http/https/data 的原 src，否则留占位
      if (tag === 'IMG') {
        var key = node.getAttribute('data-image-key') || '';
        var src = (key && imgMap[key]) || node.getAttribute('src') || '';
        if (src && /^(https?:|data:)/i.test(src)) return '![](' + src + ')';
        return '<!-- image -->';
      }
      if (tag === 'BR') return '\n';
      // 收集子节点
      var inner = '';
      for (var i = 0; i < node.childNodes.length; i++) inner += inline(node.childNodes[i]);
      // —— Obsidian 保真载体（class 约定见 doc-editor importers/markdown.js），在通用分支之前识别 ——
      if (tag === 'MARK') return inner.trim() ? '==' + inner + '==' : inner;
      if (tag === 'SPAN') {
        var obCls = ' ' + String(node.className || '') + ' ';
        if (obCls.indexOf(' wpz-embed ') >= 0) return node.textContent;   // 原样 ![[..]]，绕过 escText
        if (obCls.indexOf(' wpz-tag ') >= 0) return node.textContent;     // 原样 #tag
        if (obCls.indexOf(' wpz-comment ') >= 0) { var obc = node.textContent; return obc ? '%%' + obc + '%%' : ''; }
      }
      switch (tag) {
        case 'STRONG': case 'B': return inner.trim() ? '**' + inner + '**' : inner;
        case 'EM': case 'I': return inner.trim() ? '*' + inner + '*' : inner;
        case 'S': case 'DEL': case 'STRIKE': return inner.trim() ? '~~' + inner + '~~' : inner;
        case 'A': {
          // wikilink 载体：无 href、class=wpz-wikilink、target 存 title → 还原 [[t]]/[[t|a]]
          if ((' ' + String(node.className || '') + ' ').indexOf(' wpz-wikilink ') >= 0) {
            var obTgt = (node.getAttribute('title') || '').trim();
            var obLbl = inner.trim();
            if (!obLbl) return '';
            if (!obTgt || obTgt === obLbl) return '[[' + obLbl + ']]';
            return '[[' + obTgt + '|' + obLbl + ']]';
          }
          var href = node.getAttribute('href') || ''; return (inner && href) ? '[' + inner + '](' + href + ')' : inner;
        }
        default: return inner;   // SPAN(textStyle 容器：font/size/color) 等仅取内容
      }
    }

    // 块级节点 → 写入输出数组（含尾随空行）。depth：列表嵌套深度（缩进 2 空格/层）
    // sink：输出目标数组（默认外层 out；BLOCKQUOTE 逐子块收集时传内部数组）。
    // fmSink：{lines:[]} 可选——正文里的 ```webpz-frontmatter 代码块提升进此（文档级 YAML 头），不再留在正文。
    function block(node, depth, sink, fmSink) {
      var out2 = sink || out;
      var tag = node.nodeName.toUpperCase();
      // 数学块节点作为独立块
      if (tag === 'DIV' && (node.className || '').indexOf('math-display') >= 0) {
        var bl = node.getAttribute('data-latex');
        if (bl) { out2.push('$$' + bl + '$$'); out2.push(''); }
        return;
      }
      switch (tag) {
        case 'H1': case 'H2': case 'H3': case 'H4': case 'H5': case 'H6': {
          var level = parseInt(tag.charAt(1), 10);
          out2.push(Array(level + 1).join('#') + ' ' + inline(node).trim()); out2.push(''); return;
        }
        case 'P': { var t = inline(node).trim(); if (t) { out2.push(t); out2.push(''); } return; }
        case 'BLOCKQUOTE': {
          // 逐子块还原：每个子块（p/ul/嵌套引用…）产出自己的 md 行，再统一加 "> " 前缀。
          // 修复 v1 对整个 blockquote 做 inline() 导致多段引用粘连成一行的 bug；
          // callout 标记 [!type] T 就是首段文本 → 首行 "> [!type] T"，Obsidian 重新解析为 callout。
          var qLines = [];
          for (var qi = 0; qi < node.childNodes.length; qi++) {
            var qc = node.childNodes[qi];
            if (qc.nodeType === 3) {
              var qt = escText(qc.nodeValue.trim());
              if (qt) qLines.push.apply(qLines, qt.split('\n'));
            } else if (qc.nodeType === 1) {
              block(qc, 0, qLines, fmSink);   // 嵌套引用自然产出 "> x"，再被外层加前缀 → "> > x"
            }
          }
          // 去掉子块尾随空行后逐行加前缀（空行输出裸 ">" 保持引用连续）。
          // 先按内嵌 \n 拍平：段落内 <br> 使 inline() 产出含换行的单元素，不拍平则第二行丢 > 前缀、
          // 在 Obsidian 里脱离引用块（callout 首段 Title<br>正文 场景）。
          while (qLines.length && qLines[qLines.length - 1] === '') qLines.pop();
          if (qLines.length) {
            var qFlat = [];
            qLines.forEach(function (ln) { qFlat.push.apply(qFlat, String(ln).split('\n')); });
            qFlat.forEach(function (ln) { out2.push(ln ? '> ' + ln : '>'); });
            out2.push('');
          }
          return;
        }
        case 'PRE': {
          var codeEl = node.querySelector('code');
          var codeText = codeEl ? codeEl.textContent : node.textContent;
          var lang = '';
          // TipTap v3 CodeBlock 语言只经 class="language-X" 往返（无 data-language 属性）；
          // [\w-] 而非 \w：否则 webpz-frontmatter 被截成 webpz
          if (codeEl) lang = codeEl.getAttribute('data-language') || (/language-([\w-]+)/.exec(codeEl.className || '') || [])[1] || '';
          if (lang === 'webpz-frontmatter' && fmSink) {
            // 导入时从文件头剥离的 YAML frontmatter：提升回文档级 YAML 头，不在正文留代码块
            var fmText = String(codeText == null ? '' : codeText).replace(/\n+$/, '');
            if (fmText) fmSink.lines.push.apply(fmSink.lines, fmText.split('\n'));
            return;
          }
          out2.push('```' + lang);
          String(codeText == null ? '' : codeText).replace(/\n$/, '').split('\n').forEach(function (ln) { out2.push(ln); });
          out2.push('```'); out2.push(''); return;
        }
        case 'HR': { out2.push('---'); out2.push(''); return; }
        case 'UL': case 'OL': {
          var ordered = tag === 'OL';
          var items = [];
          for (var k = 0; k < node.children.length; k++) if (node.children[k].nodeName.toUpperCase() === 'LI') items.push(node.children[k]);
          var indent = Array(depth + 1).join('  ');
          items.forEach(function (li, idx) {
            var parts = [], nested = [];
            for (var j = 0; j < li.childNodes.length; j++) {
              var ctag = (li.childNodes[j].nodeName || '').toUpperCase();
              if (ctag === 'UL' || ctag === 'OL') nested.push(li.childNodes[j]); else parts.push(inline(li.childNodes[j]));
            }
            out2.push(indent + (ordered ? (idx + 1) + '. ' : '- ') + parts.join('').trim());
            nested.forEach(function (n) { block(n, depth + 1, out2, fmSink); });
          });
          if (depth === 0) out2.push('');
          return;
        }
        case 'TABLE': {
          // D-26: <table> → GFM pipe-table（原实现无 TD/TH/TR 分支，表格退化连排文本、结构丢失）。
          // 首行（thead/tbody 首个 tr，无论 th/td）作表头行；单元格 inline() 取文本，
          // | 转义为 \|、换行拍平空格（GFM 单行单元格约束）；列数按最宽行补齐。
          var tblRows = [];
          var trs = node.querySelectorAll('tr');
          for (var tRowI = 0; tRowI < trs.length; tRowI++) {
            var cells = trs[tRowI].querySelectorAll('th,td');
            var tRow = [];
            for (var tCellI = 0; tCellI < cells.length; tCellI++) {
              var cellMd = String(inline(cells[tCellI])).trim();
              cellMd = cellMd.split('|').join('\\|').split('\n').join(' ');
              tRow.push(cellMd);
            }
            if (tRow.length) tblRows.push(tRow);
          }
          if (tblRows.length) {
            var tCols = 1;
            for (var tMaxI = 0; tMaxI < tblRows.length; tMaxI++) tCols = Math.max(tCols, tblRows[tMaxI].length);
            var tPad = function (r) {
              var copy = r.slice();
              while (copy.length < tCols) copy.push('');
              return '| ' + copy.join(' | ') + ' |';
            };
            out2.push(tPad(tblRows[0]));
            var tSep = [];
            for (var tSepI = 0; tSepI < tCols; tSepI++) tSep.push('---');
            out2.push('| ' + tSep.join(' | ') + ' |');
            for (var tDataI = 1; tDataI < tblRows.length; tDataI++) out2.push(tPad(tblRows[tDataI]));
            out2.push('');
          }
          return;
        }
        default: {
          // 未知块/容器：含块级子节点则逐子块递归，否则按行内文本输出（通用性兜底）
          var hasBlock = false;
          for (var c = 0; c < node.children.length; c++) {
            if (/^(P|H1|H2|H3|H4|H5|H6|UL|OL|BLOCKQUOTE|PRE|HR|TABLE|DIV)$/.test(node.children[c].nodeName.toUpperCase())) { hasBlock = true; break; }
          }
          if (hasBlock) {
            for (var m = 0; m < node.childNodes.length; m++) {
              var cc = node.childNodes[m];
              if (cc.nodeType === 1) block(cc, depth, out2, fmSink);
              else if (cc.nodeType === 3 && (cc.nodeValue || '').trim()) { out2.push(escText(cc.nodeValue.trim())); out2.push(''); }
            }
          } else {
            var txt = inline(node).trim();
            if (txt) { out2.push(txt); out2.push(''); }
          }
        }
      }
    }

    var body = dom.body || dom.documentElement;
    for (var n = 0; n < body.childNodes.length; n++) {
      var nd = body.childNodes[n];
      if (nd.nodeType === 1) block(nd, 0, null, fmSink);
      else if (nd.nodeType === 3 && (nd.nodeValue || '').trim()) { out.push(escText(nd.nodeValue.trim())); out.push(''); }
    }
    return out.join('\n').replace(/\n{3,}/g, '\n\n').replace(/^\s+|\s+$/g, '') + '\n';
  }

  // 解析文档正文中的图片 → { imageKey → 可用 src }。本地 base64(data) 优先（免签名接口 + 导出自包含，
  // 签名 URL 有时效，过期后 md 里的图片会挂），本地无 data 才签名 URL 兜底，失败跳过（不阻断）。
  async function fetchDocumentImages(doc) {
    var imgMap = {};
    var bodyHtml = (doc && doc.bodyHtml) || '';
    if (!bodyHtml) return imgMap;
    var dom;
    try { dom = new DOMParser().parseFromString('<body>' + bodyHtml + '</body>', 'text/html'); }
    catch (e) { return imgMap; }
    var imgs = Array.prototype.slice.call(dom.querySelectorAll('img'));
    if (imgs.length === 0) return imgMap;
    var pageUrl = (doc && doc.url) || '';
    await Promise.all(imgs.map(function (img) {
      var imageKey = img.getAttribute('data-image-key') || '';
      if (!imageKey) return;   // 无 key：http src 留给转换器直接使用
      return sendMessage('getImageDataByPageAndKey', { pageUrl: pageUrl, imageKey: imageKey }).then(function (rec) {
        if (!rec) return;
        if (rec.data) {
          imgMap[imageKey] = rec.data;
        } else if (rec.cloudUrl) {
          return sendMessage('signAsset', { objectKey: rec.cloudUrl }).then(function (sr) {
            if (sr && sr.signedUrl) imgMap[imageKey] = sr.signedUrl;
          }).catch(function () { /* 签名失败 → 落回原始引用 */ });
        }
      }).catch(function () { /* 该图解析失败，跳过 */ });
    }));
    return imgMap;
  }

  // 将（可能缺协议的）URL 规整为可点击的 Markdown 链接（GFM 自动链接 <...>）。
  // page.url / doc.url 在本扩展中统一按无协议存储（见 urlLink.href 拼接 1442 / 导入规范化 4763），
  // 故缺失协议时补 https://（与既有约定一致），保证导出的 URL 在 Markdown 渲染器中可直接点击打开原页面。
  function mdClickableUrl(rawUrl, schemeHint, port) {
    var u = rawUrl ? String(rawUrl).trim() : '';
    if (!u) return '';
    var href = u;
    // 已带 scheme（http://、https://、mailto: 等）则原样保留；否则按 schemeHint（http 老站点）/https 补全
    if (!/^[a-z][a-z0-9+.\-]*:\/\//i.test(href) && !/^[a-z][a-z0-9+.\-]*:/i.test(href)) {
      var pref = (schemeHint === 'http' || schemeHint === 'https') ? schemeHint : 'https';
      href = pref + '://' + _applyUrlPort(href.replace(/^\/+/, ''), port);
    }
    return '<' + href + '>';
  }

  // 过滤提升回填的原始 frontmatter 行：去掉列首 webpz_sync: 键及其缩进子行。
  // 场景：Obsidian 导入 → 导出（原 frontmatter + webpz_sync 并存）→ 用户再导入该导出文件 →
  // 文件头整个 YAML（含 webpz_sync）被包进 ```webpz-frontmatter 代码块 → 再导出时若不过滤，
  // webpz_sync 块会随循环逐次翻倍。此处保证导出的 frontmatter 永远只有一份 webpz_sync（本次新生成的）。
  function filterWebpzSyncBlock(fmLines) {
    var out = [], skipping = false;
    for (var i = 0; i < fmLines.length; i++) {
      var ln = fmLines[i];
      if (/^webpz_sync:\s*$/.test(ln)) { skipping = true; continue; }
      if (skipping) {
        if (/^\s+\S/.test(ln)) continue;   // 缩进子行：属于 webpz_sync，滤除
        skipping = false;                  // 回到列首非空键：webpz_sync 块结束
      }
      out.push(ln);
    }
    return out;
  }

  // 生成单篇文档的 Markdown（frontmatter + 标题 + 正文转换）。frontmatter 带 doc_id/doc_updated 供增量导出 diff。
  function generateDocumentMarkdown(doc, imgMap, base, docAnnotations, replyMap) {
    var title = (doc && (doc.title || displayPageTitle(doc))) || (doc && doc.docId) || getMessage('docUntitled');
    // 可见链接对 /d/doc- 文档 URL 用真实服务端 base 重写协议（与 openPage 同源）。frontmatter 的
    // doc_url 仍用原始 doc.url（供增量导出 sync 匹配/diff）。
    var visDocUrl = _resolveDocUrlForExport(doc && doc.url, base);
    var sorted = (docAnnotations || []).slice().sort(function (a, b) {
      var ya = parseFloat(a.ANCHOR_Y_RATIO) || 0;
      var yb = parseFloat(b.ANCHOR_Y_RATIO) || 0;
      if (ya !== yb) return ya - yb;
      return (a.CREATE_TIME || '').localeCompare(b.CREATE_TIME || '');
    });
    var lines = [];
    // fmSink：正文中 ```webpz-frontmatter 代码块（导入时从 Obsidian 文件头剥离的 YAML）提升至此，
    // 合并进文档级 frontmatter（原键在前、webpz_sync 块在后）；已存在的列首 webpz_sync: 键及其缩进
    // 子行会被滤除（防「导出→再导入→再导出」循环时 webpz_sync 块翻倍）。
    var fmSink = { lines: [] };
    lines.push('---');
    // —— 原始 frontmatter（Obsidian 导入）：键在前。先转换正文收集 fmSink，再回填（见下方提升合并）。 ——
    lines.push('webpz_sync:');
    lines.push('  kind: document');
    lines.push('  doc_id: ' + escapeYaml((doc && doc.docId) || ''));
    lines.push('  doc_title: ' + escapeYaml(title));
    lines.push('  doc_url: ' + escapeYaml((doc && doc.url) || ''));
    lines.push('  doc_updated: ' + escapeYaml((doc && (doc.updatedAt || doc.lastVisited)) || ''));
    lines.push('  doc_tags: ' + escapeYaml((doc && doc.tags) || ''));
    lines.push('  export_date: ' + escapeYaml(new Date().toISOString()));
    // annotations 列表：供增量导出 diff（文档页上画的标记变化也要触发重导出）
    lines.push('  annotation_count: ' + sorted.length);
    lines.push('  annotations:');
    sorted.forEach(function (a) {
      lines.push('    - id: ' + escapeYaml(a.MARK_INFO_ID));
      lines.push('      type: ' + escapeYaml(getAnnotationType(a)));
      lines.push('      updated: ' + escapeYaml(a.UPDATE_TIME || ''));
    });
    lines.push('---');
    lines.push('');
    lines.push('# ' + title);
    lines.push('');
    lines.push('> ' + getMessage('expMdDoc') + (visDocUrl ? ' · ' + mdClickableUrl(visDocUrl) : ''));
    lines.push('> ' + getMessage('expMdExportedAt', [formatDateForMd(new Date())]));
    lines.push('');
    // 标签：独立行 #tag1 #tag2，与页面标注导出格式完全一致（见 generatePageMarkdown 的 Tags 段）。
    // 必须置于 blockquote 之外、行首即 #tag —— 包在 > 引用块内或加「标签:」前缀，Obsidian/Typora 等
    // 不会识别为可点击标签（用户反馈：自建文档标签无链接行为）。frontmatter 的 doc_tags 仍保留供增量 diff。
    var docTags = (doc && doc.tags) ? String(doc.tags).split(';').map(function (s) { return s.trim(); }).filter(Boolean) : [];
    if (docTags.length) {
      lines.push(docTags.map(function (t) { return '#' + t.replace(/\s+/g, '-'); }).join(' '));
      lines.push('');
    }
    lines.push('---');
    lines.push('');
    lines.push(htmlBodyToMarkdown((doc && doc.bodyHtml) || '', imgMap, fmSink));
    // —— 提升的原始 frontmatter 回填：插入 lines 首个 '---' 之后（webpz_sync: 之前）。 ——
    if (fmSink.lines.length) {
      var origFm = filterWebpzSyncBlock(fmSink.lines);
      if (origFm.length) {
        var spliceIdx = lines.indexOf('---') + 1;   // 首个 ---（frontmatter 开始）之后
        Array.prototype.splice.apply(lines, [spliceIdx, 0].concat(origFm));
      }
    }
    // 文档页上的标记 + 批注 + 回复（此前文档 md 完全丢失这部分；标记画在 /d/doc- 页，WEB_URI == doc.url）
    if (sorted.length > 0) {
      lines.push('');
      lines.push('---');
      lines.push('');
      lines.push('## ' + getMessage('expMdMarksSection'));
      lines.push('');
      sorted.forEach(function (a, idx) {
        var type = getAnnotationType(a);
        var typeInfo = TYPE_MAP[type] || {};
        var typeLabel = typeInfo.label || type;
        lines.push('### ' + (idx + 1) + '. ' + typeLabel);
        lines.push('');
        switch (type) {
          case 'highlight': renderHighlightMd(lines, a); break;
          case 'rect': renderRectMd(lines, a, imgMap); break;
          case 'pageRect': renderPageRectMd(lines, a); break;
          case 'arrow':
          case 'flag': renderArrowFlagMd(lines, a, typeLabel); break;
          case 'freehand': renderFreehandMd(lines, a); break;
          case 'text': renderTextNoteMd(lines, a); break;
          case 'imgAnno': renderImgAnnoMd(lines, a, imgMap); break;
          case 'rectFrame': renderRectFrameMd(lines, a, imgMap); break;
          case 'elementMark': renderElementMarkMd(lines, a); break;
          default: lines.push(''); break;
        }
        if (a.COMMENT_TEXT) {
          lines.push('');
          lines.push(getMessage('expMdComment', [String(a.COMMENT_TEXT).replace(/\n/g, '\n> ')]));
        }
        var dRps = (replyMap || {})[a.MARK_INFO_ID];
        if (dRps && dRps.length > 0) {
          lines.push('');
          lines.push(getMessage('expMdReplies'));
          dRps.forEach(function (r) {
            var who = r.authorName || r.authorId || '';
            var when = r.createdAt ? ' (' + formatDateForMdStr(r.createdAt) + ')' : '';
            lines.push('> ' + who + when + ': ' + String(r.message || '').replace(/\n/g, '\n> '));
          });
        }
        if (a.TAGS) {
          var aTags = a.TAGS.split(';').filter(function (t) { return t.trim(); });
          if (aTags.length > 0) {
            lines.push('');
            lines.push(aTags.map(function (t) { return '#' + t.trim().replace(/\s+/g, '-'); }).join(' '));
          }
        }
        lines.push('');
        lines.push('---');
        lines.push('');
      });
    }
    return lines.join('\n');
  }

  // 取"文档页上的标注"。注意 WEB_URI 存储不带协议（如 127.0.0.1/d/doc-xxx），
  // 而 doc.url 带协议（http://127.0.0.1:8080/d/doc-xxx），URL 直接比对会全部失配——
  // 故按 docId 匹配（与快照按 snapId 匹配同构），URL 相等仅作首个快速通道。
  // 文档 md 的「标记与批注」段与增量导出 doc diff 都依赖它。
  function fetchDocPageAnnotations(allAnnotations, doc) {
    var url = (doc && doc.url) || '';
    var docId = (doc && doc.docId) || '';
    if (!url && !docId) return [];
    var exact = (allAnnotations || []).filter(function (a) { return url && a.WEB_URI === url; });
    if (exact.length > 0) return exact;
    if (!docId) return [];
    return (allAnnotations || []).filter(function (a) {
      return String(a.WEB_URI || '').indexOf('/d/' + docId) >= 0;
    });
  }

  // 自建文档统一导出入口。fmt: 'markdown'(默认) / 'json' / 'html'(回退 exportDocumentAsHtml)。
  async function exportDocument(doc, dirHandle, fmt) {
    // CSV 是标注表格格式，文档导出的语义主体是正文（bodyHtml），二者不匹配 → 显式拒绝
    // （不拦截会掉进下方 markdown 默认分支，产出与所选格式不符的文件）
    if (fmt === 'csv') {
      showToast(getMessage('expCsvKindUnsupported'));
      return;
    }
    // P1-8 分仓：入口物化 body 到 page-like 会话缓存——后续 html/md/json 及图片提取全走它
    //（未同步文档的 body 只在本地 docBodies，不物化会导出空正文）。
    await ensureDocBody(doc);
    if (fmt === 'html') return exportDocumentAsHtml(doc, dirHandle);
    if (fmt === 'json') {
      // 导出原始 documents 记录（含 tags/urlMd5/同步字段），保证可被 restoreFromFile 重新导入。
      // 传入的 doc 多为 page-like（缺 folderId/urlMd5），故按 docId 回取原始记录。
      // 注：这里刻意不脱敏——导入端（SW restoreBackup/restoreBackupChunk）对任何来源的文件
      // 一律复位记录级同步状态（见 _resetRecordSyncState），故文件里带什么同步字段都无影响。
      // 整库 JSON 导出（backupAll）另在 SW 侧全量脱敏；两条通道各自保证，导入端是最终防线。
      // P1-8：记录已不含 bodyHtml——导入端按内联 body 拆分兼容，此处显式补上（否则导入后
      // 未同步文档正文丢失）。
      var rawDoc = doc;
      try {
        if (doc && doc.docId) rawDoc = await sendMessage('getDocument', { docId: doc.docId }) || doc;
      } catch (e) { /* 回退用传入对象 */ }
      rawDoc.bodyHtml = (doc && doc.bodyHtml) || '';
      var exportData = { _meta: { kind: 'document', exportDate: new Date().toISOString() }, document: rawDoc };
      var jsonName = docExportFileName(doc, 'json.gz');
      try { await writeFileToDir(dirHandle, jsonName, await compressBackupObject(exportData)); showToast(getMessage('expExportedTo', [jsonName])); }
      catch (e) { showToast(getMessage('expFailed', [String(e.message)])); throw e; }
      return;
    }
    // markdown（默认）
    var imgMap = {};
    try { imgMap = await fetchDocumentImages(doc); } catch (e) { /* 无图继续 */ }
    // 文档页上的标记 + 回复（「标记与批注」段）
    var dAnnos = [];
    try { dAnnos = fetchDocPageAnnotations(await exportAllAnnotations() || [], doc); } catch (e) { /* ignore */ }
    var dReplyMap = await fetchPageRepliesMap(doc);
    var _expBase = ''; try { _expBase = await getServerBase(); } catch (e) { /* base 缺失则 https:// 兜底 */ }
    var md = generateDocumentMarkdown(doc, imgMap, _expBase, dAnnos, dReplyMap);
    var mdName = docExportFileName(doc, 'md');
    try { await writeFileToDir(dirHandle, mdName, md); showToast(getMessage('expExportedTo', [mdName])); }
    catch (e) { showToast(getMessage('expFailed', [String(e.message)])); throw e; }
  }

  async function exportAll(fmt, dirHandle) {
    if (fmt === 'json') {
      // P1-32: 全量 JSON 导出流式化（NDJSON.gz v8）——分块读 SW、逐块喂压缩管道直写文件，
      // 内存峰值从「整库 JSON」降到单块。失败回退 legacy 整库路径（backupAll）。
      await exportAllJsonStream(dirHandle);
      return;
    }
    var allAnnotations = await exportAllAnnotations();
    // 有文档/快照但无标注时也允许导出（文档/快照走各自键）
    if ((!allAnnotations || allAnnotations.length === 0) && (state.documents || []).length === 0 && (state.snapshots || []).length === 0) {
      showToast(getMessage('expNothing'));
      return;
    }
    // 补全空的 AUTHOR_ID/AUTHOR_NAME → 当前用户身份
    var expIdentity2 = null;
    try { expIdentity2 = await getUserIdentity(); } catch (e) { /* ignore */ }
    var expUid2 = (expIdentity2 && expIdentity2.userId) || (expIdentity2 && expIdentity2.authorId) || '';
    var expUname2 = (expIdentity2 && expIdentity2.authorName) || '';
    for (var i = 0; i < allAnnotations.length; i++) {
      var a = allAnnotations[i];
      if (!a.USER_ID) a.USER_ID = expUid2 || a.AUTHOR_ID || '';
      if (!a.AUTHOR_ID) a.AUTHOR_ID = expUid2 || a.USER_ID || '';
      if (!a.AUTHOR_NAME) a.AUTHOR_NAME = expUname2;
    }

    // CSV/HTML 汇总导出：单文件表格化（json 已在函数开头提前 return 走流式；
    // 复用上方取数/空检查/身份补全，不拉图片/回复/服务端 base）
    if (fmt === 'csv' || fmt === 'html') {
      await exportAllTabular(fmt, dirHandle, allAnnotations);
      return;
    }

    // Markdown 导出（json 已在函数开头提前 return 走流式）
    showExportProgress(getMessage('expExportingAllPages'));
    try {
      var pageMap = {};
      state.pages.forEach(function (p) { pageMap[p.url] = p; });

        var grouped = {};
        allAnnotations.forEach(function (a) {
          var key = a.WEB_URI || 'unknown';
          if (!grouped[key]) grouped[key] = [];
          grouped[key].push(a);
        });

        var pageUrls = Object.keys(grouped);
        var docs = (state.documents || []).slice();
        var snaps = (state.snapshots || []).slice();
        var totalCount = pageUrls.length + docs.length + snaps.length;
        updateExportProgress(0, totalCount);

        // P1-31: 并发池（3）替代无界 Promise.all——此前 N 页 = N 组并发请求瞬间打到服务器
        //（每页再逐图 signAsset + 逐页 replies GET），页数大时自造突发。模式参照
        // CLOUD_BACKFILL_CONCURRENCY 的 drain 写法；结果按原下标写回保持顺序。
        var EXPORT_FETCH_CONCURRENCY = 3;
        var results = new Array(pageUrls.length);
        var _expNext = 0;
        async function _expWorker() {
          while (_expNext < pageUrls.length) {
            var idx = _expNext++;
            var url = pageUrls[idx];
            var anns = grouped[url];
            var urls = collectImageUrls(anns);
            var page = pageMap[url] || { url: url, domain: '', title: '' };
            results[idx] = await Promise.all([
              fetchImageData(url, urls),
              fetchPageRepliesMap(page)
            ]).then(function (rs) {
              return { pageUrl: url, imageMap: rs[0], replyMap: rs[1] };
            });
          }
        }
        var _expWorkers = [];
        for (var w = 0; w < Math.min(EXPORT_FETCH_CONCURRENCY, pageUrls.length); w++) _expWorkers.push(_expWorker());
        await Promise.all(_expWorkers);
        var allImageMaps = {};
        var allReplyMaps = {};
        results.forEach(function (r) { allImageMaps[r.pageUrl] = r.imageMap; allReplyMaps[r.pageUrl] = r.replyMap; });

        // 服务端 base（一次性获取，供文档 URL 协议重写复用）
        var _expBase = ''; try { _expBase = await getServerBase(); } catch (e) { /* base 缺失则 https:// 兜底 */ }
        // Write per-page markdown files
        var fileCount = 0;
        for (var i = 0; i < pageUrls.length; i++) {
          var url = pageUrls[i];
          var page = pageMap[url] || { url: url, domain: '', title: '' };
          var anns = grouped[url];
          var imageMap = allImageMaps[url] || {};
          var md = generatePageMarkdown(anns, page, imageMap, _expBase, allReplyMaps[url] || {});
          var fileName = makeExportFilename(page, 'md');
          var folderPath = getFolderExportPath(url);
          var targetDir = folderPath
            ? await getOrCreateSubDirHandle(dirHandle, folderPath.split('/'))
            : dirHandle;
          await writeFileToDir(targetDir, fileName, md);
          fileCount++;
          updateExportProgress(fileCount, totalCount);
        }

        // 自建文档：按目录归属写入对应 .md（与页面同样按 folder 归档）
        for (var di = 0; di < docs.length; di++) {
          var ddoc = docs[di];
          await ensureDocBody(ddoc);   // P1-8 分仓：正文懒加载
          var dImgMap = {};
          try { dImgMap = await fetchDocumentImages(ddoc); } catch (e) { /* 无图继续 */ }
          var dAnnos2 = fetchDocPageAnnotations(allAnnotations, ddoc);
          var dReplyMap2 = await fetchPageRepliesMap(ddoc);
          var dMd = generateDocumentMarkdown(ddoc, dImgMap, _expBase, dAnnos2, dReplyMap2);
          var dFolder = getFolderExportPath(ddoc.url);
          var dDir = dFolder ? await getOrCreateSubDirHandle(dirHandle, dFolder.split('/')) : dirHandle;
          await writeFileToDir(dDir, docExportFileName(ddoc, 'md'), dMd);
          fileCount++;
          updateExportProgress(fileCount, totalCount);
        }

        // 网页快照：每个快照导出为独立 .md（快照完整内容 + 标记 + 批注）
        // 快照批注按 WEB_URI 含 '/snap/{snapId}' 过滤（批注绑定在快照 webUri）
        for (var si = 0; si < snaps.length; si++) {
          var ssnap = snaps[si];
          await ensureSnapBody(ssnap);   // P1-8 分仓：正文懒加载（跨设备快照无本地 body，导出空体）
          var sAnnos = allAnnotations.filter(function (a) {
            return String(a.WEB_URI || '').indexOf('/snap/' + (ssnap && ssnap.snapId)) >= 0;
          });
          var sImgMap = await fetchImageData((ssnap && ssnap.url) || '', collectImageUrls(sAnnos));
          var sMd = generateSnapshotMarkdown(ssnap, sAnnos, sImgMap);
          await writeFileToDir(dirHandle, snapExportBaseName(ssnap) + '.md', sMd);
          fileCount++;
          updateExportProgress(fileCount, totalCount);
        }

        var _docN = docs.length;
        var _snapN = snaps.length;
        showToast(getMessage('expFolderDone', [String(pageUrls.length), String(_docN), String(_snapN)]));
      } finally {
        hideExportProgress();
      }
  }

  // ---- P1-32: 全量 JSON 导出（流式 NDJSON.gz v8）----
  // 分块读 SW（backupChunk）→ pull() 型 ReadableStream 逐块喂 CompressionStream → pipeTo 直写
  // 文件句柄。⚠️ 必须 pull() 型：start() 一口气 enqueue 无背压，全量数据会缓冲在流内部队列，
  // 内存峰值与整库 JSON 无异；pull 消费驱动（default highWaterMark=1），压缩慢时自动反压。
  // store 顺序保证 annotations 先于 localThumbnails（thumbIdRemap 依赖）。
  // 失败（老 SW 无 backupChunk op / 流管道异常）→ abort 落盘文件 + 回退 legacy 整库路径。
  async function exportAllJsonStream(dirHandle) {
    var STORES = ['folders', 'pages', 'annotations', 'tags', 'imageData', 'localThumbnails', 'documents', 'snapshots', 'docBodies', 'snapBodies'];
    var LIMITS = { imageData: 20, localThumbnails: 20, docBodies: 10, snapBodies: 10 };   // 携带 base64/body 大字段的 store 用小批
    var expIdentity2 = null;
    try { expIdentity2 = await getUserIdentity(); } catch (e) { /* ignore */ }
    var expUid2 = (expIdentity2 && expIdentity2.userId) || (expIdentity2 && expIdentity2.authorId) || '';
    var expUname2 = (expIdentity2 && expIdentity2.authorName) || '';

    showExportProgress(chrome.i18n.getMessage('exportAllTitle') || '正在导出全部数据');
    var writable = null;
    var fileName = '';
    try {
      // 守卫：全 store 探总量（limit=1 的轻量块），全空不导出（镜像旧「没有可导出的内容」）
      // P0-C：导出会话 id——SW 侧同一 store 只 getAllKeys 一次并缓存键表，分块从缓存切片
      //（此前每块全量 getAllKeys，1M 标注 5001 块 = O(n²/chunk) 全扫，导出侧唯一二次方热点）。
      // 会话内写库由 restoreChunk/restoreBackup 顺带失效缓存兜底。
      var expSession = 'exp-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
      var totals = {};
      var grand = 0;
      for (var s0 = 0; s0 < STORES.length; s0++) {
        var c0 = await sendMessage('backupChunk', { store: STORES[s0], offset: 0, limit: 1, session: expSession });
        totals[STORES[s0]] = (c0 && c0.total) || 0;
        grand += totals[STORES[s0]];
      }
      if (grand === 0) {
        showToast(getMessage('expNothing'));
        return;
      }

      fileName = 'sagitnote-annotations-all-' + new Date().toISOString().slice(0, 10) + '.ndjson.gz';
      var fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
      writable = await fileHandle.createWritable();   // FileSystemWritableFileStream 是 WritableStream

      var si = 0;            // 当前 store 下标
      var offset = 0;        // 当前 store 内偏移
      var doneCount = 0;
      var metaSent = false;
      var src = new ReadableStream({
        pull: async function (controller) {
          try {
            if (!metaSent) {
              metaSent = true;
              controller.enqueue(strToUtf8Bytes(JSON.stringify({
                _meta: { version: 8, format: 'ndjson', exportDate: new Date().toISOString() }
              }) + '\n'));
              return;
            }
            while (si < STORES.length) {
              var store = STORES[si];
              if (offset >= totals[store]) { si++; offset = 0; continue; }   // 本 store 完成
              var limit = LIMITS[store] || 200;
              var chunk = await sendMessage('backupChunk', { store: store, offset: offset, limit: limit, session: expSession });
              var records = (chunk && chunk.records) || [];
              if (records.length === 0) { si++; offset = 0; continue; }
              var lines = [];
              for (var r = 0; r < records.length; r++) {
                var rec = records[r];
                if (store === 'annotations') {
                  // AUTHOR/USER 回填与 legacy 导出一致
                  if (!rec.USER_ID) rec.USER_ID = expUid2 || rec.AUTHOR_ID || '';
                  if (!rec.AUTHOR_ID) rec.AUTHOR_ID = expUid2 || rec.USER_ID || '';
                  if (!rec.AUTHOR_NAME) rec.AUTHOR_NAME = expUname2;
                }
                lines.push(JSON.stringify({ store: store, record: rec }));
              }
              controller.enqueue(strToUtf8Bytes(lines.join('\n') + '\n'));
              offset += records.length;
              doneCount += records.length;
              updateExportProgress(doneCount, grand);
              return;   // 一次 pull 只喂一块，让消费端驱动节奏（反压）
            }
            controller.close();
          } catch (e) {
            controller.error(e);
          }
        }
      });
      var cs = new CompressionStream('gzip');
      // ⚠️ 不用 cs.writable.getWriter()（Chrome-150 挂起 bug，见 gzipBytes 注释）——pipeTo 驱动写入
      await src.pipeThrough(cs).pipeTo(writable);
      writable = null;   // pipeTo 正常结束已 close
      showToast(getMessage('expExportedTo', [fileName]));
    } catch (e) {
      console.warn('[exportAll] streaming failed, fallback to legacy:', e && e.message);
      try { if (writable) await writable.abort(); } catch (e2) { /* ignore */ }
      try { if (fileName) await dirHandle.removeEntry(fileName); } catch (e3) { /* ignore */ }
      await exportAllJsonLegacy(dirHandle);
    } finally {
      hideExportProgress();
    }
  }

  // P1-32: legacy 整库导出（流式路径的回退；也是旧 .json.gz 格式的唯一生产者）
  async function exportAllJsonLegacy(dirHandle) {
    var allAnnotations = await exportAllAnnotations();
    if ((!allAnnotations || allAnnotations.length === 0) && (state.documents || []).length === 0 && (state.snapshots || []).length === 0) {
      showToast(getMessage('expNothing'));
      return;
    }
    var expIdentity2 = null;
    try { expIdentity2 = await getUserIdentity(); } catch (e) { /* ignore */ }
    var expUid2 = (expIdentity2 && expIdentity2.userId) || (expIdentity2 && expIdentity2.authorId) || '';
    var expUname2 = (expIdentity2 && expIdentity2.authorName) || '';
    for (var i = 0; i < allAnnotations.length; i++) {
      var a = allAnnotations[i];
      if (!a.USER_ID) a.USER_ID = expUid2 || a.AUTHOR_ID || '';
      if (!a.AUTHOR_ID) a.AUTHOR_ID = expUid2 || a.USER_ID || '';
      if (!a.AUTHOR_NAME) a.AUTHOR_NAME = expUname2;
    }
    // 优先复用 SW backupAll：它额外包含 imageData（本地图 base64）与 tags store，
    // 手工拼装曾把这两项写死为 [] 导致全量备份丢图片/标签。
    var exportData = null;
    try {
      exportData = await sendMessage('backupAll', {});
      if (exportData && exportData.annotations) {
        for (var bi = 0; bi < exportData.annotations.length; bi++) {
          var ba = exportData.annotations[bi];
          if (!ba.USER_ID) ba.USER_ID = expUid2 || ba.AUTHOR_ID || '';
          if (!ba.AUTHOR_ID) ba.AUTHOR_ID = expUid2 || ba.USER_ID || '';
          if (!ba.AUTHOR_NAME) ba.AUTHOR_NAME = expUname2;
        }
      } else {
        exportData = null;
      }
    } catch (e) { exportData = null; }
    if (!exportData) {
      // 不再回退到「手工拼装」：该路径既丢 imageData/tags（备份不完整），又不做同步字段
      // 脱敏——pages/folders/documents/snapshots 会带着 SYNC_EXHAUSTED/SYNC_LAST_ERROR
      // 落进备份文件，再导入到别的账号就变成 pending+exhausted 死状态（既不上传、又不给
      // 重试按钮，且显示上一个账号的限额报错）。backupAll 不可用属扩展自身异常，
      // 宁可明确失败让用户重试，也不产出一份"看起来成功"的脏备份。
      console.error('[exportAll] backupAll unavailable — aborting legacy export');
      showToast(getMessage('expFailed', [getMessage('expBackupUnavailable')]));
      return;
    }
    var gz = await compressBackupObject(exportData);
    var dateStr = new Date().toISOString().slice(0, 10);
    var fileName = 'sagitnote-annotations-all-' + dateStr + '.json.gz';
    await writeFileToDir(dirHandle, fileName, gz);
    showToast(getMessage('expExportedTo', [fileName]));
  }

  // ---- 备份 gzip 压缩/解压（原生 CompressionStream，零依赖）----
  // 备份 JSON 主要用于本地存档/恢复、基本不直接查看，故统一 gzip 压缩成 .json.gz；
  // 导入端按 gzip 魔数 0x1f8b 自动识别，同时兼容旧明文 .json（见 parseBackupFile）。
  // 注：解压后内容仍是当前 _meta.version:6 结构，压缩只动传输层，不 bump 版本号。
  function strToUtf8Bytes(str) { return new TextEncoder().encode(str); }
  function utf8BytesToStr(bytes) { return new TextDecoder().decode(bytes); }
  function isGzipBytes(bytes) { return !!(bytes && bytes.length >= 2 && bytes[0] === 0x1f && bytes[1] === 0x8b); }

  async function gzipBytes(bytes) {
    // ⚠️ 必须用 pipeThrough + Response 读出全部字节，不能用 writable.getWriter().write() 模式：
    // 实测在 Chrome 150 等版本下 CompressionStream 的 writer.write() 永不 resolve（不报错、不返回），
    // 导致 compressBackupObject 卡死 → 导出 JSON 全程静默无反应（无 toast、无文件、无异常）。
    // pipeThrough + Response 是 MDN 推荐的稳健写法，已在真实 ~140KB 数据上验证（往返一致、魔数 0x1f8b）。
    var cs = new CompressionStream('gzip');
    var compressed = new Response(bytes).body.pipeThrough(cs);
    var buf = await new Response(compressed).arrayBuffer();
    return new Uint8Array(buf);
  }

  async function gunzipBytes(bytes) {
    // 同上：避免 writer.write() 挂起，改用 pipeThrough + Response（导入 .json.gz 解压走这里）。
    var ds = new DecompressionStream('gzip');
    var decompressed = new Response(bytes).body.pipeThrough(ds);
    var buf = await new Response(decompressed).arrayBuffer();
    return new Uint8Array(buf);
  }

  // 把备份对象序列化为 gzip 字节（Uint8Array）；调用方直接写入 .json.gz。
  async function compressBackupObject(obj) { return gzipBytes(strToUtf8Bytes(JSON.stringify(obj))); }

  // 读取备份文件（.json.gz 或旧明文 .json），返回解析后的对象；解压/解析失败抛错由调用方捕获。
  async function parseBackupFile(file) {
    var bytes = new Uint8Array(await file.arrayBuffer());
    if (isGzipBytes(bytes)) bytes = await gunzipBytes(bytes);
    return JSON.parse(utf8BytesToStr(bytes));
  }

  async function writeFileToDir(dirHandle, fileName, content) {
    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        await dirHandle.requestPermission({ mode: 'readwrite' });
        var fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
        var writable = await fileHandle.createWritable();
        await writable.write(content);
        await writable.close();
        return;
      } catch (e) {
        if (e.name === 'InvalidStateError' && attempt < 2) continue;
        throw e;
      }
    }
  }

  function makeExportFilename(page, ext) {
    var title = (displayPageTitle(page) || '').trim();
    var domain = (page.domain || '').trim();
    var name;
    if (title && domain) {
      name = title + '（' + domain + '）';
    } else if (title) {
      name = title;
    } else if (domain) {
      name = domain;
    } else {
      name = 'export';
    }
    return sanitizeFilename(name) + '.' + ext;
  }

  function downloadFile(content, filename, mimeType) {
    var blob = new Blob([content], { type: mimeType });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(getMessage('expSuccess'));
  }

  // ---- CSV / HTML 表格化导出（纯本地数据聚合，不拉图片/回复/服务端 base）----
  // sections 元素形状：{ page: {url, domain, title, CUSTOM_TITLE?}, annotations: [...] }。
  // 单页导出传 1 个 section，全量汇总传 N 个（共用生成器，行级渲染同构）。

  // 无协议 URL 补全（与 mdClickableUrl 同约定：page.url 统一按无协议存储），但不包 GFM 尖括号。
  function ensureUrlScheme(rawUrl) {
    var u = rawUrl ? String(rawUrl).trim() : '';
    if (!u) return '';
    if (/^[a-z][a-z0-9+.\-]*:\/\//i.test(u) || /^[a-z][a-z0-9+.\-]*:/i.test(u)) return u;
    return 'https://' + u.replace(/^\/+/, '');
  }

  // 按页面位置排序（ANCHOR_Y_RATIO 升序 + CREATE_TIME 字典序，comparator 与 generatePageMarkdown 一致）。
  // 独立实现、不重构 Markdown 内联版，避免触碰既有路径。
  function sortAnnotationsByPosition(annotations) {
    return (annotations || []).slice().sort(function (a, b) {
      var ya = parseFloat(a.ANCHOR_Y_RATIO) || 0;
      var yb = parseFloat(b.ANCHOR_Y_RATIO) || 0;
      if (ya !== yb) return ya - yb;
      return (a.CREATE_TIME || '').localeCompare(b.CREATE_TIME || '');
    });
  }

  // CONTEXT 按类型分派语义（部分类型的 CONTEXT 不是可读文本，绝不直接进 CSV/HTML）：
  //   imgAnno 的 CONTEXT 是缩略图 dataURL（或 img:url）→ 优先取 END_TAG_NAME 里存的图片 URL；
  //   freehand 是压缩路径、pageRect 是区域截图 → 本地化占位符；rect → 锚点图 URL。
  //   rectFrame（新）/freehand（新）：创建时提取的区域文本优先（CONTEXT / TEXT_SNAPSHOT），
  //   提取不到再走原有回退。
  function annotationContextText(a) {
    var type = getAnnotationType(a);
    var ctx = a.CONTEXT || '';
    if (type === 'freehand') return a.TEXT_SNAPSHOT || getMessage('expCtxFreehand');
    if (type === 'pageRect') return getMessage('expCtxScreenshot');
    if (type === 'imgAnno') {
      if (/^img:/i.test(ctx)) return ctx.slice(4);
      if (/^data:/i.test(ctx)) return a.END_TAG_NAME || getMessage('expCtxImage');
      return ctx || a.END_TAG_NAME || getMessage('expCtxImage');
    }
    if (type === 'rect') return a.END_TAG_NAME || getMessage('expCtxImage');
    if (type === 'rectFrame') return ctx || a.END_TAG_NAME || getMessage('expCtxImage');
    // highlight / text / elementMark / arrow / flag：CONTEXT 即原文（arrow/flag 通常为空串）
    return ctx;
  }

  // CSV 单元格：超长截断 → 公式注入防护 → RFC4180 转义。
  // 截断防 dataURL 意外漏入与 Excel 32767 上限；= + - @ / Tab / CR 开头前置 ' 防 Excel 公式执行；
  // 含逗号/引号/换行整体包裹。数字列（Width/Position）由调用方直接拼、不过此函数。
  function csvCell(value, maxLen) {
    var s = (value == null) ? '' : String(value);
    var limit = maxLen || 2000;
    if (s.length > limit) s = s.slice(0, limit) + '…';
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
    if (/[",\r\n]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  // 生成标注 CSV（UTF-8 BOM 前置——writeFileToDir 直写 string，BOM 保留，Excel 打开中文不乱码）。
  // 表头用英文标准词（数据可移植性，与列语义一一对应）；Type/Style 标签沿用界面本地化（与 Markdown 导出一致）。
  function generateAnnotationsCsv(sections) {
    var rows = ['\uFEFFID,Page Title,Domain,URL,Type,Style,Color,Width,Context,Note,Tags,Mode,Visible,Position,Created,Updated,Author'];
    (sections || []).forEach(function (sec) {
      var page = sec.page || {};
      var pageTitle = displayPageTitle(page);
      var url = ensureUrlScheme(page.url);
      sortAnnotationsByPosition(sec.annotations || []).forEach(function (a) {
        rows.push([
          csvCell(a.MARK_INFO_ID),
          csvCell(pageTitle),
          csvCell(page.domain || ''),
          csvCell(url),
          csvCell(getAnnotationLabel(getAnnotationType(a))),
          csvCell(a.TITLE ? getStyleLabel(a.TITLE) : ''),
          csvCell(a.MARK_COLOR || ''),
          (a.MARK_WIDTH || ''),
          csvCell(annotationContextText(a)),
          csvCell(a.COMMENT_TEXT || ''),
          csvCell(a.TAGS || ''),
          csvCell(a.ANNOTATION_MODE || ''),
          csvCell(a.SELECT_STATE !== false ? 'yes' : 'no'),
          (a.ANCHOR_Y_RATIO || ''),
          csvCell(a.CREATE_TIME || ''),
          csvCell(a.UPDATE_TIME || ''),
          csvCell(a.AUTHOR_NAME || '')
        ].join(','));
      });
    });
    return rows.join('\r\n');
  }

  // escapeHtml 只转 & < > 不转引号 → 进 HTML 属性的值必须先过白名单校验（防属性逃逸/注入）。
  function safeColorAttr(color) {
    return /^#[0-9a-f]{3,8}$/i.test(String(color || '')) ? color : '';
  }
  function safeHttpUrl(rawUrl) {
    var u = ensureUrlScheme(rawUrl);
    return /^https?:\/\//i.test(u) ? u : '';
  }

  // 生成自包含 HTML 汇总报告（内联 CSS、无外部依赖、离线可读）。
  // 全部用户文本经 escapeHtml 进文本节点；颜色/URL 仅白名单校验通过才进属性。
  function generateAnnotationsHtmlReport(sections) {
    sections = sections || [];
    var totalAnnos = 0;
    var pageSecsHtml = sections.map(function (sec) {
      var page = sec.page || {};
      var annos = sortAnnotationsByPosition(sec.annotations || []);
      totalAnnos += annos.length;
      var titleHtml = escapeHtml(displayPageTitle(page) || getMessage('expMdUntitledPage'));
      var href = safeHttpUrl(page.url);
      var urlHtml = href
        ? '<a href="' + href + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(ensureUrlScheme(page.url)) + '</a>'
        : '<span>' + escapeHtml(ensureUrlScheme(page.url)) + '</span>';
      var cards = annos.map(function (a) {
        var type = getAnnotationType(a);
        var color = safeColorAttr(a.MARK_COLOR);
        var styleLabel = a.TITLE ? getStyleLabel(a.TITLE) : '';
        var ctx = annotationContextText(a);
        if (ctx.length > 5000) ctx = ctx.slice(0, 5000) + '…';
        var tags = String(a.TAGS || '').split(';')
          .map(function (t) { return t.trim(); })
          .filter(function (t) { return t; })
          .map(function (t) { return '<span class="wpzl-tag">' + escapeHtml(t) + '</span>'; })
          .join('');
        var h = [];
        h.push('<article class="wpzl-anno">');
        h.push('<div class="wpzl-anno-head">');
        h.push('<span class="wpzl-badge">' + escapeHtml(getAnnotationLabel(type)) + '</span>');
        if (styleLabel) h.push('<span class="wpzl-style">' + escapeHtml(styleLabel) + '</span>');
        if (color) h.push('<span class="wpzl-swatch" style="background:' + color + '"></span>');
        if (a.AUTHOR_NAME) h.push('<span class="wpzl-author">' + escapeHtml(a.AUTHOR_NAME) + '</span>');
        h.push('<span class="wpzl-time">' + escapeHtml(a.CREATE_TIME || '') + (a.UPDATE_TIME ? ' · ' + escapeHtml(a.UPDATE_TIME) : '') + '</span>');
        h.push('</div>');
        if (ctx) h.push('<blockquote class="wpzl-ctx">' + escapeHtml(ctx) + '</blockquote>');
        if (a.COMMENT_TEXT) {
          h.push('<div class="wpzl-note"><span class="wpzl-note-label">' + escapeHtml(getMessage('expHtmlComment')) + '</span>'
            + escapeHtml(a.COMMENT_TEXT) + '</div>');
        }
        if (tags) h.push('<div class="wpzl-tags">' + tags + '</div>');
        h.push('</article>');
        return h.join('');
      }).join('');
      return '<section class="wpzl-page">'
        + '<h2>' + titleHtml + '</h2>'
        + '<div class="wpzl-page-meta"><span class="wpzl-domain">' + escapeHtml(page.domain || '') + '</span>'
        + urlHtml
        + '<span class="wpzl-count">' + escapeHtml(getMessage('expHtmlAnnotationsCount', [String(annos.length)])) + '</span></div>'
        + (cards || '')
        + '</section>';
    }).join('');
    if (!totalAnnos) {
      pageSecsHtml = '<p class="wpzl-empty">' + escapeHtml(getMessage('expNothing')) + '</p>';
    }
    var exportedAt = new Date().toISOString().slice(0, 19).replace('T', ' ');
    return '<!doctype html>\n<html lang="' + (document.documentElement.lang || 'zh-CN') + '">\n'
      + '<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
      + '<title>' + escapeHtml(getMessage('expHtmlReportTitle')) + '</title>\n'
      + '<style>\n'
      + 'body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,"PingFang SC","Microsoft YaHei",sans-serif;'
      + 'max-width:860px;margin:0 auto;padding:24px 16px;color:#1f2328;background:#fff;line-height:1.6}\n'
      + '.wpzl-report-hd h1{font-size:22px;margin:0 0 8px}\n'
      + '.wpzl-stats{display:flex;gap:16px;flex-wrap:wrap;color:#57606a;font-size:13px;margin-bottom:24px;'
      + 'border-bottom:1px solid #d0d7de;padding-bottom:12px}\n'
      + '.wpzl-page{margin-bottom:32px}\n'
      + '.wpzl-page h2{font-size:17px;margin:0 0 6px}\n'
      + '.wpzl-page-meta{display:flex;gap:12px;flex-wrap:wrap;font-size:13px;color:#57606a;margin-bottom:12px}\n'
      + '.wpzl-page-meta a{color:#0969da;text-decoration:none;word-break:break-all}\n'
      + '.wpzl-count{margin-left:auto}\n'
      + '.wpzl-anno{border:1px solid #d0d7de;border-radius:8px;padding:12px 14px;margin-bottom:10px}\n'
      + '.wpzl-anno-head{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:12px;color:#57606a}\n'
      + '.wpzl-badge{background:#ddf4ff;color:#0969da;border-radius:10px;padding:1px 10px;font-weight:600}\n'
      + '.wpzl-swatch{display:inline-block;width:12px;height:12px;border-radius:3px;border:1px solid rgba(0,0,0,.15)}\n'
      + '.wpzl-author{font-weight:500;color:#1f2328}\n'
      + '.wpzl-time{margin-left:auto}\n'
      + '.wpzl-ctx{margin:8px 0 0;padding:6px 12px;border-left:3px solid #0969da;background:#f6f8fa;'
      + 'border-radius:0 6px 6px 0;white-space:pre-wrap;word-break:break-word}\n'
      + '.wpzl-note{margin-top:8px;white-space:pre-wrap;word-break:break-word}\n'
      + '.wpzl-note-label{font-size:12px;color:#57606a;margin-right:8px}\n'
      + '.wpzl-tags{margin-top:8px;display:flex;gap:6px;flex-wrap:wrap}\n'
      + '.wpzl-tag{font-size:12px;background:#f0fff4;color:#116329;border:1px solid #aff5b4;'
      + 'border-radius:10px;padding:0 8px}\n'
      + '.wpzl-empty{color:#57606a}\n'
      + '</style></head>\n<body>\n'
      + '<header class="wpzl-report-hd"><h1>' + escapeHtml(getMessage('expHtmlReportTitle')) + '</h1>'
      + '<div class="wpzl-stats">'
      + '<span>' + escapeHtml(getMessage('expHtmlStatExported')) + ': ' + exportedAt + '</span>'
      + '<span>' + escapeHtml(getMessage('expHtmlStatPages')) + ': ' + sections.length + '</span>'
      + '<span>' + escapeHtml(getMessage('expHtmlStatAnnotations')) + ': ' + totalAnnos + '</span>'
      + '</div></header>\n'
      + pageSecsHtml
      + '\n</body>\n</html>';
  }

  // 全量 CSV/HTML 汇总导出：按 WEB_URI 分组 → sections → 单文件写所选目录根。
  // 与 Markdown 全量（逐页多文件）不同：单文件聚合；文档/快照本体不导（仅其页面标注以分组形式呈现，
  // 标题富化回退查 documents/snapshots）；无网络请求，进度遮罩仅防大库拼串期间的空窗。
  async function exportAllTabular(fmt, dirHandle, allAnnotations) {
    if (!allAnnotations || allAnnotations.length === 0) {
      showToast(getMessage('expNothing'));
      return;
    }
    showExportProgress(getMessage('expExportingAllPages'));
    try {
      var grouped = {};
      allAnnotations.forEach(function (a) {
        var key = a.WEB_URI || 'unknown';
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push(a);
      });
      var pageMap = {};
      state.pages.forEach(function (p) { pageMap[p.url] = p; });
      // pageMap miss 的 WEB_URI（文档页 /d/doc-*、快照页 /snap/*）回退查 documents/snapshots。
      // 标注 WEB_URI 无协议存储、doc/snap.url 可能带协议 → 键两侧都剥协议再比对。
      var kindLookup = {};
      var normKey = function (u) { return String(u || '').replace(/^https?:\/\//i, ''); };
      (state.documents || []).forEach(function (d) {
        kindLookup[normKey(d.url)] = { url: d.url, domain: d.domain || '', title: d.title || '' };
      });
      (state.snapshots || []).forEach(function (s) {
        kindLookup[normKey(s.url)] = { url: s.url, domain: s.domain || '', title: s.title || '' };
      });
      var sections = Object.keys(grouped).map(function (url) {
        var page = pageMap[url] || kindLookup[normKey(url)] || { url: url, domain: '', title: '' };
        return { page: page, annotations: grouped[url] };
      });
      // 按页面标题排序，报告/表格的页面顺序稳定可预期
      sections.sort(function (x, y) {
        return displayPageTitle(x.page).localeCompare(displayPageTitle(y.page));
      });
      var content = fmt === 'csv' ? generateAnnotationsCsv(sections) : generateAnnotationsHtmlReport(sections);
      var fileName = 'sagitnote-annotations-all-' + new Date().toISOString().slice(0, 10) + (fmt === 'csv' ? '.csv' : '.html');
      await writeFileToDir(dirHandle, fileName, content);
      showToast(getMessage('expExportedTo', [fileName]));
    } finally {
      hideExportProgress();
    }
  }

  // ---- Markdown generation ----

  function sanitizeFilename(str) {
    return (str || 'export').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/\s+/g, '-').substring(0, 80);
  }

  function escapeYaml(str) {
    if (!str) return '""';
    str = String(str);
    if (str.indexOf('"') >= 0) str = str.replace(/"/g, '\\"');
    if (str.indexOf(':') >= 0 || str.indexOf('#') >= 0 || str.indexOf('\n') >= 0 ||
        str.indexOf("'") >= 0 || str.indexOf('{') >= 0 || str.indexOf('}') >= 0 ||
        str.indexOf('[') >= 0 || str.indexOf(']') >= 0 || str.indexOf(',') >= 0 ||
        str.indexOf('&') >= 0 || str.indexOf('*') >= 0 || str.indexOf('!') >= 0 ||
        str.indexOf('|') >= 0 || str.indexOf('>') >= 0 || str.indexOf('%') >= 0 ||
        str.indexOf('@') >= 0 || str.indexOf('`') >= 0) {
      return '"' + str + '"';
    }
    return '"' + str + '"';
  }

  function collectImageUrls(annotations) {
    var urls = [];
    annotations.forEach(function (a) {
      var ex = a.END_XPATH || '';
      // Image rect annotations store the image URL in END_TAG_NAME
      if ((ex === '$pic' || ex === '$imgAnno' || ex === '$rectFrame') && a.END_TAG_NAME && !isVideoUrl(a.END_TAG_NAME)) {
        if (urls.indexOf(a.END_TAG_NAME) < 0) urls.push(a.END_TAG_NAME);
      }
      // imgAnno CONTEXT may contain 'img:url' or data URL
      if (ex === '$imgAnno' && a.CONTEXT && a.CONTEXT.indexOf('img:') === 0) {
        var imgUrl = a.CONTEXT.substring(4);
        if (imgUrl && urls.indexOf(imgUrl) < 0) urls.push(imgUrl);
      }
    });
    return urls;
  }

  function fetchImageData(pageUrl, imageUrls) {
    if (!imageUrls || imageUrls.length === 0) return Promise.resolve({});
    return sendMessage('getImageDataBatch', { pageUrl: pageUrl, imageUrls: imageUrls }).then(function (results) {
      var map = {};
      var signTasks = [];
      if (results) {
        for (var key in results) {
          var rec = results[key];
          if (!rec) continue;
          if (rec.data) {
            // 本地有 base64 → 直接内嵌
            map[key] = rec.data;
          } else if (rec.cloudUrl) {
            // 本地无 data 但已上云（END_TAG_NAME 常已是 objectKey）→ 签名 URL 兜底，
            // 比在 Markdown 里输出不可打开的裸 objectKey 可用（时效签名，胜于完全失效）。
            // IIFE 固定 key：var 在循环中会被后续迭代改写，异步回调里会取错键。
            (function (k, cloudUrl) {
              signTasks.push(sendMessage('signAsset', { objectKey: cloudUrl }).then(function (sr) {
                if (sr && sr.signedUrl) map[k] = sr.signedUrl;
              }).catch(function () { /* 签名失败 → 落回原始引用 */ }));
            })(key, rec.cloudUrl);
          }
        }
      }
      return Promise.all(signTasks).then(function () { return map; });
    }).catch(function () { return {}; });
  }

  // 拉取本页"协作回复"并按 markId 分组（markId == MARK_INFO_ID）。
  // 回复存服务端（mark_replies，share 作用域），SW 消息 wpzl-list-page-replies →
  // GET /api/v1/shares/page-replies?urlMd5= 自动聚合本页全部分享的回复。
  // 未登录/无分享/接口失败 → 返回 {}（导出不因回复缺失而中断）。
  function fetchPageRepliesMap(page) {
    if (!page || !page.url) return Promise.resolve({});
    // pages 记录的 url 键与 WEB_URI 同构（hostname+path，不带协议/端口）；文档/快照实体的 url 带
    // 协议（http://host:port/...），直接查 pages 会 miss → 规整成同构形式再查一次。
    var candidates = [page.url];
    try {
      var u = new URL(page.url);
      var norm = u.hostname + u.pathname + u.search;
      if (norm && candidates.indexOf(norm) < 0) candidates.push(norm);
    } catch (e) { /* 非 URL 形式（已规范化的 webUri）→ 无回退 */ }
    return candidates.reduce(function (chain, url) {
      return chain.then(function (urlMd5) {
        if (urlMd5) return urlMd5;
        return sendMessage('getPageUrlMd5', { url: url }).catch(function () { return null; });
      });
    }, Promise.resolve(null)).then(function (urlMd5) {
      if (!urlMd5) return [];
      // ⚠️ 回复是顶层 request.type 消息（SW onMessage 直处理），不能走 sendMessage 的
      // db-operation 包装——包装后落入未知 operation 会静默返回空。用 sendDirectMessage 直发。
      return sendDirectMessage('wpzl-list-page-replies', { urlMd5: urlMd5 });
    }).then(function (rows) {
      var map = {};
      (rows || []).forEach(function (r) {
        if (!r || !r.markId) return;
        if (!map[r.markId]) map[r.markId] = [];
        map[r.markId].push(r);
      });
      return map;
    }).catch(function () { return {}; });
  }

  function getStyleLabel(style) {
    switch (style) {
      case 'bjs': return getMessage('styleFill');
      case 'bk': return getMessage('styleBorder');
      case 'xhx': return getMessage('styleUnderline');
      case 'blx': return getMessage('styleWavy');
      case 'zjys': return getMessage('expStyleTextColor');
      default: return style || getMessage('styleDefault');
    }
  }

  function generatePageMarkdown(annotations, page, imageMap, base, replyMap) {
    // 可见 URL 对 /d/doc- 文档页用真实服务端 base 重写协议（与 openPage 同源）。frontmatter 的
    // page_url 仍用原始 page.url（供增量导出 sync 匹配/diff）。
    var visPageUrl = _resolveDocUrlForExport(page && page.url, base);
    var sorted = annotations.slice().sort(function (a, b) {
      var ya = parseFloat(a.ANCHOR_Y_RATIO) || 0;
      var yb = parseFloat(b.ANCHOR_Y_RATIO) || 0;
      if (ya !== yb) return ya - yb;
      return (a.CREATE_TIME || '').localeCompare(b.CREATE_TIME || '');
    });

    // Frontmatter
    var lines = [];
    lines.push('---');
    lines.push('webpz_sync:');
    lines.push('  page_url: ' + escapeYaml(page.url));
    lines.push('  page_domain: ' + escapeYaml(page.domain));
    lines.push('  page_title: ' + escapeYaml(displayPageTitle(page)));
    lines.push('  export_date: ' + escapeYaml(new Date().toISOString()));
    lines.push('  annotation_count: ' + sorted.length);
    lines.push('  annotations:');
    sorted.forEach(function (a) {
      lines.push('    - id: ' + escapeYaml(a.MARK_INFO_ID));
      lines.push('      type: ' + escapeYaml(getAnnotationType(a)));
      lines.push('      updated: ' + escapeYaml(a.UPDATE_TIME || ''));
    });
    lines.push('---');
    lines.push('');

    // Title
    lines.push('# ' + (displayPageTitle(page) || page.domain || getMessage('expMdUntitledPage')));
    lines.push('');
    lines.push('> URL: ' + mdClickableUrl(visPageUrl, page && page.scheme, page && page.port));
    lines.push('> ' + getMessage('expMdExportedAt', [formatDateForMd(new Date())]));
    lines.push('');
    lines.push('---');
    lines.push('');

    // Annotations
    sorted.forEach(function (a, idx) {
      var type = getAnnotationType(a);
      var typeInfo = TYPE_MAP[type] || {};
      var typeLabel = typeInfo.label || type;
      var color = a.MARK_COLOR || '#ff3c82';
      var time = a.UPDATE_TIME || a.CREATE_TIME || '';

      lines.push('### ' + (idx + 1) + '. ' + typeLabel);
      lines.push('');
      lines.push(getMessage('expMdMeta', [typeLabel, color, formatDateForMdStr(time)]));

      switch (type) {
        case 'highlight':
          renderHighlightMd(lines, a);
          break;
        case 'rect':
          renderRectMd(lines, a, imageMap);
          break;
        case 'pageRect':
          renderPageRectMd(lines, a);
          break;
        case 'arrow':
        case 'flag':
          renderArrowFlagMd(lines, a, typeLabel);
          break;
        case 'freehand':
          renderFreehandMd(lines, a);
          break;
        case 'text':
          renderTextNoteMd(lines, a);
          break;
        case 'imgAnno':
          renderImgAnnoMd(lines, a, imageMap);
          break;
        case 'rectFrame':
          renderRectFrameMd(lines, a, imageMap);
          break;
        case 'elementMark':
          renderElementMarkMd(lines, a);
          break;
        default:
          lines.push('');
          break;
      }

      // Comment
      if (a.COMMENT_TEXT) {
        lines.push('');
        lines.push(getMessage('expMdComment', [a.COMMENT_TEXT.replace(/\n/g, '\n> ')]));
      }

      // Replies（服务端协作回复，按 markId 关联；随批注一并输出）
      var annReplies = (replyMap || {})[a.MARK_INFO_ID];
      if (annReplies && annReplies.length > 0) {
        lines.push('');
        lines.push(getMessage('expMdReplies'));
        annReplies.forEach(function (r) {
          var who = r.authorName || r.authorId || '';
          var when = r.createdAt ? ' (' + formatDateForMdStr(r.createdAt) + ')' : '';
          lines.push('> ' + who + when + ': ' + String(r.message || '').replace(/\n/g, '\n> '));
        });
      }

      // Tags
      if (a.TAGS) {
        var tags = a.TAGS.split(';').filter(function (t) { return t.trim(); });
        if (tags.length > 0) {
          lines.push('');
          lines.push(tags.map(function (t) { return '#' + t.trim().replace(/\s+/g, '-'); }).join(' '));
        }
      }

      lines.push('');
      lines.push('---');
      lines.push('');
    });

    return lines.join('\n');
  }


  function generateAllPagesMarkdown(allAnnotations, grouped, pageMap, allImageMaps) {
    var pageUrls = Object.keys(grouped);
    var totalCount = allAnnotations.length;
    var dateStr = new Date().toISOString();

    // Frontmatter
    var lines = [];
    lines.push('---');
    lines.push('webpz_sync:');
    lines.push('  export_date: ' + escapeYaml(dateStr));
    lines.push('  total_pages: ' + pageUrls.length);
    lines.push('  total_annotations: ' + totalCount);
    lines.push('  pages:');
    pageUrls.forEach(function (url) {
      var page = pageMap[url] || {};
      var anns = grouped[url];
      lines.push('    - url: ' + escapeYaml(url));
      lines.push('      title: ' + escapeYaml(displayPageTitle(page) || ''));
      lines.push('      domain: ' + escapeYaml(page.domain || ''));
      lines.push('      annotation_count: ' + anns.length);
      lines.push('      annotations:');
      anns.forEach(function (a) {
        lines.push('        - id: ' + escapeYaml(a.MARK_INFO_ID));
        lines.push('          type: ' + escapeYaml(getAnnotationType(a)));
        lines.push('          updated: ' + escapeYaml(a.UPDATE_TIME || ''));
      });
    });
    lines.push('---');
    lines.push('');

    lines.push('# ' + getMessage('expMdTitle'));
    lines.push('');
    lines.push('> ' + getMessage('expMdExportedAt', [formatDateForMd(new Date())]));
    lines.push('> ' + getMessage('expMdSummary', [String(pageUrls.length), String(totalCount)]));
    lines.push('');
    lines.push('---');
    lines.push('');

    // Each page
    pageUrls.forEach(function (url) {
      var page = pageMap[url] || { url: url, domain: '', title: '' };
      var anns = grouped[url];
      var imageMap = allImageMaps[url] || {};

      lines.push('# ' + (displayPageTitle(page) || page.domain || url));
      lines.push('');
      lines.push('> URL: ' + mdClickableUrl(url));
      if (page.domain) lines.push('> ' + getMessage('expMdDomain', [page.domain]));
      lines.push('> ' + getMessage('expMdAnnoCount', [String(anns.length)]));
      lines.push('');
      lines.push('---');
      lines.push('');

      // Sort annotations by Y position
      var sorted = anns.slice().sort(function (a, b) {
        var ya = parseFloat(a.ANCHOR_Y_RATIO) || 0;
        var yb = parseFloat(b.ANCHOR_Y_RATIO) || 0;
        if (ya !== yb) return ya - yb;
        return (a.CREATE_TIME || '').localeCompare(b.CREATE_TIME || '');
      });

      sorted.forEach(function (a, idx) {
        var type = getAnnotationType(a);
        var typeInfo = TYPE_MAP[type] || {};
        var typeLabel = typeInfo.label || type;
        var color = a.MARK_COLOR || '#ff3c82';
        var time = a.UPDATE_TIME || a.CREATE_TIME || '';

        lines.push('### ' + (idx + 1) + '. ' + typeLabel);
        lines.push('');
        lines.push(getMessage('expMdMeta', [typeLabel, color, formatDateForMdStr(time)]));

        switch (type) {
          case 'highlight': renderHighlightMd(lines, a); break;
          case 'rect': renderRectMd(lines, a, imageMap); break;
          case 'pageRect': renderPageRectMd(lines, a); break;
          case 'arrow':
          case 'flag': renderArrowFlagMd(lines, a, typeLabel); break;
          case 'freehand': renderFreehandMd(lines, a); break;
          case 'text': renderTextNoteMd(lines, a); break;
          case 'imgAnno': renderImgAnnoMd(lines, a, imageMap); break;
          case 'rectFrame': renderRectFrameMd(lines, a, imageMap); break;
          case 'elementMark': renderElementMarkMd(lines, a); break;
          default: lines.push(''); break;
        }

        if (a.COMMENT_TEXT) {
          lines.push('');
          lines.push(getMessage('expMdComment', [a.COMMENT_TEXT.replace(/\n/g, '\n> ')]));
        }
        if (a.TAGS) {
          var tags = a.TAGS.split(';').filter(function (t) { return t.trim(); });
          if (tags.length > 0) {
            lines.push('');
            lines.push(tags.map(function (t) { return '#' + t.trim().replace(/\s+/g, '-'); }).join(' '));
          }
        }
        lines.push('');
        lines.push('---');
        lines.push('');
      });

    });

    return lines.join('\n');
  }

  // ---- Incremental Export (File System Access API) ----

  function parseFrontmatter(text) {
    var match = text.match(/^---\r?\n([\s\S]*?)\r?\n---/);
    if (!match) return null;
    var yaml = match[1];
    var result = {};

    // Simple YAML parser for the flat-ish webpz_sync structure
    var currentPath = [];
    var currentObj = result;
    var stack = [{ obj: result, indent: -1 }];

    yaml.split(/\r?\n/).forEach(function (line) {
      if (!line.trim() || line.trim().charAt(0) === '#') return;
      var indent = line.search(/\S/);
      var content = line.trim();

      // Pop stack to find parent at this indent level
      while (stack.length > 1 && stack[stack.length - 1].indent >= indent) {
        stack.pop();
      }
      currentObj = stack[stack.length - 1].obj;

      var listMatch = content.match(/^- (.*)/);
      var kvMatch = content.match(/^([\w]+):\s*(.*)/);

      if (listMatch) {
        // List item
        var val = listMatch[1].trim();
        var parent = stack[stack.length - 1];
        if (parent._listKey && currentObj[parent._listKey]) {
          var list = currentObj[parent._listKey];
          // Check if value is 'key: value'
          var innerKv = val.match(/^([\w]+):\s*(.*)/);
          if (innerKv) {
            var lastItem = list[list.length - 1];
            if (typeof lastItem === 'object') {
              lastItem[innerKv[1]] = unquoteYaml(innerKv[2]);
            }
          }
        }
      } else if (kvMatch) {
        var key = kvMatch[1];
        var rawVal = kvMatch[2].trim();
        if (rawVal === '') {
          // Empty value -> this key starts a sub-object or list
          currentObj[key] = [];
          stack.push({ obj: currentObj, indent: indent, _listKey: key });
        } else {
          currentObj[key] = unquoteYaml(rawVal);
        }
      }
    });

    // Fix: convert annotation arrays to proper objects
    // The parser creates flat arrays; we need to group consecutive kv pairs into objects
    if (result.annotations && Array.isArray(result.annotations)) {
      result.annotations = groupArrayItems(result.annotations);
    }
    if (result.pages && Array.isArray(result.pages)) {
      result.pages = groupArrayItems(result.pages);
    }

    return result;
  }

  function unquoteYaml(val) {
    if (!val) return val;
    if ((val.charAt(0) === '"' && val.charAt(val.length - 1) === '"') ||
        (val.charAt(0) === "'" && val.charAt(val.length - 1) === "'")) {
      return val.substring(1, val.length - 1);
    }
    return val;
  }

  function groupArrayItems(arr) {
    if (!Array.isArray(arr)) return arr;
    var items = [];
    var current = null;
    arr.forEach(function (item) {
      if (typeof item === 'object' && !Array.isArray(item)) {
        // Direct object (shouldn't happen with our parser but just in case)
        items.push(item);
      } else {
        // Primitive values from list items - skip
      }
    });
    return items.length > 0 ? items : arr;
  }

  function parseWebpzSyncFrontmatter(text) {
    var match = text.match(/^---\r?\n([\s\S]*?)\r?\n---/);
    if (!match) return null;

    // Extract the webpz_sync block using regex for reliability
    var yaml = match[1];
    var sync = {};

    // Page-level fields
    var m;
    m = yaml.match(/page_url:\s*(.*)/);
    if (m) sync.page_url = unquoteYaml(m[1].trim());
    m = yaml.match(/page_domain:\s*(.*)/);
    if (m) sync.page_domain = unquoteYaml(m[1].trim());
    m = yaml.match(/page_title:\s*(.*)/);
    if (m) sync.page_title = unquoteYaml(m[1].trim());
    m = yaml.match(/export_date:\s*(.*)/);
    if (m) sync.export_date = unquoteYaml(m[1].trim());
    m = yaml.match(/annotation_count:\s*(\d+)/);
    if (m) sync.annotation_count = parseInt(m[1]) || 0;

    // Document-level fields（自建文档导出 frontmatter，供增量导出 diff）
    m = yaml.match(/kind:\s*(.*)/);
    if (m) sync.kind = unquoteYaml(m[1].trim());
    m = yaml.match(/doc_id:\s*(.*)/);
    if (m) sync.doc_id = unquoteYaml(m[1].trim());
    m = yaml.match(/snap_id:\s*(.*)/);
    if (m) sync.snap_id = unquoteYaml(m[1].trim());
    m = yaml.match(/snap_updated:\s*(.*)/);
    if (m) sync.snap_updated = unquoteYaml(m[1].trim());
    m = yaml.match(/doc_updated:\s*(.*)/);
    if (m) sync.doc_updated = unquoteYaml(m[1].trim());

    // Parse annotations list - each has id, type, updated
    sync.annotations = [];
    var annoRegex = /-\s*id:\s*(.*?)\s*\n\s*type:\s*(.*?)\s*\n\s*updated:\s*(.*?)\s*(?:\n|$)/g;
    var annoMatch;
    while ((annoMatch = annoRegex.exec(yaml)) !== null) {
      sync.annotations.push({
        id: unquoteYaml(annoMatch[1].trim()),
        type: unquoteYaml(annoMatch[2].trim()),
        updated: unquoteYaml(annoMatch[3].trim())
      });
    }

    return sync;
  }

  async function incrementalExport() {
    // 后台下载门禁：增量导出同为备份路径，入口先检查（在 FS Access 支持检查与说明弹窗之前，spec §4.2）
    if (!(await _pendingExportGate())) return;

    // Check browser support
    if (!window.showDirectoryPicker) {
      showToast(getMessage('expNoFsAccess'));
      return;
    }

    // Show explanation dialog before proceeding
    var confirmed = await new Promise(function (resolve) {
      var overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.style.display = 'flex';

      var modal = document.createElement('div');
      modal.className = 'modal';
      modal.style.width = '420px';

      modal.innerHTML =
        '<h3 class="modal-title">' + getMessage('expIncTitle') + '</h3>' +
        '<div style="margin:16px 0;font-size:13px;line-height:1.8;color:var(--text);">' +
          '<div>' + getMessage('expIncDesc') + '</div>' +
          '<ul style="margin:8px 0 8px 20px;padding:0;">' +
            '<li>' + getMessage('expIncNew') + '</li>' +
            '<li>' + getMessage('expIncChanged') + '</li>' +
            '<li>' + getMessage('expIncUnchanged') + '</li>' +
          '</ul>' +
          '<div style="color:var(--text-secondary);margin-top:4px;">' + getMessage('expIncPickFolder') + '</div>' +
          '<div style="color:var(--text-secondary);">' + getMessage('expIncFirstTime') + '</div>' +
        '</div>' +
        '<div class="modal-actions">' +
          '<button class="btn btn-cancel" id="ieCancelBtn">' + getMessage('cancel') + '</button>' +
          '<button class="btn btn-primary" id="ieConfirmBtn">' + getMessage('expIncContinue') + '</button>' +
        '</div>';

      overlay.appendChild(modal);
      document.body.appendChild(overlay);

      modal.querySelector('#ieCancelBtn').addEventListener('click', function () {
        document.body.removeChild(overlay);
        resolve(false);
      });
      modal.querySelector('#ieConfirmBtn').addEventListener('click', function () {
        document.body.removeChild(overlay);
        resolve(true);
      });
      overlay.addEventListener('click', function (e) {
        if (e.target === overlay) {
          document.body.removeChild(overlay);
          resolve(false);
        }
      });
    });

    if (!confirmed) return;

    try {
      var dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });

      showExportProgress(getMessage('expIncScanning'));

      // Step 1: Scan existing .md files recursively
      var scanResults = await scanDirRecursive(dirHandle, '');
      var exportedPages = {};
      var exportedDocs = {};
      var exportedSnaps = {};
      scanResults.forEach(function (r) {
        if (r.isDoc && r.docId) {
          exportedDocs[r.docId] = { fileName: r.fileName, docUpdated: r.docUpdated, annotations: r.annotations };
        } else if (r.isSnap && r.snapId) {
          exportedSnaps[r.snapId] = { fileName: r.fileName, snapUpdated: r.snapUpdated, annotations: r.annotations };
        } else {
          exportedPages[r.pageUrl] = {
            fileName: r.fileName,
            annotations: r.annotations,
            exportDate: r.exportDate
          };
        }
      });
      updateExportProgress(1, 1);

      hideExportProgress();

      // Step 2: Get all current annotations + documents + snapshots from IndexedDB
      var allAnnotations = await exportAllAnnotations();
      var incDocs = (state.documents || []).slice();
      var incSnaps = (state.snapshots || []).slice();
      if ((!allAnnotations || allAnnotations.length === 0) && incDocs.length === 0 && incSnaps.length === 0) {
        showToast(getMessage('expNothing'));
        return;
      }

      // Step 3: Group annotations by WEB_URI
      var grouped = {};
      allAnnotations.forEach(function (a) {
        var key = a.WEB_URI || 'unknown';
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push(a);
      });

      var pageMap = {};
      state.pages.forEach(function (p) { pageMap[p.url] = p; });

      // Step 4: Diff - find pages that need exporting
      var toExport = [];
      var skippedCount = 0;

      for (var pageUrl in grouped) {
        var annotations = grouped[pageUrl];
        var existing = exportedPages[pageUrl];

        if (!existing) {
          // New page
          toExport.push({ pageUrl: pageUrl, annotations: annotations, status: 'new', fileName: null });
        } else {
          // Check for new or updated annotations
          var existingMap = {};
          existing.annotations.forEach(function (ea) { existingMap[ea.id] = ea; });

          var hasChanges = false;
          for (var i = 0; i < annotations.length; i++) {
            var a = annotations[i];
            var existingAnn = existingMap[a.MARK_INFO_ID];
            if (!existingAnn) {
              hasChanges = true;
              break;
            }
            // Check if annotation was updated since last export
            var currentUpdated = a.UPDATE_TIME || a.CREATE_TIME || '';
            var exportedUpdated = existingAnn.updated || '';
            if (currentUpdated && exportedUpdated && currentUpdated > exportedUpdated) {
              hasChanges = true;
              break;
            }
          }
          // Also check if annotations were deleted (fewer than before)
          if (!hasChanges && annotations.length !== existing.annotations.length) {
            hasChanges = true;
          }

          // Check if folder path changed (page moved to different directory)
          var pathChanged = false;
          if (!hasChanges) {
            var folderPath = getFolderExportPath(pageUrl);
            var expectedPath = folderPath ? folderPath + '/' : '';
            var existingBase = existing.fileName || '';
            var existingDir = existingBase.indexOf('/') >= 0
              ? existingBase.substring(0, existingBase.lastIndexOf('/') + 1)
              : '';
            if (expectedPath !== existingDir) {
              hasChanges = true;
              pathChanged = true;
            }
          }

          if (hasChanges) {
            toExport.push({
              pageUrl: pageUrl,
              annotations: annotations,
              status: 'updated',
              fileName: existing.fileName,
              oldFileName: pathChanged ? existing.fileName : null
            });
          } else {
            skippedCount++;
          }
        }
      }

      // Step 4b: Diff - 自建文档（按 doc_updated 变化 + 目录迁移判定）
      var toExportDocs = [];
      var skippedDocs = 0;
      incDocs.forEach(function (d) {
        var existing = exportedDocs[d.docId];
        var dUpdated = d.updatedAt || d.lastVisited || '';
        if (!existing) {
          toExportDocs.push({ doc: d, status: 'new', fileName: null, oldFileName: null });
        } else {
          var docChanged = false;
          var docPathChanged = false;
          if (dUpdated && existing.docUpdated && dUpdated !== existing.docUpdated) docChanged = true;
          // 文档页上的标注增删/更新也触发重导出（doc_updated 只反映文档本体编辑）
          if (!docChanged) {
            var dCurAnnos = fetchDocPageAnnotations(allAnnotations, d);
            var dExAnnos = existing.annotations || [];
            if (dCurAnnos.length !== dExAnnos.length) {
              docChanged = true;
            } else {
              var dExMap = {};
              dExAnnos.forEach(function (ea) { dExMap[ea.id] = ea; });
              for (var da = 0; da < dCurAnnos.length; da++) {
                var dAnn = dCurAnnos[da];
                var dExA = dExMap[dAnn.MARK_INFO_ID];
                var dCur = dAnn.UPDATE_TIME || dAnn.CREATE_TIME || '';
                if (!dExA || (dCur && dExA.updated && dCur > dExA.updated)) { docChanged = true; break; }
              }
            }
          }
          if (!docChanged) {
            var dFolderPath = getFolderExportPath(d.url);
            var dExpected = dFolderPath ? dFolderPath + '/' : '';
            var dExistingBase = existing.fileName || '';
            var dExistingDir = dExistingBase.indexOf('/') >= 0
              ? dExistingBase.substring(0, dExistingBase.lastIndexOf('/') + 1)
              : '';
            if (dExpected !== dExistingDir) { docChanged = true; docPathChanged = true; }
          }
          if (docChanged) {
            toExportDocs.push({ doc: d, status: 'updated', fileName: existing.fileName, oldFileName: docPathChanged ? existing.fileName : null });
          } else {
            skippedDocs++;
          }
        }
      });

      // Step 4c: Diff - 网页快照（snap_updated 变化 + 批注增删/更新判定；与全量导出一致写根目录，不做目录迁移）
      var toExportSnaps = [];
      var skippedSnaps = 0;
      // 批注按 WEB_URI 含 '/snap/{snapId}' 归属快照（与全量导出过滤同构）
      var snapAnnosMap = {};
      allAnnotations.forEach(function (a) {
        var wu = String(a.WEB_URI || '');
        var mm = wu.indexOf('/snap/');
        if (mm < 0) return;
        var sid = wu.substring(mm + 6).split(/[/?#]/)[0];
        if (!sid) return;
        if (!snapAnnosMap[sid]) snapAnnosMap[sid] = [];
        snapAnnosMap[sid].push(a);
      });
      incSnaps.forEach(function (s) {
        var existing = exportedSnaps[s.snapId];
        var sAnnos = snapAnnosMap[s.snapId] || [];
        var sUpdated = s.updatedAt || s.lastVisited || '';
        if (!existing) {
          toExportSnaps.push({ snap: s, annotations: sAnnos, status: 'new', fileName: null });
          return;
        }
        var snapChanged = false;
        if (sUpdated && existing.snapUpdated && sUpdated !== existing.snapUpdated) snapChanged = true;
        if (!snapChanged) {
          var exMap = {};
          (existing.annotations || []).forEach(function (ea) { exMap[ea.id] = ea; });
          if (sAnnos.length !== (existing.annotations || []).length) {
            snapChanged = true;
          } else {
            for (var sa = 0; sa < sAnnos.length; sa++) {
              var sAnn = sAnnos[sa];
              var sEx = exMap[sAnn.MARK_INFO_ID];
              var sCur = sAnn.UPDATE_TIME || sAnn.CREATE_TIME || '';
              if (!sEx || (sCur && sEx.updated && sCur > sEx.updated)) { snapChanged = true; break; }
            }
          }
        }
        if (snapChanged) {
          toExportSnaps.push({ snap: s, annotations: sAnnos, status: 'updated', fileName: existing.fileName });
        } else {
          skippedSnaps++;
        }
      });

      if (toExport.length === 0 && toExportDocs.length === 0 && toExportSnaps.length === 0) {
        showToast(getMessage('expIncrementalUpToDate', [String(skippedCount + skippedDocs + skippedSnaps)]));
        return;
      }

      showExportProgress(getMessage('expIncExporting'));
      try {

      // Step 5: Export changed/new pages + documents + snapshots
      var newCount = 0, updatedCount = 0;
      var incTotal = toExport.length + toExportDocs.length + toExportSnaps.length;
      // 服务端 base（一次性获取，供文档 URL 协议重写复用）
      var _expBase = ''; try { _expBase = await getServerBase(); } catch (e) { /* base 缺失则 https:// 兜底 */ }
      updateExportProgress(0, incTotal);

      for (var idx = 0; idx < toExport.length; idx++) {
        var item = toExport[idx];
        var page = pageMap[item.pageUrl] || { url: item.pageUrl, domain: '', title: '' };
        var dateStr = new Date().toISOString().slice(0, 10);

        // Fetch images + replies for this page
        var imageUrls = collectImageUrls(item.annotations);
        var imageMap = await fetchImageData(item.pageUrl, imageUrls);
        var incReplyMap = await fetchPageRepliesMap(page);

        // Generate markdown
        var md = generatePageMarkdown(item.annotations, page, imageMap, _expBase, incReplyMap);

        // Determine filename — reuse existing filename for updates, generate new for additions
        var fileName = item.fileName || makeExportFilename(page, 'md');
        // Extract just the filename part if it includes a path
        var baseName = fileName.indexOf('/') >= 0 ? fileName.split('/').pop() : fileName;

        // Write file to correct subfolder
        var folderPath = getFolderExportPath(item.pageUrl);
        var targetDir = folderPath
          ? await getOrCreateSubDirHandle(dirHandle, folderPath.split('/'))
          : dirHandle;
        await writeFileToDir(targetDir, baseName, md);

        // Remove old file if page moved to a different folder
        if (item.oldFileName) {
          await removeFileByPath(dirHandle, item.oldFileName);
          await removeEmptyParentDirs(dirHandle, item.oldFileName);
        }

        if (item.status === 'new') newCount++;
        else updatedCount++;
        updateExportProgress(idx + 1, incTotal);
      }

      // Step 5b: Export changed/new documents
      for (var dj = 0; dj < toExportDocs.length; dj++) {
        var ditem = toExportDocs[dj];
        await ensureDocBody(ditem.doc);   // P1-8 分仓：正文懒加载
        var dImgMap = {};
        try { dImgMap = await fetchDocumentImages(ditem.doc); } catch (e) { /* 无图继续 */ }
        var dAnnos3 = fetchDocPageAnnotations(allAnnotations, ditem.doc);
        var dReplyMap3 = await fetchPageRepliesMap(ditem.doc);
        var dMd = generateDocumentMarkdown(ditem.doc, dImgMap, _expBase, dAnnos3, dReplyMap3);
        var dBaseName = docExportFileName(ditem.doc, 'md');
        var dFolder = getFolderExportPath(ditem.doc.url);
        var dTarget = dFolder ? await getOrCreateSubDirHandle(dirHandle, dFolder.split('/')) : dirHandle;
        await writeFileToDir(dTarget, dBaseName, dMd);
        if (ditem.oldFileName) {
          await removeFileByPath(dirHandle, ditem.oldFileName);
          await removeEmptyParentDirs(dirHandle, ditem.oldFileName);
        }
        if (ditem.status === 'new') newCount++;
        else updatedCount++;
        updateExportProgress(toExport.length + dj + 1, incTotal);
      }

      // Step 5c: Export changed/new snapshots（写根目录，与全量导出布局一致；沿用已有文件名）
      for (var sj = 0; sj < toExportSnaps.length; sj++) {
        var sitem = toExportSnaps[sj];
        await ensureSnapBody(sitem.snap);   // P1-8 分仓：正文懒加载
        var sImgMap2 = await fetchImageData((sitem.snap && sitem.snap.url) || '', collectImageUrls(sitem.annotations));
        var sMd2 = generateSnapshotMarkdown(sitem.snap, sitem.annotations, sImgMap2);
        // 更新沿用已有文件名（兼容旧命名"标题.md"）；新建用带（快照）后缀的新命名
        var sNameBase2 = sitem.fileName
          ? (sitem.fileName.indexOf('/') >= 0 ? sitem.fileName.split('/').pop() : sitem.fileName)
          : snapExportBaseName(sitem.snap) + '.md';
        await writeFileToDir(dirHandle, sNameBase2, sMd2);
        if (sitem.status === 'new') newCount++;
        else updatedCount++;
        updateExportProgress(toExport.length + toExportDocs.length + sj + 1, incTotal);
      }

      } finally {
        hideExportProgress();
      }

      // Step 6: Show result
      showIncrementalResult(newCount, updatedCount, skippedCount + skippedDocs + skippedSnaps);

    } catch (err) {
      if (err.name === 'AbortError') return; // User cancelled
      console.error('Incremental export error:', err);
      showToast(getMessage('expIncrementalFailed', [String(err.message)]));
    }
  }

  function showIncrementalResult(newCount, updatedCount, skippedCount) {
    var overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.style.display = 'flex';

    var modal = document.createElement('div');
    modal.className = 'modal';
    modal.style.width = '400px';

    var totalCount = newCount + updatedCount;

    modal.innerHTML =
      '<h3 class="modal-title">' + getMessage('expIncDoneTitle') + '</h3>' +
      '<div style="margin:16px 0;font-size:14px;line-height:2;color:var(--text);">' +
        '<div>' + getMessage('expIncNewPages', ['<strong style="color:var(--primary);">' + newCount + '</strong>']) + '</div>' +
        '<div>' + getMessage('expIncUpdatedPages', ['<strong style="color:var(--primary);">' + updatedCount + '</strong>']) + '</div>' +
        '<div>' + getMessage('expIncSkipped', ['<strong>' + skippedCount + '</strong>']) + '</div>' +
        '<div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--border);">' + getMessage('expIncTotalFiles', ['<strong>' + totalCount + '</strong>']) + '</div>' +
      '</div>' +
      '<div class="modal-actions">' +
        '<button class="btn btn-primary" id="incrementalResultClose">' + getMessage('ok') + '</button>' +
      '</div>';

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) { overlay.remove(); }
    });
    modal.querySelector('#incrementalResultClose').addEventListener('click', function () {
      overlay.remove();
    });
  }

  // ---- Markdown per-type renderers ----

  function renderHighlightMd(lines, a) {
    var text = a.CONTEXT || '';
    var style = getStyleLabel(a.TITLE);
    lines.push('');
    lines.push(getMessage('expMdStyle', [style]));
    if (text) {
      lines.push('');
      lines.push('> ' + text.replace(/\n/g, '\n> '));
    }
  }

  function renderRectMd(lines, a, imageMap) {
    var imgUrl = a.END_TAG_NAME || '';
    lines.push('');
    if (imgUrl) {
      var imgSrc = imageMap[imgUrl] || imgUrl;
      lines.push('![' + getMessage('expMdImgAnnoAlt') + '](' + imgSrc + ')');
    }
  }

  function renderPageRectMd(lines, a) {
    var context = a.THUMBNAIL || '';
    lines.push('');
    // objectKey（u/xxx.webp）在 Markdown 中无意义，需先下载转 base64 再嵌入——MVP 阶段跳过
    // TODO: 阶段 2 支持导出时批量签名 + 下载 + 嵌入
    if (context && (context.indexOf('data:') === 0 || context.indexOf('http') === 0)) {
      lines.push('![' + getMessage('altAreaScreenshot') + '](' + context + ')');
    }
  }

  function renderArrowFlagMd(lines, a, typeLabel) {
    lines.push('');
    lines.push('*' + getMessage('expMdTypeAnno', [typeLabel]) + '*');
  }

  // 矩形框（$rectFrame）：END_TAG_NAME 存锚点图 URL（与 $pic 同约定），有本地图则内嵌 base64
  function renderRectFrameMd(lines, a, imageMap) {
    // CONTEXT = 创建时提取的矩形区域文本（rect-frame-drawing.js 写入）；无文本（如纯图片区域）回退图片/占位符
    var text = a.CONTEXT || '';
    var imgUrl = a.END_TAG_NAME || '';
    if (text) {
      lines.push('');
      lines.push('> ' + text.replace(/\n/g, '\n> '));
    }
    lines.push('');
    if (imgUrl) {
      lines.push('![' + getMessage('expMdRectFrameAlt') + '](' + (imageMap[imgUrl] || imgUrl) + ')');
    } else if (!text) {
      lines.push('*' + getMessage('expMdRectFrameAnno') + '*');
    }
  }

  // 元素标记（$elemMark）：START_TAG_NAME=锚点元素标签、CONTEXT=元素文本、END_TAG_NAME=媒体 src（img/video）
  function renderElementMarkMd(lines, a) {
    var tag = a.START_TAG_NAME || '';
    var text = a.CONTEXT || '';
    var src = a.END_TAG_NAME || '';
    lines.push('');
    if (tag) lines.push(getMessage('expMdElement', [tag]));
    if (text) {
      lines.push('');
      lines.push('> ' + text.replace(/\n/g, '\n> '));
    }
    if (src && /^(https?:|data:)/i.test(src)) {
      lines.push('');
      lines.push('![' + getMessage('expMdElementMediaAlt') + '](' + src + ')');
    }
  }

  function renderFreehandMd(lines, a) {
    // TEXT_SNAPSHOT = 创建时提取的划线区域文本（freehand-drawing.js 写入；CONTEXT 被点集占用）；无文本回退占位符
    var text = a.TEXT_SNAPSHOT || '';
    lines.push('');
    if (text) {
      lines.push('> ' + text.replace(/\n/g, '\n> '));
    } else {
      lines.push('*' + getMessage('expMdFreehandAnno') + '*');
    }
  }

  function renderTextNoteMd(lines, a) {
    var text = a.CONTEXT || '';
    lines.push('');
    if (text) {
      lines.push('> ' + text.replace(/\n/g, '\n> '));
    }
  }

  function renderImgAnnoMd(lines, a, imageMap) {
    var imgUrl = a.END_TAG_NAME || '';
    var context = a.CONTEXT || '';
    lines.push('');
    // CONTEXT may be 'img:url' or a data URL
    var thumbSrc = '';
    if (context && context.indexOf('img:') === 0) {
      var refUrl = context.substring(4);
      thumbSrc = imageMap[refUrl] || refUrl;
    } else if (context && context.indexOf('data:') === 0) {
      thumbSrc = context;
    }
    if (thumbSrc) {
      lines.push('![' + getMessage('expMdImgMarkThumbAlt') + '](' + thumbSrc + ')');
    } else if (imgUrl) {
      var src = imageMap[imgUrl] || imgUrl;
      lines.push('![' + getMessage('expMdImgMarkAlt') + '](' + src + ')');
    }
  }

  function formatDateForMd(d) {
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) +
      ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }

  function formatDateForMdStr(ts) {
    if (!ts) return '';
    if (typeof ts === 'string' && ts.indexOf('T') < 0) return ts;
    var d = new Date(ts);
    if (isNaN(d.getTime())) return ts;
    return formatDateForMd(d);
  }

  // ---- i18n ----

  function applyI18n() {
    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      var key = el.getAttribute('data-i18n');
      var msg = chrome.i18n.getMessage(key);
      if (msg) el.textContent = msg;
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) {
      var key = el.getAttribute('data-i18n-placeholder');
      var msg = chrome.i18n.getMessage(key);
      if (msg) el.placeholder = msg;
    });
    // data-i18n-title：图标按钮 tooltip。此前 applyI18n 不处理该属性（manager.html 里的多处
    // 一直显示硬编码中文 title），补上后与既有命令式设置（同步按钮/导入按钮等）取同一 key，无冲突。
    document.querySelectorAll('[data-i18n-title]').forEach(function (el) {
      var key = el.getAttribute('data-i18n-title');
      var msg = chrome.i18n.getMessage(key);
      if (msg) el.title = msg;
    });
    document.querySelectorAll('[data-i18n-aria-label]').forEach(function (el) {
      var key = el.getAttribute('data-i18n-aria-label');
      var msg = chrome.i18n.getMessage(key);
      if (msg) el.setAttribute('aria-label', msg);
    });
    var lang = chrome.i18n.getUILanguage();
    if (lang) document.documentElement.lang = lang;
  }

  // ---- Folder Tree ----

  // folder DB ↔ state 字段转换（expanded 不入库）
  // 默认目录 id='root' 本身无特殊逻辑；其子目录 parentFolderId='root' 仍有效，不要把 'root' 转成 null，
  // 否则 root 的子目录会变成顶层目录（层级错乱）。
  function folderDbToState(f) {
    return {
      id: f.folderId,
      name: f.name || '',
      parentId: f.parentFolderId || null,
      order: f.orderSeq || 0
    };
  }

  function folderStateToDb(f) {
    return {
      folderId: f.id,
      name: f.name || '',
      parentFolderId: f.parentId || null,
      orderSeq: f.order || 0
    };
  }

  // 取页面所属目录 id（从 pages.FOLDER_ID 读，取代旧 pageFolderMap）
  function getPageFolderId(p) {
    return (p && p.FOLDER_ID) || null;
  }

  // 折叠态存 chrome.storage.local（纯 UI，不同步）。collapsed 集合：缺省=展开（与旧行为一致）。
  function loadFolderCollapsed() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(['wpzl_folder_collapsed'], function (result) {
          state.folderCollapsed = (result && result.wpzl_folder_collapsed) ? result.wpzl_folder_collapsed : {};
          resolve();
        });
      } catch (e) {
        state.folderCollapsed = {};
        resolve();
      }
    });
  }

  function saveFolderCollapsed() {
    try { chrome.storage.local.set({ wpzl_folder_collapsed: state.folderCollapsed }); } catch (e) { /* ignore */ }
  }

  function isFolderExpanded(folderId) {
    // 缺省展开（不在 collapsed 集合即展开）；默认目录(root) 无特殊逻辑，可正常折叠
    if (!folderId) return true;
    return !state.folderCollapsed[folderId];
  }

  // 从 folders store 加载目录（getAllFolders → 字段转换 → 过滤 PENDING_DELETED）。
  // 默认目录(root) 与普通目录一样作为真实记录存在于 folders store，参与同步，无特殊渲染逻辑。
  function loadFolders() {
    return sendMessage('getAllFolders', {}).then(function (folders) {
      var converted = (folders || []).filter(function (f) {
        return f && f.SYNC_STATUS !== 'pending_deleted';
      }).map(folderDbToState);
      state.folders = converted;
    });
  }

  function getChildFolders(parentId) {
    return state.folders
      .filter(function (f) { return f.parentId === parentId; })
      .sort(function (a, b) { return (a.order || 0) - (b.order || 0); });
  }

  // 目录树条目排序：手动排序号（拖拽重排写入，恒 ≥1）升序在前；未排序项（null）排后、
  // 彼此按时间新到旧。两字段（SORT_ORDER / lastVisited）均已同步，跨设备顺序一致、确定性。
  function _sortTreeEntries(entries) {
    function ts(e) { return Date.parse(e.lastVisited || '') || 0; }
    return entries.slice().sort(function (a, b) {
      var oa = (typeof a.SORT_ORDER === 'number' && a.SORT_ORDER > 0) ? a.SORT_ORDER : Infinity;
      var ob = (typeof b.SORT_ORDER === 'number' && b.SORT_ORDER > 0) ? b.SORT_ORDER : Infinity;
      if (oa !== ob) return oa - ob;
      return ts(b) - ts(a);
    });
  }

  function getPagesInFolder(folderId) {
    return state.pages.filter(function (p) {
      return getPageFolderId(p) === folderId;
    });
  }

  // 目录树用：返回某目录下的 pages + documents，按 URL 去重（文档胜出，与 renderSidebar
  // 侧栏合并去重 1172-1176 一致——在 /d/{docId} 页画过批注会生成同 URL 的 pages 记录，
  // 树视图只保留文档条目，避免同一 URL 在树里重复出现）。
  function getTreeEntriesInFolder(folderId) {
    var pagesIn = state.pages.filter(function (p) { return getPageFolderId(p) === folderId && !_isPageShadowedBySnapshot(p); });
    var docsIn = (state.documents || []).filter(function (d) { return getPageFolderId(d) === folderId; });
    var docUrlSet = {};
    docsIn.forEach(function (d) { if (d.url) docUrlSet[d.url] = true; });
    pagesIn = pagesIn.filter(function (p) { return !docUrlSet[p.url]; });
    var snapsIn = (state.snapshots || []).filter(function (s) { return getPageFolderId(s) === folderId; });
    return _sortTreeEntries(pagesIn.concat(docsIn).concat(snapsIn));
  }

  // 未分类条目（pages + documents + snapshots，按 URL 去重，文档胜出）。快照 url 独立，无需去重。
  function getUnclassifiedTreeEntries() {
    var pagesIn = state.pages.filter(function (p) { return !getPageFolderId(p) && !_isPageShadowedBySnapshot(p); });
    var docsIn = (state.documents || []).filter(function (d) { return !getPageFolderId(d); });
    var docUrlSet = {};
    docsIn.forEach(function (d) { if (d.url) docUrlSet[d.url] = true; });
    pagesIn = pagesIn.filter(function (p) { return !docUrlSet[p.url]; });
    var snapsIn = (state.snapshots || []).filter(function (s) { return !getPageFolderId(s); });
    return _sortTreeEntries(pagesIn.concat(docsIn).concat(snapsIn));
  }

  function getFolderPath(folderId) {
    var path = [];
    var current = folderId;
    while (current) {
      var folder = state.folders.find(function (f) { return f.id === current; });
      if (!folder) break;
      path.unshift(folder.name);
      current = folder.parentId;
    }
    return path;
  }

  function countPagesRecursive(folderId) {
    var count = getTreeEntriesInFolder(folderId).length;
    getChildFolders(folderId).forEach(function (child) {
      count += countPagesRecursive(child.id);
    });
    return count;
  }

  function getDescendantFolderIds(folderId) {
    var ids = [folderId];
    getChildFolders(folderId).forEach(function (child) {
      ids = ids.concat(getDescendantFolderIds(child.id));
    });
    return ids;
  }

  // ---- Folder ↔ Page List 联动过滤 ----

  // 设置当前过滤的目录：null=清除(显示全部); ''=未分类; string=目录id(含子孙)
  function setActiveFolder(folderId) {
    state.activeFolderId = folderId;
    renderSidebar(); // 重渲页面列表 + 目录树（应用 .active 高亮）
  }

  // 当前过滤目录的显示名（仅显示目录自身名称，避免 root/default 占位污染）
  function getActiveFolderLabel() {
    if (state.activeFolderId === '') return chrome.i18n.getMessage('unclassified') || '未分类';
    if (!state.activeFolderId) return '';
    var f = state.folders.find(function (x) { return x.id === state.activeFolderId; });
    return f ? f.name : '';
  }

  // 根据过滤状态更新页面列表标题与「显示全部」按钮
  function updatePageListHeader() {
    var titleEl = document.querySelector('.sidebar-title');
    var btn = document.getElementById('showAllBtn');
    var label = getActiveFolderLabel();
    if (state.activeFolderId !== null && label) {
      if (titleEl) { titleEl.textContent = label; titleEl.title = label; }
      if (btn) btn.style.display = '';
    } else {
      if (titleEl) { titleEl.textContent = chrome.i18n.getMessage('pageList') || '页面列表'; titleEl.removeAttribute('title'); }
      if (btn) btn.style.display = 'none';
    }
  }

  // ---- Folder Tree Rendering ----

  // 渲染目录树里的一个页面/文档条目。页面条目 HTML 与改造前逐字一致（仅 favicon/badge 多传
  // 文档分支）；文档条目加 tree-page-item-doc + data-kind="document"，favicon 取文档图标、
  // badge 显示「文」（与侧栏 page-list 1230 一致）。
  function renderTreePageItemHtml(p, depth, isUnclassified) {
    var isActive = state.currentPage && state.currentPage.url === p.url;
    var domain = p.domain || '';
    var isDoc = p.kind === 'document';
    var isSnap = p.kind === 'snapshot';
    var styleAttr = isUnclassified ? '' : (' style="padding-left:' + (24 + (depth + 1) * 16) + 'px"');
    var cls = 'tree-page-item' + (isActive ? ' active' : '') + (isDoc ? ' tree-page-item-doc' : '') + (isSnap ? ' tree-page-item-snapshot' : '');
    var html = '<div class="' + cls + '" data-url="' + escapeHtml(p.url) + '" data-domain="' + escapeHtml(domain) + '" draggable="true"'
             + (isDoc ? ' data-kind="document"' : '') + (isSnap ? ' data-kind="snapshot"' : '') + styleAttr + '>';
    html += '<img class="tree-page-favicon" src="' + generateFaviconSvg(domain || '?', p.kind) + '" alt="">';
    html += '<div class="tree-page-title" title="' + escapeHtml(displayPageTitle(p) || p.url) + '">' + truncate(displayPageTitle(p) || p.url, 30) + '</div>';
    html += '<span class="tree-page-badge">' + _badgeTextFor(p) + '</span>';
    html += '<button class="tree-page-move" data-move-url="' + escapeHtml(p.url) + '" title="' + getMessage('folMoveToFolder') + '">⋯</button>';
    html += '</div>';
    return html;
  }

  function renderFolderTree() {
    var container = document.getElementById('folderTreeContent');
    if (!container) return;
    var topFolders = getChildFolders(null);
    var html = '';
    topFolders.forEach(function (folder) {
      html += renderFolderNode(folder, 0);
    });
    // Unclassified entries（pages + 自建文档，按 URL 去重）
    var unclassified = getUnclassifiedTreeEntries();
    if (unclassified.length > 0) {
      var isActiveUnclass = state.activeFolderId === '';
      html += '<div class="tree-unclassified-label' + (isActiveUnclass ? ' active' : '') + '" data-folder-id="" style="font-size:11px;font-weight:600;color:var(--text-muted);padding:8px 12px 4px;text-transform:uppercase;cursor:pointer;">' + getMessage('unclassified') + '</div>';
      unclassified.forEach(function (p) {
        html += renderTreePageItemHtml(p, 0, true);
      });
    }
    // 空态：无任何目录且无未分类条目 → 提示用户点 + 创建（避免面板留白困惑）。
    // renderSidebar 现在即使 folders 为空也显示面板，此处负责给出可操作的空态文案。
    if (topFolders.length === 0 && unclassified.length === 0) {
      html = '<div class="folder-tree-empty" style="padding:10px 12px;font-size:12px;color:var(--text-muted);line-height:1.5;">'
        + escapeHtml(chrome.i18n.getMessage('folderTreeEmpty') || '暂无目录，点击右上角 + 新建目录或文档')
        + '</div>';
    }
    container.innerHTML = html;
  }

  function renderFolderNode(folder, depth) {
    var children = getChildFolders(folder.id);
    var entries = getTreeEntriesInFolder(folder.id);
    var hasChildren = children.length > 0 || entries.length > 0;
    var isExpanded = isFolderExpanded(folder.id);
    var isActiveFolder = state.activeFolderId === folder.id;
    var totalCount = countPagesRecursive(folder.id);
    var indent = depth * 16;

    var html = '<div class="tree-node" data-folder-id="' + folder.id + '">';
    html += '<div class="tree-node-row' + (isActiveFolder ? ' active' : '') + '" style="padding-left:' + (8 + indent) + 'px" data-folder-id="' + folder.id + '" draggable="true">';
    html += '<span class="tree-node-arrow' + (isExpanded ? ' expanded' : '') + (!hasChildren ? ' empty' : '') + '">▶</span>';
    html += '<span class="tree-node-icon">📁</span>';
    html += '<span class="tree-node-name">' + escapeHtml(folder.name) + '</span>';
    if (totalCount > 0) {
      html += '<span class="tree-node-count">' + totalCount + '</span>';
    }
    html += '</div>';
    html += '<div class="tree-children' + (isExpanded ? '' : ' collapsed') + '">';
    children.forEach(function (child) {
      html += renderFolderNode(child, depth + 1);
    });
    entries.forEach(function (p) {
      html += renderTreePageItemHtml(p, depth, false);
    });
    html += '</div></div>';
    return html;
  }

  // ---- 目录树拖拽手动排序（仅同父级重排） ----
  // 语义：文件夹只在同级文件夹之间重排；条目（页面/文档/快照）只在同一容器内重排
  // （某目录的条目区或未分类块）。拖到文件夹行/条目行中段不显示插入线也不生效——
  // 「移入目录」仍走 ⋯ 按钮 / 右键菜单，避免拖拽误移归属。跨父级/跨类型显示禁止。
  // 持久化：文件夹走 putFolder 重写 orderSeq（全链已有）；条目走 setSortOrders 批量写
  // SORT_ORDER/sortOrder 标脏同步。乐观更新 state 后 renderSidebar。

  function _initTreeDragReorder() {
    var container = document.getElementById('folderTreeContent');
    if (!container) return;
    var dragEl = null;      // 被拖拽的行（.tree-node-row 或 .tree-page-item）
    var dragKind = null;    // 'folder' | 'entry'
    var dropTarget = null;  // 当前悬停目标行
    var dropPos = null;     // 'above' | 'below'

    function clearIndicator() {
      if (dropTarget) dropTarget.classList.remove('tree-drop-above', 'tree-drop-below');
      dropTarget = null; dropPos = null;
    }
    function endDrag() {
      if (dragEl) dragEl.classList.remove('tree-dragging');
      dragEl = null; dragKind = null;
      clearIndicator();
    }

    container.addEventListener('dragstart', function (e) {
      var t = e.target;
      if (!(t instanceof Element)) return;
      // ⋯ 移入目录按钮 / 展开箭头上不发起拖拽（其原生点击行为优先）
      if (t.closest('.tree-page-move') || t.closest('.tree-node-arrow')) { e.preventDefault(); return; }
      var row = t.closest('.tree-node-row');
      var item = t.closest('.tree-page-item');
      if (row) { dragEl = row; dragKind = 'folder'; }
      else if (item) { dragEl = item; dragKind = 'entry'; }
      else { return; }
      dragEl.classList.add('tree-dragging');
      try {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', ''); // Firefox 必须 setData 才启动拖拽
      } catch (err) { /* ignore */ }
    });

    container.addEventListener('dragover', function (e) {
      if (!dragEl) return;
      var t = (e.target instanceof Element) ? e.target : null;
      var targetRow = null;
      if (dragKind === 'folder') {
        // 文件夹：目标行的 .tree-node 包装必须与源在同一父容器（同级）
        var row = t && t.closest('.tree-node-row');
        if (row && row !== dragEl) {
          var srcWrapper = dragEl.closest('.tree-node');
          var dstWrapper = row.closest('.tree-node');
          if (srcWrapper && dstWrapper && srcWrapper.parentElement === dstWrapper.parentElement) targetRow = row;
        }
      } else {
        // 条目：目标必须是同一容器内的 .tree-page-item
        var item = t && t.closest('.tree-page-item');
        if (item && item !== dragEl && item.parentElement === dragEl.parentElement) targetRow = item;
      }
      if (!targetRow) {
        e.dataTransfer.dropEffect = 'none';
        clearIndicator();
        return;
      }
      e.preventDefault(); // 允许 drop
      e.dataTransfer.dropEffect = 'move';
      var rect = targetRow.getBoundingClientRect();
      var ratio = (e.clientY - rect.top) / (rect.height || 1);
      var pos = ratio < 0.25 ? 'above' : (ratio > 0.75 ? 'below' : null);
      if (dropTarget !== targetRow || dropPos !== pos) {
        clearIndicator();
        if (pos) { // 行中段（25%~75%）无插入线：拖到文件夹体上≠移入其中
          dropTarget = targetRow; dropPos = pos;
          targetRow.classList.add(pos === 'above' ? 'tree-drop-above' : 'tree-drop-below');
        }
      }
    });

    container.addEventListener('drop', function (e) {
      if (!dragEl || !dropTarget || !dropPos) { endDrag(); return; }
      e.preventDefault();
      var el = dragEl, target = dropTarget, pos = dropPos, kind = dragKind;
      endDrag();
      try { _applyTreeReorder(el, target, pos, kind); } catch (err) {
        console.error('tree reorder failed:', err);
        renderSidebar();
      }
    });

    container.addEventListener('dragend', endDrag);
  }

  // 计算重排后的同级列表：从 state 取当前顺序（与渲染一致），把 moved 移到目标行上/下方。
  function _reorderList(list, matchDragged, matchTarget, pos) {
    var fromIdx = list.findIndex(matchDragged);
    var targetIdx = list.findIndex(matchTarget);
    if (fromIdx < 0 || targetIdx < 0 || fromIdx === targetIdx) return null;
    var moved = list[fromIdx];
    var rest = list.filter(function (_, i) { return i !== fromIdx; });
    var insertAt = rest.findIndex(matchTarget);
    rest.splice(pos === 'above' ? insertAt : insertAt + 1, 0, moved);
    return rest;
  }

  function _applyTreeReorder(dragEl, targetRow, pos, kind) {
    if (kind === 'folder') {
      var draggedId = dragEl.dataset.folderId;
      var targetId = targetRow.dataset.folderId;
      var folder = state.folders.find(function (f) { return f.id === draggedId; });
      if (!folder) return;
      var newList = _reorderList(
        getChildFolders(folder.parentId),
        function (f) { return f.id === draggedId; },
        function (f) { return f.id === targetId; },
        pos
      );
      if (!newList) return;
      var changed = [];
      newList.forEach(function (f, i) {
        if ((f.order || 0) !== i + 1) { f.order = i + 1; changed.push(f); }
      });
      renderSidebar(); // 乐观更新（getChildFolders 按 order 排序）
      changed.forEach(function (f) {
        sendMessage('putFolder', { folder: folderStateToDb(f) }).catch(function (err) {
          console.error('putFolder reorder failed:', err);
        });
      });
      return;
    }
    // entry：同一容器内的条目重排。容器 → 所属目录（null = 未分类）
    var entryContainer = dragEl.parentElement;
    var folderId = null;
    if (entryContainer && entryContainer.closest && entryContainer.closest('.tree-node')) {
      folderId = entryContainer.closest('.tree-node').dataset.folderId || null;
    }
    function kindOf(el) { return el.getAttribute('data-kind') || 'page'; }
    function sameEntry(p, el) { return (p.kind || 'page') === kindOf(el) && p.url === el.dataset.url; }
    var entries = (folderId === null) ? getUnclassifiedTreeEntries() : getTreeEntriesInFolder(folderId);
    var newList2 = _reorderList(
      entries,
      function (p) { return sameEntry(p, dragEl); },
      function (p) { return sameEntry(p, targetRow); },
      pos
    );
    if (!newList2) return;
    var updates = [];
    newList2.forEach(function (p, i) {
      if ((typeof p.SORT_ORDER === 'number' ? p.SORT_ORDER : 0) !== i + 1) {
        p.SORT_ORDER = i + 1;
        updates.push({ kind: p.kind || 'page', url: p.url, docId: p.docId, snapId: p.snapId, sortOrder: i + 1 });
      }
    });
    renderSidebar(); // 乐观更新（_sortTreeEntries 按 SORT_ORDER 排序）
    if (updates.length) {
      sendMessage('setSortOrders', { updates: updates }).catch(function (err) {
        console.error('setSortOrders failed:', err);
      });
    }
  }

  // ---- Folder CRUD ----

  var pendingFolderAction = null;

  function createFolder(name, parentId) {
    var id = 'f_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
    var siblings = getChildFolders(parentId);
    var maxOrder = siblings.reduce(function (m, f) { return Math.max(m, f.order || 0); }, -1);
    var folder = { id: id, name: name, parentId: parentId, order: maxOrder + 1 };
    // 确保父目录展开以显示新子目录（纯 UI 折叠态；删除 collapsed 项即展开）
    if (parentId) delete state.folderCollapsed[parentId];
    saveFolderCollapsed();
    sendMessage('putFolder', { folder: folderStateToDb(folder) }).then(function () {
      return loadFolders();
    }).then(function () { renderSidebar(); });
  }

  function renameFolder(folderId, newName) {
    var folder = state.folders.find(function (f) { return f.id === folderId; });
    if (folder) {
      var updated = Object.assign({}, folder, { name: newName });
      sendMessage('putFolder', { folder: folderStateToDb(updated) }).then(function () {
        return loadFolders();
      }).then(function () { renderSidebar(); });
    }
  }

  function deleteFolder(folderId) {
    var descendants = getDescendantFolderIds(folderId); // 含 folderId + 所有子孙
    // 软删 folder（含子孙）→ softDeleteFolder（标 PENDING_DELETED，推送后由 sync-engine 硬删）
    var folderPromises = descendants.map(function (fid) {
      return sendMessage('softDeleteFolder', { folderId: fid });
    });
    // 受影响页面移出目录 → setPageFolderId(null)（标脏推送，让其它设备同步归属变更）
    var affectedPages = state.pages.filter(function (p) {
      return descendants.indexOf(getPageFolderId(p)) >= 0;
    });
    var pagePromises = affectedPages.map(function (p) {
      return sendMessage('setPageFolderId', { url: p.url, folderId: null });
    });
    Promise.all(folderPromises.concat(pagePromises)).then(function () {
      return loadFolders();
    }).then(function () {
      return refreshPageCounts(); // pages.FOLDER_ID 变更后重载 state.pages
    }).then(function () {
      renderSidebar();
    });
  }

  function toggleFolderExpand(folderId) {
    if (!folderId) return;
    // 折叠态存 chrome.storage.local（不同步），缺省展开
    if (state.folderCollapsed[folderId]) {
      delete state.folderCollapsed[folderId];
    } else {
      state.folderCollapsed[folderId] = true;
    }
    saveFolderCollapsed();
    renderFolderTree();
  }

  function showFolderModal(title, defaultValue, callback) {
    var modal = document.getElementById('folderModal');
    document.getElementById('folderModalTitle').textContent = title;
    var input = document.getElementById('folderNameInput');
    input.value = defaultValue || '';
    modal.style.display = 'flex';
    setTimeout(function () { input.focus(); input.select(); }, 50);
    pendingFolderAction = callback;
  }

  function closeFolderModal() {
    document.getElementById('folderModal').style.display = 'none';
    pendingFolderAction = null;
  }

  function showFolderContextMenu(event, folderId) {
    event.preventDefault();
    event.stopPropagation();
    hideContextMenu(); // 切换右键对象时先关闭其它菜单（如 pageContextMenu / moveToFolderDropdown）
    var menu = document.getElementById('folderContextMenu');
    var html = '';
    html += '<div class="context-menu-item" data-action="new-doc" data-folder-id="' + folderId + '">' + (chrome.i18n.getMessage('newDocument') || '新建文档') + '</div>';
    html += '<div class="context-menu-item" data-action="new-sub" data-folder-id="' + folderId + '">' + getMessage('folNewSubfolder') + '</div>';
    html += '<div class="context-menu-item" data-action="rename" data-folder-id="' + folderId + '">' + getMessage('mgRename') + '</div>';
    var count = countPagesRecursive(folderId);
    html += '<div class="context-menu-item danger" data-action="delete" data-folder-id="' + folderId + '">' + getMessage('delete') + (count > 0 ? getMessage('folDeleteCountSuffix', [String(count)]) : '') + '</div>';
    menu.innerHTML = html;
    menu.style.display = 'block';
    // Position
    var x = event.clientX, y = event.clientY;
    if (x + 180 > window.innerWidth) x = window.innerWidth - 180;
    if (y + menu.offsetHeight > window.innerHeight) y = window.innerHeight - menu.offsetHeight;
    menu.style.left = x + 'px';
    menu.style.top = y + 'px';
  }

  function hideContextMenu() {
    document.getElementById('folderContextMenu').style.display = 'none';
    document.getElementById('moveToFolderDropdown').style.display = 'none';
    var pcm = document.getElementById('pageContextMenu');
    if (pcm) pcm.style.display = 'none';
  }

  // ---- Page Context Menu (右键删除单页) ----

  function showPageContextMenu(event, url, domain) {
    event.preventDefault();
    event.stopPropagation();
    hideContextMenu(); // 切换右键对象时先关闭其它菜单（如 folderContextMenu / moveToFolderDropdown）
    var menu = document.getElementById('pageContextMenu');
    var html = '';
    html += '<div class="context-menu-item" data-action="rename" data-url="' + escapeHtml(url) + '" data-domain="' + escapeHtml(domain || '') + '">✏️ ' + getMessage('mgRename') + '</div>';
    html += '<div class="context-menu-item danger" data-action="delete" data-url="' + escapeHtml(url) + '" data-domain="' + escapeHtml(domain || '') + '">' + (chrome.i18n.getMessage('delete') || '删除') + '</div>';
    menu.innerHTML = html;
    menu.style.display = 'block';
    // Position（与 showFolderContextMenu 一致的 viewport clamp）
    var x = event.clientX, y = event.clientY;
    if (x + 180 > window.innerWidth) x = window.innerWidth - 180;
    if (y + menu.offsetHeight > window.innerHeight) y = window.innerHeight - menu.offsetHeight;
    menu.style.left = x + 'px';
    menu.style.top = y + 'px';
  }

  // 右键页面 → 重命名：复用 folderModal 弹窗（与目录重命名交互一致）。
  // 自定义标题存到 pages.CUSTOM_TITLE，自动抓取的 title 不再覆盖（见 service-worker _updatePageRecord guard）。
  function promptRenamePage(url, domain) {
    // 从 state.pages 取当前记录以预填标题
    var rec = state.pages.find(function (p) { return p.url === url; });
    var currentDisplay = rec ? displayPageTitle(rec) : (rec && rec.title || '');
    showFolderModal(getMessage('mgRenamePage'), currentDisplay, function (newName) {
      // newName 已是 trim 后的非空串（showFolderModal 的 Enter/确认逻辑保证）
      // 若用户清空输入：showFolderModal 视为取消、不会回调，因此这里不需要处理"清除"分支
      sendMessage('renamePage', { url: url, customTitle: newName }).then(function () {
        // 更新本地 state 立即反映（避免等待 SW 回写 IDB）
        if (rec) rec.CUSTOM_TITLE = newName;
        renderSidebar();
        if (state.currentPage && state.currentPage.url === url) {
          // 同步顶部 pageTitle
          var titleEl = document.getElementById('pageTitle');
          if (titleEl) titleEl.textContent = newName;
        }
      }).catch(function (e) {
        // P2-8: 重命名失败不再静默——此前仅 console.error，乐观 UI 已改的标题刷新后回弹且用户无感知
        console.error('renamePage failed:', e);
        if (rec) delete rec.CUSTOM_TITLE;   // 回滚乐观更新，与库内现状一致
        renderSidebar();
        showToast((chrome.i18n.getMessage('renameFailed') || '重命名失败') + ': ' + (e && e.message ? e.message : 'unknown'));
      });
    });
  }

  // ---- Phase 7: 文档重命名 / 删除（document 不走 renamePage/deletePage）----
  function promptRenameDocument(url) {
    var doc = (state.documents || []).find(function (d) { return d.url === url; });
    if (!doc) return;
    showFolderModal(chrome.i18n.getMessage('renameDocument') || '重命名文档', doc.title || '', function (newName) {
      sendMessage('putDocument', { doc: { docId: doc.docId, title: newName } })
        .then(function () { return refreshDocuments(); })
        .then(function () {
          if (state.currentPage && state.currentPage.url === url) renderContent();
        })
        .catch(function (e) { showToast((chrome.i18n.getMessage('docSaveFailed') || '保存失败') + ': ' + e.message); });
    });
  }

  function confirmDeleteDocument(url) {
    var doc = (state.documents || []).find(function (d) { return d.url === url; });
    if (!doc) return;
    if (!confirm(chrome.i18n.getMessage('confirmDeleteDocument') || '确定删除此文档？')) return;
    sendMessage('softDeleteDocument', { docId: doc.docId }).then(function () {
      if (state.currentPage && state.currentPage.url === url) {
        state.currentPage = null;
        var ce = document.getElementById('contentEmpty');
        var cp = document.getElementById('contentPage');
        if (ce) ce.style.display = 'flex';
        if (cp) cp.style.display = 'none';
      }
      return refreshDocuments();
    }).then(function () {
      showToast(chrome.i18n.getMessage('docDeleted') || '文档已删除');
    }).catch(function (e) { showToast((chrome.i18n.getMessage('docDeleteFailed') || '删除失败') + ': ' + e.message); });
  }

  // ---- 快照重命名 / 删除（与文档同构；走 putSnapshot/softDeleteSnapshot，不走 renamePage/deletePage）----
  function promptRenameSnapshot(url) {
    var snap = (state.snapshots || []).find(function (s) { return s.url === url; });
    if (!snap) return;
    showFolderModal(chrome.i18n.getMessage('renameSnapshot') || '重命名快照', snap.title || '', function (newName) {
      sendMessage('putSnapshot', { snap: { snapId: snap.snapId, title: newName } })
        .then(function () { return refreshDocuments(); })
        .then(function () {
          if (state.currentPage && state.currentPage.url === url) renderContent();
        })
        .catch(function (e) { showToast((chrome.i18n.getMessage('snapshotSaveFailed') || '保存失败') + ': ' + e.message); });
    });
  }

  function confirmDeleteSnapshot(url) {
    var snap = (state.snapshots || []).find(function (s) { return s.url === url; });
    if (!snap) return;
    if (!confirm(chrome.i18n.getMessage('confirmDeleteSnapshot') || '确定删除此快照？')) return;
    sendMessage('softDeleteSnapshot', { snapId: snap.snapId }).then(function () {
      if (state.currentPage && state.currentPage.url === url) {
        state.currentPage = null;
        var ce = document.getElementById('contentEmpty');
        var cp = document.getElementById('contentPage');
        if (ce) ce.style.display = 'flex';
        if (cp) cp.style.display = 'none';
      }
      return refreshDocuments();
    }).then(function () {
      showToast(chrome.i18n.getMessage('snapshotDeleted') || '快照已删除');
    }).catch(function (e) { showToast((chrome.i18n.getMessage('snapshotDeleteFailed') || '删除失败') + ': ' + e.message); });
  }

  // ---- Batch Mode (批量操作) ----

  function toggleBatchMode() {
    state.batchMode = !state.batchMode;
    if (!state.batchMode) state.batchSelectedUrls.clear();
    var headerEl = document.getElementById('sidebarHeader');
    var batchHeaderEl = document.getElementById('sidebarBatchHeader');
    var toggleBtn = document.getElementById('batchToggleBtn');
    if (headerEl) headerEl.style.display = state.batchMode ? 'none' : '';
    if (batchHeaderEl) batchHeaderEl.style.display = state.batchMode ? 'flex' : 'none';
    if (toggleBtn) toggleBtn.classList.toggle('active', state.batchMode);
    renderSidebar();
    if (state.batchMode) updateBatchUI();
  }

  function updateBatchUI() {
    var count = state.batchSelectedUrls.size;
    var countEl = document.getElementById('batchSelectedCount');
    if (countEl) countEl.textContent = chrome.i18n.getMessage('batchSelected', [String(count)]) || (count + ' 项');
    // 选中数为 0 时禁用三个动作按钮
    ['batchDeleteBtn', 'batchExportBtn', 'batchMoveBtn'].forEach(function (id) {
      var btn = document.getElementById(id);
      if (btn) btn.disabled = (count === 0);
    });
    // 全选 checkbox 全选/半选态（仅计算当前可见页面）
    var visibleUrls = Array.prototype.slice.call(document.querySelectorAll('.page-item-checkbox'))
      .map(function (c) { return c.dataset.url; });
    var chk = document.getElementById('batchSelectAllChk');
    if (chk) {
      var selectedVisible = visibleUrls.filter(function (u) { return state.batchSelectedUrls.has(u); }).length;
      chk.checked = visibleUrls.length > 0 && selectedVisible === visibleUrls.length;
      chk.indeterminate = selectedVisible > 0 && selectedVisible < visibleUrls.length;
    }
    // 同步 .batch-selected class（避免整页重渲染）
    Array.prototype.slice.call(document.querySelectorAll('.page-item')).forEach(function (item) {
      item.classList.toggle('batch-selected', state.batchSelectedUrls.has(item.dataset.url));
    });
    // 同步 checkbox checked 状态
    Array.prototype.slice.call(document.querySelectorAll('.page-item-checkbox')).forEach(function (cb) {
      cb.checked = state.batchSelectedUrls.has(cb.dataset.url);
    });
  }

  function batchSelectAllToggle() {
    var visibleUrls = Array.prototype.slice.call(document.querySelectorAll('.page-item-checkbox'))
      .map(function (c) { return c.dataset.url; });
    if (visibleUrls.length === 0) return;
    var allSelected = visibleUrls.every(function (u) { return state.batchSelectedUrls.has(u); });
    if (allSelected) {
      visibleUrls.forEach(function (u) { state.batchSelectedUrls.delete(u); });
    } else {
      visibleUrls.forEach(function (u) { state.batchSelectedUrls.add(u); });
    }
    updateBatchUI();
  }

  // ---- Page Delete (单页 + 批量共用) ----

  function confirmDeletePage(url, domain) {
    // 先查此页标注数，拼到确认文案
    sendMessage('loadAnnotations', { domain: domain, webUri: url }).then(function (markList) {
      var count = markList ? Object.keys(markList).length : 0;
      pendingPageDeleteItems = [{ url: url, domain: domain }];
      var text = getMessage('confirmDeletePageText', [String(count)]);
      document.getElementById('deleteModalText').textContent = text;
      document.getElementById('deleteModal').style.display = 'flex';
    }).catch(function () {
      // 标注查询失败也允许删除
      pendingPageDeleteItems = [{ url: url, domain: domain }];
      var text = getMessage('confirmDeletePageText', ['?']);
      document.getElementById('deleteModalText').textContent = text;
      document.getElementById('deleteModal').style.display = 'flex';
    });
  }

  function batchDeleteSelected() {
    if (state.batchSelectedUrls.size === 0) {
      showToast(chrome.i18n.getMessage('toastNoSelection') || '请先选择页面');
      return;
    }
    var items = Array.from(state.batchSelectedUrls).map(function (url) {
      var d = (state.documents || []).find(function (x) { return x.url === url; });
      if (d) return { url: url, domain: d.domain || '', kind: 'document', docId: d.docId };
      var s = (state.snapshots || []).find(function (x) { return x.url === url; });
      if (s) return { url: url, domain: s.domain || '', kind: 'snapshot', snapId: s.snapId };
      var p = state.pages.find(function (x) { return x.url === url; });
      return { url: url, domain: (p && p.domain) || '', kind: 'page' };
    });
    pendingPageDeleteItems = items;
    var text = getMessage('confirmBatchDeletePagesText');
    document.getElementById('deleteModalText').textContent =
      getMessage('confirmBatchDeletePages', [String(items.length)]) + '\n' + text;
    document.getElementById('deleteModal').style.display = 'flex';
  }

  async function executePageDelete() {
    if (!pendingPageDeleteItems || pendingPageDeleteItems.length === 0) {
      closeDeleteModal();
      return;
    }
    var items = pendingPageDeleteItems;
    closeDeleteModal();

    // P1-34: 逐项 try/catch——第 i 项失败不再中断剩余项，刷新/清理块无条件执行
    var failures = [];
    var succeeded = [];
    for (var i = 0; i < items.length; i++) {
      try {
        if (items[i].kind === 'document') {
          await sendMessage('softDeleteDocument', { docId: items[i].docId });
        } else if (items[i].kind === 'snapshot') {
          await sendMessage('softDeleteSnapshot', { snapId: items[i].snapId });
        } else {
          await sendMessage('deletePage', items[i]);
        }
        succeeded.push(items[i]);
      } catch (err) {
        console.warn('[batchDelete] item failed:', items[i].url || items[i].docId || items[i].snapId, err);
        failures.push({ item: items[i], err: err });
      }
    }

    try {
      // 刷新页面列表（getAllPages 已过滤 pending_deleted，删除后立即消失）
      var pages = await loadAllPages();
      state.pages = pages || [];
      // 含文档/快照时一并刷新（softDelete 后侧栏立即消失）
      if (items.some(function (it) { return it.kind === 'document' || it.kind === 'snapshot'; })) {
        try { await refreshDocuments(); } catch (e) { /* ignore */ }
      }
      // 如果当前页被删，清空 currentPage
      if (state.currentPage && succeeded.some(function (it) { return it.url === state.currentPage.url; })) {
        state.currentPage = null;
        state.annotations = [];
        var ce = document.getElementById('contentEmpty');
        var cp = document.getElementById('contentPage');
        if (ce) ce.style.display = 'flex';
        if (cp) cp.style.display = 'none';
      }
      // 清理批量选中态（只清成功的项，失败项保留选中便于重试）
      succeeded.forEach(function (it) { state.batchSelectedUrls.delete(it.url); });
      renderSidebar();
      if (state.batchMode) updateBatchUI();
      renderFolderTree();
      if (failures.length === 0) {
        var toastKey = items.length > 1 ? 'toastPagesDeleted' : 'toastPageDeleted';
        showToast(chrome.i18n.getMessage(toastKey, [String(items.length)]) || ('已删除 ' + items.length + ' 个页面'));
      } else if (failures.length === items.length) {
        showToast((chrome.i18n.getMessage('batchDeleteFailed') || '删除失败') + ': ' + failures[0].err.message);
      } else {
        showToast(getMessage('batchDeletePartialSuccess',
          [String(succeeded.length), String(failures.length)]));
      }
    } catch (refreshErr) {
      showToast((chrome.i18n.getMessage('batchDeleteFailed') || '删除失败') + ': ' + refreshErr.message);
    }
  }

  // ---- Batch Export ----

  async function batchExportSelected() {
    if (state.batchSelectedUrls.size === 0) {
      showToast(chrome.i18n.getMessage('toastNoSelection') || '请先选择页面');
      return;
    }
    var exportModal = document.getElementById('exportModal');
    if (!exportModal) {
      showToast(getMessage('expUiUnavailable'));
      return;
    }
    pendingBatchExportUrls = Array.from(state.batchSelectedUrls);
    // 直接弹格式选择器，不走 openExportModal('current')（那个会因 state.currentPage 为空被拦截）
    document.getElementById('exportScopeLabel').textContent =
      getMessage('batchExportScopeLabel', [String(pendingBatchExportUrls.length)]);
    document.querySelectorAll('.export-format-pill').forEach(function (p) { p.classList.remove('active'); });
    var defaultPill = document.querySelector('.export-format-pill[data-fmt="json"]');
    if (defaultPill) defaultPill.classList.add('active');
    _syncExportFormatHint();
    exportModal.style.display = 'flex';
  }

  async function executeBatchExport(fmt, dirHandle, urls) {
    pendingBatchExportUrls = null;
    if (!urls || urls.length === 0) return;

    showExportProgress(chrome.i18n.getMessage('batchExportTitle') || '正在批量导出...');

    // P1-34: 逐项 try/catch——单项导出失败不再中断剩余项；进度更新放 finally 保证不卡进度条
    var failures = [];
    // CSV 不支持文档/快照：批量混选时跳过这两类并计数（不逐项弹 toast 刷屏），收尾统一提示
    var skippedKind = 0;
    try {
      for (var i = 0; i < urls.length; i++) {
        try {
          var page = state.pages.find(function (p) { return p.url === urls[i]; });
          var doc = (state.documents || []).find(function (d) { return d.url === urls[i]; });
          var snap = (state.snapshots || []).find(function (s) { return s.url === urls[i]; });
          if (!page && !doc && !snap) { continue; }
          if (doc) {
            // CSV 不支持自建文档（表格格式与正文语义不匹配）→ 跳过并计数
            if (fmt === 'csv') { skippedKind++; continue; }
            // 自建文档：按所选格式导出（Markdown/JSON；html 回退 HTML）
            await exportDocument(doc, dirHandle, fmt);
            continue;
          }
          if (snap) {
            // CSV 不支持网页快照 → 跳过并计数
            if (fmt === 'csv') { skippedKind++; continue; }
            // 网页快照：按所选格式导出（Markdown/JSON；默认 html）——此前未传 fmt，选 Markdown/JSON 也会导出 HTML
            await exportSnapshot(snap, dirHandle, fmt);
            continue;
          }
          // 临时切换 state.currentPage + 加载该页 annotations，复用 exportCurrentPage
          state.currentPage = page;
          var markList = await loadAnnotations(page.domain, page.url);
          state.annotations = markList ? Object.values(markList) : [];
          await exportCurrentPage(fmt, dirHandle);
        } catch (err) {
          console.warn('[batchExport] item failed:', urls[i], err);
          failures.push({ url: urls[i], err: err });
        } finally {
          updateExportProgress(i + 1, urls.length);
        }
      }
      if (skippedKind > 0) {
        // CSV 批量混选：有文档/快照被跳过 → 统一提示导出数与跳过数
        showToast(getMessage('expCsvBatchDone',
          [String(urls.length - failures.length - skippedKind), String(skippedKind)]));
      } else if (failures.length === 0) {
        showToast(chrome.i18n.getMessage('toastPagesExported', [String(urls.length)]) || ('已导出 ' + urls.length + ' 个页面'));
      } else if (failures.length === urls.length) {
        showToast((chrome.i18n.getMessage('batchExportFailed') || '导出失败') + ': ' + failures[0].err.message);
      } else {
        showToast(getMessage('batchExportPartialSuccess',
          [String(urls.length - failures.length), String(failures.length)]));
      }
    } catch (err) {
      showToast((chrome.i18n.getMessage('batchExportFailed') || '导出失败') + ': ' + err.message);
    } finally {
      hideExportProgress();
    }
  }

  // ---- Batch Move ----

  function batchMoveSelected() {
    if (state.batchSelectedUrls.size === 0) {
      showToast(chrome.i18n.getMessage('toastNoSelection') || '请先选择页面');
      return;
    }
    showMovePagesModal();
  }

  function showMovePagesModal() {
    var count = state.batchSelectedUrls.size;
    var textEl = document.getElementById('movePagesModalText');
    if (textEl) {
      textEl.textContent = getMessage('batchMoveText', [String(count)]);
    }
    // 渲染目录树（含「未分类」选项）
    var treeEl = document.getElementById('movePagesTree');
    var html = '';
    html += '<div class="folder-picker-item" data-target-folder="" data-depth="0">';
    html += '<span class="folder-picker-icon">📁</span><span>' + (chrome.i18n.getMessage('unclassified') || '未分类') + '</span>';
    html += '</div>';
    function renderFolderItem(folder, depth) {
      var indent = depth * 14;
      html += '<div class="folder-picker-item" data-target-folder="' + escapeHtml(folder.id) + '" style="padding-left:' + (12 + indent) + 'px">';
      html += '<span class="folder-picker-icon">📁</span><span>' + escapeHtml(folder.name) + '</span>';
      html += '</div>';
      getChildFolders(folder.id).forEach(function (child) {
        renderFolderItem(child, depth + 1);
      });
    }
    getChildFolders(null).forEach(function (f) { renderFolderItem(f, 0); });
    treeEl.innerHTML = html;

    // 重置选中态
    pendingMovePagesSelection = null;
    var confirmBtn = document.getElementById('movePagesConfirmBtn');
    if (confirmBtn) confirmBtn.disabled = true;

    document.getElementById('movePagesModal').style.display = 'flex';
  }

  function closeMovePagesModal() {
    document.getElementById('movePagesModal').style.display = 'none';
    pendingMovePagesSelection = null;
  }

  async function confirmMovePages() {
    var folderId = pendingMovePagesSelection;
    if (folderId === null || folderId === undefined) return;
    var urls = Array.from(state.batchSelectedUrls);
    closeMovePagesModal();
    // P1-34: 逐项 try/catch——单项移动失败不再中断剩余项，刷新块无条件执行
    var failures = [];
    var movedMeta = 0;  // 文档或快照（需 refreshDocuments 刷新，普通 page 走 setPageFolderId）
    for (var i = 0; i < urls.length; i++) {
      try {
        var dRec = (state.documents || []).find(function (d) { return d.url === urls[i]; });
        var sRec = (state.snapshots || []).find(function (s) { return s.url === urls[i]; });
        if (dRec) {
          // 自建文档：partial putDocument（镜像 assignPageToFolder），SW merge 仅改 folderId
          await sendMessage('putDocument', { doc: { docId: dRec.docId, folderId: folderId || null } });
          movedMeta++;
        } else if (sRec) {
          // 快照：partial putSnapshot（镜像 assignPageToFolder），SW merge 仅改 folderId
          await sendMessage('putSnapshot', { snap: { snapId: sRec.snapId, folderId: folderId || null } });
          movedMeta++;
        } else {
          await sendMessage('setPageFolderId', { url: urls[i], folderId: folderId || null });
        }
      } catch (err) {
        console.warn('[batchMove] item failed:', urls[i], err);
        failures.push({ url: urls[i], err: err });
      }
    }
    try {
      var pages = await loadAllPages();
      state.pages = pages || [];
      if (movedMeta > 0) { try { await refreshDocuments(); } catch (e) { /* ignore */ } }
      renderSidebar();
      renderFolderTree();
      if (state.batchMode) updateBatchUI();
      if (failures.length === 0) {
        showToast(chrome.i18n.getMessage('toastPagesMoved', [String(urls.length)]) || ('已移动 ' + urls.length + ' 个页面'));
      } else if (failures.length === urls.length) {
        showToast((chrome.i18n.getMessage('batchMoveFailed') || '移动失败') + ': ' + failures[0].err.message);
      } else {
        showToast(getMessage('batchMovePartialSuccess',
          [String(urls.length - failures.length), String(failures.length)]));
      }
    } catch (refreshErr) {
      showToast((chrome.i18n.getMessage('batchMoveFailed') || '移动失败') + ': ' + refreshErr.message);
    }
  }

  // ---- Page Folder Assignment ----

  function assignPageToFolder(pageUrl, folderId) {
    var docRec = (state.documents || []).find(function (d) { return d.url === pageUrl; });
    var pageRec = state.pages.find(function (p) { return p.url === pageUrl; });
    var snapRec = (state.snapshots || []).find(function (s) { return s.url === pageUrl; });
    var tasks = [];
    // 自建文档：partial putDocument（SW db.putDocument 是 merge，仅改 folderId；与 promptRenameDocument 同模式）
    if (docRec) tasks.push(sendMessage('putDocument', { doc: { docId: docRec.docId, folderId: folderId } }));
    // 快照：partial putSnapshot（同 merge 语义；folderId||null 支持移至未分类）
    if (snapRec) tasks.push(sendMessage('putSnapshot', { snap: { snapId: snapRec.snapId, folderId: folderId || null } }));
    // 同 URL 的 pages 记录（在 /d/{docId} 画过批注会存在）一并迁移，避免跨目录重复显示
    if (pageRec) tasks.push(sendMessage('setPageFolderId', { url: pageUrl, folderId: folderId || null }));
    if (tasks.length === 0) return;
    Promise.all(tasks).then(function () {
      // 文档/快照与 pages 各自刷新（refreshDocuments 含 snapshots；refreshPageCounts 内部都会 renderSidebar + renderFolderTree）
      var chain = (docRec || snapRec) ? refreshDocuments() : Promise.resolve();
      return chain.then(function () { return pageRec ? refreshPageCounts() : Promise.resolve(); });
    }).then(function () {
      renderSidebar();
      if (state.currentPage && state.currentPage.url === pageUrl) renderContent();
    }).catch(function (e) {
      showToast((chrome.i18n.getMessage('docSaveFailed') || '保存失败') + ': ' + (e && e.message || e));
    });
  }

  function showMoveToFolderDropdown(event, pageUrl) {
    event.stopPropagation();
    var dropdown = document.getElementById('moveToFolderDropdown');
    var pageRec = state.pages.find(function (p) { return p.url === pageUrl; });
    var docRec = (state.documents || []).find(function (d) { return d.url === pageUrl; });
    var snapRec = (state.snapshots || []).find(function (s) { return s.url === pageUrl; });
    // 文档/快照优先（独立 url，无 dedup）；无 pages 记录时取其 folderId 作为当前目录
    var currentFolderId = (docRec && getPageFolderId(docRec)) || (snapRec && getPageFolderId(snapRec)) || (pageRec && getPageFolderId(pageRec)) || null;

    var html = '<div class="move-to-folder-header">' + getMessage('folMoveToFolder') + '</div><div class="move-to-folder-list">';
    html += '<div class="move-to-folder-item' + (currentFolderId === null ? ' current' : '') + '" data-target-folder="" data-move-page="' + escapeHtml(pageUrl) + '">⋯ ' + getMessage('unclassified') + '</div>';

    function renderFolderOption(folder, depth) {
      var indent = depth * 12;
      var isCurrent = currentFolderId === folder.id;
      html += '<div class="move-to-folder-item' + (isCurrent ? ' current' : '') + '" data-target-folder="' + folder.id + '" data-move-page="' + escapeHtml(pageUrl) + '" style="padding-left:' + (14 + indent) + 'px">';
      html += '📁 ' + escapeHtml(folder.name);
      html += '</div>';
      getChildFolders(folder.id).forEach(function (child) {
        renderFolderOption(child, depth + 1);
      });
    }
    getChildFolders(null).forEach(function (f) { renderFolderOption(f, 0); });

    html += '</div>';
    dropdown.innerHTML = html;
    dropdown.style.display = 'flex';

    // Position near the button
    var rect = event.target.getBoundingClientRect();
    var x = rect.left, y = rect.bottom + 4;
    if (x + 240 > window.innerWidth) x = window.innerWidth - 244;
    if (y + 320 > window.innerHeight) y = rect.top - 324;
    dropdown.style.left = x + 'px';
    dropdown.style.top = y + 'px';
  }

  // ---- Export Folder Path Helpers ----

  async function getOrCreateSubDirHandle(baseHandle, pathSegments) {
    var handle = baseHandle;
    for (var i = 0; i < pathSegments.length; i++) {
      handle = await handle.getDirectoryHandle(pathSegments[i], { create: true });
    }
    return handle;
  }

  function getFolderExportPath(pageUrl) {
    // 文档/快照在各自 state（独立于 state.pages），此处一并回退查找，使按目录归档对其同样生效
    var p = state.pages.find(function (x) { return x.url === pageUrl; })
      || (state.documents || []).find(function (x) { return x.url === pageUrl; })
      || (state.snapshots || []).find(function (x) { return x.url === pageUrl; });
    var folderId = p ? getPageFolderId(p) : null;
    if (!folderId) return '';
    var path = getFolderPath(folderId);
    return path.map(function (s) { return sanitizeFilename(s); }).join('/');
  }

  async function removeFileByPath(baseHandle, relativePath) {
    try {
      var parts = relativePath.split('/');
      var fileName = parts.pop();
      var dir = baseHandle;
      for (var i = 0; i < parts.length; i++) {
        dir = await dir.getDirectoryHandle(parts[i]);
      }
      await dir.removeEntry(fileName);
    } catch (e) { /* ignore if not found */ }
  }

  async function removeEmptyParentDirs(baseHandle, relativePath) {
    try {
      var parts = relativePath.split('/');
      // Walk from deepest directory upward
      for (var depth = parts.length - 1; depth >= 1; depth--) {
        var parentPath = parts.slice(0, depth - 1);
        var dirName = parts[depth - 1];
        var parent = baseHandle;
        for (var i = 0; i < parentPath.length; i++) {
          parent = await parent.getDirectoryHandle(parentPath[i]);
        }
        // Check if directory is empty
        var targetDir = await parent.getDirectoryHandle(dirName);
        var isEmpty = true;
        for await (var _ of targetDir.values()) { isEmpty = false; break; }
        if (isEmpty) {
          await parent.removeEntry(dirName);
        } else {
          break; // Stop when non-empty dir found
        }
      }
    } catch (e) { /* ignore */ }
  }

  async function scanDirRecursive(dirHandle, basePath) {
    var results = [];
    for await (var entry of dirHandle.values()) {
      if (entry.kind === 'file' && entry.name.endsWith('.md')) {
        try {
          var file = await entry.getFile();
          var text = await file.text();
          var sync = parseWebpzSyncFrontmatter(text);
          if (sync && sync.page_url) {
            results.push({
              pageUrl: sync.page_url,
              fileName: (basePath ? basePath + '/' : '') + entry.name,
              annotations: sync.annotations || [],
              exportDate: sync.export_date || '',
              handle: entry
            });
          } else if (sync && sync.kind === 'document' && sync.doc_id) {
            results.push({
              isDoc: true,
              docId: sync.doc_id,
              docUpdated: sync.doc_updated || '',
              annotations: sync.annotations || [],
              fileName: (basePath ? basePath + '/' : '') + entry.name,
              handle: entry
            });
          } else if (sync && sync.snap_id) {
            // 网页快照 md（webpz_snapshot frontmatter，含 snap_updated + annotations 列表）
            results.push({
              isSnap: true,
              snapId: sync.snap_id,
              snapUpdated: sync.snap_updated || '',
              annotations: sync.annotations || [],
              fileName: (basePath ? basePath + '/' : '') + entry.name,
              handle: entry
            });
          }
        } catch (e) { /* skip */ }
      } else if (entry.kind === 'directory') {
        var subPath = (basePath ? basePath + '/' : '') + entry.name;
        var subResults = await scanDirRecursive(entry, subPath);
        results = results.concat(subResults);
      }
    }
    return results;
  }

  // ---- Init ----

  function refreshPageCounts() {
    // Reload all pages and verify annotation counts by loading each page's annotations
    return loadAllPages().then(function (pages) {
      state.pages = pages || [];
      // Batch-verify counts for all pages
      var countPromises = state.pages.map(function (p) {
        return loadAnnotations(p.domain, p.url).then(function (markList) {
          var actualCount = Object.keys(markList || {}).length;
          // 仅本地实际有标注时才覆盖：登录后全量同步分阶段落盘，annotations 可能晚于 pages 提交，
          // 此刻 actualCount 暂为 0；若用它覆盖会把服务端下发的正确 annotationCount 抹成 0，
          // 并被下方 filter 误判为空页面丢弃（症状：只见目录不见页面，需手动 F5）。
          if (actualCount > 0 && p.annotationCount !== actualCount) {
            p.annotationCount = actualCount;
          }
        }).catch(function () {});
      });
      return Promise.all(countPromises).then(function () {
        // Remove stale entries: keep pages with annotations OR with a page summary
        // OR with 页面级属性（收藏/整页批注/目录归属）——这些是用户主动设置的，需在管理页可见
        // SYNC_STATUS==='synced' 的页面来自服务端（用户真实拥有），即使本地标注计数暂未算出也保留，
        // 避免刚登录同步未落盘时被误删。
        state.pages = state.pages.filter(function (p) {
          return p.annotationCount > 0 ||
                 (p.summaryBlocks && p.summaryBlocks.length > 0) ||
                 p.FAVORITE === true ||
                 (p.PAGE_NOTE && p.PAGE_NOTE.blocks && p.PAGE_NOTE.blocks.length > 0) ||
                 p.FOLDER_ID ||
                 p.SYNC_STATUS === 'synced';
        });
      });
    });
  }

  // ---- 属主冲突阻断对话框（owner-auth consistency，spec 改动 C）----
  // 分裂态（本地数据属主≠当前登录账号）时替代业务加载。不可关闭：无 X、无遮罩点击关闭
  // （manager 既有 modal 的关闭 handler 均按 id 单独绑定，本 modal 不在其中的任何一个）。
  // 两个出口都是「解除分裂」：清空本地（owner→null，继续当前账号）或登出（清空+回登录页）。
  function _renderOwnerMismatchDialog(owner, authUser) {
    var modal = document.getElementById('ownerMismatchModal');
    if (!modal) return;
    var ownerLine = document.getElementById('ownerMismatchOwnerLine');
    var currentLine = document.getElementById('ownerMismatchCurrentLine');
    // i18n 占位符用 getMessage 第二参数（substitutions）传值——不用 replace('$1', v)：
    // 后者的 $-替换模式会被 loginId 中的 $& 等字符干扰。key 缺失时 getMessage 返回 "" → 走中文兜底。
    if (ownerLine) {
      var _om = chrome.i18n.getMessage('ownerMismatchOwner', [owner.loginId || String(owner.userId)]);
      ownerLine.textContent = _om || ('本地数据属于：' + (owner.loginId || owner.userId));
    }
    if (currentLine) {
      var _cm = chrome.i18n.getMessage('ownerMismatchCurrent', [authUser.loginId || authUser.name || String(authUser.id)]);
      currentLine.textContent = _cm || ('当前登录：' + (authUser.loginId || authUser.name || authUser.id));
    }
    // data-i18n 默认文案已在 HTML；标题/说明/按钮由手动遍历补 i18n（守卫早于 _wpzlAfterAuth 的 applyI18n，
    // 此处自行翻译一次，业务加载被阻断时 applyI18n 不会跑）
    var _i18nKeys = ['ownerMismatchTitle', 'ownerMismatchDesc', 'ownerMismatchClearBtn', 'ownerMismatchLogoutBtn'];
    for (var i = 0; i < _i18nKeys.length; i++) {
      var el = document.querySelector('[data-i18n="' + _i18nKeys[i] + '"]');
      var msg = chrome.i18n.getMessage(_i18nKeys[i]);
      if (el && msg) el.textContent = msg;
    }
    var clearBtn = document.getElementById('ownerMismatchClearBtn');
    var logoutBtn = document.getElementById('ownerMismatchLogoutBtn');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      clearBtn.disabled = true;
      // clearAllData 走 db-operation 信封（与 settings.js sendMessage 包装一致），
      // handler 清 IDB + resetSyncState + owner=null（service-worker.js clearAllData case）
      chrome.runtime.sendMessage({ type: 'db-operation', operation: 'clearAllData', params: {} }, function (resp) {
        if (!(resp && resp.success)) {
          clearBtn.disabled = false;
          // 错误就地显示在说明行（不经 toast：错误语义与对话框同框呈现更直接，
          // 也避免在阻断态引入业务 toast 依赖）：
          // 简单把描述行替换为错误信息，按钮恢复可点，对话框保持
          var descEl = document.querySelector('[data-i18n="ownerMismatchDesc"]');
          if (descEl) descEl.textContent = ((resp && resp.error) || 'Clear failed');
          return;
        }
        // 主动触发全量拉回（spec 审查修正）：分裂态登录从未走完 _finalizeAuth（onLogin 没跑过），
        // reload 后 manager 只被动轮询 ~14s；sync_token 已被 resetSyncState 清空 → 此触发必全量。
        chrome.runtime.sendMessage({ type: 'sync-trigger' }, function () {
          location.reload();
        });
      });
    });
    if (logoutBtn) logoutBtn.addEventListener('click', function () {
      logoutBtn.disabled = true;
      // 与 manager.js 既有登出同款（约 :4897：Promise 形态 sendMessage + .catch + .finally 跳转）：
      // SW 清 IDB + 登出 + 广播 auth-state-changed。这里用 .catch().finally() 与其完全一致。
      // P0(CL-01): force=true——分裂态阻断对话框的登出是防串号硬路径（数据属旧属主，
      // 清空是继续使用的前提），不能被 pending_unsynced 拦住造成死锁。
      chrome.runtime.sendMessage({ type: 'auth-logout', reason: 'owner-mismatch', force: true })
        .then(function (resp) {
          // D-35: 清空失败 → 中止（保持阻断对话框在场），提示重试，不跳登录页
          if (resp && resp.success === false && resp.error === 'local_clear_failed') {
            logoutBtn.disabled = false;
            window.alert(chrome.i18n.getMessage('logoutClearFailedRetry') ||
              '本地数据清空失败，已中止退出。请再试一次退出；若持续失败，请重启浏览器后重试。');
            return;
          }
          try { location.replace(chrome.runtime.getURL('popup/auth.html')); } catch (e) { /* ignore */ }
        })
        .catch(function () {
          try { location.replace(chrome.runtime.getURL('popup/auth.html')); } catch (e) { /* ignore */ }
        });
    });
    modal.style.display = 'flex';
  }

  document.addEventListener('DOMContentLoaded', function () {
    // 决策 5：强制登录守卫 — 未登录直接跳 auth.html，不加载任何业务代码。
    // 例外（数据可达性优先）：未登录但本地仍有用户数据时放行为本地模式——
    // 切换账号被拦截、refresh token 失效（连续 401）等场景，用户必须仍能查看本地数据，
    // 否则被锁死在登录页（登新账号被拦、原账号 token 已不可用）。
    // 游客档认领自愈（2026-11）：先发 repair 触发并等其完成再走守卫——认领中断残留的数据
    // 先恢复可见再渲染业务列表；无标志时空转一次 storage 读。SW 不可达/无此 handler
    //（lastError）时容错照常走守卫（SW 顶层冷启动自检兜底）。
    chrome.runtime.sendMessage({ type: 'wpzl-repair-claim' }, function () {
      if (chrome.runtime.lastError) { /* ignore：照常走守卫 */ }
      chrome.runtime.sendMessage({ type: 'auth-status' }, function (statusResp) {
        if (statusResp && statusResp.success && statusResp.data && statusResp.data.isLoggedIn) {
          // 已登录：先比对本地数据属主（owner-auth consistency，spec 改动 C）。
          // 分裂态（owner≠登录账号）→ 渲染阻断对话框，不进 _wpzlAfterAuth（消息监听器与
          // 全部业务 init 都在其中注册，不调用即业务代码完全不跑）。
          chrome.runtime.sendMessage({ type: 'wpzl-has-local-data' }, function (dataResp) {
            var _owner = dataResp && dataResp.data && dataResp.data.owner;
            var _authUid = statusResp.data.user ? String(statusResp.data.user.id) : '';
            if (_owner && _authUid && String(_owner.userId) !== _authUid) {
              _renderOwnerMismatchDialog(_owner, statusResp.data.user);
              return;
            }
            // 属主一致（或 owner 为 null——首登前/刚清空，走既有认领逻辑）：继续加载业务
            window.__wpzlLoggedIn = true;
            _wpzlAfterAuth();
            // 游客档认领结果一次性提示（2026-11）：短命键 wpzl_claim_result（TTL 2 分钟），
            // 读后即删。覆盖 auth 页跳转太快/被直接关闭/SW 中途重启的场景；跨账号（userId
            // 不匹配）不弹。放在属主守卫通过之后——分裂态不提示认领。
            try {
              chrome.storage.local.get(['wpzl_claim_result'], function (r) {
                var c = r && r.wpzl_claim_result;
                var consume = function () { chrome.storage.local.remove(['wpzl_claim_result'], function () { /* ignore */ }); };
                if (!c || !c.total) return;
                if (Date.now() - (c.at || 0) > 2 * 60 * 1000) { consume(); return; }
                if (_authUid && String(c.userId) === _authUid) {
                  showToast(chrome.i18n.getMessage('authClaimToast', [String(c.total)]) || '');
                }
                consume();
              });
            } catch (e) { /* ignore */ }
          });
          return;
        }
        // 未登录：本地模式（游客档，2026-09-29）——无条件进入，不再要求 hasData、不再跳
        // auth.html（安装即用：游客可管理本地数据；登录入口在 popup/面板/设置页多处可达）。
        window.__wpzlLoggedIn = false;
        _wpzlAfterAuth(false);
      });
    });

    // isLoggedIn：可选参数，缺省（undefined）=已登录（不破坏现有调用）；
    // false=本地模式（游客档）——用于游客档配置加载与 guest chip。
    function _wpzlAfterAuth(isLoggedIn) {
    applyI18n();
    // D3：启动后台下载进度监听（左下角提示条）；空转 2 次自停，sync-progress 会重新唤醒。
    // 此处 re-arm dismissed 守卫：刷新管理页后恢复提示条（会话内被用户关闭后不再自动弹出）。
    _bgDownloadDismissed = false;
    try { _startBgDownloadWatch(); } catch (e) { /* ignore */ }

    // ---- 右上角用户信息条（账号 + 到期 + 刷新，渲染逻辑搬自 popup.js renderUserTier）----
    var mgrUserChip = document.getElementById('mgrUserChip');
    var mgrUserName = document.getElementById('mgrUserName');
    var mgrUserTier = document.getElementById('mgrUserTier');
    var mgrUserAvatar = document.getElementById('mgrUserAvatar');
    var mgrRefreshBtn = document.getElementById('mgrRefreshUserBtn');
    var _mgrCurrentUser = null;
    var _mgrAvatarDataUrl = null;

    // 渲染等级标签：Pro(含到期日) / Pro 临期 / 已过期 / 免费版
    // reminderDays：服务端下发的到期提醒窗口（30=年付/3=月付），非空且剩余天数在窗口内 → 临期态

    // 服务端到期串（UTC-naive）→ epoch ms：naive 按 UTC 构造（服务端 2026-11 起全链路 UTC 轴），
    // 裸 new Date(str) 按本地时区解释 naive → 判定/剩余天数偏一个时区（跨日界差一天）。
    function _mgrProExpiryMs(s) {
      if (!s) return NaN;
      var t = String(s).trim();
      var m = t.replace('T', ' ').match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?$/);
      if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
      return Date.parse(t);
    }

    function mgrRenderUserTier(isPro, proExpiresAt, reminderDays) {
      if (!mgrUserTier) return;
      var hasExpiry = proExpiresAt && String(proExpiresAt).length > 0;
      var isExpired = false;
      if (!isPro && hasExpiry) {
        try { isExpired = Date.now() >= _mgrProExpiryMs(proExpiresAt); } catch (e) {}
      }
      if (isPro) {
        // 临期第四态：进入提醒窗口（剩余 ≤ reminderDays 天）时橙色提示，优先于普通 Pro 态
        if (hasExpiry && reminderDays) {
          var _dLeft = null;
          try { _dLeft = Math.ceil((_mgrProExpiryMs(proExpiresAt) - Date.now()) / 86400000); } catch (e) {}
          if (_dLeft != null && _dLeft >= 0 && _dLeft <= reminderDays) {
            mgrUserTier.textContent = chrome.i18n.getMessage('userExpiringSoon', [String(_dLeft)]) || 'Pro';
            mgrUserTier.className = 'user-tier expiring';
            return;
          }
        }
        var expiryDate = '';
        if (hasExpiry) {
          try {
            var _eMs = _mgrProExpiryMs(proExpiresAt);
            expiryDate = isNaN(_eMs) ? '' : new Date(_eMs).toLocaleDateString();
          } catch (e) {}
        }
        mgrUserTier.textContent = (chrome.i18n.getMessage('userPro') || 'Pro') + (expiryDate ? ' · ' + expiryDate : '');
        mgrUserTier.className = 'user-tier pro';
      } else if (isExpired) {
        mgrUserTier.textContent = chrome.i18n.getMessage('userExpired') || '已过期';
        mgrUserTier.className = 'user-tier expired';
      } else {
        mgrUserTier.textContent = chrome.i18n.getMessage('userFree') || '免费版';
        mgrUserTier.className = 'user-tier free';
      }
    }

    function mgrRenderUser(user, isPro, proExpiresAt, reminderDays) {
      if (!mgrUserChip || !user) return;
      mgrUserChip.style.display = 'flex';
      // 清除游客 chip 态（本地模式 → 登录热更新后恢复可展开账号面板）
      mgrUserChip.classList.remove('mgr-guest-chip');
      mgrUserChip.title = '';
      _mgrCurrentUser = user;
      var displayName = user.name || user.loginId || 'U';
      if (mgrUserName) mgrUserName.textContent = displayName;
      if (mgrUserAvatar && !_mgrAvatarDataUrl) mgrUserAvatar.textContent = displayName.charAt(0).toUpperCase();
      mgrRenderUserTier(isPro, proExpiresAt, reminderDays);
      _mgrFillPanelIdentity(user);
    }

    // 本地模式（游客档，2026-09-29）：用户区 chip 显示「⚠ 本地模式 / 未登录」。
    // chip 纯展示不绑账号面板（游客无账号可管理）；title=localModeReminder 完整提醒（悬停可见）。
    function _mgrRenderGuestChip() {
      if (!mgrUserChip) return;
      mgrUserChip.style.display = 'flex';
      mgrUserChip.classList.add('mgr-guest-chip');
      if (mgrUserName) mgrUserName.textContent = chrome.i18n.getMessage('localModeBadge') || '本地模式';
      if (mgrUserAvatar) { mgrUserAvatar.textContent = '⚠'; mgrUserAvatar.style.backgroundImage = ''; }
      if (mgrUserTier) {
        mgrUserTier.textContent = chrome.i18n.getMessage('notLoggedIn') || '未登录';
        mgrUserTier.className = 'user-tier guest';
      }
      mgrUserChip.title = chrome.i18n.getMessage('localModeReminder') || '';
    }

    // 应用最新 pro 状态到 manager UI（等级标签 + gradeConfig/limits 门控 + 同步按钮）。
    // 三个入口共用：手动↻刷新、页面打开时的后台核对、SW wpzl-pro-status-updated 广播。
    function _mgrApplyProStatus(data) {
      if (!data) return;
      mgrRenderUserTier(!!data.isPro, data.expiresAt, data.expiryReminderDays != null ? data.expiryReminderDays : null);
      // 热更新 gradeConfig/limits（来自服务端的最新数据）→ 重算功能门控
      state.gradeConfig = data.gradeConfig || {};
      state.limits = data.limits || {};
      updateExportFormatUI();
      // 分享管理菜单项按 features.collaboration 重算显隐（升级开通/到期降级即时生效）
      _updateShareMgrItemVisibility();
      // 到期提醒横幅：与等级标签同口径评估（三个入口都汇聚到本函数）
      _mgrUpdateExpiryBanner(data);
      // 重新查询 sync-status：等级变化后 SW 的 _syncEnabled 可能仍为旧值（init 时按当时等级设定），
      // forceRefresh 链路经 onProChanged 重评估 → 回写 enabled
      chrome.runtime.sendMessage({ type: 'sync-status' }, function (syncResult) {
        if (syncResult && syncResult.success && syncResult.data) {
          state.syncEnabled = !!syncResult.data.enabled;
        }
        updateSyncButtonVisibility();
      });
    }

    // ---- Pro 到期顶部横幅（持久化可关闭；与 SW 系统通知独立去重，见 SW 侧 _wpzlEvalProExpiryReminder）----
    // 关闭语义（dismissedTier）：30=在 30 天档关闭（升到 3 天档时会重新出现）、3=在 3 天档关闭（不再出现）。
    // 状态锚定 expiresAt：续费后到期时间变化 → 旧状态失配 → 横幅重新可用。
    var MGR_EXPIRY_BANNER_KEY = 'wpzl_pro_expiry_banner';
    function _mgrUpdateExpiryBanner(data) {
      var banner = document.getElementById('proExpiryBanner');
      if (!banner || !data) return;
      var daysLeft = null, tier = null;
      if (data.isPro && data.expiresAt && data.expiryReminderDays != null) {
        try { daysLeft = Math.ceil((_mgrProExpiryMs(data.expiresAt) - Date.now()) / 86400000); } catch (e) {}
        if (daysLeft != null && daysLeft >= 0 && daysLeft <= data.expiryReminderDays) {
          // 年付剩余≤3 天升到 3 档（升档后横幅重新出现）；月付恒为 3 档
          tier = (data.expiryReminderDays >= 30 && daysLeft <= 3) ? 3 : data.expiryReminderDays;
        }
      }
      if (tier == null) {
        banner.style.display = 'none';
        document.body.classList.remove('wpzl-has-expiry-banner');
        return;
      }
      chrome.storage.local.get([MGR_EXPIRY_BANNER_KEY], function (r) {
        var st = (r && r[MGR_EXPIRY_BANNER_KEY]) || null;
        // 已在当前或更紧迫档位关闭过 → 不再显示（dismissedTier 数值越小越紧迫）
        if (st && st.expiresAt === data.expiresAt && st.dismissedTier <= tier) {
          banner.style.display = 'none';
          document.body.classList.remove('wpzl-has-expiry-banner');
          return;
        }
        var textEl = document.getElementById('proExpiryBannerText');
        if (textEl) textEl.textContent = chrome.i18n.getMessage('proExpiryBannerText', [String(daysLeft)]) || '';
        // 记录当前档位/到期时间，供关闭按钮写入 dismissedTier
        banner.dataset.tier = String(tier);
        banner.dataset.expiresAt = data.expiresAt;
        banner.style.display = 'flex';
        // 横幅占据 40px 正常流高度：body 加类让 .main-content 相应收缩（其高度是 calc(100vh-56px) 硬算的）
        document.body.classList.add('wpzl-has-expiry-banner');
      });
    }
    (function _mgrBindExpiryBanner() {
      var banner = document.getElementById('proExpiryBanner');
      if (!banner) return;
      var renewBtn = document.getElementById('proExpiryBannerRenew');
      var closeBtn = document.getElementById('proExpiryBannerClose');
      if (renewBtn) renewBtn.addEventListener('click', function () {
        // 统一升级/续费入口：复用/新开 upgrade 弹窗（与顶栏升级按钮同一消息）
        try { chrome.runtime.sendMessage({ type: 'wpzl-open-upgrade' }, function () { void chrome.runtime.lastError; }); } catch (e) { /* ignore */ }
      });
      if (closeBtn) closeBtn.addEventListener('click', function () {
        // 持久化关闭（与左下角下载条的会话级 dismissed 不同：到期横幅不持久化会每次刷新重复打扰）
        var expiresAt = banner.dataset.expiresAt || null;
        var tier = Number(banner.dataset.tier) || 3;
        if (expiresAt) {
          try {
            var _st = {};
            _st[MGR_EXPIRY_BANNER_KEY] = { expiresAt: expiresAt, dismissedTier: tier };
            chrome.storage.local.set(_st, function () { void chrome.runtime.lastError; });
          } catch (e) { /* ignore */ }
        }
        banner.style.display = 'none';
        document.body.classList.remove('wpzl-has-expiry-banner');
      });
    })();

    // 刷新按钮：用现有 token 从服务器重拉等级/到期/限额（forceRefresh），按钮转圈反馈。
    // 同时更新 gradeConfig + syncEnabled → 刷新同步按钮/导出格式 UI，避免升级 Pro 后按钮不出现。
    if (mgrRefreshBtn) {
      mgrRefreshBtn.addEventListener('click', async function () {
        if (mgrRefreshBtn.disabled) return;
        mgrRefreshBtn.disabled = true;
        mgrRefreshBtn.classList.add('refreshing');
        try {
          var result = await chrome.runtime.sendMessage({ type: 'pro-status', forceRefresh: true });
          if (result && result.success && result.data) {
            _mgrApplyProStatus(result.data);
          }
        } catch (e) { /* ignore */ } finally {
          mgrRefreshBtn.classList.remove('refreshing');
          mgrRefreshBtn.disabled = false;
        }
      });
    }

    initEvents();
    initTagDropdown();
    initSidebarResizer();
    initSidebarWidthResizer();

    // 监听 SW 广播，补齐 manager 缺失的事件驱动刷新。
    // 历史 bug：manager 曾不监听任何运行时消息，切换用户/登出后内存 state.pages 仍显示旧账号菜单
    // （而详情页标注按当前用户实时查 IDB 已为空），造成「菜单残留 + 点开无标注」现象。
    // P1-36: 捕获本 manager tab 的 tabId（扩展页免 tabs 权限可用）——SW 数据变更广播带 originTabId，
    // 自源写操作触发的广播跳过（自己 op 后已有刷新），只响应其它 tab/上下文的写入。
    var _managerTabId = null;
    try {
      chrome.tabs.getCurrent(function (t) { _managerTabId = (t && t.id != null) ? t.id : null; });
    } catch (e) { /* 非 tab 宿主时保持 null：退化为接收所有广播（最坏一次冗余自刷新） */ }
    var _wpzlDataChangedTimer = null;
    chrome.runtime.onMessage.addListener(function (message) {
      if (!message || !message.type) return;
      try {
        if (message.type === 'auth-state-changed' && message.isLoggedIn === false) {
          // 账号已登出 / 切换用户：清空内存状态，避免旧账号页面菜单残留，再跳登录页。
          // 与 SW 注释「manager 跳 auth.html」及 init 守卫一致；重开 manager 时 DOMContentLoaded 自然加载新账号。
          state.pages = [];
          state.currentPage = null;
          state.annotations = [];
          state.filteredAnnotations = [];
          state.activeTag = null;
          state.currentAuthor = null;
          state.activeFolderId = null;
          try { renderSidebar(); renderContent(); } catch (e) { /* ignore */ }
          location.replace(chrome.runtime.getURL('popup/auth.html'));
          return;
        }
        if (message.type === 'wpzl-sync-state' && message.state === 'online') {
          // 同步完成：先刷新再判定，避免过早清 awaitingFirstSync 导致竞态空态
          refreshPageCounts()
            .then(function () { return loadFolders(); })
            .then(function () { return refreshDocuments(); })
            .then(function () {
              if (!state.pages || state.pages.length === 0) {
                state.awaitingFirstSync = false;  // 确认无数据 → "暂无标注页面"
                try { renderSidebar(); } catch (e) {}
              }
            })
            .catch(function () { /* ignore */ });
          try { loadSyncFailures(); } catch (e) { /* ignore */ }
          return;
        }
        if (message.type === 'wpzl-sync-state' && message.state === 'syncing') {
          // 同步启动：侧栏仍空则保持等待状态（不限时轮询兜底）
          if (!state.pages || state.pages.length === 0) state.awaitingFirstSync = true;
          return;
        }
        if (message.type === 'wpzl-sync-exhausted') {
          // P1-14/P1-33：耗尽主动通知——toast 提示 + 立即刷新失败列表与角标，
          // 取代"依赖用户自己打开失败查看器"的被动发现（删除未同步/文档被拒等最终一致性问题）
          try {
            showToast(chrome.i18n.getMessage('syncExhaustedNotice') || '部分数据同步已停止自动重试，请查看同步失败列表');
            loadSyncFailures();
          } catch (e) { /* ignore */ }
          return;
        }
        if (message.type === 'wpzl-data-changed') {
          // P1-36: 其它 tab/上下文（另一个 manager tab、popup 等）写了数据 → 轻量失效重拉
          // （refreshPageCounts→loadFolders→refreshDocuments 三件套；打开中的详情视图不重渲染，
          // stale-while-revalidate）。自源跳过（originTabId === 本 tab）；300ms 去抖合并连续广播。
          if (message.originTabId != null && message.originTabId === _managerTabId) return;
          if (_wpzlDataChangedTimer) clearTimeout(_wpzlDataChangedTimer);
          _wpzlDataChangedTimer = setTimeout(function () {
            _wpzlDataChangedTimer = null;
            refreshPageCounts()
              .then(function () { return loadFolders(); })
              .then(function () { return refreshDocuments(); })
              .catch(function () { /* ignore */ });
          }, 300);
          return;
        }
        if (message.type === 'wpzl-sync-state' && message.state === 'offline') {
          // 脱机：同步无法进行，显示空态避免永久 spinner
          state.awaitingFirstSync = false;
          try { renderSidebar(); } catch (e) {}
          return;
        }
        if (message.type === 'wpzl-sync-state' && message.state === 'server_error') {
          // 服务端异常（探活可达但同步请求失败，已进入退避/熔断）：
          // 与 offline 分支同构——终止 awaitingFirstSync 让 1.2s 轮询自然停止（不再持续唤醒 SW），
          // 短暂提示后显示空态；累计失败明细交给失败查看器。
          state.awaitingFirstSync = false;
          var _seOverlay = _ensureSyncOverlay();
          var _seTextEl = _seOverlay.querySelector('.wpzl-sync-text');
          if (_seTextEl) {
            _seTextEl.textContent = (chrome.i18n.getMessage('syncServerError')
              || 'Server error · auto-sync paused, will retry later')
              + ' ' + (chrome.i18n.getMessage('syncServerErrorResume')
              || "Click 'Sync now' to retry immediately");
            setTimeout(function () { _hideSyncOverlay(); }, 4000);
          }
          try { renderSidebar(); } catch (e) {}
          try { loadSyncFailures(); } catch (e) {}
          return;
        }
        if (message.type === 'wpzl-sync-progress') {
          // D3：同步进行中 → 启动后台下载进度轮询，同步结束后捕获文档/图片后台下载阶段
          try { _startBgDownloadWatch(); } catch (e) { /* ignore */ }
          if (state.awaitingFirstSync && (!state.pages || state.pages.length === 0)) {
            var overlay = _ensureSyncOverlay();
            var textEl = overlay.querySelector('.wpzl-sync-text');
            if (textEl) {
              // 阶段切换：首次收到进度 → 显示 "正在同步数据… (N/Total 条)"
              if (message.total) {
                textEl.textContent = getMessage('syncingProgress', [String(message.pulled), String(message.total)]);
              } else if (message.pulled) {
                textEl.textContent = getMessage('syncingPulledOnly', [String(message.pulled)]);
              }
            }
            // 每个 cursor page 落盘后立即尝试渲染侧栏，不等 1.2s 轮询周期
            refreshPageCounts()
              .then(function () { return loadFolders(); })
              .then(function () { return refreshDocuments(); })
              .catch(function () {});
          }
          return;
        }
        if (message.type === 'wpzl-bg-download-progress') {
          // 2026-10-04：SW 推送退化为 nudge（无数据负载）——收到即立即向 SW 轮询
          // 'bg-download-progress'（会话累计 done + IDB 真值 remaining），单一事实来源，
          // 杜绝推送/轮询两个批作用域数据源渲染不一致。
          try { _refreshBgDownloadBar(); } catch (e) { /* ignore */ }
          return;
        }
        if (message.type === 'wpzl-sync-state' && message.state === 'token_expired') {
          _showManagerReauthDialog();
          return;
        }
        if (message.type === 'wpzl-pro-status-updated') {
          // SW 侧 pro 缓存已刷新（登录预热 / 6h alarm / 任意页面手动↻）→ 热更新等级与功能门控，
          // 后台改级后无需刷新页面即生效（历史 bug：manager 不监听此广播，缓存更新了页面也不知道）
          if (message.isLoggedIn === false) return;
          _mgrApplyProStatus({
            isPro: message.isPro,
            expiresAt: message.expiresAt,
            gradeConfig: message.gradeConfig,
            limits: message.limits,
            expiryReminderDays: (message.expiryReminderDays != null) ? message.expiryReminderDays : null
          });
          return;
        }
        if (message.type === 'wpzl-user-profile-updated') {
          // 改名/改密成功（本 tab 或其它 tab）→ 热更 chip 名 + 面板身份 + 改密表单显隐
          if (message.user) {
            _mgrCurrentUser = message.user;
            var _disp = message.user.name || message.user.loginId || 'U';
            var _mgrUserName = document.getElementById('mgrUserName');
            if (_mgrUserName) _mgrUserName.textContent = _disp;
            if (!_mgrAvatarDataUrl) {
              var _mgrUserAvatar = document.getElementById('mgrUserAvatar');
              if (_mgrUserAvatar) _mgrUserAvatar.textContent = _disp.charAt(0).toUpperCase();
            }
            _mgrFillPanelIdentity(message.user);
            _mgrApplyHasPassword(message.user.hasPassword);
          }
          return;
        }
        if (message.type === 'wpzl-avatar-updated') {
          // 头像上传成功（本 tab 或其它 tab）→ 热更 chip 与面板头像
          if (message.dataUrl) _mgrApplyAvatar(message.dataUrl);
          return;
        }
      } catch (e) {
        console.warn('[manager] onMessage handler error:', e && e.message);
      }
    });

    // 注："允许修改他人标注"已写死 true（state.allowEditOthers 默认值），不再读 storage —— 原设置开关已从 settings 页移除。

    // 加载当前等级的权限/限额配置（gradeConfig）—— 功能门控的唯一数据来源
    chrome.storage.local.get(['wpzl_auth', 'wpzl_pro_cache'], function (result) {
      var auth = result.wpzl_auth;
      if (auth && auth.user) {
        state.isLoggedIn = true;
      }
      // gradeConfig 由服务端按用户等级下发（各等级各有自己的 features / exportFormats / perTypeLimits …）。
      var proCache = result.wpzl_pro_cache;
      var gc = null;
      if (proCache && proCache.data) {
        var defaultGc = proCache.data.defaultGradeConfig || null;
        gc = proCache.data.gradeConfig || null;
        // 权益到期检查：只看 expiresAt（服务端到期已把 isPro 置 false，但 gradeConfig 仍是用户当前等级）；到期则降级到服务端默认等级配置。
        if (gc && proCache.data.expiresAt) {
          try {
            var expMs = _mgrProExpiryMs(proCache.data.expiresAt);
            if (!isNaN(expMs) && Date.now() >= expMs) gc = defaultGc;
          } catch (e) {}
        }
      }
      state.gradeConfig = gc || {};
      // limits 为服务端按 effective 等级计算的限额快照（含到期降级），客户端据此在创建文档前做强制（best-effort，服务端同步时仍权威）
      state.limits = (proCache && proCache.data && proCache.data.limits) || {};
      updateExportFormatUI();
      updateSyncButtonVisibility();

      // 渲染右上角用户信息条：用户名来自 wpzl_auth.user，等级/到期来自 wpzl_pro_cache.data
      if (auth && auth.user) {
        var _isPro = !!(proCache && proCache.data && proCache.data.isPro);
        var _expiresAt = (proCache && proCache.data && proCache.data.expiresAt) || null;
        var _reminderDays = (proCache && proCache.data && proCache.data.expiryReminderDays != null) ? proCache.data.expiryReminderDays : null;
        mgrRenderUser(auth.user, _isPro, _expiresAt, _reminderDays);
        // 横幅也先用缓存秒渲（下方 forceRefresh 回来后 _mgrApplyProStatus 会再评估一次；
        // 脱机时 forceRefresh 回落缓存数据，此处保证横幅仍能出现）
        _mgrUpdateExpiryBanner(proCache && proCache.data);
        // 分享管理菜单项：登录 + 当前等级授予 collaboration 才显示（分享属主 API 需 JWT 且需等级开通协作）
        _updateShareMgrItemVisibility();
        // 打开即向服务器核对等级：wpzl_pro_cache TTL 24h，后台改级后 F5 也应立即生效。
        // 先用缓存秒渲（上方 mgrRenderUser），响应回来后再热更新（失败静默保持缓存渲染）。
        chrome.runtime.sendMessage({ type: 'pro-status', forceRefresh: true }, function (resp) {
          if (resp && resp.success && resp.data) _mgrApplyProStatus(resp.data);
        });
      } else {
        // 本地模式（游客档，2026-09-29）：未登录 → 取 SW 游客档常量（与服务端免费档对齐，
        // 单一真相源 guest-grade-config）填 gradeConfig/limits；跳过 pro-status forceRefresh
        //（无 token）。cloudSync:false → 同步按钮隐藏（updateSyncButtonVisibility）；
        // collaboration:false + state.isLoggedIn=false → 分享管理项隐藏。
        chrome.runtime.sendMessage({ type: 'guest-grade-config' }, function (gresp) {
          if (gresp && gresp.success && gresp.data) {
            state.gradeConfig = gresp.data.gradeConfig || {};
            state.limits = gresp.data.limits || {};
            updateExportFormatUI();
            updateSyncButtonVisibility();
            _updateShareMgrItemVisibility();
          }
          _mgrRenderGuestChip();
        });
      }
    });

    // ---- 用户信息面板（点击右上角用户名展开）----
    function _mgrFillPanelIdentity(user) {
      if (!user) return;
      var displayName = user.name || user.loginId || 'U';
      var upName = document.getElementById('upName');
      var upLoginId = document.getElementById('upLoginId');
      var upEmail = document.getElementById('upEmail');
      var upFallback = document.getElementById('upAvatarFallback');
      if (upName) upName.textContent = displayName;
      if (upLoginId) upLoginId.textContent = user.loginId || '';
      if (upEmail) {
        if (user.email) { upEmail.textContent = user.email; upEmail.style.display = 'block'; }
        else upEmail.style.display = 'none';
      }
      if (upFallback && !_mgrAvatarDataUrl) upFallback.textContent = displayName.charAt(0).toUpperCase();
      _mgrApplyHasPassword(user.hasPassword);
      _mgrApplyMarketingOptIn(user.marketingEmailOptIn === true);
    }

    function _mgrApplyAvatar(dataUrl) {
      _mgrAvatarDataUrl = dataUrl || null;
      var chip = document.getElementById('mgrUserAvatar');
      var upImg = document.getElementById('upAvatarImg');
      var upFallback = document.getElementById('upAvatarFallback');
      var displayName = _mgrCurrentUser ? (_mgrCurrentUser.name || _mgrCurrentUser.loginId || 'U') : 'U';
      if (dataUrl) {
        if (chip) { chip.textContent = ''; chip.style.backgroundImage = 'url("' + dataUrl + '")'; chip.style.backgroundSize = 'cover'; chip.style.backgroundPosition = 'center'; }
        if (upImg) { upImg.src = dataUrl; upImg.style.display = 'block'; }
        if (upFallback) upFallback.style.display = 'none';
      } else {
        if (chip) { chip.style.backgroundImage = ''; chip.style.backgroundSize = ''; chip.style.backgroundPosition = ''; chip.textContent = displayName.charAt(0).toUpperCase(); }
        if (upImg) { upImg.removeAttribute('src'); upImg.style.display = 'none'; }
        if (upFallback) { upFallback.textContent = displayName.charAt(0).toUpperCase(); upFallback.style.display = ''; }
      }
    }

    function _mgrTogglePanel() {
      var panel = document.getElementById('userPanel');
      if (!panel) return;
      var willOpen = !panel.style.display || panel.style.display === 'none';
      if (willOpen) { panel.style.display = 'flex'; _mgrLoadPanel(); }
      else panel.style.display = 'none';
    }

    function _mgrLoadPanel() {
      _mgrLoadUsage();
      _mgrLoadAvatar();
      _mgrLoadMarketingOptIn();
    }

    // 产品更新邮件 opt-in 开关：设置勾选态并解锁（程序化赋 checked 不触发 change，无回环）
    function _mgrApplyMarketingOptIn(optIn) {
      var cb = document.getElementById('upMarketingOptIn');
      if (cb) { cb.checked = !!optIn; cb.disabled = false; }
    }

    // 面板打开时加载邮件偏好：先按 SW 缓存秒渲并锁定，再向服务器重拉兜底
    //（升级扩展前登录的旧会话 wpzl_auth.user 缺 marketingEmailOptIn 字段）；失败（脱机）解锁退回缓存值
    function _mgrLoadMarketingOptIn() {
      var cb = document.getElementById('upMarketingOptIn');
      if (cb) { cb.checked = !!(_mgrCurrentUser && _mgrCurrentUser.marketingEmailOptIn === true); cb.disabled = true; }
      chrome.runtime.sendMessage({ type: 'user-info-refresh' }, function (resp) {
        if (resp && resp.success && resp.data) {
          _mgrCurrentUser = resp.data;
          _mgrFillPanelIdentity(resp.data);
        } else if (cb) {
          cb.disabled = false;
        }
      });
    }

    function _mgrLoadAvatar() {
      chrome.runtime.sendMessage({ type: 'avatar-get' }, function (resp) {
        if (resp && resp.success) _mgrApplyAvatar(resp.data ? resp.data.dataUrl : null);
      });
    }

    // 限额/使用值格式化：-1 → ∞，0/缺省 → —，其余数字直出
    function _mgrFmtLimit(v) {
      if (v == null || v === '') return '—';
      var n = Number(v);
      if (n === -1) return '∞';
      if (n === 0) return '—';
      return String(v);
    }

    function _mgrFmtBytes(bytes) {
      if (bytes == null) return '—';
      var n = Number(bytes);
      if (n <= 0) return '0 B';
      if (n < 1024) return n + ' B';
      if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
      if (n < 1024 * 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB';
      return (n / 1024 / 1024 / 1024).toFixed(2) + ' GB';
    }

    function _mgrSetRow(dl, dtKey, ddText) {
      if (!dl) return;
      var dt = document.createElement('dt');
      dt.textContent = chrome.i18n.getMessage(dtKey) || dtKey;
      var dd = document.createElement('dd');
      dd.textContent = ddText;
      var row = document.createElement('div');
      row.className = 'user-panel-row';
      row.appendChild(dt); row.appendChild(dd);
      dl.appendChild(row);
    }

    // 使用情况加载失败态：面板此前静默 return 导致区域一直空白（服务端重启/网络抖动/SW 冷启动
    // 丢响应时用户无从得知），改为显示可点击重试行 + 存储条占位
    var _mgrUsageAutoRetried = false;
    function _mgrRenderUsageFailed(dl, fill, text) {
      if (fill) fill.style.width = '0%';
      if (text) text.textContent = '—';
      if (!dl) return;
      dl.innerHTML = '';
      var row = document.createElement('div');
      row.className = 'user-panel-row user-panel-row-failed';
      var dt = document.createElement('dt');
      dt.textContent = chrome.i18n.getMessage('userPanelUsageFailed') || 'Load failed, click to retry';
      var dd = document.createElement('dd');
      dd.textContent = '↻';
      row.appendChild(dt); row.appendChild(dd);
      row.addEventListener('click', function () { _mgrUsageAutoRetried = false; _mgrLoadUsage(); });
      dl.appendChild(row);
    }

    function _mgrLoadUsage(isAutoRetry) {
      var dl = document.getElementById('upUsageList');
      var fill = document.getElementById('upStorageFill');
      var text = document.getElementById('upStorageText');
      chrome.runtime.sendMessage({ type: 'user-usage' }, function (resp) {
        var lastErr = chrome.runtime.lastError; // 显式读取，抑制 Unchecked runtime.lastError 控制台噪音
        if (!resp || !resp.success || !resp.data) {
          _mgrRenderUsageFailed(dl, fill, text);
          // SW 冷启动时第一条消息的响应可能被丢弃：延迟自动重试一次；仍失败保留手动重试入口
          if (!_mgrUsageAutoRetried && isAutoRetry !== true) {
            _mgrUsageAutoRetried = true;
            setTimeout(function () { _mgrLoadUsage(true); }, 1500);
          }
          return;
        }
        _mgrUsageAutoRetried = false;
        var u = resp.data;
        var limits = state.limits || {};
        if (dl) {
          dl.innerHTML = '';
          _mgrSetRow(dl, 'userPanelMarks', u.markCount + ' / ' + _mgrFmtLimit(limits.markLimit));
          _mgrSetRow(dl, 'userPanelMarksToday', (u.dailyMarkCount || 0) + ' / ' + _mgrFmtLimit(limits.dailyMarkLimit));
          _mgrSetRow(dl, 'userPanelDocsToday', u.docCountToday + ' / ' + _mgrFmtLimit(limits.docLimit));
          if (u.docCountTotal > 0) _mgrSetRow(dl, 'userPanelDocsTotal', String(u.docCountTotal));
        }
        if (fill || text) {
          var used = u.storageUsedBytes || 0;
          var total = u.storageLimitBytes;
          // 无限额度判定：服务端 resolveLimitBytes 把 cloudStorageMb=-1 转成 Long.MAX_VALUE，
          // 客户端用 limits.cloudStorageMb === -1 才是可靠信号（Number.MAX_VALUE 与之不同）。
          var unlimited = (limits.cloudStorageMb === -1);
          var pct = 0;
          if (!unlimited && total && total > 0) {
            pct = Math.min(100, (used / total) * 100);
          }
          if (fill) fill.style.width = pct.toFixed(1) + '%';
          if (text) {
            text.textContent = _mgrFmtBytes(used) + ' / ' + (unlimited ? '∞' : _mgrFmtBytes(total));
          }
        }
      });
    }

    // ---- 游客信息弹窗（未登录：限额 / 本地使用情况 / 功能限制）----
    // 用量数据全走本地 IDB（游客不触网）：总量/页面数 getStatistics、当日新建 getDailyMarkCount、
    // 今日文档 getAllDocuments 本地按 createdAt 过滤；限额与每页类型上限读 state.limits/gradeConfig
    //（未登录时由 guest-grade-config 填充，与服务端免费档对齐，勿写死数字）。
    var _GUEST_PER_TYPE_LABEL_KEYS = {
      arrow: 'toolArrow', flag: 'toolFlag', rect: 'toolRect', pageRect: 'toolPageRect',
      line: 'toolLine', textAnnotation: 'toolText', imageAnnotation: 'toolImageAnno',
      rectFrame: 'toolRectFrame', elementMark: 'toolElementMark', highlight: 'typeHighlight'
    };

    // _mgrSetRow 的原生 label 变体（每页上限行 label 是 tool* 键名而非固定 i18n 键）
    function _mgrSetRowLabel(dl, label, ddText) {
      if (!dl) return;
      var dt = document.createElement('dt');
      dt.textContent = label;
      var dd = document.createElement('dd');
      dd.textContent = ddText;
      var row = document.createElement('div');
      row.className = 'user-panel-row';
      row.appendChild(dt); row.appendChild(dd);
      dl.appendChild(row);
    }

    function _mgrGuestRowUnavailable(dl, key) {
      _mgrSetRow(dl, key, '—');
    }

    function _mgrFillGuestInfo() {
      var limits = state.limits || {};
      var dl = document.getElementById('guestUsageList');
      if (dl) {
        dl.innerHTML = '';
        sendMessage('getStatistics').then(function (st) {
          st = st || {};
          _mgrSetRow(dl, 'userPanelMarks', String(st.totalAnnotations || 0) + ' / ' + _mgrFmtLimit(limits.markLimit));
          _mgrSetRow(dl, 'guestInfoPages', String(st.totalPages || 0) + ' / ' + _mgrFmtLimit(limits.pageLimit));
        }).catch(function () {
          _mgrGuestRowUnavailable(dl, 'userPanelMarks');
        });
        sendMessage('getDailyMarkCount').then(function (c) {
          var n = (c && typeof c.count === 'number') ? c.count : 0;
          _mgrSetRow(dl, 'userPanelMarksToday', String(n) + ' / ' + _mgrFmtLimit(limits.dailyMarkLimit));
        }).catch(function () {
          _mgrGuestRowUnavailable(dl, 'userPanelMarksToday');
        });
        sendMessage('getAllDocuments').then(function (docs) {
          // 今日新建口径与创建门禁一致（manager 建档检查按本地日过滤 createdAt）
          var prefix = _todayDatePrefix();
          var n = 0;
          (docs || []).forEach(function (d) {
            if (!d || typeof d.createdAt !== 'string') return;
            var dd = parseStoredTime(d.createdAt);
            if (isNaN(dd.getTime())) return;
            var mm = String(dd.getMonth() + 1).padStart(2, '0');
            var day = String(dd.getDate()).padStart(2, '0');
            if (dd.getFullYear() + '-' + mm + '-' + day === prefix) n++;
          });
          _mgrSetRow(dl, 'userPanelDocsToday', String(n) + ' / ' + _mgrFmtLimit(limits.docLimit));
        }).catch(function () {
          _mgrGuestRowUnavailable(dl, 'userPanelDocsToday');
        });
      }
      var pdl = document.getElementById('guestPerPageList');
      if (pdl) {
        pdl.innerHTML = '';
        var ptl = (state.gradeConfig && state.gradeConfig.perTypeLimits) || {};
        // 按相同 limitPerPage 分组合并（免费档除高亮外全部 5/页，逐项罗列冗长——同值并作一行文字描述）。
        // 通用逻辑：配置值互不相同时自然退化为逐项罗列，不写死任何分组。
        var groupList = [];   // { lim, labels:[] }，按 _GUEST_PER_TYPE_LABEL_KEYS 定义序首次出现排列
        var groupIdx = {};
        Object.keys(_GUEST_PER_TYPE_LABEL_KEYS).forEach(function (k) {
          var cfg = ptl[k];
          if (!cfg || cfg.enabled === false) return;
          var label = chrome.i18n.getMessage(_GUEST_PER_TYPE_LABEL_KEYS[k]) || k;
          var lim = (typeof cfg.limitPerPage === 'number') ? cfg.limitPerPage : -1;
          if (!(lim in groupIdx)) { groupIdx[lim] = groupList.length; groupList.push({ lim: lim, labels: [] }); }
          groupList[groupIdx[lim]].labels.push(label);
        });
        groupList.forEach(function (g) {
          _mgrSetRowLabel(pdl, g.labels.join(' / '), _mgrFmtLimit(g.lim));
        });
      }
      var rl = document.getElementById('guestRestrictList');
      if (rl) {
        rl.innerHTML = '';
        ['guestRestrictDoc', 'guestRestrictSync', 'guestRestrictShare', 'guestRestrictSnapshot',
         'guestRestrictImage', 'guestRestrictExport'].forEach(function (k) {
          var li = document.createElement('li');
          li.textContent = chrome.i18n.getMessage(k) || k;
          rl.appendChild(li);
        });
      }
    }

    function _mgrOpenGuestInfo() {
      var m = document.getElementById('guestInfoModal');
      if (!m) return;
      m.style.display = 'flex';
      _mgrFillGuestInfo();
    }

    function _mgrCloseGuestInfo() {
      var m = document.getElementById('guestInfoModal');
      if (m) m.style.display = 'none';
    }

    var guestInfoModal = document.getElementById('guestInfoModal');
    if (guestInfoModal) {
      guestInfoModal.addEventListener('click', function (e) {
        if (e.target === guestInfoModal) _mgrCloseGuestInfo();
      });
      var guestInfoCloseBtn = document.getElementById('guestInfoCloseBtn');
      if (guestInfoCloseBtn) guestInfoCloseBtn.addEventListener('click', _mgrCloseGuestInfo);
      var guestInfoLoginBtn = document.getElementById('guestInfoLoginBtn');
      if (guestInfoLoginBtn) {
        guestInfoLoginBtn.addEventListener('click', function () {
          _mgrCloseGuestInfo();
          chrome.runtime.sendMessage({ type: 'wpzl-open-auth' }).catch(function () { /* ignore */ });
        });
      }
    }

    // 功能菜单「我的信息」钩子（initEvents 作用域不可见本闭包，同 mgrOpenShareManagerFn 模式）：
    // 登录→账号面板；未登录（游客 chip）→游客信息弹窗。与点右上角用户名行为完全一致。
    mgrOpenMyInfoFn = function () {
      if (mgrUserChip && mgrUserChip.classList.contains('mgr-guest-chip')) _mgrOpenGuestInfo();
      else _mgrTogglePanel();
    };

    if (mgrUserChip) {
      mgrUserChip.addEventListener('click', function (e) {
        if (e.target.closest && e.target.closest('#mgrRefreshUserBtn')) return; // ↻ 刷新按钮原逻辑不劫持
        // 本地模式（游客档）：游客无账号可管理（账号面板全是需登录的 API），点击展开
        // 游客信息弹窗（限额/本地使用情况/功能限制），提示信息比单条 toast 完整。
        if (mgrUserChip.classList.contains('mgr-guest-chip')) {
          _mgrOpenGuestInfo();
          return;
        }
        _mgrTogglePanel();
      });
    }

    // 上传头像：选文件 → 客户端压缩（max 512px webp）→ SW 上传 → 本地回显
    var upAvatarFileInput = document.getElementById('upAvatarFileInput');
    var upAvatarUploadBtn = document.getElementById('upAvatarUploadBtn');
    if (upAvatarUploadBtn && upAvatarFileInput) {
      upAvatarUploadBtn.addEventListener('click', function () { upAvatarFileInput.click(); });
      upAvatarFileInput.addEventListener('change', function () {
        var f = upAvatarFileInput.files && upAvatarFileInput.files[0];
        upAvatarFileInput.value = '';
        if (!f) return;
        _mgrCompressAvatarFile(f).then(function (dataUrl) {
          return chrome.runtime.sendMessage({ type: 'avatar-upload', dataUrl: dataUrl })
            .then(function (resp) {
              if (resp && resp.success) {
                _mgrApplyAvatar(dataUrl); // 直接用已压缩 dataUrl 本地回显（广播也会带同一 dataUrl 热更其它 tab）
                showToast(chrome.i18n.getMessage('userPanelAvatarSaved') || '头像已更新');
              } else {
                showToast((resp && resp.error) || (chrome.i18n.getMessage('userPanelAvatarTooLarge') || '头像更新失败'));
              }
            });
        }).catch(function () {
          showToast(chrome.i18n.getMessage('userPanelAvatarTooLarge') || '头像更新失败');
        });
      });
    }

    // 客户端头像压缩：等比缩 max 512px（只缩不放大）→ webp（不支持回退 jpeg）。
    function _mgrCompressAvatarFile(file) {
      var MAX = 512;
      return new Promise(function (resolve, reject) {
        try {
          if (!window.createImageBitmap) {
            // 兜底：无 createImageBitmap 时直接读 dataURL 上传（服务端仍会校验类型/大小）
            var fr = new FileReader();
            fr.onload = function () { resolve(fr.result); };
            fr.onerror = function () { reject(new Error('read failed')); };
            fr.readAsDataURL(file);
            return;
          }
          createImageBitmap(file).then(function (bmp) {
            var w = bmp.width, h = bmp.height;
            var scale = Math.min(1, MAX / Math.max(w, h));
            var tw = Math.max(1, Math.round(w * scale));
            var th = Math.max(1, Math.round(h * scale));
            var canvas = document.createElement('canvas');
            canvas.width = tw; canvas.height = th;
            var ctx = canvas.getContext('2d');
            ctx.drawImage(bmp, 0, 0, tw, th);
            bmp.close();
            var dataUrl = canvas.toDataURL('image/webp', 0.85);
            if (!dataUrl || dataUrl.indexOf('data:image/webp') !== 0) {
              dataUrl = canvas.toDataURL('image/jpeg', 0.85);
            }
            resolve(dataUrl);
          }).catch(function () {
            var fr2 = new FileReader();
            fr2.onload = function () { resolve(fr2.result); };
            fr2.onerror = function () { reject(new Error('read failed')); };
            fr2.readAsDataURL(file);
          });
        } catch (e) { reject(e); }
      });
    }

    // 改名表单
    var upNameForm = document.getElementById('upNameForm');
    if (upNameForm) {
      upNameForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var input = document.getElementById('upNameInput');
        var name = (input && input.value) ? input.value.trim() : '';
        if (!name) return;
        var btn = upNameForm.querySelector('button[type="submit"]');
        if (btn) btn.disabled = true;
        chrome.runtime.sendMessage({ type: 'user-profile-update', name: name }, function (resp) {
          if (btn) btn.disabled = false;
          if (resp && resp.success) {
            if (input) input.value = '';
            showToast(chrome.i18n.getMessage('userPanelNameSaved') || '名称已保存');
            // chip 名与面板身份由 wpzl-user-profile-updated 广播热更（本 tab 亦会收到）
          } else {
            showToast((resp && resp.error) || getMessage('savingFailed'));
          }
        });
      });
    }

    // 改密表单：hasPassword=false（OAuth-only）时隐藏旧密码框并改文案为「设置密码」
    function _mgrApplyHasPassword(hasPassword) {
      var oldPwd = document.getElementById('upOldPwd');
      var title = document.getElementById('upPwdTitle');
      var submit = document.getElementById('upPwdSubmitBtn');
      var setPwd = hasPassword === false;
      if (oldPwd) oldPwd.style.display = setPwd ? 'none' : '';
      var label = setPwd
        ? (chrome.i18n.getMessage('userPanelSetPassword') || '设置密码')
        : (chrome.i18n.getMessage('userPanelChangePassword') || '修改密码');
      if (title) title.textContent = label;
      if (submit) submit.textContent = label;
    }

    var upPwdForm = document.getElementById('upPwdForm');
    if (upPwdForm) {
      upPwdForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var oldPwd = document.getElementById('upOldPwd');
        var newPwd = document.getElementById('upNewPwd');
        var newPwd2 = document.getElementById('upNewPwd2');
        var newVal = newPwd ? newPwd.value : '';
        var newVal2 = newPwd2 ? newPwd2.value : '';
        if (newVal !== newVal2) {
          showToast(chrome.i18n.getMessage('userPanelPasswordMismatch') || '两次输入的新密码不一致');
          return;
        }
        // 密码最低强度：8-100 位且同时包含字母和数字（与服务端 PasswordPolicy 同规则）
        if (!/^(?=.*[A-Za-z])(?=.*\d).{8,100}$/.test(newVal)) {
          showToast(chrome.i18n.getMessage('authPwdWeak') || '密码至少 8 位，且需同时包含字母和数字。');
          return;
        }
        var btn = upPwdForm.querySelector('button[type="submit"]');
        if (btn) btn.disabled = true;
        chrome.runtime.sendMessage({ type: 'user-password-change', currentPassword: oldPwd ? oldPwd.value : '', newPassword: newVal }, function (resp) {
          if (btn) btn.disabled = false;
          if (resp && resp.success) {
            if (oldPwd) oldPwd.value = '';
            if (newPwd) newPwd.value = '';
            if (newPwd2) newPwd2.value = '';
            showToast(chrome.i18n.getMessage('userPanelPasswordSaved') || '密码已更新');
          } else {
            showToast((resp && resp.error) || getMessage('mgChangeFailed'));
          }
        });
      });
    }

    // 产品更新邮件偏好开关：提交期间锁定；成功 toast（勾选态由 wpzl-user-profile-updated 广播
    //→ _mgrFillPanelIdentity → _mgrApplyMarketingOptIn 回设并解锁）；失败回滚到变更前状态
    var upMarketingOptIn = document.getElementById('upMarketingOptIn');
    if (upMarketingOptIn) {
      upMarketingOptIn.addEventListener('change', function () {
        var next = upMarketingOptIn.checked;
        upMarketingOptIn.disabled = true;
        chrome.runtime.sendMessage({ type: 'user-marketing-email-update', optIn: next }, function (resp) {
          if (resp && resp.success) {
            showToast(chrome.i18n.getMessage('userPanelMarketingSaved') || '邮件偏好已保存');
            // 勾选态/解锁主链路走 wpzl-user-profile-updated 广播；此处直接回设一次兜底广播丢失（幂等）
            _mgrApplyMarketingOptIn(!!(resp.data && resp.data.marketingEmailOptIn));
          } else {
            upMarketingOptIn.checked = !next;
            upMarketingOptIn.disabled = false;
            showToast((resp && resp.error) || chrome.i18n.getMessage('userPanelMarketingSaveFailed') || '邮件偏好保存失败');
          }
        });
      });
    }

    // ---- 支付：购买（新标签打开收银台 + 轮询到账）/ 我的订单 / 退款申请 ----

    // 我的订单 modal
    function _mgrPayOrderStatusText(o) {
      var map = { CREATED: 'payOrderStatusCreated', PAID: 'payOrderStatusPaid', EXPIRED: 'payOrderStatusExpired', CLOSED: 'payOrderStatusClosed' };
      var text = chrome.i18n.getMessage(map[o.status] || 'payOrderStatusCreated') || o.status;
      if (o.refundStatus === 'REQUESTED') text += ' · ' + (chrome.i18n.getMessage('payRefundRequested') || '');
      else if (o.refundStatus === 'APPROVED' || o.refundStatus === 'TICKET_CREATED') text += ' · ' + (chrome.i18n.getMessage('payRefundProcessing') || '');
      else if (o.refundStatus === 'REFUNDED') text += ' · ' + (chrome.i18n.getMessage('payRefundRefunded') || '');
      else if (o.refundStatus === 'REJECTED') text += ' · ' + (chrome.i18n.getMessage('payRefundRejected') || '');
      else if (o.refundStatus === 'REFUND_FAILED') text += ' · ' + (chrome.i18n.getMessage('payRefundFailed') || '');
      return text;
    }

    function _mgrRenderPayOrders(orders) {
      var body = document.getElementById('payOrdersBody');
      if (!body) return;
      body.innerHTML = '';
      if (!orders || !orders.length) {
        var empty = document.createElement('div');
        empty.className = 'pay-orders-empty';
        empty.textContent = chrome.i18n.getMessage('payOrdersEmpty') || '';
        body.appendChild(empty);
        return;
      }
      orders.forEach(function (o) {
        var row = document.createElement('div');
        row.className = 'pay-order-row';
        var info = document.createElement('div');
        info.className = 'pay-order-info';
        var name = document.createElement('div');
        name.className = 'pay-order-name';
        name.textContent = o.productName || o.productCode || o.orderNo;
        var sub = document.createElement('div');
        sub.className = 'pay-order-sub';
        var created = _tsMin(o.createdAt);
        sub.textContent = created + ' · ' + (o.durationDays != null ? o.durationDays + ' ' + (chrome.i18n.getMessage('payDays') || 'd') : '');
        info.appendChild(name);
        info.appendChild(sub);
        var mid = document.createElement('div');
        mid.className = 'pay-order-mid';
        var amount = document.createElement('div');
        amount.className = 'pay-order-amount';
        amount.textContent = (o.currency || '') + ' ' + (o.amount || '');
        var status = document.createElement('div');
        status.className = 'pay-order-status s-' + (o.status || '').toLowerCase();
        status.textContent = _mgrPayOrderStatusText(o);
        mid.appendChild(amount);
        mid.appendChild(status);
        row.appendChild(info);
        row.appendChild(mid);
        if (o.canRefund) {
          var btn = document.createElement('button');
          btn.className = 'btn btn-cancel pay-order-refund-btn';
          btn.textContent = chrome.i18n.getMessage('payRefundBtn') || '';
          btn.addEventListener('click', function () { _mgrRefundClick(o.orderNo); });
          row.appendChild(btn);
        }
        body.appendChild(row);
      });
    }

    function _mgrLoadPayOrders() {
      var body = document.getElementById('payOrdersBody');
      if (!body) return;
      body.innerHTML = '<div class="pay-orders-empty">…</div>';
      chrome.runtime.sendMessage({ type: 'payment-orders', limit: 50 }, function (resp) {
        if (!document.getElementById('payOrdersBody')) return;
        if (!(resp && resp.success)) {
          body.innerHTML = '';
          var err = document.createElement('div');
          err.className = 'pay-orders-empty';
          err.textContent = chrome.i18n.getMessage('payOrdersLoadFailed') || '';
          body.appendChild(err);
          return;
        }
        _mgrRenderPayOrders(resp.data);
      });
    }

    function _mgrRefundClick(orderNo) {
      if (!window.confirm(chrome.i18n.getMessage('payRefundConfirm') || '')) return;
      var reason = window.prompt(chrome.i18n.getMessage('payRefundReasonPrompt') || '', '');
      if (reason === null) return; // 取消
      chrome.runtime.sendMessage({ type: 'payment-refund', orderNo: orderNo, reason: reason || '' }, function (resp) {
        if (resp && resp.success) {
          showToast(chrome.i18n.getMessage('payRefundRequestedToast') || '');
        } else {
          var code = resp && resp.serverCode;
          showToast(code === 40320
            ? (chrome.i18n.getMessage('payRefundWindowClosed') || '')
            : ((resp && resp.error) || getMessage('payCreateFailed')));
        }
        _mgrLoadPayOrders();
      });
    }

    var upOrdersBtn = document.getElementById('upOrdersBtn');
    if (upOrdersBtn) {
      upOrdersBtn.addEventListener('click', function () {
        var modal = document.getElementById('payOrdersModal');
        if (!modal) return;
        modal.style.display = 'flex';
        _mgrLoadPayOrders();
      });
    }
    var _payOrdersCloseBtn = document.getElementById('payOrdersCloseBtn');
    if (_payOrdersCloseBtn) {
      _payOrdersCloseBtn.addEventListener('click', function () {
        var modal = document.getElementById('payOrdersModal');
        if (modal) modal.style.display = 'none';
      });
    }
    var _payOrdersModalEl = document.getElementById('payOrdersModal');
    if (_payOrdersModalEl) {
      _payOrdersModalEl.addEventListener('click', function (e) {
        if (e.target === _payOrdersModalEl) _payOrdersModalEl.style.display = 'none';
      });
    }

    // 登记 manager 所在 tabId：SW/popup 复用 tab 用（免 "tabs" 权限的登记制，详见 SW
    // _wpzlGetRegisteredTab 注释——无权限时 tabs.query 按 url 匹配自身扩展页会落空）。
    // pagehide 除名：F5 会先除名再由本块重新登记（自愈）；跳 auth.html 登录页时除名，
    // 避免登记表把「已变成登录页的 tab」误当 manager 聚焦。
    // 双实例互斥（2026-11-05）：本地模式下未登录打开 manager → 页内入口登录是新开 auth tab，
    // 登录成功 auth.html replace 成 manager 会产生第二个实例。新实例登记时发现登记表指向
    // 别的 tab（旧 manager 还活着）→ 关掉旧 tab，保证至多一个 manager。关旧后延迟登记：
    // 旧 tab 卸载的 pagehide 无条件除名 + SW onRemoved 除名先清掉旧值，避免刚写入就被删。
    try {
      chrome.tabs.getCurrent(function (tab) {
        if (!tab || tab.id == null) return;
        chrome.storage.session.get(['wpzl_mgr_tab_id'], function (r) {
          var oldId = r && r.wpzl_mgr_tab_id;
          if (oldId != null && oldId !== tab.id) {
            try {
              chrome.tabs.remove(oldId, function () { void chrome.runtime.lastError; /* 旧 id 已失效则忽略 */ });
            } catch (e) { /* ignore */ }
            setTimeout(function () {
              try { chrome.storage.session.set({ wpzl_mgr_tab_id: tab.id }); } catch (e) { /* ignore */ }
            }, 800);
          } else {
            chrome.storage.session.set({ wpzl_mgr_tab_id: tab.id });
          }
        });
      });
      window.addEventListener('pagehide', function () {
        try { chrome.storage.session.remove('wpzl_mgr_tab_id'); } catch (e) { /* ignore */ }
      });
    } catch (e) { /* ignore */ }

    // #pay-orders 深链（升级弹窗「我的订单」入口直达）：打开订单 modal 并加载最新列表。
    // 触发路径有三种：建 tab 首载 / F5 带 hash 重载 / 已开 tab 被 tabs.update 仅改 hash 重导航
    // （同文档导航不重载页面，必须靠 hashchange 才能接住）。
    // 打开后立刻清掉 hash：hash 常驻会让 F5 每次都自动弹订单页，且同 hash 再导航不会再触发 hashchange。
    function _mgrOpenPayOrdersDeepLink() {
      if (window.location.hash !== '#pay-orders') return;
      try { history.replaceState(null, '', location.pathname + location.search); } catch (e) { /* ignore */ }
      var modal = document.getElementById('payOrdersModal');
      if (modal && (!modal.style.display || modal.style.display === 'none')) {
        modal.style.display = 'flex';
        _mgrLoadPayOrders();
      }
    }
    window.addEventListener('hashchange', _mgrOpenPayOrdersDeepLink);
    _mgrOpenPayOrdersDeepLink();

    // #export-all 深链（settings / auth 四处「去备份 / 导出」入口直达「导出全部」弹框，2026-10-04）：
    // 触发路径同 #pay-orders 三种。与 #pay-orders 的差异：导出全部弹框的 scope label 依赖
    // state.pages（页面总数），首载时数据未就绪——这里立即调用会显示 "(0 个页面)"，故首载/F5
    // 路径由初始加载链完成后调用（见下方 refreshPageCounts().then 链尾），本处只注册
    // hashchange 接住「已开 tab 被 tabs.update 仅改 hash」路径（state.pages 此时已就绪）。
    // 打开后立刻清掉 hash：防 F5 每次自动弹导出框（同 #pay-orders 的理由）。
    function _mgrOpenExportAllDeepLink() {
      if (window.location.hash !== '#export-all') return;
      try { history.replaceState(null, '', location.pathname + location.search); } catch (e) { /* ignore */ }
      var exportModalEl = document.getElementById('exportModal');
      if (exportModalEl && (!exportModalEl.style.display || exportModalEl.style.display === 'none')) {
        openExportModal('all');
      }
    }
    window.addEventListener('hashchange', _mgrOpenExportAllDeepLink);

    // 顶栏「购买 Pro」一级入口：打开升级弹窗（与 popup / 注入面板更多菜单同一 SW 消息）
    var mgrUpgradeBtn = document.getElementById('mgrUpgradeBtn');
    if (mgrUpgradeBtn) {
      mgrUpgradeBtn.addEventListener('click', function (e) {
        // 防 document 级 userPanel 关闭器（点击 .user-menu-wrapper 外部即关）误判点击
        e.stopPropagation();
        chrome.runtime.sendMessage({ type: 'wpzl-open-upgrade' });
      });
    }

    // Sync failures 按钮（计划 D16/D17）：打开同步失败查看器
    var syncFailuresBtn = document.getElementById('syncFailuresBtn');
    if (syncFailuresBtn) {
      syncFailuresBtn.addEventListener('click', function () {
        var modal = document.getElementById('syncFailuresModal');
        if (modal) modal.style.display = 'flex';
        loadSyncFailures();
        // P1-14/33：用户已查看 → 清除 popup 用的未读耗尽标志
        try { chrome.storage.local.remove('wpzl_exhausted_notify'); } catch (e) { /* ignore */ }
      });
      // 初始加载徽标（同步或图片上云用户）
      loadSyncFailures();
    }
    var _sfCloseBtn = document.getElementById('syncFailuresCloseBtn');
    if (_sfCloseBtn) {
      _sfCloseBtn.addEventListener('click', function () {
        var modal = document.getElementById('syncFailuresModal');
        if (modal) modal.style.display = 'none';
      });
    }
    var _sfRetryAllBtn = document.getElementById('sfRetryAllBtn');
    if (_sfRetryAllBtn) {
      _sfRetryAllBtn.addEventListener('click', function () {
        if (_sfRetryAllBtn.disabled) return;
        _sfRetryAllBtn.disabled = true;
        _sfRetryAllBtn.classList.add('is-loading');
        retryUploadAllFn([]).then(function () {
          _sfRetryAllBtn.classList.remove('is-loading');
          // 按当前 state 重算禁用态：无条件 disabled=false 会在 0 可重试项时误亮按钮
          updateSyncFailuresBadge();
        }).catch(function () {
          _sfRetryAllBtn.classList.remove('is-loading');
          updateSyncFailuresBadge();
        });
      });
    }
    // 列表内单项操作（事件委托）：retry=重传，discard=放弃上传（保留本地数据，移出队列）
    function _sfDelegateClick(e) {
      var btn = e.target.closest('[data-sf-action]');
      if (!btn) return;
      var action = btn.getAttribute('data-sf-action');
      if (action !== 'retry' && action !== 'discard' && action !== 'upgrade') return;
      if (action === 'upgrade') {
        // 与顶栏「购买 Pro」同一 SW 消息（无具名函数可复用，顶栏入口即 inline 发送）
        chrome.runtime.sendMessage({ type: 'wpzl-open-upgrade' });
        return;
      }
      var kind = btn.getAttribute('data-kind');
      var id = btn.getAttribute('data-id');
      var store = btn.getAttribute('data-store') || '';
      var thumbPending = btn.getAttribute('data-thumbpending') === '1';
      btn.disabled = true;
      btn.classList.add('is-loading');
      var fn = action === 'discard' ? discardUploadItem : retryUploadItem;
      fn({ kind: kind, id: id, store: store, thumbPending: thumbPending })
        .then(function () {
          btn.classList.remove('is-loading');
          btn.disabled = false;
        })
        .catch(function () {
          btn.classList.remove('is-loading');
          btn.disabled = false;
        });
    }
    var _sfMarksEl = document.getElementById('syncFailuresMarks');
    var _sfImagesEl = document.getElementById('syncFailuresImages');
    if (_sfMarksEl) _sfMarksEl.addEventListener('click', _sfDelegateClick);
    if (_sfImagesEl) _sfImagesEl.addEventListener('click', _sfDelegateClick);

    // ---- Share management modal（分享管理：跨页集中管理本人全部分享）----
    // 右侧=按 webUri 分组的页面列表，左侧=选中页面的分享卡片；过滤器 全部/有效/无效。
    var SM = { all: [], filter: 'all', selected: null, editingId: null, serverBase: '', search: '' };
    var SM_PERMS = [
      { bit: 1, cls: 'view',   icon: '👁', key: 'sharePermView' },
      { bit: 2, cls: 'create', icon: '✏️', key: 'sharePermCreate' },
      { bit: 4, cls: 'reply',  icon: '💬', key: 'sharePermReply' },
      { bit: 8, cls: 'edit',   icon: '✍️', key: 'sharePermEdit' }
    ];
    // 有效期可选项 = 等级配置 shareExpiryDayOptions（state.gradeConfig 已含到期降级，照
    // canExportFormat 回退模式）；等级未配置/为空时回退与服务端出厂默认同值的集合。
    function smExpiryOptions() {
      var opts = state.gradeConfig && state.gradeConfig.shareExpiryDayOptions;
      return (opts && opts.length) ? opts : [1, 3, 7, 15, 30];
    }

    function smT(key, subs, fallback) {
      var m = chrome.i18n.getMessage(key, subs);
      return m || (fallback != null ? fallback : key);
    }
    function smSend(type, extra) {
      return new Promise(function (resolve, reject) {
        chrome.runtime.sendMessage(Object.assign({ type: type }, extra || {}), function (r) {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          if (r && r.success) return resolve(r.data);
          // serverCode 透传到 Error 上（40001=V69 活跃分享数配额等），供 catch 分流本地化文案
          var e = new Error((r && r.error) || 'FAILED');
          if (r && typeof r.serverCode === 'number') e.serverCode = r.serverCode;
          reject(e);
        });
      });
    }
    // 40001 配额 → 本地化文案（服务端消息为固定中文未走 shareI18n）；其余保留 前缀+服务端消息
    function smShareErrText(err, prefixKey, prefixFallback) {
      if (err && err.serverCode === 40001) {
        var cap = /上限\s*(\d+)/.exec((err && err.message) || '');
        return cap ? smT('shareLimitToast', [cap[1]], null) : smT('shareLimitToastNoLimit', null, null);
      }
      return smT(prefixKey, null, prefixFallback) + (err && err.message ? ': ' + err.message : '');
    }
    // 无效口径：已过期或已禁用（与链接实际 404/410 表现一致）
    function smIsInvalid(s) { return !!s.expired || s.isActive === false; }
    function smShareUrl(s) {
      return (SM.serverBase || '').replace(/\/+$/, '') + '/share/' + (s.code || '');
    }
    function smFmtTime(iso) { return _tsMin(iso); }

    // 按当前过滤器取组内可见分享；'active' 下组内有效数为 0 则整组隐藏
    function smVisibleShares(group) {
      if (SM.filter === 'active') return group.shares.filter(function (s) { return !smIsInvalid(s); });
      if (SM.filter === 'invalid') return group.shares.filter(function (s) { return smIsInvalid(s); });
      return group.shares;
    }

    // SM.all → 按 webUri 分组；组排序日期=组内最新分享 createdAt（最后一次分享该页的时间），按最新分享日期倒序
    function smBuildGroups() {
      var byUri = {};
      var order = [];
      SM.all.forEach(function (s) {
        if (!s || !s.webUri) return;
        var g = byUri[s.webUri];
        if (!g) {
          g = byUri[s.webUri] = { webUri: s.webUri, title: '', host: '', shares: [], created: '' };
          order.push(g);
        }
        g.shares.push(s);
        if (!g.title && s.title) g.title = s.title;
        if (!g.host && s.originHost) g.host = s.originHost;
        if (s.createdAt && (g.created === '' || s.createdAt > g.created)) g.created = s.createdAt;
      });
      order.forEach(function (g) {
        if (!g.title) g.title = g.webUri;
        if (!g.host) g.host = (g.webUri.split('/')[0] || '').trim();
        g.activeN = g.shares.filter(function (s) { return !smIsInvalid(s); }).length;
        g.invalidN = g.shares.length - g.activeN;
      });
      order.sort(function (a, b) { return a.created < b.created ? 1 : (a.created > b.created ? -1 : 0); });
      return order;
    }

    // 组是否命中搜索（标题 / webUri 不区分大小写子串）
    function smMatchSearch(g) {
      var q = (SM.search || '').toLowerCase();
      if (!q) return true;
      return (g.title || '').toLowerCase().indexOf(q) >= 0
        || (g.webUri || '').toLowerCase().indexOf(q) >= 0;
    }

    // 当前选中失效（被过滤/搜索隐藏）时重选第一个可见组
    function smPickSelection(groups) {
      var cur = groups.filter(function (g) { return g.webUri === SM.selected; })[0];
      if (cur && smVisibleShares(cur).length && smMatchSearch(cur)) return;
      SM.selected = null;
      for (var i = 0; i < groups.length; i++) {
        if (smVisibleShares(groups[i]).length && smMatchSearch(groups[i])) { SM.selected = groups[i].webUri; break; }
      }
    }

    function smLoad() {
      var pagesEl = document.getElementById('shareMgrPages');
      var detailEl = document.getElementById('shareMgrDetail');
      if (!pagesEl || !detailEl) return;
      detailEl.innerHTML = '';
      var loading = document.createElement('div');
      loading.className = 'share-mgr-loading';
      loading.textContent = smT('shareLoading', null, '加载中…');
      detailEl.appendChild(loading);
      smSend('wpzl-list-shares').then(function (list) {
        SM.all = Array.isArray(list) ? list : [];
        var groups = smBuildGroups();
        smPickSelection(groups);
        smRenderPages(groups);
        smRenderDetail(groups);
      }).catch(function (err) {
        detailEl.innerHTML = '';
        var fail = document.createElement('div');
        fail.className = 'share-mgr-empty';
        fail.textContent = smT('shareMgrLoadFailed', null, '加载分享失败') + (err && err.message ? ': ' + err.message : '');
        detailEl.appendChild(fail);
      });
    }

    function smRenderPages(groups) {
      var pagesEl = document.getElementById('shareMgrPages');
      if (!pagesEl) return;
      pagesEl.innerHTML = '';
      var visible = groups.filter(function (g) { return smVisibleShares(g).length && smMatchSearch(g); });
      // 顶部计数：N 个页面 / M 条分享（按当前过滤口径）
      var summaryEl = document.getElementById('shareMgrSummary');
      if (summaryEl) {
        var total = 0;
        visible.forEach(function (g) { total += smVisibleShares(g).length; });
        summaryEl.textContent = visible.length
          ? smT('shareMgrSummary', [String(visible.length), String(total)], visible.length + ' 个页面 / ' + total + ' 条分享')
          : '';
      }
      if (!visible.length) {
        var empty = document.createElement('div');
        empty.className = 'share-mgr-empty';
        empty.textContent = SM.search ? smT('shareMgrSearchEmpty', null, '无匹配页面') : smT('shareMgrEmpty', null, '暂无分享');
        pagesEl.appendChild(empty);
        return;
      }
      visible.forEach(function (g) {
        var item = document.createElement('div');
        item.className = 'share-mgr-page-item' + (g.webUri === SM.selected ? ' active' : '');
        item.setAttribute('data-sm-weburi', g.webUri);
        var title = document.createElement('div');
        title.className = 'share-mgr-page-title';
        title.textContent = g.title || g.webUri;
        title.title = g.title || g.webUri;
        var host = document.createElement('div');
        host.className = 'share-mgr-page-host';
        host.textContent = g.host || '';
        host.title = g.webUri;
        var meta = document.createElement('div');
        meta.className = 'share-mgr-page-meta';
        var date = document.createElement('span');
        date.textContent = _tsDate(g.created);
        var count = document.createElement('span');
        count.className = 'share-mgr-page-count' + (g.invalidN > 0 && g.activeN === 0 ? ' has-invalid' : '');
        count.textContent = smT('shareMgrActiveCount', [String(g.activeN)], '有效' + g.activeN)
          + ' / ' + smT('shareMgrInvalidCount', [String(g.invalidN)], '无效' + g.invalidN);
        meta.appendChild(date); meta.appendChild(count);
        item.appendChild(title); item.appendChild(host); item.appendChild(meta);
        pagesEl.appendChild(item);
      });
    }

    function smPermChip(def, on) {
      var chip = document.createElement('span');
      chip.className = 'share-mgr-perm ' + (on ? 'on-' + def.cls : 'off');
      chip.textContent = def.icon + ' ' + smT(def.key, null, def.key);
      return chip;
    }
    function smBadge(text, cls) {
      var b = document.createElement('span');
      b.className = 'share-mgr-badge' + (cls ? ' ' + cls : '');
      b.textContent = text;
      return b;
    }
    function smMiniBtn(text, action, shareId, danger) {
      var btn = document.createElement('button');
      btn.className = 'share-mgr-mini' + (danger ? ' danger' : '');
      btn.textContent = text;
      btn.setAttribute('data-sm-action', action);
      btn.setAttribute('data-sm-id', shareId);
      return btn;
    }

    // 行内编辑表单（卡片下方展开；单点编辑 SM.editingId）
    function smEditForm(s) {
      var form = document.createElement('div');
      form.className = 'share-mgr-edit';
      // 标题
      var labTitle = document.createElement('label');
      labTitle.textContent = smT('shareMgrTitle', null, '标题');
      var inTitle = document.createElement('input');
      inTitle.type = 'text'; inTitle.value = s.title || ''; inTitle.maxLength = 200;
      form.appendChild(labTitle); form.appendChild(inTitle);
      // 权限四枚 checkbox
      var labPerms = document.createElement('label');
      labPerms.textContent = smT('shareMgrPermissions', null, '权限');
      var row = document.createElement('div');
      row.className = 'share-mgr-edit-row';
      var bits = s.editPower || 0;
      SM_PERMS.forEach(function (def) {
        var lb = document.createElement('label');
        var cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.className = 'sm-ep';
        cb.setAttribute('data-sm-bit', String(def.bit));
        cb.checked = (bits & def.bit) !== 0;
        lb.appendChild(cb);
        lb.appendChild(document.createTextNode(def.icon + ' ' + smT(def.key, null, def.key)));
        row.appendChild(lb);
      });
      form.appendChild(labPerms); form.appendChild(row);
      // 口令（哨兵：留空=不改、纯空格=清除、非空=新口令）
      var labPw = document.createElement('label');
      labPw.textContent = smT('shareMgrPassword', null, '口令');
      var inPw = document.createElement('input');
      inPw.type = 'text'; inPw.value = ''; inPw.autocomplete = 'off';
      inPw.placeholder = smT('shareMgrPwKeepHint', null, '留空不修改；输入空格清除');
      form.appendChild(labPw); form.appendChild(inPw);
      // 有效期（保持现状 / 等级允许的天数选项，自保存起重新计算）
      var labExp = document.createElement('label');
      labExp.textContent = smT('shareExpiry', null, '有效期');
      var selExp = document.createElement('select');
      var optKeep = document.createElement('option');
      optKeep.value = ''; optKeep.textContent = smT('shareExpiryKeep', null, '保持现状');
      selExp.appendChild(optKeep);
      smExpiryOptions().forEach(function (d) {
        var o = document.createElement('option');
        o.value = String(d);
        o.textContent = smT('shareExpiryOption', [String(d)], d + ' 天');
        selExp.appendChild(o);
      });
      form.appendChild(labExp); form.appendChild(selExp);
      // 保存/取消
      var actions = document.createElement('div');
      actions.className = 'share-mgr-edit-actions';
      var btnCancel = document.createElement('button');
      btnCancel.className = 'btn btn-cancel';
      btnCancel.textContent = smT('shareCancel', null, '取消');
      btnCancel.addEventListener('click', function () { SM.editingId = null; smRenderDetail(smBuildGroups()); });
      var btnSave = document.createElement('button');
      btnSave.className = 'btn btn-primary';
      btnSave.textContent = smT('shareSave', null, '保存');
      btnSave.addEventListener('click', function () {
        var ep = 0;
        form.querySelectorAll('input.sm-ep:checked').forEach(function (cb) { ep |= parseInt(cb.getAttribute('data-sm-bit'), 10); });
        var patch = { title: inTitle.value, editPower: ep, expiryDays: selExp.value === '' ? null : parseInt(selExp.value, 10) };
        var rawPw = inPw.value;
        if (rawPw !== '') patch.password = rawPw.trim() === '' ? '' : rawPw;
        btnSave.disabled = true;
        btnSave.classList.add('is-loading');
        smSend('wpzl-update-share', { shareId: s.shareId, payload: patch }).then(function () {
          SM.editingId = null;
          showToast(smT('shareMgrSaved', null, '已保存'));
          smLoad();
        }).catch(function (err) {
          btnSave.disabled = false;
          btnSave.classList.remove('is-loading');
          showToast(smShareErrText(err, 'shareMgrSaveFailed', '保存失败'));
        });
      });
      actions.appendChild(btnCancel); actions.appendChild(btnSave);
      form.appendChild(actions);
      return form;
    }

    function smCard(s) {
      var off = s.isActive === false;
      var invalid = smIsInvalid(s);
      var card = document.createElement('div');
      card.className = 'share-mgr-card' + (invalid ? ' off' : '');
      var top = document.createElement('div');
      top.className = 'share-mgr-card-top';
      var bits = s.editPower || 0;
      SM_PERMS.forEach(function (def) { top.appendChild(smPermChip(def, (bits & def.bit) !== 0)); });
      if (s.hasPassword) top.appendChild(smBadge(smT('shareHasPassword', null, '已设口令'), 'pw'));
      else top.appendChild(smBadge(smT('shareNoPassword', null, '公开')));
      if (off) top.appendChild(smBadge(smT('shareDisabled', null, '已禁用'), 'bad'));
      if (s.expired) top.appendChild(smBadge(smT('shareMgrExpired', null, '已过期'), 'bad'));
      else if (s.expiresAt) top.appendChild(smBadge(smT('shareExpiresOn', [smFmtTime(s.expiresAt)], '过期于 ' + smFmtTime(s.expiresAt))));
      else top.appendChild(smBadge(smT('shareNoExpiry', null, '永不过期')));
      if (s.code) {
        var code = document.createElement('span');
        code.className = 'share-mgr-code';
        code.textContent = String(s.code).slice(0, 10) + '…';
        top.appendChild(code);
      }
      card.appendChild(top);
      var sub = document.createElement('div');
      sub.className = 'share-mgr-card-sub';
      // 互动人数：在该分享下发过回复或建过协作标记的 distinct 被分享者数（纯打开未互动不计入）
      var interactors = document.createElement('span');
      interactors.textContent = smT('shareMgrInteractors', [String(s.interactorCount || 0)], (s.interactorCount || 0) + ' 人互动');
      var created = document.createElement('span');
      created.textContent = smT('shareMgrCreated', [smFmtTime(s.createdAt)], '创建于 ' + smFmtTime(s.createdAt));
      sub.appendChild(interactors); sub.appendChild(created);
      card.appendChild(sub);
      var actions = document.createElement('div');
      actions.className = 'share-mgr-card-actions';
      actions.appendChild(smMiniBtn(smT('shareCopyLink', null, '复制链接'), 'copy', s.shareId));
      actions.appendChild(smMiniBtn(smT('shareOpenLink', null, '打开'), 'open', s.shareId));
      actions.appendChild(smMiniBtn(smT('shareEdit', null, '编辑'), 'edit', s.shareId));
      actions.appendChild(smMiniBtn(off ? smT('shareEnable', null, '启用') : smT('shareDisable', null, '禁用'), off ? 'enable' : 'disable', s.shareId, !off));
      actions.appendChild(smMiniBtn(smT('shareMgrDelete', null, '删除'), 'delete', s.shareId, true));
      card.appendChild(actions);
      if (SM.editingId === s.shareId) card.appendChild(smEditForm(s));
      return card;
    }

    function smRenderDetail(groups) {
      var detailEl = document.getElementById('shareMgrDetail');
      if (!detailEl) return;
      detailEl.innerHTML = '';
      var group = groups.filter(function (g) { return g.webUri === SM.selected; })[0];
      if (!group) {
        var empty = document.createElement('div');
        empty.className = 'share-mgr-empty';
        empty.textContent = smT('shareMgrDetailEmpty', null, '在右侧选择页面查看分享');
        detailEl.appendChild(empty);
        return;
      }
      var head = document.createElement('div');
      head.className = 'share-mgr-detail-head';
      var title = document.createElement('div');
      title.className = 'share-mgr-detail-title';
      title.textContent = group.title;
      title.title = group.title;
      var uri = document.createElement('div');
      uri.className = 'share-mgr-detail-uri';
      uri.textContent = group.webUri;
      uri.title = group.webUri;
      head.appendChild(title); head.appendChild(uri);
      detailEl.appendChild(head);
      var shares = smVisibleShares(group);
      if (!shares.length) {
        var none = document.createElement('div');
        none.className = 'share-mgr-empty';
        none.textContent = smT('shareMgrDetailEmpty', null, '在右侧选择页面查看分享');
        detailEl.appendChild(none);
        return;
      }
      shares.forEach(function (s) { detailEl.appendChild(smCard(s)); });
    }

    // 详情区操作（事件委托）：copy/open/edit/disable/enable/delete
    function smDelegateAction(e) {
      var btn = e.target.closest('[data-sm-action]');
      if (!btn) return;
      var action = btn.getAttribute('data-sm-action');
      var shareId = btn.getAttribute('data-sm-id');
      var s = SM.all.filter(function (x) { return x.shareId === shareId; })[0];
      if (!s) return;
      if (action === 'copy') {
        copyText(smShareUrl(s));
        showToast(smT('shareCopied', null, '链接已复制'));
      } else if (action === 'open') {
        window.open(smShareUrl(s), '_blank');
      } else if (action === 'edit') {
        SM.editingId = shareId;
        smRenderDetail(smBuildGroups());
      } else if (action === 'disable' || action === 'enable') {
        btn.disabled = true;
        smSend(action === 'enable' ? 'wpzl-enable-share' : 'wpzl-disable-share', { shareId: shareId })
          .then(function () { smLoad(); })
          .catch(function (err) {
            btn.disabled = false;
            showToast(smShareErrText(err, 'shareFailed', '操作失败'));
          });
      } else if (action === 'delete') {
        if (!window.confirm(smT('shareMgrDeleteConfirm', null, '确定彻底删除该分享？链接立即失效，协作批注与回复将保留。'))) return;
        btn.disabled = true;
        smSend('wpzl-delete-share', { shareId: shareId }).then(function () {
          showToast(smT('shareMgrDeleted', null, '分享已删除'));
          smLoad();
        }).catch(function (err) {
          btn.disabled = false;
          showToast(smT('shareMgrDeleteFailed', null, '删除失败') + (err && err.message ? ': ' + err.message : ''));
        });
      }
    }

    var _smDetailEl = document.getElementById('shareMgrDetail');
    if (_smDetailEl) _smDetailEl.addEventListener('click', smDelegateAction);

    // 右侧页面列表（事件委托）：选中页面
    var _smPagesEl = document.getElementById('shareMgrPages');
    if (_smPagesEl) {
      _smPagesEl.addEventListener('click', function (e) {
        var item = e.target.closest('[data-sm-weburi]');
        if (!item) return;
        SM.selected = item.getAttribute('data-sm-weburi');
        SM.editingId = null;
        var groups = smBuildGroups();
        smRenderPages(groups);
        smRenderDetail(groups);
      });
    }

    // 过滤器切换
    var _smFiltersEl = document.getElementById('shareMgrFilters');
    if (_smFiltersEl) {
      _smFiltersEl.addEventListener('click', function (e) {
        var btn = e.target.closest('.share-mgr-filter-btn');
        if (!btn) return;
        SM.filter = btn.getAttribute('data-filter') || 'all';
        _smFiltersEl.querySelectorAll('.share-mgr-filter-btn').forEach(function (b) {
          b.classList.toggle('active', b === btn);
        });
        var groups = smBuildGroups();
        smPickSelection(groups);
        smRenderPages(groups);
        smRenderDetail(groups);
      });
    }

    // 搜索框：按页面名称（标题/webUri）过滤菜单
    var _smSearchEl = document.getElementById('shareMgrSearch');
    if (_smSearchEl) {
      _smSearchEl.addEventListener('input', function () {
        SM.search = _smSearchEl.value.trim();
        var groups = smBuildGroups();
        smPickSelection(groups);
        smRenderPages(groups);
        smRenderDetail(groups);
      });
    }

    // 打开/关闭
    // 分享管理：入口迁入右上角"功能"菜单，把打开函数挂到顶层钩子供 initEvents 侧调用
    mgrOpenShareManagerFn = function () {
      var modal = document.getElementById('shareMgrModal');
      if (modal) modal.style.display = 'flex';
      SM.editingId = null;
      // serverBase 经 SW 读 WPZL_SERVER_BASE（单一来源）；取不到也照常打开（仅复制/打开链接不可用）
      getServerBase().then(function (b) { SM.serverBase = b || ''; });
      smLoad();
    };
    var _smCloseBtn = document.getElementById('shareMgrCloseBtn');
    if (_smCloseBtn) {
      _smCloseBtn.addEventListener('click', function () {
        var modal = document.getElementById('shareMgrModal');
        if (modal) modal.style.display = 'none';
      });
    }
    // 点遮罩关闭
    var _smModalEl = document.getElementById('shareMgrModal');
    if (_smModalEl) {
      _smModalEl.addEventListener('mousedown', function (e) {
        if (e.target === _smModalEl) _smModalEl.style.display = 'none';
      });
    }


    // Sync button：仅当前等级授予 cloudSync 功能时显示
    var syncNowBtn = document.getElementById('syncNowBtn');
    if (syncNowBtn) {
      // Check sync availability
      chrome.runtime.sendMessage({ type: 'sync-status' }, function (syncResult) {
        // 记录同步引擎就绪状态；按钮显示与否由 updateSyncButtonVisibility 综合 gradeConfig.features.cloudSync 判定。
        if (syncResult && syncResult.success && syncResult.data) {
          state.syncEnabled = !!syncResult.data.enabled;
          // 上次同步新鲜度：从未同步/上次失败/超过 10 分钟 → 打开 manager 时静默补一次同步
          // （updateSyncButtonVisibility 汇合 gradeConfig 后触发，见其内注释）
          var _lst = syncResult.data.lastSyncTime;
          state.syncStale = !_lst || syncResult.data.lastSyncSuccess === false
            || (Date.now() - new Date(_lst).getTime() > 10 * 60 * 1000);
        } else {
          state.syncEnabled = false;
        }
        updateSyncButtonVisibility();
      });

      syncNowBtn.addEventListener('click', function () {
        var overlay = document.getElementById('syncProgressOverlay');
        var bar = document.getElementById('syncProgressBar');
        var text = document.getElementById('syncProgressText');
        var viewReportLink = document.getElementById('syncViewReportLink');
        var lastReport = null;

        syncNowBtn.disabled = true;
        // 图标按钮无文字 span，用图标旋转表示同步中（旧代码写 span.textContent 已不可用）
        syncNowBtn.classList.add('is-syncing');
        if (viewReportLink) viewReportLink.style.display = 'none';

        // Show progress overlay
        overlay.style.display = 'flex';
        bar.style.width = '10%';
        text.textContent = getMessage('syncConnecting');

        // Simulate progress stages since sync is a single async call
        var progressTimer = setInterval(function () {
          var w = parseFloat(bar.style.width) || 10;
          if (w < 85) {
            w = Math.min(85, w + Math.random() * 10 + 2);
            bar.style.width = w + '%';
            if (w < 30) text.textContent = getMessage('syncPhaseDownloading');
            else if (w < 60) text.textContent = getMessage('syncPhaseComparing');
            else text.textContent = getMessage('syncPhaseUploading');
          }
        }, 400);

        chrome.runtime.sendMessage({ type: 'sync-trigger' })
          .then(function (result) {
            clearInterval(progressTimer);
            bar.style.width = '100%';

            if (result && result.success) {
              var pushCount = (result.data && result.data.pushed) || 0;
              var pullCount = (result.data && result.data.pulled) || 0;
              var autoPushed = (result.data && result.data.autoPushedSinceLastView) || 0;
              var autoPulled = (result.data && result.data.autoPulledSinceLastView) || 0;
              // 主文本：本次触发的同步结果（与详情报告里的明细对齐）
              if (pushCount === 0 && pullCount === 0) {
                if (autoPushed > 0 || autoPulled > 0) {
                  var bits = [];
                  if (autoPushed > 0) bits.push(getMessage('syncAutoUpBit', [String(autoPushed)]));
                  if (autoPulled > 0) bits.push(getMessage('syncAutoDownBit', [String(autoPulled)]));
                  text.innerHTML = getMessage('syncNoopAutoDone', [bits.join('、')]);
                } else {
                  text.textContent = getMessage('syncUpToDate');
                }
              } else {
                var msg = getMessage('syncDonePushPull', [String(pushCount), String(pullCount)]);
                if (autoPushed > 0 || autoPulled > 0) {
                  var extras = [];
                  if (autoPushed > 0) extras.push(getMessage('syncExtraAutoUp', [String(autoPushed)]));
                  if (autoPulled > 0) extras.push(getMessage('syncExtraAutoDown', [String(autoPulled)]));
                  msg += getMessage('syncDoneExtrasSuffix', [extras.join('、')]);
                }
                text.innerHTML = msg;
              }
              // 构造同步报告 payload
              if (result.data && result.data.report) {
                lastReport = {
                  report: result.data.report,
                  pushed: pushCount,
                  pulled: pullCount,
                  autoPushed: autoPushed,
                  autoPulled: autoPulled,
                  conflicts: result.data.conflicts || 0,
                  rejected: result.data.rejected || 0,
                  deleted: result.data.deleted || 0,
                  attemptedPushAnn: result.data.report.attemptedPushAnn || 0,
                  attemptedPushPage: result.data.report.attemptedPushPage || 0,
                  attemptedPushFolder: result.data.report.attemptedPushFolder || 0,
                  attemptedDeleteAnn: result.data.report.attemptedDeleteAnn || 0
                };
                if (viewReportLink) {
                  try { viewReportLink.dataset.lastReport = JSON.stringify(lastReport); } catch (e) { /* ignore */ }
                }
                // 有"本次触发"或"自动同步"条目时，展示详情入口
                if ((pushCount + pullCount + autoPushed + autoPulled) > 0 && viewReportLink) {
                  viewReportLink.style.display = 'inline-block';
                }
              }
              // Refresh page list and current page annotations（含同步下来的页面标题）
              // 同步重载 folders/documents：与自动同步路径一致，避免新目录/文档需整页刷新才出现。
              refreshPageCounts()
                .then(function () { return loadFolders(); })
                .then(function () { return refreshDocuments(); })  // 用 refreshDocuments：loadAllDocuments 不赋值 state.documents，手动同步后文档会丢
                .catch(function () { /* ignore */ });
              if (state.currentPage) {
                loadAnnotations(state.currentPage.domain, state.currentPage.url).then(function (markList) {
                  state.annotations = Object.values(markList);
                  renderContent();
                }).catch(function () {});
              }
            } else if (result && result.error === 'sync_in_progress') {
              text.textContent = getMessage('syncAlreadyRunning');
              setTimeout(function () {
                overlay.style.display = 'none';
                bar.style.width = '0%';
              }, 1200);
              return;
            } else {
              var errMsg = (result && result.error) || getMessage('syncNetworkError');
              // Detect server-side lock (409 Conflict) or connection errors
              if (errMsg.indexOf('另一个设备正在同步') !== -1) {
                text.textContent = getMessage('syncLockedByOther');
              } else {
                text.textContent = getMessage('syncFailedPrefix', [errMsg]);
              }
            }

            // Keep the completed bar visible for 1.5s, then hide.
            // 若有同步明细，则自动弹出报告弹窗（用户可见），浮层仍按原计划隐藏。
            setTimeout(function () {
              overlay.style.display = 'none';
              bar.style.width = '0%';
              // 本次触发有推/拉 → 弹报告；本次为 0 但自动同步非 0 → 也弹（让用户看说明）
              if (lastReport && (lastReport.pushed + lastReport.pulled +
                                 lastReport.autoPushed + lastReport.autoPulled) > 0) {
                try { showSyncReportModal(lastReport); } catch (e) { /* ignore */ }
              }
            }, 1500);
          })
          .catch(function (err) {
            clearInterval(progressTimer);
            text.textContent = getMessage('syncFailedPrefix', [String(err.message)]);
            bar.style.width = '100%';
            bar.style.background = 'var(--danger)';
            setTimeout(function () {
              overlay.style.display = 'none';
              bar.style.width = '0%';
              bar.style.background = '';
            }, 2000);
          })
          .finally(function () {
            syncNowBtn.disabled = false;
            syncNowBtn.classList.remove('is-syncing');
          });
      });
    }

    getUserIdentity().then(function (identity) {
      state.currentAuthor = identity || null;
    }).catch(function () {
      state.currentAuthor = null;
    }).then(function () {
      return refreshPageCounts();
    }).then(function () { return loadFolders(); })
    .then(function () { return loadFolderCollapsed(); })
    .then(function () {
      // 加载文档 + 快照（含快照覆盖集合 + 带批注快照的批注数回填），确保下方首次 renderSidebar
      // 已具备快照去重能力——否则 /snap/{snapId} 的 pages 记录会先以普通页闪现，约 2s 后被
      // refreshDocuments 去重为快照条目，用户感知"刷新后条目自动消失"。
      return _loadDocsAndSnapshotsIntoState().catch(function (e) { console.error('loadAllDocuments/Snapshots failed:', e); });
    })
    .then(function () {
      renderSidebar();
      // #export-all 深链首载/F5 路径：数据（pages/folders/docs）就绪后再开「导出全部」弹框，
      // 避免 scope label 显示 "(0 个页面)"。hashchange 路径（已开 tab 改 hash）在
      // _mgrOpenPayOrdersDeepLink 旁注册，不经此处。
      try { _mgrOpenExportAllDeepLink(); } catch (e) { /* ignore */ }
      // 立即查询一次同步进度：让 overlay 尽快从"正在连接服务器…"切换到进度文字
      // （不依赖 push 消息，SW 可能在 manager 加载前就已开始发送）
      try {
        chrome.runtime.sendMessage({ type: 'sync-running' }, function (r) {
          var d = r && r.success && r.data;
          if (d) {
            var overlay = _ensureSyncOverlay();
            var textEl = overlay.querySelector('.wpzl-sync-text');
            if (d.downloadTotal) {
              // 有总数：显示 "正在同步数据… (N/Total 条)"
              textEl.textContent = getMessage('syncingProgress', [String(d.downloadPulled || 0), String(d.downloadTotal)]);
            } else if (d.syncing || d.initState === 'pending' || d.initState === 'running') {
              // 同步进行中但第一批数据还没返回：至少告诉用户"正在同步"
              textEl.textContent = getMessage('syncingLoading');
            } else if (d.downloadPulled) {
              // 同步已完成，有下载数
              textEl.textContent = getMessage('syncingPulledOnly', [String(d.downloadPulled)]);
            }
          }
        });
      } catch (e) { /* ignore */ }
      // 刚登录竞态兜底：见下方 _pollSidebarIfEmpty 注释。
      _pollSidebarIfEmpty();
    }).catch(function (err) {
      console.error('Failed to load pages:', err);
    });

    // 刚登录目录竞态兜底：onLogin 全量同步分阶段落盘（pages/annotations 提交时机不同），
    // online 广播那一刻若数据尚未对读事务可见，首次 refreshPageCounts 可能仍读空 → 左侧目录空。
    // 此处轮询 IDB 直到数据出现。分两阶段：
    //   ~14s 无条件窗口（覆盖登录→同步启动延迟）
    //   之后：只要 sync-running 报告同步进行中或 init 未完成，不限时继续等
    //   终止信号统一交给 sync-state online/offline 广播（见 onMessage listener）
    function _pollSidebarIfEmpty() {
      var attempts = 0;
      var INTERVAL = 1200;       // ~1.2s/次
      var UNCONDITIONAL_MAX = 12; // ~14s 无条件窗口
      var _seenSyncing = false;
      var _idleConfirm = 0;      // 引擎空闲在线连续确认计数（空账号快速收尾，见 tick 内分支）
      var IDLE_CONFIRM_MAX = 2;       // 连续 2 次空闲+空数据 → 空态权威，提前收尾
      var IDLE_CONFIRM_INTERVAL = 600; // 确认轮短间隔（ms）：覆盖"同步恰在此间隙启动"的竞态

      function _isSyncPending() {
        return new Promise(function (resolve) {
          try {
            chrome.runtime.sendMessage({ type: 'sync-running' }, function (r) {
              var d = r && r.success && r.data;
              // 服务端错误熔断：同步不在进行，停止等待（防广播竞态漏掉 server_error 终态）
              if (d && d.state === 'server_error') { resolve({ pending: false, idleSynced: false }); return; }
              var pending = !!(d && (d.syncing || d.initState === 'pending' || d.initState === 'running'));
              // 引擎空闲且已在线完成同步（未持锁 + 状态机 online + init completed）：
              // 此时不可能再有数据经同步到来（SW 状态机只在转换时广播，空账号刷新页面
              // 常态下收不到 online 广播，见 tick 内 idleSynced 分支）。
              var idleSynced = !!(d && !pending && d.state === 'online' && d.initState === 'completed');
              // 主动拉取进度更新 overlay（不依赖 push 消息）
              if (d) {
                var overlay = _ensureSyncOverlay();
                var textEl = overlay.querySelector('.wpzl-sync-text');
                if (d.downloadTotal) {
                  textEl.textContent = getMessage('syncingProgress', [String(d.downloadPulled || 0), String(d.downloadTotal)]);
                } else if (pending) {
                  // 同步进行中但数据还没到：至少告诉用户不是"连接中"
                  textEl.textContent = getMessage('syncingLoading');
                } else if (d.downloadPulled) {
                  textEl.textContent = getMessage('syncingPulledOnly', [String(d.downloadPulled)]);
                }
              }
              resolve({ pending: pending, idleSynced: idleSynced });
            });
          } catch (e) { resolve({ pending: false, idleSynced: false }); }
        });
      }

      function tick() {
        attempts++;
        refreshPageCounts()
          .then(function () { return loadFolders(); })
          .then(function () { return refreshDocuments(); })
          .then(function () {
            if (state.pages && state.pages.length > 0) {
              // 数据已出现：更新 overlay 为完成提示，短暂延迟后由 renderSidebar 隐藏
              var overlay = _ensureSyncOverlay();
              var textEl = overlay.querySelector('.wpzl-sync-text');
              if (textEl && overlay.style.display !== 'none') {
                textEl.textContent = getMessage('syncDonePages', [String(state.pages.length)]);
                setTimeout(function () { _hideSyncOverlay(); }, 1500);
              }
              return;
            }
            return _isSyncPending().then(function (sr) {
              if (sr.pending) {
                _seenSyncing = true;
                _idleConfirm = 0;
                setTimeout(tick, INTERVAL);  // 不限时：同步进行中就一直等
                return;
              }
              // 引擎空闲且已在线同步完成：不会再有数据经同步到来，空结果即权威结论。
              // 连续确认 IDLE_CONFIRM_MAX 次后提前收尾，不再干等整个无条件窗口
              // （空账号刷新页面此前必跑满 ~26s：SW 早已同步完、状态静默归位 online，
              //   无转换即无广播，页面唯一退路是窗口耗尽）。
              // 登录竞态不受影响：全量同步进行中时 syncing/initState=running → 上方 pending 路径；
              // 引擎尚未初始化完成（initState pending/running）同样走 pending 路径。
              if (sr.idleSynced) {
                _idleConfirm++;
                if (_idleConfirm >= IDLE_CONFIRM_MAX) {
                  if (state.awaitingFirstSync) {
                    state.awaitingFirstSync = false;
                    try { renderSidebar(); } catch (e) { /* ignore */ }
                  }
                  return;  // 遮罩已收尾（或广播早已清过标志），轮询使命完成
                }
                setTimeout(tick, IDLE_CONFIRM_INTERVAL);  // 短间隔二次确认，防同步恰在此间隙启动
                return;
              }
              // 不在同步中：无条件窗口内继续等，之后交给 online/offline 广播终态判定
              if (!_seenSyncing && attempts <= UNCONDITIONAL_MAX) {
                setTimeout(tick, INTERVAL);
                return;
              }
              // 收尾兜底（2026-09-13）：无条件窗口结束且引擎空闲时不再干等广播——online 广播
              // 可能在页面加载前已发过（SW 重启后状态机静默归位，不补发转换），漏收会让遮罩
              // 永远停在"正在连接服务器"。此处按空态收尾，与 offline/server_error 广播分支同构。
              if (state.awaitingFirstSync) {
                state.awaitingFirstSync = false;
                try { renderSidebar(); } catch (e) { /* ignore */ }
              }
            });
          })
          .catch(function () { setTimeout(tick, INTERVAL); });
      }
      // 立即查询一次进度（不等 1.2s），让 overlay 尽快从"正在连接服务器…"切换到进度文字
      _isSyncPending();
      setTimeout(tick, INTERVAL);
    }

    // ---- 同步详情报告 ----
    // _escapeHtml / _truncate 已提升至 IIFE 顶层（见"同步失败查看器"区），此处直接复用。
    function _resultLabel(r) {
      if (r === 'accepted') return '<span style="color:#10b981;">' + getMessage('syncResUploaded') + '</span>';
      if (r === 'rejected') return '<span style="color:#ef4444;">' + getMessage('syncResRejected') + '</span>';
      if (r === 'conflict') return '<span style="color:#f59e0b;">' + getMessage('syncResConflict') + '</span>';
      if (r === 'new') return '<span style="color:#3b82f6;">' + getMessage('syncResNew') + '</span>';
      if (r === 'updated') return '<span style="color:#3b82f6;">' + getMessage('syncResUpdated') + '</span>';
      if (r === 'pulled') return '<span style="color:#3b82f6;">' + getMessage('syncResPulled') + '</span>';
      return r || '';
    }
    function _renderReportSection(title, items, overflow, itemRenderer) {
      if (!items || items.length === 0) return '';
      var rows = items.map(itemRenderer).join('');
      var more = overflow > 0
        ? '<div style="padding:8px 12px;color:#94a3b8;font-size:12px;">' + getMessage('syncReportMore', [String(overflow)]) + '</div>'
        : '';
      return '<div style="margin-bottom:14px;">' +
        '<div style="font-weight:600;margin-bottom:6px;color:var(--text-primary);">' + title +
        '（' + (items.length + overflow) + '）</div>' +
        '<div style="border:1px solid var(--border-color);border-radius:6px;max-height:240px;overflow-y:auto;">' +
        rows + more +
        '</div></div>';
    }
    function showSyncReportModal(payload) {
      var modal = document.getElementById('syncReportModal');
      var summary = document.getElementById('syncReportSummary');
      var body = document.getElementById('syncReportBody');
      if (!modal || !payload || !payload.report) return;

      var r = payload.report;
      var autoPushed = payload.autoPushed || 0;
      var autoPulled = payload.autoPulled || 0;
      // 概要：区分「本次触发」与「自上次查看以来累计（自动同步）」
      var summaryHtml = '<div style="margin-bottom:6px;">' +
        getMessage('syncReportTriggered', [String(payload.pushed), String(payload.pulled)]) +
        (payload.conflicts > 0 ? getMessage('syncReportConflicts', [String(payload.conflicts)]) : '') +
        (payload.rejected > 0 ? getMessage('syncReportRejected', [String(payload.rejected)]) : '') +
        (payload.deleted > 0 ? getMessage('syncReportDeleted', [String(payload.deleted)]) : '') +
        '</div>';
      if (autoPushed > 0 || autoPulled > 0) {
        summaryHtml += '<div style="color:#64748b;margin-bottom:6px;">' +
          getMessage('syncReportAutoLabel', [String(autoPushed), String(autoPulled)]) +
          '<span style="color:#94a3b8;">' + getMessage('syncReportAutoNote') + '</span>' +
          '</div>';
      }
      summaryHtml += '<div style="color:#94a3b8;">' +
        getMessage('syncReportQueue', [String(r.attemptedPushAnn), String(r.attemptedPushPage),
          String(r.attemptedPushFolder), String(r.attemptedDeleteAnn)]) + '</div>';
      summary.innerHTML = summaryHtml;

      var html = '';

      // 推送的标注
      html += _renderReportSection(getMessage('syncSectionPushedAnn'), r.pushedAnn, r.pushedAnnOverflow, function (a) {
        return '<div style="padding:8px 12px;border-bottom:1px solid var(--border-color);">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;">' +
          '<span style="font-weight:500;">' + _escapeHtml(_truncate(a.title || getMessage('noTitle'), 60)) + '</span>' +
          '<span>' + _resultLabel(a.result) + '</span>' +
          '</div>' +
          '<div style="font-size:12px;color:#94a3b8;margin-top:2px;word-break:break-all;">' +
          _escapeHtml(_truncate(a.url, 80)) + '</div>' +
          '<div style="font-size:12px;color:#64748b;margin-top:2px;">' +
          getMessage('syncReportDirtyFields', [(a.dirtyFields && a.dirtyFields.length ? a.dirtyFields.join('、') : '—'), (a.prevStatus || '—')]) +
          '</div></div>';
      });

      // 推送的页面（标题/收藏/目录等变更）
      html += _renderReportSection(getMessage('syncSectionPushedPage'), r.pushedPage, r.pushedPageOverflow, function (p) {
        return '<div style="padding:8px 12px;border-bottom:1px solid var(--border-color);">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;">' +
          '<span style="font-weight:500;">' + _escapeHtml(_truncate(displayPageTitle(p) || getMessage('noTitle'), 60)) + '</span>' +
          '<span>' + _resultLabel(p.result) + '</span>' +
          '</div>' +
          '<div style="font-size:12px;color:#94a3b8;margin-top:2px;word-break:break-all;">' +
          _escapeHtml(_truncate(p.url, 80)) + '</div>' +
          '<div style="font-size:12px;color:#64748b;margin-top:2px;">' +
          getMessage('syncReportDirtyFieldsOnly', [(p.dirtyFields && p.dirtyFields.length ? p.dirtyFields.join('、') : '—')]) +
          '</div></div>';
      });

      // 推送的目录
      html += _renderReportSection(getMessage('syncSectionPushedFolder'), r.pushedFolder, r.pushedFolderOverflow, function (f) {
        return '<div style="padding:8px 12px;border-bottom:1px solid var(--border-color);">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;">' +
          '<span style="font-weight:500;">' + _escapeHtml(_truncate(f.name || getMessage('noTitle'), 60)) + '</span>' +
          '<span>' + _resultLabel(f.result) + '</span>' +
          '</div></div>';
      });

      // 拉取的标注
      html += _renderReportSection(getMessage('syncSectionPulledAnn'), r.pulledAnn, r.pulledAnnOverflow, function (a) {
        return '<div style="padding:8px 12px;border-bottom:1px solid var(--border-color);">' +
          '<div style="display:flex;justify-content:space-between;gap:8px;">' +
          '<span style="font-weight:500;">' + _escapeHtml(_truncate(a.title || getMessage('noTitle'), 60)) + '</span>' +
          '<span>' + _resultLabel(a.result) + '</span>' +
          '</div>' +
          '<div style="font-size:12px;color:#94a3b8;margin-top:2px;word-break:break-all;">' +
          _escapeHtml(_truncate(a.url, 80)) + '</div>' +
          (a.authorName ? '<div style="font-size:12px;color:#64748b;margin-top:2px;">' + getMessage('syncReportAuthor', [_escapeHtml(a.authorName)]) + '</div>' : '') +
          '</div>';
      });

      // 拉取的页面
      html += _renderReportSection(getMessage('syncSectionPulledPage'), r.pulledPage, r.pulledPageOverflow, function (p) {
        return '<div style="padding:8px 12px;border-bottom:1px solid var(--border-color);">' +
          '<div style="font-weight:500;">' + _escapeHtml(_truncate(displayPageTitle(p) || getMessage('noTitle'), 80)) + '</div>' +
          '<div style="font-size:12px;color:#94a3b8;margin-top:2px;word-break:break-all;">' +
          _escapeHtml(_truncate(p.url, 80)) + '</div></div>';
      });

      // 拉取的目录
      html += _renderReportSection(getMessage('syncSectionPulledFolder'), r.pulledFolder, r.pulledFolderOverflow, function (f) {
        return '<div style="padding:8px 12px;border-bottom:1px solid var(--border-color);">' +
          '<div style="font-weight:500;">' + _escapeHtml(_truncate(f.name || getMessage('noTitle'), 80)) + '</div></div>';
      });

      if (!html) {
        body.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:24px;">' +
          getMessage('syncReportEmpty') +
          (autoPushed + autoPulled > 0
            ? '<br>' + getMessage('syncReportEmptyAuto', [String(autoPushed + autoPulled)])
            : '') +
          '</div>';
      } else {
        body.innerHTML = html;
      }

      // 完整明细到控制台，方便排查
      console.log('[Sagitnote Sync Report]', payload);
      modal.style.display = 'flex';
    }

    var _reportLink = document.getElementById('syncViewReportLink');
    if (_reportLink) {
      _reportLink.addEventListener('click', function (e) {
        e.preventDefault();
        // 在浮层关闭前一刻捕获到的 lastReport；为简化作用域，存到 DOM dataset
        var stored = _reportLink.dataset.lastReport;
        if (stored) {
          try { showSyncReportModal(JSON.parse(stored)); } catch (err) { /* ignore */ }
        }
      });
    }
    var _reportCloseBtn = document.getElementById('syncReportCloseBtn');
    if (_reportCloseBtn) {
      _reportCloseBtn.addEventListener('click', function () {
        var modal = document.getElementById('syncReportModal');
        if (modal) modal.style.display = 'none';
      });
    }
    } // _wpzlAfterAuth
  });

})();
