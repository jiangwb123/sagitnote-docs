// Markdown → HTML 转换（用于自建文档「导入文件」）
// 依赖 marked（GFM：表格/删除线/任务列表）。输出交给 TipTap setContent 按 schema 二次清洗。
import { marked } from 'marked';

// Obsidian 语法保真（导入/导出往返）：载体 HTML 与 manager.js htmlBodyToMarkdown、
// doc-editor/index.js 的五个 Obsidian Mark、服务端 HtmlSanitizer 白名单三方约定：
//   [[t]]/[[t|a]] → <a class="wpz-wikilink" title="T">ALIAS</a>（无 href：jsoup href 协议限制
//                   只约束 href 值，无 href 即不受限；同时避开 TipTap Link 的 a[href] 匹配）
//   ![[x]]       → <span class="wpz-embed">![[x]]</span>（文本含语法本身，导出原样取回）
//   ==x==        → <mark class="wpz-highlight">（服务端白名单已补 mark 标签）
//   %%x%%        → <span class="wpz-comment">x</span>（文本不含 %%，导出时补回）
//   #tag         → <span class="wpz-tag">#tag</span>（前邻必须空白，Obsidian 不识别 abc#tag）
//   > [!type] T  → 不在导入层处理（文本真相：marked 原样产出 blockquote + 字面标记文本，
//                  渲染层仅加 class，导出逐行 > 前缀后 Obsidian 自动重新解析）
//   YAML frontmatter → 剥离文件头，包成 ```webpz-frontmatter 围栏代码块（TipTap CodeBlock 存活；
//                  导出时由 htmlBodyToMarkdown 的 fmSink 提升回文档级 YAML 头）

function escHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// 文件头 YAML frontmatter：--- ... --- 剥离（Obsidian 语义：仅认文件最顶部）
var FM_RE = /^---[ \t]*\r?\n([\s\S]*?)\r?\n---[ \t]*(?:\r?\n|$)/;
function splitFrontmatter(md) {
  var m = FM_RE.exec(md);
  if (!m) return { fm: '', body: md };
  return { fm: m[1], body: md.slice(m[0].length) };
}

// 标签字符集：字母/数字/中文/下划线/连字符/斜杠（Obsidian 嵌套标签 a/b/c）
var TAG_RE = /^#[A-Za-z0-9一-鿿_\-\/]+/;

// marked.use 一次性注册（模块级）。自定义 inline 扩展的 tokenizer 在所有内建 token
// （escape/codespan/tag/link）之前执行——因此代码块（块级 token，文本不进 inline lexer）
// 与内联代码（tokenizer 锚定 ^，反引号位置不会命中 [[ / == 等语法）天然不被改写。
// 各 start 函数喂给 startInline 裁剪逻辑：inlineText 在语法起始处提前截断，
// 否则 ==/%%/#/[ 不在 inlineText 的停字符集内会被整段吞掉。
marked.use({
  gfm: true,
  breaks: false,
  extensions: [
    {
      name: 'obsidianEmbed',
      level: 'inline',
      start(src) { return src.indexOf('![['); },
      tokenizer(src) {
        var cap = /^!\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/.exec(src);
        if (!cap) return;
        // 载体文本 = 原始语法串（含别名），导出时 textContent 原样取回
        return { type: 'obsidianEmbed', raw: cap[0], text: cap[0] };
      },
      renderer(token) { return '<span class="wpz-embed">' + escHtml(token.text) + '</span>'; },
    },
    {
      name: 'obsidianWikilink',
      level: 'inline',
      start(src) { return src.indexOf('[['); },
      tokenizer(src) {
        var cap = /^\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/.exec(src);
        if (!cap) return;
        var target = (cap[1] || '').trim();
        var alias = cap[2] ? cap[2].trim() : '';
        return { type: 'obsidianWikilink', raw: cap[0], target: target, alias: alias };
      },
      renderer(token) {
        var label = token.alias || token.target;
        return '<a class="wpz-wikilink" title="' + escHtml(token.target) + '">' + escHtml(label) + '</a>';
      },
    },
    {
      name: 'obsidianHighlight',
      level: 'inline',
      start(src) { return src.indexOf('=='); },
      tokenizer(src) {
        // 两侧紧邻等号/空白不视为高亮（Obsidian 行为：== x == 非法）
        var cap = /^==(?=[^\s=])([\s\S]*?[^\s=])==/.exec(src);
        if (!cap) return;
        // inner 递归 lex：==**粗体**== 内的强调保留
        var tokens = this.lexer.inlineTokens(cap[1]);
        return { type: 'obsidianHighlight', raw: cap[0], tokens: tokens };
      },
      renderer(token) { return '<mark class="wpz-highlight">' + this.parser.parseInline(token.tokens) + '</mark>'; },
    },
    {
      name: 'obsidianComment',
      level: 'inline',
      start(src) { return src.indexOf('%%'); },
      tokenizer(src) {
        var cap = /^%%(?=[^\s%])([\s\S]*?[^\s%])%%/.exec(src);
        if (!cap) return;
        // 载体文本不含 %% 本身，导出时补回
        return { type: 'obsidianComment', raw: cap[0], text: cap[1] };
      },
      renderer(token) { return '<span class="wpz-comment">' + escHtml(token.text) + '</span>'; },
    },
    {
      name: 'obsidianTag',
      level: 'inline',
      start(src) { return src.indexOf('#'); },
      tokenizer(src, tokens) {
        var cap = TAG_RE.exec(src);
        if (!cap) return;
        // 边界守卫：前邻 token 以非空白结尾 → 是 abc#tag 的一部分，不是标签（Obsidian 行为）。
        // 标题安全：块级 lexer 先消费行首 #，不进入 inline。
        var prev = tokens[tokens.length - 1];
        if (prev && /\S$/.test(prev.text || prev.raw || '')) return;
        return { type: 'obsidianTag', raw: cap[0], text: cap[0] };
      },
      renderer(token) { return '<span class="wpz-tag">' + escHtml(token.text) + '</span>'; },
    },
  ],
});

export function markdownToHtml(md) {
  var s = String(md || '');
  var parts = splitFrontmatter(s);
  var src = parts.fm ? '```webpz-frontmatter\n' + parts.fm + '\n```\n\n' + parts.body : parts.body;
  // marked.parse 同步返回 HTML 字符串
  return marked.parse(src);
}
