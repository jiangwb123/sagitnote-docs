// .docx → HTML（用于自建文档「导入文件」）
// 用 mammoth（浏览器构建，按需动态 import，镜像 pdf.js 的 ensurePdfjs 模式）。
// mammoth 语义化抽取：标题/列表/表格/段落/行内样式；docx 内嵌图片默认 base64 内嵌（命中 DocImage allowBase64）。
// 输出再经 TipTap setContent 按 schema 二次清洗（与 HTML/Markdown 导入一致的双保险）。
var _mammothReady = null;

async function ensureMammoth() {
  if (_mammothReady) return _mammothReady;
  _mammothReady = (async function () {
    var mod = await import(chrome.runtime.getURL('lib/mammoth/mammoth.bundle.js'));
    return mod.mammoth;
  })().catch(function (e) {
    _mammothReady = null; // 失败清空缓存，下次重试
    console.error('[importers/docx] mammoth 库动态加载失败（lib/mammoth/mammoth.bundle.js）', e);
    throw e;
  });
  return _mammothReady;
}

// 返回 HTML 字符串（mammoth 语义化 HTML 片段；无 body 包裹，与 markdown/html 导出一致）。
export async function docxToHtml(arrayBuffer) {
  var mammoth = await ensureMammoth();
  var result = await mammoth.convertToHtml({ arrayBuffer: arrayBuffer });
  return (result && result.value) || '';
}
