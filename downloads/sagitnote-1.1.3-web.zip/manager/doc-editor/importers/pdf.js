// PDF → HTML（用于自建文档「导入文件」）
// 复用扩展既有的 pdfjs 包（content 脚本同款），fake worker 模式（MV3 合规，无 Blob URL）。
//
// 转换策略与「打开 PDF 网页时」一致：每页渲染成位图，嵌成 <img>。
// 优点：忠实保留版式/图片/表格/字体，对扫描件同样有效（比文本抽取鲁棒得多）。
// 压缩：逐页比较 WebP/JPEG 取更小者（远小于 PNG）；取舍是导入「页面图片」而非可编辑文本。
var _pdfjsReady = null;

// 与 content.js 完全一致的 pdfjs 装载方式（fake worker）
async function ensurePdfjs() {
  if (_pdfjsReady) return _pdfjsReady;
  _pdfjsReady = (async function () {
    var main = await import(chrome.runtime.getURL('lib/pdfjs/pdf.bundle.js'));
    var pdfjsLib = main.pdfjsLib;
    // 统一使用 fake worker 模式（同 content.js；IIFE 副作用注册 globalThis.pdfjsWorker）
    await import(chrome.runtime.getURL('lib/pdfjs/pdf.worker.bundle.js'));
    return pdfjsLib;
  })().catch(function (e) {
    _pdfjsReady = null; // 失败清空缓存，下次重试
    throw e;
  });
  return _pdfjsReady;
}

// 每页 canvas 内部宽度（px）：略高于显示宽度，保证缩放后文字清晰。
var RENDER_WIDTH = 1200;
// 页宽 clamp 上下界（px）：下界保留可读性，上界避免编辑器横向溢出（覆盖 A3/横向等宽幅 PDF）。
var PAGE_WIDTH_MIN = 680;
var PAGE_WIDTH_MAX = 1400;

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

// 同一张 canvas 分别编 WebP / JPEG，取更小者。
// - 纯文字页：WebP 通常更小；含照片页：两者互有胜负 → 逐页比较最稳。
// - 不支持 WebP 编码的环境 toDataURL 会回退为 PNG，体积偏大，比较后自然会被 JPEG 淘汰。
// - 服务端 HtmlSanitizer 已放行 data:image/*（含 webp/jpeg），编辑器/详情页均可渲染。
function pickSmallerDataUrl(canvas) {
  var jpeg = canvas.toDataURL('image/jpeg', 0.85);
  var webp = canvas.toDataURL('image/webp', 0.82);
  return webp.length < jpeg.length ? webp : jpeg;
}

// 返回 { html, pageWidth }：pageWidth 为建议的编辑器页宽（取最宽页，clamp 到可读范围）。
// html 为各页 <img>（每页按自身 PDF 页宽换算显示宽度，DocImage 锁定长宽比，仅改尺寸不变形）。
export async function pdfToHtml(arrayBuffer) {
  var pdfjsLib = await ensurePdfjs();
  var pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  var html = '';
  var maxDisplayWidth = 0;
  for (var p = 1; p <= pdf.numPages; p++) {
    var page = await pdf.getPage(p);
    var base = page.getViewport({ scale: 1.0 });
    // PDF 点 → CSS px @96dpi（A4 595pt→793px、Letter 612pt→816px），clamp 到可读范围。
    // 每页按自身宽度算显示宽：宽幅页变大、窄页变小，避免一刀切压窄宽幅 PDF（右侧截断）。
    var displayW = clamp(Math.round(base.width * 96 / 72), PAGE_WIDTH_MIN, PAGE_WIDTH_MAX);
    if (displayW > maxDisplayWidth) maxDisplayWidth = displayW;
    var scale = RENDER_WIDTH / base.width; // canvas 内部仍按 RENDER_WIDTH 渲染保证清晰
    var viewport = page.getViewport({ scale: scale });

    var canvas = document.createElement('canvas');
    canvas.width = Math.round(viewport.width);
    canvas.height = Math.round(viewport.height);
    var ctx = canvas.getContext('2d');
    // PDF 可能无白底，先填白避免透明背景在编辑器里发灰
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: ctx, viewport: viewport }).promise;

    var dataUrl = pickSmallerDataUrl(canvas);
    // width 属性会被 DocImage 保留（render 为 style:width:Npx）；每页 displayW ≤ maxDisplayWidth
    // （同一 clamp 上界），故最宽图恒 ≤ 编辑器页宽，不会溢出。
    html += '<img src="' + dataUrl + '" width="' + displayW + '" alt="PDF p.' + p + '">';

    page.cleanup && page.cleanup();
  }
  return { html: html, pageWidth: maxDisplayWidth + 'px' };
}
