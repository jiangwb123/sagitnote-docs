// 文件导入分发器：按扩展名/MIME 判定类型，分流到对应转换器。
// 所有转换在本地完成；输出 HTML 由 doc-editor 的 importFile 经 TipTap setContent 写入。
import { markdownToHtml } from './markdown.js';
import { analyzeHtml } from './html.js';
import { pdfToHtml } from './pdf.js';
import { docxToHtml } from './docx.js';
import { xlsxToHtml } from './xlsx.js';

function detectKind(file) {
  var name = String(file.name || '').toLowerCase();
  var mt = String(file.type || '').toLowerCase();
  if (name.indexOf('.pdf') === name.length - 4 || mt === 'application/pdf') return 'pdf';
  if (name.endsWith('.docx') || mt === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') return 'docx';
  if (name.endsWith('.xlsx') || name.endsWith('.xls') ||
      mt === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
      mt === 'application/vnd.ms-excel') return 'xlsx';
  if (name.endsWith('.html') || name.endsWith('.htm') || mt === 'text/html') return 'html';
  if (name.endsWith('.md') || name.endsWith('.markdown') || mt === 'text/markdown') return 'markdown';
  throw new Error('unsupported');
}

// 统一返回 { html, pageWidth, needsChoice, unsupportedTags, readOnlyHtml }：
//  - html：过滤后 HTML（编辑器可表示的内容）
//  - readOnlyHtml：只读导入用 HTML（保留 canvas/svg/video/audio，剥 iframe/embed/object/form）
//  - needsChoice：html 导入检测到「编辑器无法表示的元素」→ 调用方弹窗二选一
//  - pageWidth：可选建议编辑器页宽（目前仅 PDF 提供，按其页宽自适应）
// html/markdown/docx/xlsx 的 readOnlyHtml 同 html（它们不产生编辑器无法表示的元素）。
export async function convertToHtml(file) {
  var kind = detectKind(file);
  var result;
  if (kind === 'pdf') result = await pdfToHtml(await file.arrayBuffer());
  else if (kind === 'docx') result = await docxToHtml(await file.arrayBuffer());
  else if (kind === 'xlsx') result = await xlsxToHtml(await file.arrayBuffer());
  else if (kind === 'html') return Object.assign({ pageWidth: null }, analyzeHtml(await file.text()));
  else result = await markdownToHtml(await file.text()); // markdown
  if (typeof result === 'string') result = { html: result, pageWidth: null };
  return Object.assign({ readOnlyHtml: result.html, needsChoice: false, unsupportedTags: [] }, result);
}
