// .xlsx / .xls → HTML（用于自建文档「导入文件」）
// 用 SheetJS（社区版，浏览器构建，按需动态 import，镜像 pdf.js 的 ensurePdfjs 模式）。
// 每个 worksheet → 一张 <table>（XLSX.utils.sheet_to_html），多 sheet 时用 <h3>sheet 名</h3> 分隔。
// 命中 doc-editor 已注册的 Table 扩展（td/th/colspan/rowspan/全局 style 均已放行）。
var _xlsxReady = null;

async function ensureXlsx() {
  if (_xlsxReady) return _xlsxReady;
  _xlsxReady = (async function () {
    var mod = await import(chrome.runtime.getURL('lib/xlsx/xlsx.bundle.js'));
    return mod.XLSX;
  })().catch(function (e) {
    _xlsxReady = null; // 失败清空缓存，下次重试
    console.error('[importers/xlsx] SheetJS 库动态加载失败（lib/xlsx/xlsx.bundle.js）', e);
    throw e;
  });
  return _xlsxReady;
}

function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// 返回 HTML 字符串：每张表前加 <h3>sheet 名</h3>；单 sheet 也加标题（便于区分）。
export async function xlsxToHtml(arrayBuffer) {
  var XLSX = await ensureXlsx();
  var wb = XLSX.read(new Uint8Array(arrayBuffer), { type: 'array' });
  var names = wb.SheetNames || [];
  var parts = [];
  for (var i = 0; i < names.length; i++) {
    var name = names[i];
    var ws = wb.Sheets[name];
    if (!ws) continue;
    // sheet_to_html 产出 <table ...>..</table>（含 id/td data 属性；TipTap schema 会剥多余属性）
    var tableHtml = XLSX.utils.sheet_to_html(ws, { editable: false });
    parts.push('<h3>' + escapeHtml(name) + '</h3>' + tableHtml);
  }
  return parts.join('\n');
}
