// HTML/HTM → 清洗后 HTML（用于自建文档「导入文件」）
// 用 DOMParser 解析，剥除脚本/样式/事件处理等危险与非内容节点，返回 <body> 内 HTML。
// 之后 TipTap setContent 会再按 schema 清洗一道（双保险）：未注册的标签/属性一律丢弃。

// TipTap（ProseMirror 内核）schema 未注册、导入后会被丢弃的「富元素」集合。
// 检测到这些元素时弹窗让用户在「过滤导入 / 只读导入」间二选一。
export const UNSUPPORTED_TAGS = ['canvas', 'svg', 'iframe', 'video', 'audio', 'embed', 'object', 'form'];

// 危险/非内容节点（两种路径都剥；head 整块移除以丢掉 title/meta/link 等）
const STRIP_COMMON = 'script, style, link, meta, noscript, template, title, base, head';
// 只读路径额外剥离（过滤路径下这些元素由 TipTap schema 丢弃；只读路径无 TipTap，必须显式剥）。
// 注意：这些是「编辑/只读都放行不了」的嵌入/表单面（安全 + 合规），只读导入并不保留它们。
const STRIP_READ_ONLY = 'iframe, embed, object, form';

function stripCommon(doc) {
  doc.querySelectorAll(STRIP_COMMON).forEach(function (n) {
    n.remove();
  });

  // 剥除 on* 事件属性与 javascript: 协议的 href/src（防 XSS；schema 也会再过滤）
  doc.querySelectorAll('*').forEach(function (el) {
    Array.prototype.forEach.call(el.attributes, function (attr) {
      var name = attr.name.toLowerCase();
      var val = String(attr.value || '').trim().toLowerCase();
      if (name.indexOf('on') === 0) {
        el.removeAttribute(attr.name);
      } else if ((name === 'href' || name === 'src') && val.indexOf('javascript:') === 0) {
        el.removeAttribute(attr.name);
      }
    });
  });
}

// 过滤路径：剥危险/非内容节点，返回 body HTML（TipTap setContent 再按 schema 二次过滤）。
export function htmlFileToHtml(raw) {
  var doc = new DOMParser().parseFromString(String(raw || ''), 'text/html');
  stripCommon(doc);
  return doc.body ? doc.body.innerHTML : '';
}

// 只读路径：在通用清洗之外再剥 iframe/embed/object/form，但保留 canvas/svg/video/audio/source
// 等安全富元素（服务端 HtmlSanitizer 的只读白名单会再消毒一道）。
export function htmlFileToHtmlReadOnly(raw) {
  var doc = new DOMParser().parseFromString(String(raw || ''), 'text/html');
  stripCommon(doc);
  doc.querySelectorAll(STRIP_READ_ONLY).forEach(function (n) {
    n.remove();
  });
  return doc.body ? doc.body.innerHTML : '';
}

// 检测 body 内是否存在编辑器无法表示的元素（去重、小写）。返回命中标签名数组。
export function detectUnsupportedTags(raw) {
  var doc = new DOMParser().parseFromString(String(raw || ''), 'text/html');
  if (!doc.body) return [];
  var seen = {};
  var out = [];
  doc.querySelectorAll(UNSUPPORTED_TAGS.join(',')).forEach(function (el) {
    var t = el.tagName.toLowerCase();
    if (!seen[t]) {
      seen[t] = true;
      out.push(t);
    }
  });
  return out;
}

// 一次解析出「过滤版 + 只读版 + 检测结果」，避免 convertToHtml 对大文件重复解析。
export function analyzeHtml(raw) {
  var doc = new DOMParser().parseFromString(String(raw || ''), 'text/html');

  var unsupportedTags = [];
  var seen = {};
  doc.querySelectorAll(UNSUPPORTED_TAGS.join(',')).forEach(function (el) {
    var t = el.tagName.toLowerCase();
    if (!seen[t]) {
      seen[t] = true;
      unsupportedTags.push(t);
    }
  });

  var filtered = doc.cloneNode(true);
  stripCommon(filtered);
  var readOnly = doc.cloneNode(true);
  stripCommon(readOnly);
  readOnly.querySelectorAll(STRIP_READ_ONLY).forEach(function (n) {
    n.remove();
  });

  return {
    html: filtered.body ? filtered.body.innerHTML : '',
    readOnlyHtml: readOnly.body ? readOnly.body.innerHTML : '',
    needsChoice: unsupportedTags.length > 0,
    unsupportedTags: unsupportedTags
  };
}
