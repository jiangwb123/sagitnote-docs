// 「自建文档」富文本编辑器（Phase 6 + Phase 8）— TipTap v3 + KaTeX + 图片云链路
//
// 被打包成独立 IIFE（dist/manager/doc-editor.js），由 manager.js 按需 <script src> 注入，
// 暴露 window.WPZL_docEditor。绝不在 manager.js 顶层 import（懒加载不可妥协）。
//
// ── 关键契约：数学节点序列化对齐 ──
// 服务端 /d/{docId} 渲染脚本 + HtmlSanitizer 白名单要求：
//   inline → <span class="math-inline" data-latex="<tex>">
//   block  → <div  class="math-display" data-latex="<tex>" data-math-type="display">
// 默认 @tiptap/extension-mathematics 的 parseHTML/renderHTML 依赖 data-type，HtmlSanitizer 会
// 剥离 data-type → 重开编辑器无法回 parse。故 .extend() 覆写，改用 class + data-latex 键。
//
// ── D1 文档图片：剪贴板/拖拽 → base64 直接内嵌进 body；外链图保持外链 ──
// 编辑态 img src 即最终态（data: 或 http），随 body 存 R2；「将图片保存到文档」按钮把选中外链图
// fetch 成 base64 内嵌（失败保留外链）。文档图片不再走 imageData/image_assets 间接层。
// pageUrl=docWebUri（mount 时传入）；imageKey/pageKey 由 SW 用 wpzl_md5 算。

import { Editor, mergeAttributes, Extension, Mark } from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';
import Link from '@tiptap/extension-link';
import Image from '@tiptap/extension-image';
import { TextStyle, FontFamily, FontSize, Color, BackgroundColor } from '@tiptap/extension-text-style';
import Paragraph from '@tiptap/extension-paragraph';
import { InlineMath, BlockMath } from '@tiptap/extension-mathematics';
// 表格扩展：v3 把 Table/TableRow/TableHeader/TableCell 都从 @tiptap/extension-table 具名导出
// （-table-row/-cell/-header 子包只是再导出）。序列化为 <table><thead><tbody><tr><th><td colspan rowspan>，
// 服务端 HtmlSanitizer relaxed() 已放行全套标签 + colspan/rowspan/style，无需改白名单。
import { Table, TableRow, TableHeader, TableCell } from '@tiptap/extension-table';
import TextAlign from '@tiptap/extension-text-align';
import katex from 'katex';   // 预览实时渲染（与 extension-mathematics 共用同一份 katex，rollup 去重不增体积）
import { convertToHtml } from './importers/index.js';   // 导入文件：PDF/HTML/Markdown → HTML 分发器（其内部按需 import marked / 复用 pdfjs）
import { Plugin, PluginKey } from '@tiptap/pm/state';
import { Decoration, DecorationSet } from '@tiptap/pm/view';

// —— 表格行高拖拽插件（prosemirror-tables 只支持列宽 columnResizing，行高需自定义）——
const rowResizingPluginKey = new PluginKey('docRowResizing');

class RowResizeState {
  constructor(activeRow, dragging) { this.activeRow = activeRow; this.dragging = dragging; }
  apply(tr) {
    const a = tr.getMeta(rowResizingPluginKey);
    if (a && a.setHandle !== undefined) return new RowResizeState(a.setHandle, null);
    if (a && a.setDragging !== undefined) return new RowResizeState(this.activeRow, a.setDragging);
    if (this.activeRow > -1 && tr.docChanged) {
      let h = tr.mapping.map(this.activeRow, -1);
      const $pos = tr.doc.resolve(h);
      if ($pos.node().type.name !== 'tableRow') h = -1;
      return new RowResizeState(h, this.dragging);
    }
    return this;
  }
}

function domRowAround(target) {
  while (target && target.nodeName !== 'TR')
    target = target.classList && target.classList.contains('ProseMirror') ? null : target.parentNode;
  return target;
}

// 从 DOM <tr> 反查 ProseMirror 中对应 tableRow 的 pos（兼容 TableView NodeView 包装）
function rowPosFromDOM(view, trEl) {
  try {
    const pos = view.posAtDOM(trEl, 0);
    const $pos = view.state.doc.resolve(pos);
    for (let d = $pos.depth; d >= 0; d--) {
      // $pos.start(d) 返回的是节点内容的起始位置；setNodeMarkup 需要用节点自身位置（-1）
      if ($pos.node(d).type.name === 'tableRow') return $pos.start(d) - 1;
    }
  } catch (e) { /* trEl not in editor DOM */ }
  return -1;
}

// 从 ProseMirror pos 直接取对应 DOM 元素（绕开 domAtPos 的文本节点陷阱）
function rowDOMAtPos(view, pos) {
  try {
    const el = view.nodeDOM(pos);
    if (el && el.nodeName === 'TR') return el;
  } catch (e) { /* NodeView boundary / position mismatch */ }
  return null;
}

function rowResizing({ handleHeight = 5, minRowHeight = 20 } = {}) {
  return new Plugin({
    key: rowResizingPluginKey,
    state: { init() { return new RowResizeState(-1, null); }, apply(tr, prev) { return prev.apply(tr); } },
    props: {
      attributes(state) {
        const ps = rowResizingPluginKey.getState(state);
        return ps && ps.activeRow > -1 ? { class: 'resize-cursor-row' } : {};
      },
      handleDOMEvents: {
        mousemove(view, event) {
          if (!view.editable) return;
          const ps = rowResizingPluginKey.getState(view.state);
          if (!ps || ps.dragging) return;
          const trEl = domRowAround(event.target);
          let row = -1;
          if (trEl) {
            const r = trEl.getBoundingClientRect();
            // 仅在行内靠近底边时激活（handleHeight px 内）；同时保证光标在行内
            if (event.clientY >= r.top && r.bottom - event.clientY <= handleHeight) {
              row = rowPosFromDOM(view, trEl);
            }
          }
          if (row !== ps.activeRow) updateRowHandle(view, row);
        },
        mouseleave(view) {
          if (!view.editable) return;
          const ps = rowResizingPluginKey.getState(view.state);
          if (ps && ps.activeRow > -1 && !ps.dragging) updateRowHandle(view, -1);
        },
        mousedown(view, event) {
          if (!view.editable) return false;
          const ps = rowResizingPluginKey.getState(view.state);
          if (!ps || ps.activeRow === -1 || ps.dragging) return false;
          const $row = view.state.doc.resolve(ps.activeRow);
          // 用 view.nodeDOM 直接取 <tr>，避免 domAtPos().childNodes[N] 踩到空白文本节点
          const rowEl = rowDOMAtPos(view, ps.activeRow);
          const startH = (rowEl && rowEl.offsetHeight) || (($row.node().attrs.rowHeight) || minRowHeight);
          view.dispatch(view.state.tr.setMeta(rowResizingPluginKey, { setDragging: { startY: event.clientY, startHeight: startH } }));
          const win = view.dom.ownerDocument.defaultView || window;
          function finish(e) {
            win.removeEventListener('mouseup', finish); win.removeEventListener('mousemove', move);
            const ps2 = rowResizingPluginKey.getState(view.state);
            if (!ps2 || !ps2.dragging) return;
            const h = Math.max(minRowHeight, ps2.dragging.startHeight + (e.clientY - ps2.dragging.startY));
            const tr = view.state.tr.setNodeMarkup(ps.activeRow, null, { ...$row.node().attrs, rowHeight: h });
            view.dispatch(tr.setMeta(rowResizingPluginKey, { setDragging: null }));
          }
          function move(e) {
            if (!e.which) return finish(e);
            const ps2 = rowResizingPluginKey.getState(view.state);
            if (!ps2 || !ps2.dragging) return;
            const h = Math.max(minRowHeight, ps2.dragging.startHeight + (e.clientY - ps2.dragging.startY));
            // 拖拽中直接操作 DOM 实现即时视觉反馈；finish 时通过 transaction 提交
            const re2 = rowDOMAtPos(view, ps.activeRow);
            if (re2) re2.style.height = h + 'px';
          }
          win.addEventListener('mouseup', finish); win.addEventListener('mousemove', move);
          event.preventDefault(); return true;
        },
      },
      decorations(state) {
        const ps = rowResizingPluginKey.getState(state);
        if (ps && ps.activeRow > -1) {
          // 在每个激活行的最后一个单元格末尾注入行高拖拽手柄 widget
          // Decoration.node 不可用于 NodeView 内部的节点（如 tableRow），故用 widget
          const decos = [];
          state.doc.descendants((node, pos) => {
            // 找到 activeRow 对应每一行的最后一个单元格
            if (node.type.name === 'tableCell' || node.type.name === 'tableHeader') {
              const $cell = state.doc.resolve(pos);
              // 检查这个单元格是否属于激活行
              for (let d = $cell.depth; d >= 0; d--) {
                if ($cell.node(d).type.name === 'tableRow' && $cell.start(d) === ps.activeRow) {
                  // 在单元格末尾（end of node - 1）放 widget
                  decos.push(Decoration.widget(pos + node.nodeSize - 1, () => {
                    const h = document.createElement('div');
                    h.className = 'row-resize-handle';
                    return h;
                  }, { side: -1 }));
                  return false; // 找到就停止遍历该行
                }
              }
            }
          });
          return DecorationSet.create(state.doc, decos);
        }
        return DecorationSet.empty;
      },
    },
  });
}
function updateRowHandle(view, value) { view.dispatch(view.state.tr.setMeta(rowResizingPluginKey, { setHandle: value })); }

// RowResizeExtension — 把 rowResizing plugin 注册为 TipTap Extension
const RowResizeExtension = Extension.create({
  name: 'rowResize',
  addProseMirrorPlugins() { return [rowResizing({ handleHeight: 5, minRowHeight: 20 })]; },
});

// 扩展 TableRow：增加 rowHeight 属性（序列化为 style="height:Xpx"，对齐 colwidth 的存续模式）
const DocTableRow = TableRow.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      rowHeight: {
        default: null,
        parseHTML: element => {
          const h = element.style.height || element.getAttribute('height');
          if (!h) return null;
          const v = parseInt(h, 10);
          return v > 0 ? v : null;
        },
        renderHTML({ rowHeight }) {
          if (rowHeight == null) return {};
          return { style: `height: ${rowHeight}px` };
        },
      },
    };
  },
});

// —— 数学节点覆写：对齐服务端 /d/{docId} 渲染脚本 + HtmlSanitizer 白名单 ——
const DocInlineMath = InlineMath.extend({
  parseHTML() {
    return [{ tag: 'span.math-inline' }, { tag: 'span[data-latex]' }];
  },
  renderHTML({ HTMLAttributes }) {
    return ['span', mergeAttributes(this.options.HTMLAttributes || {}, HTMLAttributes, { class: 'math-inline' })];
  },
});
const DocBlockMath = BlockMath.extend({
  parseHTML() {
    return [{ tag: 'div.math-display' }, { tag: 'div[data-latex]' }];
  },
  renderHTML({ HTMLAttributes }) {
    return ['div', mergeAttributes(this.options.HTMLAttributes || {}, HTMLAttributes, { class: 'math-display', 'data-math-type': 'display' })];
  },
});

// —— 文档图片扩展：加 width/height 自定义 attrs，承载 TipTap v3 内置 ResizableNodeView 的缩放结果 ——
//   D1：文档图片内嵌为 data:image/...;base64 或外链 http，随 body 存取；不再走 data-image-key 间接层。
//   渲染为 inline style（HtmlSanitizer 全局放行 style + img[width,height]），重开可还原尺寸。
const pxNum = (v) => { const n = parseInt(String(v).replace(/[^\d.]/g, ''), 10); return Number.isFinite(n) && n > 0 ? n : null; };
const DocImage = Image.extend({
  // D1：所有文档图都有 src（内嵌 data: 或外链 http），用 parent 默认 img 规则即可解析。
  parseHTML() { return this.parent ? this.parent() : []; },
  addAttributes() {
    return {
      ...(this.parent ? this.parent() : {}),
      width: {
        default: null,
        parseHTML: (el) => pxNum(el.getAttribute('width') || el.style.width),
        renderHTML: (attrs) => (attrs.width ? { style: `width: ${attrs.width}px` } : {}),
      },
      height: {
        default: null,
        parseHTML: (el) => pxNum(el.getAttribute('height') || el.style.height),
        renderHTML: (attrs) => (attrs.height ? { style: `height: ${attrs.height}px` } : {}),
      },
    };
  },
});

// —— 字体（inline，按选区）：直接用官方 FontFamily / FontSize（addGlobalAttributes 挂到 textStyle mark） ——
//   HtmlSanitizer 全局放行 style，font-family/font-size 往返安全。当前值读 editor.getAttributes('textStyle')。

// —— 行距（block，按段落）：Paragraph 上挂 lineHeight 属性 → inline style on <p> ——
//   不用官方 inline LineHeight（mark）：光标在段落内点击行距时，inline mark 只影响后续输入、不改当前段落，
//   体验差；段落级属性 updateAttributes('paragraph') 对当前段落（含跨段落选区）立即生效，符合"行距"语义。
const DocParagraph = Paragraph.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      lineHeight: {
        default: null,
        parseHTML: (el) => el.style.lineHeight || null,
        renderHTML: (attrs) => (attrs.lineHeight ? { style: `line-height: ${attrs.lineHeight}` } : {}),
      },
    };
  },
  addCommands() {
    return {
      ...this.parent?.(),
      setLineHeight: (lineHeight) => ({ commands }) => commands.updateAttributes('paragraph', { lineHeight }),
      unsetLineHeight: () => ({ commands }) => commands.updateAttributes('paragraph', { lineHeight: null }),
    };
  },
});

// —— Obsidian 保真 marks（导入/导出往返，载体约定见 importers/markdown.js 头注释）——
//   [[t]]/[[t|a]] → <a class="wpz-wikilink" title="T">ALIAS</a>：无 href 是刻意设计——
//     ① jsoup relaxed() 对 a[href] 有协议限制（http/https/mailto），笔记名 href 会被剥；
//     ② TipTap Link 的 parseHTML 只匹配 a[href]，无 href 互不冲突。target 存 title 属性
//     （relaxed() 的 a 自带 title 白名单）。
//   inclusive:false：光标落在 chip 尾部继续输入时不延续 mark（chip 边界稳定，导出还原可靠）。
const ObsidianWikilink = Mark.create({
  name: 'obsidianWikilink',
  inclusive: false,
  addAttributes() {
    return {
      target: {
        default: null,
        parseHTML: (el) => el.getAttribute('title') || null,
        renderHTML: (attrs) => (attrs.target ? { title: attrs.target } : {}),
      },
    };
  },
  parseHTML() { return [{ tag: 'a.wpz-wikilink' }]; },
  renderHTML({ HTMLAttributes }) { return ['a', mergeAttributes({ class: 'wpz-wikilink' }, HTMLAttributes), 0]; },
});
const ObsidianEmbed = Mark.create({
  name: 'obsidianEmbed',
  inclusive: false,
  parseHTML() { return [{ tag: 'span.wpz-embed' }]; },
  renderHTML({ HTMLAttributes }) { return ['span', mergeAttributes({ class: 'wpz-embed' }, HTMLAttributes), 0]; },
});
const ObsidianTag = Mark.create({
  name: 'obsidianTag',
  inclusive: false,
  parseHTML() { return [{ tag: 'span.wpz-tag' }]; },
  renderHTML({ HTMLAttributes }) { return ['span', mergeAttributes({ class: 'wpz-tag' }, HTMLAttributes), 0]; },
});
const ObsidianComment = Mark.create({
  name: 'obsidianComment',
  inclusive: false,
  parseHTML() { return [{ tag: 'span.wpz-comment' }]; },
  renderHTML({ HTMLAttributes }) { return ['span', mergeAttributes({ class: 'wpz-comment' }, HTMLAttributes), 0]; },
});
// ==高亮== 载体 <mark>：服务端 HtmlSanitizer 已补 mark 标签白名单（relaxed() 不含）。
// 不引入 @tiptap/extension-highlight（避免新依赖；编辑器「荧光笔」工具栏仍用 BackgroundColor，互不影响）。
const ObsidianHighlight = Mark.create({
  name: 'obsidianHighlight',
  parseHTML() { return [{ tag: 'mark' }]; },
  renderHTML({ HTMLAttributes }) { return ['mark', mergeAttributes({ class: 'wpz-highlight' }, HTMLAttributes), 0]; },
});

let editor = null;
let host = null;
let onSaveCb = null;
let onCancelCb = null;
let lastSavedHtml = '';          // #4: last successfully saved HTML snapshot (dirty baseline; updated via markSaved)
let _ctrlSHandler = null;        // #4: Ctrl+S global keydown handler ref (removed in destroy)
let _pageWidth = '820px';        // 页面宽度（「全宽」='none'），mount 初始化 CSS var → buildToolbar 下拉回填
let currentDocWebUri = '';   // Phase 8：图片 pageKey 用（mount 时传入）

function ensureCSS(id, href) {
  if (document.getElementById(id)) return;
  const l = document.createElement('link');
  l.id = id; l.rel = 'stylesheet'; l.href = href;
  document.head.appendChild(l);
}

// i18n（doc-editor 在 manager 页运行，chrome.i18n 可用；fallback 保证键缺失时不阻断）
function i18n(key, fallback) {
  try { var m = chrome.i18n.getMessage(key); return m || fallback; } catch (e) { return fallback; }
}

// 内置 toast（doc-editor 独立 bundle，无 manager.js 上下文）
function showToast(msg, ms) {
  let el = document.getElementById('wpzl-doc-editor-toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'wpzl-doc-editor-toast';
    el.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#1e293b;color:#fff;padding:8px 16px;border-radius:6px;font-size:13px;z-index:2147483647;box-shadow:0 4px 12px rgba(0,0,0,0.2);display:none;';
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.style.display = 'block';
  clearTimeout(el._t);
  el._t = setTimeout(() => { el.style.display = 'none'; }, ms || 2200);
}

// 持久加载提示条（导入 PDF/HTML/Markdown 转换耗时较长时用）。区别于 showToast：
//   - 不自动消失，必须显式 hideLoadingBar() 关闭（转换耗时不可预测，toast 固定 2.2s 会过早消失）
//   - 带 spinner 动画 + 文案，让用户明确感知"正在处理"而非"没反应"
//   - 同样挂 document.body、z-index 顶格，样式复用 toast 的暗色胶囊风格
function showLoadingBar(msg) {
  let el = document.getElementById('wpzl-doc-editor-loading');
  if (!el) {
    el = document.createElement('div');
    el.id = 'wpzl-doc-editor-loading';
    el.className = 'wpzl-doc-editor-loading';
    el.innerHTML =
      '<span class="wpzl-doc-editor-loading-spin"></span>' +
      '<span class="wpzl-doc-editor-loading-text"></span>';
    document.body.appendChild(el);
  }
  el.querySelector('.wpzl-doc-editor-loading-text').textContent = msg || '';
  el.style.display = 'flex';
}
function hideLoadingBar() {
  const el = document.getElementById('wpzl-doc-editor-loading');
  if (el) el.style.display = 'none';
}

// SW db-operation 封装（doc-editor 在 manager 页，chrome.runtime 可用）
function dbOperation(operation, params) {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage(
        { type: 'db-operation', operation: operation, params: params || {} },
        (resp) => {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          if (resp && resp.success) resolve(resp.data);
          else reject(new Error((resp && resp.error) || 'op failed'));
        }
      );
    } catch (e) { reject(e); }
  });
}

// D1：剪贴板/拖拽图片 → base64 直接内嵌进文档 body（data:image/...;base64）。
// 不再走 imageData/image_assets 间接层 —— 图片随 body 一起存 R2、随文档删除自动清理。
// 服务端 HtmlSanitizer 已放开 data:image/*（仅光栅图，MIME 守卫阻断 data:text/html 等）。
async function insertImageBlob(blob) {
  if (!editor || !blob) return;
  const base64 = await _readFileAsDataUrl(blob);
  editor.chain().focus().setImage({ src: base64 }).run();
}

function _readFileAsDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onloadend = () => resolve(r.result);
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

// ===== 批量导入本地图片（D1：data:base64 内嵌 body；入口=侧边栏「从图片新建」/ 📥 多选）=====
// 图片仅来自用户本地文件，全程本地处理。服务端 HtmlSanitizer 对 img src 的 data: 仅放行
// data:image/(png|jpeg|jpg|webp|gif) —— 白名单外类型（bmp/avif/tiff/svg/heic 等）必须经
// canvas 重编码为 webp/jpeg 再内嵌，否则本地能显示、/d/ 公开渲染页会被置空 src 丢图。
// GIF 永不重编码（canvas 只能出单帧丢动画，data:image/gif 本就在白名单内）。
//
// 体积策略（用户选择 + 限额自适应）：
//  - 每次导入先弹窗（chooseImageImportOptions）让用户选择：「等比缩小像素」可填最大宽度/高度
//    （px，等比 scale=min(1,maxW/w,maxH/h)，只缩不放大、不变形；任一维度留空=不限），
//    或保留原始尺寸（高清批注场景）。最大宽度默认预填当前页宽（img max-width:100% 超出部分不显示）
//  - 保留原始尺寸时不做任何降级（尊重高清需求），超预算整图跳过（skip:'quota'）
//  - 选择缩放时 manager 的 sizeBudget（= docSizeLimit 字符数，≤0 不限）仍兜底：单图装不下按
//    「q0.9 → q0.7 → 目标宽×0.6/q0.7」阶梯降级（结果仍 ≤ 用户指定上限），仍超才跳过
const DOC_IMG_ALLOWED_MIME = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif'];
const DOC_IMG_MAX_EDGE = 4096;                 // 与注入侧 wpzl_compressForImageBackup 的 maxW 一致
const DOC_IMG_MAX_PIXELS = 24000000;           // 同上（总像素上限）
const DOC_IMG_QUALITY = 0.9;                   // 同上（webp/jpeg 编码质量，主候选质量）
const DOC_IMG_RAW_MAX_BYTES = 8 * 1024 * 1024; // 超过此体积不做「原样内嵌」候选（只走重编码）
const DOC_IMG_TAG_OVERHEAD = 100;              // 单图 img/段落标签开销（预算口径的粗略余量）

// 扩展名 → MIME（file.type 为空时兜底；覆盖白名单 + 需重编码的常见类型）
const DOC_IMG_EXT_MIME = {
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', jfif: 'image/jpeg',
  webp: 'image/webp', gif: 'image/gif', bmp: 'image/bmp', avif: 'image/avif',
  heic: 'image/heic', heif: 'image/heif', tif: 'image/tiff', tiff: 'image/tiff', svg: 'image/svg+xml'
};

function _sniffImageMime(file) {
  if (file && file.type && String(file.type).indexOf('image/') === 0) return String(file.type).toLowerCase();
  const ext = String((file && file.name) || '').toLowerCase().split('.').pop();
  return DOC_IMG_EXT_MIME[ext] || '';
}

// 文档是否有实质内容（镜像 manager handleDocEditorImport 的 nonEmpty 判定：可见文字，或
// 图片/表格/分隔线/块级公式等非文字节点）。决定 importImages「整体写入」还是「追加末尾」。
function _docHasContent() {
  if (!editor) return false;
  let has = false;
  editor.state.doc.descendants((node) => {
    if (node.isText && node.text && node.text.trim()) { has = true; return false; }
    if (['image', 'table', 'horizontalRule', 'blockMath'].indexOf(node.type.name) >= 0) { has = true; return false; }
    return true;
  });
  return has;
}

// 文件名数字感排序（img2 < img10），多选导入顺序可预期
function _docNumericNameCompare(a, b) {
  return String(a.name || '').localeCompare(String(b.name || ''), undefined, { numeric: true, sensitivity: 'base' });
}

// 导入弹窗「最大宽度」的默认预填值：文档页宽（img max-width:100%，超出部分不显示）。
// 「全宽」（'none'）/异常值兜底 1280 —— 全宽文档按常见屏宽的保守值。
function _docPageWidthPx() {
  const n = parseInt(_pageWidth, 10);
  return (n > 0) ? n : 1280;
}

// 解码图片取绘制源与尺寸。createImageBitmap 对光栅图最快（SVG 必失败）→ 回退 <img>+objectURL。
// 返回 { source, width, height, close }；坏文件 / 无固有尺寸 → null。close 负责 bitmap.close()。
async function _decodeImageSource(file) {
  try {
    const bitmap = await createImageBitmap(file);
    if (bitmap.width > 0 && bitmap.height > 0) {
      return { source: bitmap, width: bitmap.width, height: bitmap.height, close: () => bitmap.close() };
    }
    bitmap.close();
  } catch (e) { /* SVG 等 → 走 <img> 回退 */ }
  return await new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    const done = (ok) => {
      URL.revokeObjectURL(url);
      resolve(ok && img.naturalWidth > 0 && img.naturalHeight > 0
        ? { source: img, width: img.naturalWidth, height: img.naturalHeight, close: () => {} }
        : null);
    };
    img.onload = () => done(true);
    img.onerror = () => done(false);
    img.src = url;
  });
}

// webp 编码能力探测（模块级惰性缓存；Chrome 扩展页必支持，探测仅为防御性回退依据）
let _canvasWebpOk = null;
function _canvasSupportsWebp() {
  if (_canvasWebpOk == null) {
    try {
      const c = document.createElement('canvas');
      c.width = 1; c.height = 1;
      _canvasWebpOk = c.toDataURL('image/webp').indexOf('data:image/webp') === 0;
    } catch (e) { _canvasWebpOk = false; }
  }
  return _canvasWebpOk;
}

// canvas 重编码 → 可内嵌 dataUrl。只缩不放大（MAX_EDGE / MAX_PIXELS 双约束），webp 优先，
// 失败回退 jpeg → png（三者均命中服务端白名单）。仿 wpzl_compressRectThumb 但自包含（doc-editor 不依赖注入层）。
// quality 由调用方传入（预算降级时降低），缺省 DOC_IMG_QUALITY。
function _encodeCanvasToSrc(source, width, height, quality) {
  try {
    const scale = Math.min(1,
      DOC_IMG_MAX_EDGE / width,
      DOC_IMG_MAX_EDGE / height,
      Math.sqrt(DOC_IMG_MAX_PIXELS / (width * height)));
    const w = Math.max(1, Math.round(width * scale));
    const h = Math.max(1, Math.round(height * scale));
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(source, 0, 0, w, h);
    const types = _canvasSupportsWebp() ? ['image/webp', 'image/jpeg', 'image/png'] : ['image/jpeg', 'image/png'];
    for (let i = 0; i < types.length; i++) {
      const url = canvas.toDataURL(types[i], quality || DOC_IMG_QUALITY);
      if (url.indexOf('data:' + types[i]) === 0) return url;
    }
  } catch (e) { /* 落到 null，由调用方按 decode 失败跳过 */ }
  return null;
}

// 单文件 → 可内嵌 src（用户选择的目标尺寸 + 预算自适应）。成功 { src }；失败 { skip: 'unsupported'|'decode'|'quota' }。
// used/budget 为预算口径（budget ≤ 0 = 不限）：used + 新 src 长度须 ≤ budget。
// maxW/maxH 为用户在导入弹窗填的最大宽度/高度（px，≤0 = 该维度不限；都 ≤0 = 保留原始尺寸）。
//  - GIF：无法重编码（丢动画）→ 原样内嵌；超预算只能跳过
//  - 保留原始尺寸（未触发缩放）：白名单原样即最优（无损）；白名单外仍须原尺寸转码（服务端白名单约束）
//  - 触发缩放：等比 scale=min(1,maxW/w,maxH/h)（只缩不放大、不变形）webp q0.9，
//    与「原样」（仅白名单且 ≤8MB）比大小取小者 —— 小图标原样更小且无损
//  - 预算兜底仅在触发缩放时生效（尊重「保留原始尺寸」的选择，不偷偷降画质/分辨率）：
//    q0.7 → 目标宽×0.6/q0.7 阶梯降级（结果仍 ≤ 用户上限）；仍超 → skip quota
async function _fileToEmbeddableSrc(file, used, budget, maxW, maxH) {
  const mime = _sniffImageMime(file);
  if (!mime) return { skip: 'unsupported' };
  const fits = (len) => (budget <= 0) || (used + len + DOC_IMG_TAG_OVERHEAD <= budget);
  if (mime === 'image/gif') {
    const gifSrc = await _readFileAsDataUrl(file);
    return fits(gifSrc.length) ? { src: gifSrc } : { skip: 'quota' };
  }
  const dec = await _decodeImageSource(file);
  if (!dec) return { skip: 'decode' };
  try {
    const scale = Math.min(1,
      (maxW > 0) ? maxW / dec.width : 1,
      (maxH > 0) ? maxH / dec.height : 1,
      DOC_IMG_MAX_EDGE / dec.width,
      DOC_IMG_MAX_EDGE / dec.height);
    const userScaled = scale < 1;   // 含 MAX_EDGE 硬上限触发的收敛（>4096px 即使「保留原尺寸」也须缩到仓库级上限）
    const targetW = Math.max(1, Math.round(dec.width * scale));
    let rawSrc = null;
    if (DOC_IMG_ALLOWED_MIME.indexOf(mime) >= 0
      && file.size <= DOC_IMG_RAW_MAX_BYTES
      && dec.width <= DOC_IMG_MAX_EDGE && dec.height <= DOC_IMG_MAX_EDGE) {
      try { rawSrc = await _readFileAsDataUrl(file); } catch (e) { rawSrc = null; }
    }
    let best;
    if (rawSrc && !userScaled) {
      best = rawSrc;   // 保留原始尺寸：原样即最优（无损，重编码只会降质）
    } else {
      const mainH = Math.max(1, Math.round(dec.height * targetW / dec.width));
      const mainSrc = _encodeCanvasToSrc(dec.source, targetW, mainH, DOC_IMG_QUALITY);
      best = (rawSrc && (!mainSrc || rawSrc.length < mainSrc.length)) ? rawSrc : mainSrc;
    }
    if (!best) return { skip: 'decode' };
    if (fits(best.length)) return { src: best };
    if (budget > 0 && userScaled) {
      const fallbacks = [
        { w: targetW, q: 0.7 },
        { w: Math.max(160, Math.round(targetW * 0.6)), q: 0.7 },
      ];
      for (let i = 0; i < fallbacks.length; i++) {
        if (fallbacks[i].w > dec.width) continue;   // 只缩不放大
        const h = Math.max(1, Math.round(dec.height * fallbacks[i].w / dec.width));
        const src = _encodeCanvasToSrc(dec.source, fallbacks[i].w, h, fallbacks[i].q);
        if (src && fits(src.length)) return { src };
      }
    }
    return { skip: 'quota' };
  } finally {
    dec.close();
  }
}

// —— 导入图片前的尺寸选择弹窗（每次导入都询问、不记忆 —— 是否缩放须由用户当场决定，
//     高清批注场景需要能保留原始尺寸）。复用 wpzl-math-modal 样式。——
// 返回 Promise<{ maxWidth, maxHeight } | null>（null = 取消）；≤0 = 该维度不限，都 ≤0 = 保留原始尺寸。
let _imgImportDialog = null;
function closeImageImportDialog() {
  if (!_imgImportDialog) return;
  if (_imgImportDialog.overlay && _imgImportDialog.overlay.parentNode) {
    _imgImportDialog.overlay.parentNode.removeChild(_imgImportDialog.overlay);
  }
  _imgImportDialog = null;
}
function chooseImageImportOptions() {
  closeImageImportDialog();
  const overlay = document.createElement('div');
  overlay.className = 'wpzl-math-modal-overlay';
  overlay.innerHTML =
    '<div class="wpzl-math-modal" role="dialog" aria-modal="true">'
    + '<div class="wpzl-math-modal-header">'
    + '<span class="wpzl-math-modal-title"></span>'
    + '<button class="wpzl-math-modal-close" type="button" aria-label="Close">×</button>'
    + '</div>'
    + '<div class="wpzl-math-modal-body">'
    + '<label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer">'
    + '<input type="checkbox" class="wpzl-imgimp-chk" />'
    + '<span class="wpzl-imgimp-chk-label"></span>'
    + '</label>'
    + '<div style="display:flex;align-items:center;gap:8px;margin-top:10px;flex-wrap:wrap">'
    + '<span class="wpzl-imgimp-wlabel" style="font-size:13px"></span>'
    + '<input class="wpzl-prompt-input wpzl-imgimp-w" type="number" min="0" step="10" style="width:110px" />'
    + '<span class="wpzl-imgimp-hlabel" style="font-size:13px"></span>'
    + '<input class="wpzl-prompt-input wpzl-imgimp-h" type="number" min="0" step="10" style="width:110px" />'
    + '</div>'
    + '<div class="wpzl-imgimp-hint" style="margin-top:10px;font-size:12px;color:#64748b;line-height:1.5"></div>'
    + '</div>'
    + '<div class="wpzl-math-modal-footer">'
    + '<button class="wpzl-math-modal-btn wpzl-math-modal-cancel wpzl-imgimp-cancel" type="button"></button>'
    + '<button class="wpzl-math-modal-btn wpzl-math-modal-primary wpzl-imgimp-ok" type="button"></button>'
    + '</div>'
    + '</div>';
  document.body.appendChild(overlay);
  const chk = overlay.querySelector('.wpzl-imgimp-chk');
  const wInput = overlay.querySelector('.wpzl-imgimp-w');
  const hInput = overlay.querySelector('.wpzl-imgimp-h');
  overlay.querySelector('.wpzl-math-modal-title').textContent = i18n('docImportImagesChoiceTitle', '导入图片');
  overlay.querySelector('.wpzl-imgimp-chk-label').textContent = i18n('docImportImagesScaleChk', '等比缩小像素（减小存储体积）');
  overlay.querySelector('.wpzl-imgimp-wlabel').textContent = i18n('docImportImagesMaxWLabel', '最大宽度 (px)');
  overlay.querySelector('.wpzl-imgimp-hlabel').textContent = i18n('docImportImagesMaxHLabel', '最大高度 (px，可留空)');
  overlay.querySelector('.wpzl-imgimp-hint').textContent = i18n('docImportImagesKeepHint',
    '勾选后图片等比缩小到不超过上述上限（任一项留空则该方向不限）；不勾选则保留原始尺寸，适合高清批注，但大图会更快占满文档大小限额。');
  overlay.querySelector('.wpzl-imgimp-ok').textContent = i18n('docImportImagesConfirm', '导入');
  overlay.querySelector('.wpzl-imgimp-cancel').textContent = i18n('docImportImagesCancel', '取消');
  // 默认：勾选缩放 + 最大宽度预填页宽（图片在文档里最多显示到页宽），高度不限
  chk.checked = true;
  wInput.value = String(_docPageWidthPx());
  hInput.value = '';
  const syncInputs = () => {
    wInput.disabled = !chk.checked;
    hInput.disabled = !chk.checked;
  };
  syncInputs();
  chk.addEventListener('change', syncInputs);
  _imgImportDialog = { overlay };
  return new Promise((resolve) => {
    const done = (r) => { closeImageImportDialog(); resolve(r); };
    const num = (el) => {
      if (!chk.checked) return 0;
      const n = parseInt(el.value, 10);
      return (isFinite(n) && n > 0) ? Math.floor(n) : 0;
    };
    const confirm = () => done({ maxWidth: num(wInput), maxHeight: num(hInput) });
    const onKey = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); done(null); }
      else if (e.key === 'Enter') { e.preventDefault(); confirm(); }
    };
    overlay.addEventListener('keydown', onKey);
    overlay.querySelector('.wpzl-imgimp-ok').addEventListener('click', confirm);
    overlay.querySelector('.wpzl-imgimp-cancel').addEventListener('click', () => done(null));
    overlay.querySelector('.wpzl-math-modal-close').addEventListener('click', () => done(null));
    overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) done(null); });
    // 80ms 后聚焦输入框：避开 openDocEditor 的 titleInput.focus()（setTimeout 50ms），防焦点被抢
    setTimeout(() => { if (_imgImportDialog) wInput.focus(); }, 80);
  });
}
// 批量导入图片主入口（manager 两处入口共用：侧边栏「从图片新建」/ 编辑器 📥 多选）。
//  - 空文档 → setContent 整体写入；已有内容 → insertContentAt 追加到文档末尾（追加语义，不弹替换确认）
//  - 内容用 JSON 节点数组单事务插入（不拼 HTML 字符串，省一次 DOMParser）：Ctrl+Z 一次撤销整批
//  - 尾部补空段：块级 image 结尾时光标无处落、无法在图后继续输入
//  - 全程不调 .focus()：openDocEditor 随后有 titleInput.focus() 的 setTimeout(50)，抢焦点会致标题输入闪烁
//  - opts.sizeBudget：bodyHtml 字符数预算（manager 由 docSizeLimit 换算，≤0 不限）
//  - opts.maxWidth/maxHeight：用户在导入弹窗选择的等比缩放上限（px，≤0 不限；都 ≤0 保留原始尺寸）
//  - 返回 { inserted, skipped:[{name,reason}], firstName }（firstName=排序后首个成功文件去扩展名，供标题回填）
async function importImages(files, opts) {
  if (!editor) throw new Error('editor not ready');
  const budget = (opts && Number(opts.sizeBudget) > 0) ? Math.floor(Number(opts.sizeBudget)) : 0;
  const maxW = (opts && Number(opts.maxWidth) > 0) ? Math.floor(Number(opts.maxWidth)) : 0;
  const maxH = (opts && Number(opts.maxHeight) > 0) ? Math.floor(Number(opts.maxHeight)) : 0;
  const list = Array.from(files || []).filter((f) => !!_sniffImageMime(f)).sort(_docNumericNameCompare);
  const result = { inserted: 0, skipped: [], firstName: '' };
  if (!list.length) return result;
  // 预算口径：当前 body 已占字符 + 已插入图。与 _enforceDocQuota / 服务端计量同为 bodyHtml 字符串长度。
  let used = budget > 0 ? String(editor.getHTML() || '').length : 0;
  const tip = i18n('docImportImagesLoading', '正在导入图片…');
  showLoadingBar(tip + ' 0/' + list.length);
  try {
    const nodes = [];
    for (let i = 0; i < list.length; i++) {
      showLoadingBar(tip + ' ' + (i + 1) + '/' + list.length);   // showLoadingBar 重复调用只更新文案
      const f = list[i];
      try {
        const r = await _fileToEmbeddableSrc(f, used, budget, maxW, maxH);
        if (r && r.src) {
          nodes.push({ type: 'image', attrs: { src: r.src } });
          used += r.src.length + DOC_IMG_TAG_OVERHEAD;
          if (!result.firstName) result.firstName = String(f.name || '').replace(/\.[^.]+$/, '').trim();
        } else {
          result.skipped.push({ name: f.name || '', reason: (r && r.skip) || 'decode' });
        }
      } catch (e) {
        console.error('[doc-editor] 图片导入失败', { fileName: f.name, fileSize: f.size, fileType: f.type, error: e });
        result.skipped.push({ name: f.name || '', reason: 'decode' });
      }
    }
    if (nodes.length) {
      nodes.push({ type: 'paragraph' });
      const ok = _docHasContent()
        ? editor.commands.insertContentAt(editor.state.doc.content.size, nodes)
        : editor.commands.setContent(nodes);
      if (ok) result.inserted = nodes.length - 1;
    }
    return result;
  } finally {
    hideLoadingBar();
  }
}

// 导入文件：用导入转换出的 HTML 整体替换文档内容。
// 分两次 dispatch：先 clearContent（销毁所有图片等 NodeView、彻底清空旧内容），再 setContent 写入新内容。
// 不能只靠单次 setContent 整文档替换——「图片→图片」替换时旧图片 NodeView 可能残留，表现为旧图追加。
// 不同内容 → getHTML() 与 lastSavedHtml 分歧 → isDirty() 自动为 true，无需额外标志。
function setHTML(html) {
  if (!editor) return;
  editor.chain().clearContent().run();
  editor.commands.setContent(html || '<p></p>');
}

// D1：「将图片保存到文档」—— 把选中的外部链接图片 fetch 成 base64 内嵌进 body。
// 仅对 http(s) 外链图生效（按钮在 refresh() 里按选中态 enable/disable）。
// 合规：plain GET、不伪造 Referer、不绕防盗链；fetch 失败（403/CORS/网络）→ 提示并保留外链。
async function embedSelectedImageIntoDoc(ed) {
  const sel = ed.state.selection;
  if (!sel.node || sel.node.type.name !== 'image') {
    showToast(i18n('docSelectImageFirst', '请先选中一张图片（点击图片）')); return;
  }
  const src = sel.node.attrs.src || '';
  if (!/^https?:\/\//i.test(src)) return;   // 非外链（内嵌/空）：按钮已 disable，防御性兜底
  showToast(i18n('docEmbedImageWorking', '正在获取图片…'), 1500);
  try {
    const r = await dbOperation('fetchImageAsBase64', { imageUrl: src });
    if (!r || !r.ok || !r.dataUrl) throw new Error((r && r.reason) || 'fetch failed');
    const tr = ed.state.tr;
    tr.setNodeMarkup(sel.from, undefined, Object.assign({}, sel.node.attrs, { src: r.dataUrl }));
    ed.view.dispatch(tr);
    // TipTap Image ResizableNodeView.onUpdate 不重设 <img>.src（setNodeMarkup 只改 ProseMirror state），
    // 手动同步 DOM 使图片立即显示为新内嵌数据。
    if (host) {
      const imgEl = host.querySelector('img[src^="http"]');
      if (imgEl) imgEl.src = r.dataUrl;
    }
    showToast(i18n('docEmbedImageDone', '已转为内联图片'), 1500);
  } catch (e) {
    // 转换失败（防盗链/CORS/网络）：保留外链 src 不变
    showToast(i18n('docEmbedImageFetchFailed', '无法获取图片数据，转换失败，已保留外链'));
  }
}

function makeBtn(opts) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'wpzl-doc-tb-btn';
  b.textContent = opts.label;
  b.title = opts.title;
  b.dataset.activeKey = opts.activeKey || '';
  if (typeof opts.isActive === 'function') b._isActive = opts.isActive;   // 自定义高亮谓词（如按 heading level）
  b.addEventListener('click', opts.onClick);
  return b;
}

// 带「当前色指示条」的按钮（文字颜色 / 背景高亮共用）。makeBtn 之上追加底部色条，
// getIndicator(ed) 返回当前色字符串或 null（无色时色条透明）。refresh() 每次事务回填。
function makeColorBtn(opts) {
  const b = makeBtn(opts);
  b.classList.add('wpzl-doc-tb-colorbtn');
  const bar = document.createElement('span');
  bar.className = 'wpzl-doc-tb-colorbar';
  b.appendChild(bar);
  b._refreshIndicator = (ed) => {
    const c = opts.getIndicator ? opts.getIndicator(ed) : null;
    bar.style.background = c || '';
    bar.classList.toggle('is-empty', !c);
  };
  return b;
}

// 插入表格按钮：点击弹 N×N 网格选择器，悬停高亮 (0,0)→(i,j) 矩形并显示「r × c」，
// 点选即 insertTable({rows,cols,withHeaderRow:true})。弹层挂 document.body + position:fixed
// （按 button rect 定位），避开工具栏 sticky/overflow 的裁切与层叠上下文。
function makeTableInsertBtn(ed) {
  const MAX = 8;
  const btn = makeBtn({
    label: '▦', title: i18n('insertTable', '插入表格'),
    onClick: (e) => { e.stopPropagation(); togglePopup(); },
  });

  let popup = null, labelEl = null, cells = [];
  let onDocClick = null, onKey = null, onScroll = null;

  function closePopup() {
    if (!popup) return;
    popup.remove(); popup = null; labelEl = null; cells = [];
    if (onDocClick) { document.removeEventListener('click', onDocClick, true); onDocClick = null; }
    if (onKey) { document.removeEventListener('keydown', onKey); onKey = null; }
    if (onScroll) { window.removeEventListener('scroll', onScroll, true); onScroll = null; }
  }
  function highlight(r, c) {
    cells.forEach((cell) => {
      cell.classList.toggle('is-on', parseInt(cell.dataset.r, 10) <= r && parseInt(cell.dataset.c, 10) <= c);
    });
    if (labelEl) labelEl.textContent = (r + 1) + ' × ' + (c + 1);
  }
  function togglePopup() {
    if (popup) { closePopup(); return; }
    popup = document.createElement('div'); popup.className = 'wpzl-table-grid-popup';
    labelEl = document.createElement('div'); labelEl.className = 'wpzl-table-grid-label'; labelEl.textContent = '1 × 1';
    const grid = document.createElement('div'); grid.className = 'wpzl-table-grid'; cells = [];
    for (let r = 0; r < MAX; r++) {
      for (let c = 0; c < MAX; c++) {
        const cell = document.createElement('div');
        cell.className = 'wpzl-table-grid-cell'; cell.dataset.r = r; cell.dataset.c = c;
        cell.addEventListener('mouseover', () => highlight(r, c));
        cell.addEventListener('click', (ev) => {
          ev.stopPropagation();
          ed.chain().focus().insertTable({ rows: r + 1, cols: c + 1, withHeaderRow: true }).run();
          closePopup();
        });
        grid.appendChild(cell); cells.push(cell);
      }
    }
    popup.appendChild(labelEl); popup.appendChild(grid); document.body.appendChild(popup);
    const rect = btn.getBoundingClientRect();     // 定位到按钮正下方
    popup.style.top = (rect.bottom + 4) + 'px';
    popup.style.left = (Math.min(rect.left, (window.innerWidth || document.documentElement.clientWidth) - 200)) + 'px';
    highlight(0, 0);
    onDocClick = (ev) => { if (!popup.contains(ev.target) && ev.target !== btn && !btn.contains(ev.target)) closePopup(); };
    onKey = (ev) => { if (ev.key === 'Escape') closePopup(); };
    onScroll = () => closePopup();
    setTimeout(() => {   // 延一帧挂捕获监听，避免「开弹层这次 click」当场把自己关掉
      document.addEventListener('click', onDocClick, true);
      document.addEventListener('keydown', onKey);
      window.addEventListener('scroll', onScroll, true);
    }, 0);
  }
  return btn;
}

// 预设调色板（字色用较深色便于阅读；高亮用浅荧光色作底，黑字仍清晰）
const TEXT_COLORS = ['#e03131', '#f08c00', '#fcc419', '#2f9e44', '#2563eb', '#9c36b5', '#1f2329', '#868e96'];
const HIGHLIGHT_COLORS = [
  // 浅色组（现有 6 色，低对比度荧光色）
  '#fff3bf', '#d3f9d8', '#d0ebff', '#ffdeeb', '#ffe8cc', '#f3d9fa',
  // 饱和组（新增 6 色：红/黄/绿/蓝/紫/橙，更高对比度，黑字清晰）
  '#ff8787', '#ffd43b', '#69db7c', '#4dabf7', '#9775fa', '#ffa94d',
];

// 下拉选择控件（字体 / 字号 / 行距）。getValue(ed) 在每次 transaction 时回填当前值。
function makeSelect(opts) {
  const s = document.createElement('select');
  s.className = 'wpzl-doc-tb-select';
  s.title = opts.title || '';
  opts.options.forEach((o) => {
    const opt = document.createElement('option');
    opt.value = o.value;
    opt.textContent = o.label;
    s.appendChild(opt);
  });
  s.addEventListener('change', () => opts.onChange(s.value));
  if (typeof opts.getValue === 'function') s._getValue = opts.getValue;
  return s;
}

function makeSep() {
  const s = document.createElement('span');
  s.className = 'wpzl-doc-tb-sep';
  return s;
}

function buildToolbar(toolbar, ed) {
  // 文字格式：字体 / 字号 / 行距（下拉）
  toolbar.appendChild(makeSelect({
    title: 'Font',
    options: [
      { value: '', label: 'Font' },
      // value 用 CSSOM 序列化形式（多词族双引号、无冗余引号），与 el.style.fontFamily 读回值一致，下拉才能正确回填
      { value: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif', label: 'Sans' },
      { value: 'Georgia, "Times New Roman", serif', label: 'Serif' },
      { value: 'ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace', label: 'Mono' },
      { value: '"PingFang SC", "Microsoft YaHei", sans-serif', label: i18n('deFontYaHei', '雅黑') },
      { value: 'SimSun, "Songti SC", serif', label: i18n('deFontSong', '宋体') },
      { value: 'KaiTi, STKaiti, serif', label: i18n('deFontKai', '楷体') },
    ],
    getValue: (e) => (e.getAttributes('textStyle').fontFamily || ''),
    onChange: (v) => ed.chain().focus()[v ? 'setFontFamily' : 'unsetFontFamily'](v || undefined).run(),
  }));
  toolbar.appendChild(makeSelect({
    title: 'Font size',
    options: [{ value: '', label: 'Size' }].concat(
      ['12', '13', '14', '15', '16', '18', '20', '24', '28', '32'].map((n) => ({ value: n + 'px', label: n }))
    ),
    getValue: (e) => (e.getAttributes('textStyle').fontSize || ''),
    onChange: (v) => ed.chain().focus()[v ? 'setFontSize' : 'unsetFontSize'](v || undefined).run(),
  }));
  toolbar.appendChild(makeSelect({
    title: 'Line height',
    options: [{ value: '', label: 'Line' }].concat(
      // value 用 CSSOM 形式（无尾随 .0，与 el.style.lineHeight 一致）；label 保留 .0 便于阅读
      [['1', '1.0'], ['1.15', '1.15'], ['1.3', '1.3'], ['1.5', '1.5'], ['1.75', '1.75'], ['2', '2.0']]
        .map(function (vl) { return { value: vl[0], label: vl[1] }; })
    ),
    getValue: (e) => (e.getAttributes('paragraph').lineHeight || ''),
    onChange: (v) => ed.chain().focus()[v ? 'setLineHeight' : 'unsetLineHeight'](v || undefined).run(),
  }));
  // 页面宽度：控制编辑区 max-width（CSS var --wpzl-doc-page-width）与左右边界线
  //   none = 全宽（无边界线），其余值限制 ProseMirror 宽度并绘制虚线
  const PAGE_WIDTH_OPTS = [
    { value: '680px', label: '680' },
    { value: '820px', label: '820' },
    { value: '960px', label: '960' },
    { value: '1080px', label: '1080' },
    { value: 'none',  label: i18n('pageWidthFull', 'Full') },
  ];
  toolbar.appendChild(makeSelect({
    title: i18n('pageWidth', 'Page width'),
    options: PAGE_WIDTH_OPTS,
    getValue: () => _pageWidth,
    onChange: (v) => setPageWidth(v || '820px'),
  }));
  toolbar.appendChild(makeSep());

  // 文本格式
  toolbar.appendChild(makeBtn({ label: 'B', title: 'Bold', activeKey: 'bold',
    onClick: () => ed.chain().focus().toggleBold().run() }));
  toolbar.appendChild(makeBtn({ label: 'I', title: 'Italic', activeKey: 'italic',
    onClick: () => ed.chain().focus().toggleItalic().run() }));
  toolbar.appendChild(makeBtn({ label: 'Code', title: 'Inline code', activeKey: 'code',
    onClick: () => ed.chain().focus().toggleCode().run() }));
  // 下划线 / 删除线：StarterKit v3 默认已含 Underline / Strike，零依赖
  toolbar.appendChild(makeBtn({ label: 'U', title: 'Underline', activeKey: 'underline',
    onClick: () => ed.chain().focus().toggleUnderline().run() }));
  toolbar.appendChild(makeBtn({ label: 'S', title: 'Strikethrough', activeKey: 'strike',
    onClick: () => ed.chain().focus().toggleStrike().run() }));
  // 文字颜色（预设调色板）— Color 扩展挂 textStyle.color → <span style="color:…">；服务端全局放行 style
  toolbar.appendChild(makeColorBtn({
    label: 'A', title: i18n('deTextColor', '文字颜色'),
    isActive: (e) => !!e.getAttributes('textStyle').color,
    getIndicator: (e) => e.getAttributes('textStyle').color || null,
    onClick: () => openColorPalette({
      title: i18n('deTextColor', '文字颜色'), colors: TEXT_COLORS,
      current: ed.getAttributes('textStyle').color || '',
      onPick: (hex) => ed.chain().focus().setColor(hex).run(),
      onClear: () => ed.chain().focus().unsetColor().run(),
    }),
  }));
  // 背景高亮 / 荧光笔（预设调色板）— BackgroundColor 挂 textStyle.backgroundColor →
  // <span style="background-color:…">；服务端全局放行 style，无需改 HtmlSanitizer 白名单（避开 <mark>）
  toolbar.appendChild(makeColorBtn({
    label: '▤', title: i18n('deBgHighlight', '背景高亮'),
    isActive: (e) => !!e.getAttributes('textStyle').backgroundColor,
    getIndicator: (e) => e.getAttributes('textStyle').backgroundColor || null,
    onClick: () => openColorPalette({
      title: i18n('deBgHighlight', '背景高亮'), colors: HIGHLIGHT_COLORS,
      current: ed.getAttributes('textStyle').backgroundColor || '',
      onPick: (hex) => ed.chain().focus().setBackgroundColor(hex).run(),
      onClear: () => ed.chain().focus().unsetBackgroundColor().run(),
    }),
  }));
  toolbar.appendChild(makeSep());

  // 标题：isActive 按 level 精确匹配，避免 H1/H2 互相串高亮（旧 bug：两者 activeKey 都是 'heading'）
  toolbar.appendChild(makeBtn({ label: 'H1', title: 'Heading 1',
    isActive: (e) => e.isActive('heading', { level: 1 }),
    onClick: () => ed.chain().focus().toggleHeading({ level: 1 }).run() }));
  toolbar.appendChild(makeBtn({ label: 'H2', title: 'Heading 2',
    isActive: (e) => e.isActive('heading', { level: 2 }),
    onClick: () => ed.chain().focus().toggleHeading({ level: 2 }).run() }));
  // 段落对齐（左/中/右）—— TextAlign 扩展序列化为 style="text-align:…"，HtmlSanitizer 全局放行 style
  toolbar.appendChild(makeBtn({ label: '⫷', title: i18n('textAlignLeft', 'Align left'),
    isActive: (e) => e.isActive({ textAlign: 'left' }),
    onClick: () => ed.chain().focus().setTextAlign('left').run() }));
  toolbar.appendChild(makeBtn({ label: '⫼', title: i18n('textAlignCenter', 'Align center'),
    isActive: (e) => e.isActive({ textAlign: 'center' }),
    onClick: () => ed.chain().focus().setTextAlign('center').run() }));
  toolbar.appendChild(makeBtn({ label: '⫸', title: i18n('textAlignRight', 'Align right'),
    isActive: (e) => e.isActive({ textAlign: 'right' }),
    onClick: () => ed.chain().focus().setTextAlign('right').run() }));
  toolbar.appendChild(makeSep());

  // 列表 / 块
  toolbar.appendChild(makeBtn({ label: '•', title: 'Bullet list', activeKey: 'bulletList',
    onClick: () => ed.chain().focus().toggleBulletList().run() }));
  toolbar.appendChild(makeBtn({ label: '1.', title: 'Ordered list', activeKey: 'orderedList',
    onClick: () => ed.chain().focus().toggleOrderedList().run() }));
  toolbar.appendChild(makeBtn({ label: '“”', title: 'Quote', activeKey: 'blockquote',
    onClick: () => ed.chain().focus().toggleBlockquote().run() }));
  toolbar.appendChild(makeBtn({ label: '</>', title: 'Code block', activeKey: 'codeBlock',
    onClick: () => ed.chain().focus().toggleCodeBlock().run() }));
  toolbar.appendChild(makeSep());

  // 插入：链接 / 图片 URL（粘贴/拖拽图片由 editorProps 自动捕获走云链路）
  toolbar.appendChild(makeBtn({ label: '🔗', title: 'Insert link',
    onClick: () => {
      openPromptDialog({
        title: 'Insert link', placeholder: 'https://example.com', okLabel: 'Insert',
        initial: ed.getAttributes('link').href || '',
        onConfirm: (url) => {
          if (!url) return;
          if (ed.isActive('link')) {
            // 光标已在链接内：更新 href（扩展到整个 link mark 再 setLink）
            ed.chain().focus().extendMarkRange('link').setLink({ href: url }).run();
          } else if (ed.state.selection.empty) {
            // 无选区：插入 url 作为链接文本。setLink 对空选区只设 mark、不产生可见链接，
            // 用户期望「输入网址 → 出现链接」，故空选区下直接 insertContent 一段带 link mark 的文本。
            ed.chain().focus().insertContent({
              type: 'text', text: url, marks: [{ type: 'link', attrs: { href: url } }],
            }).run();
          } else {
            // 有选区：把选中文本链接化
            ed.chain().focus().setLink({ href: url }).run();
          }
        },
      });
    } }));
  toolbar.appendChild(makeBtn({ label: '🖼', title: 'Insert image (URL)',
    onClick: () => {
      openPromptDialog({
        title: 'Insert image', placeholder: 'https://example.com/image.png', okLabel: 'Insert',
        onConfirm: (url) => {
          if (!url) return;
          ed.chain().focus().setImage({ src: url }).run();
        },
      });
    } }));
  // D1：「将图片保存到文档」—— 仅选中 http(s) 外链图时 enable（refresh 里按选中态切换）。
  const embedBtn = makeBtn({ label: '☁', title: i18n('embedImageInDoc', 'Save image to document'),
    onClick: () => embedSelectedImageIntoDoc(ed) });
  embedBtn._embedImageBtn = true;
  embedBtn.disabled = true;   // 初始：未选中外链图
  toolbar.appendChild(embedBtn);
  toolbar.appendChild(makeSep());

  // 表格：插入（▦ → 网格选择器）+ 单元格操作（打 _tableOnly 标记，refresh 里按是否在表格内切 disabled）
  toolbar.appendChild(makeTableInsertBtn(ed));
  const cellOps = [
    { label: '↥', title: i18n('tableAddRowAbove', '上方加行'), cmd: () => ed.chain().focus().addRowBefore().run() },
    { label: '↧', title: i18n('tableAddRowBelow', '下方加行'), cmd: () => ed.chain().focus().addRowAfter().run() },
    { label: '↤', title: i18n('tableAddColLeft', '左侧加列'), cmd: () => ed.chain().focus().addColumnBefore().run() },
    { label: '↦', title: i18n('tableAddColRight', '右侧加列'), cmd: () => ed.chain().focus().addColumnAfter().run() },
    { label: i18n('deTableDelRowShort', '删行'), title: i18n('tableDeleteRow', '删除当前行'), cmd: () => ed.chain().focus().deleteRow().run() },
    { label: i18n('deTableDelColShort', '删列'), title: i18n('tableDeleteCol', '删除当前列'), cmd: () => ed.chain().focus().deleteColumn().run() },
    { label: '☰', title: i18n('tableToggleHeader', '切换表头行'), cmd: () => ed.chain().focus().toggleHeaderRow().run() },
    { label: i18n('deTableDelTableShort', '删表'), title: i18n('tableDelete', '删除整个表格'), cmd: () => ed.chain().focus().deleteTable().run() },
  ];
  cellOps.forEach((op) => {
    const b = makeBtn({ label: op.label, title: op.title, onClick: op.cmd });
    b._tableOnly = true;
    b.disabled = true;   // 初始：光标不在表格内
    toolbar.appendChild(b);
  });
  toolbar.appendChild(makeSep());

  // 数学：inline / display。选中已有数学节点 → 编辑其 LaTeX（原地更新，类型随节点）；
  // 否则插入新公式。均走 openMathDialog（多行 + 实时预览），内部 stripLatexDelimiters 去定界符。
  toolbar.appendChild(makeBtn({ label: '𝑥', title: 'Inline math (LaTeX)',
    onClick: () => {
      const sel = ed.state.selection;
      if (sel.node && (sel.node.type.name === 'inlineMath' || sel.node.type.name === 'blockMath')) {
        promptAndEditMath(sel.node, sel.from);
      } else {
        openMathDialog({ mode: 'inline', onConfirm: (tex) => insertMath(tex, false) });
      }
    } }));
  toolbar.appendChild(makeBtn({ label: '∑', title: 'Display math (LaTeX)',
    onClick: () => {
      const sel = ed.state.selection;
      if (sel.node && (sel.node.type.name === 'inlineMath' || sel.node.type.name === 'blockMath')) {
        promptAndEditMath(sel.node, sel.from);
      } else {
        openMathDialog({ mode: 'display', onConfirm: (tex) => insertMath(tex, true) });
      }
    } }));

  // 右侧 Save / Cancel
  const tail = document.createElement('span');
  tail.className = 'wpzl-doc-tb-tail';
  const cancel = document.createElement('button');
  cancel.type = 'button';
  cancel.className = 'wpzl-doc-tb-btn wpzl-doc-tb-text';
  cancel.textContent = i18n('docEditorClose', '关闭');
  cancel.title = i18n('docEditorClose', '关闭');
  cancel.addEventListener('click', () => { if (onCancelCb) onCancelCb(); });
  const save = document.createElement('button');
  save.type = 'button';
  save.className = 'wpzl-doc-tb-btn wpzl-doc-tb-primary';
  save.textContent = i18n('docEditorSave', '保存');
  save.title = i18n('docEditorSave', '保存');
  // Save：直接 onSaveCb(getHTML)（D1：图片已内嵌进 body，无需云地址重写）
  save.addEventListener('click', doSave);
  tail.appendChild(cancel);
  tail.appendChild(save);
  toolbar.appendChild(tail);

  // active 态同步：按钮（优先 _isActive 谓词，回退 activeKey）+ 下拉（回填当前值）
  const refresh = () => {
    toolbar.querySelectorAll('.wpzl-doc-tb-btn').forEach((btn) => {
      if (btn._tableOnly) btn.disabled = !ed.isActive('table');   // 表格操作按钮：仅光标在表格内可用
      if (btn._embedImageBtn) {   // D1：仅选中 http(s) 外链图时启用「将图片保存到文档」
        const sel = ed.state.selection;
        const n = sel && sel.node;
        const s = (n && n.type && n.type.name === 'image') ? String(n.attrs.src || '') : '';
        btn.disabled = !/^https?:\/\//i.test(s);
        return;
      }
      if (typeof btn._isActive === 'function') { btn.classList.toggle('is-active', !!btn._isActive(ed)); return; }
      const k = btn.dataset.activeKey;
      if (!k) return;
      btn.classList.toggle('is-active', ed.isActive(k));
    });
    toolbar.querySelectorAll('.wpzl-doc-tb-select').forEach((sel) => {
      if (typeof sel._getValue !== 'function') return;
      const v = sel._getValue(ed);
      if (sel.value !== String(v)) sel.value = String(v);   // 避免重置光标/重绘：值未变不触动
    });
    // 文字颜色 / 背景高亮按钮的「当前色指示条」
    toolbar.querySelectorAll('.wpzl-doc-tb-btn').forEach((btn) => {
      if (typeof btn._refreshIndicator === 'function') btn._refreshIndicator(ed);
    });
  };
  ed.on('transaction', refresh);
  refresh();
}

// 粘贴/拖拽 image/* → insertImageBlob（走云链路）
function handleImageInsert(event) {
  const dt = event.dataTransfer || event.clipboardData;
  if (!dt || !dt.items) return false;
  const items = Array.from(dt.items);
  const imageItems = items.filter((it) => it.kind === 'file' && it.type.indexOf('image/') === 0);
  if (imageItems.length === 0) return false;
  event.preventDefault();
  imageItems.forEach((it) => {
    const blob = it.getAsFile();
    if (blob) insertImageBlob(blob);
  });
  return true;
}

// D1：保存用 HTML。文档图片已内嵌为 data:image/...;base64，直接随 body 保留（存 R2）。
// 不再剥离 data: src —— 服务端 HtmlSanitizer 已放开 data:image/*（MIME 守卫阻断 data:text/html 等）。
function getHTMLForSave() {
  return String(editor.getHTML() || '')
    // 空段落补 <br>：ProseMirror getHTML 把空 <p>（含 inline style，如 line-height）序列化成
    // <p></p>。渲染端空块级元素无行盒，高度塌缩为 0 → 空行消失（编辑态靠 ProseMirror 注入的
    // trailingBreak 撑起一行，序列化时被剥离）。补 <br> 让空行在 manager 预览 / /d 公开页都
    // 保留一行高度。重开编辑器时 <p><br></p> 仍解析为空段落（br 视作 trailingBreak）。
    .replace(/<p(\s[^>]*)?>\s*<\/p>/gi, '<p$1><br></p>');
}

// #4：保存逻辑（工具栏 Save 按钮 + Ctrl+S 共用）。直接回调 onSaveCb(getHTMLForSave)。
function doSave() {
  if (!editor) return;
  var saveBtn = document.querySelector('#docEditorHost .wpzl-doc-tb-primary');
  if (saveBtn && saveBtn.disabled) return;     // 保存进行中，防重入
  var label = i18n('docEditorSave', 'Save');
  if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = '...'; }
  Promise.resolve()
    .then(function () { if (onSaveCb) onSaveCb(getHTMLForSave()); })
    .catch(function (e) { showToast(i18n('docSaveFailed', '保存失败') + ': ' + (e && e.message || e)); })
    .finally(function () { if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = label; } });
}

// #4：manager 在保存成功后回调，更新脏标记基线（仅成功才视为 clean）。
function markSaved() {
  if (editor) lastSavedHtml = editor.getHTML();
}

// #4：比较时忽略 img src（外链↔内嵌切换不应判为脏），只比文本/结构。
function _normalizeHtmlForDirty(html) {
  return String(html || '').replace(/(<img[^>]*?)\ssrc="[^"]*"/gi, '$1');
}

// #4：当前内容是否相对上次保存有改动（供 manager 关闭前确认）。
function isDirty() {
  return !!editor && _normalizeHtmlForDirty(editor.getHTML()) !== _normalizeHtmlForDirty(lastSavedHtml);
}

function mount(container, opts) {
  opts = opts || {};
  ensureCSS('wpzl-katex-css', 'katex/katex.min.css');
  ensureCSS('wpzl-doc-editor-css', 'editor.css');

  if (editor) { editor.destroy(); editor = null; }
  if (_ctrlSHandler) { document.removeEventListener('keydown', _ctrlSHandler); _ctrlSHandler = null; }   // #4：防重挂载监听累积
  container.innerHTML = '';
  container.classList.add('wpzl-doc-editor-root');
  host = container;
  currentDocWebUri = opts.docWebUri || '';   // Phase 8：图片 pageKey 用
  if (opts.initialPageWidth) _pageWidth = opts.initialPageWidth;   // 从保存记录恢复页面宽度

  const toolbar = document.createElement('div');
  toolbar.className = 'wpzl-doc-toolbar';
  const content = document.createElement('div');
  content.className = 'wpzl-doc-content';
  container.appendChild(toolbar);
  container.appendChild(content);
  content.style.setProperty('--wpzl-doc-page-width', _pageWidth);   // 初始化页面宽度（默认 820px）

  editor = new Editor({
    element: content,
    content: opts.initialHtml || '<p></p>',
    extensions: [
      StarterKit.configure({ link: false, paragraph: false }),   // paragraph 由 DocParagraph 替代（加 lineHeight）
      Link.configure({
        openInNewTab: true,
        autolink: true,
        HTMLAttributes: { rel: 'noopener noreferrer nofollow' },
      }),
      TextStyle,           // base mark：承载 fontFamily/fontSize/color 等 inline 文本样式
      Color,               // textStyle.color → setColor/unsetColor（<span style="color:…">；服务端 HtmlSanitizer 全局放行 style）
      BackgroundColor,     // textStyle.backgroundColor → setBackgroundColor/unsetBackgroundColor（<span style="background-color:…">；荧光笔高亮，同样全局放行 style，无需改服务端白名单）
      FontFamily,          // addGlobalAttributes → textStyle.fontFamily
      FontSize,            // addGlobalAttributes → textStyle.fontSize
      DocParagraph,        // 段落级 lineHeight（替代 StarterKit 自带 paragraph）
      // Obsidian 保真 marks：不注册则导入的载体元素在 setContent 时被 schema 剥成纯文本（硬约束）
      ObsidianWikilink,    // [[t|a]] → <a class="wpz-wikilink" title="t">
      ObsidianEmbed,       // ![[x]] → <span class="wpz-embed">
      ObsidianTag,         // #标签 → <span class="wpz-tag">
      ObsidianComment,     // %%注释%% → <span class="wpz-comment">
      ObsidianHighlight,   // ==高亮== → <mark class="wpz-highlight">
      // resize：仅 4 角拖拽手柄（ResizableNodeView 默认 directions），alwaysPreserveAspectRatio=true
      // 强制锁定原始长宽比（TipTap 默认 preserveAspectRatio=false 可单独拉伸 → 图片变形）。
      // 锁定比后：① 图片不变形；② 锚定到图片的批注（Y_RATIO 等比例坐标）随等比缩放仍定位准确。
      DocImage.configure({ inline: false, allowBase64: true, resize: { enabled: true, minWidth: 40, minHeight: 40, alwaysPreserveAspectRatio: true } }),
      DocInlineMath.configure({ katexOptions: { throwOnError: false } }),
      DocBlockMath.configure({ katexOptions: { throwOnError: false } }),
      // 段落对齐：left / center / right（序列化为 style="text-align:…"，HtmlSanitizer 全局放行 style）
      TextAlign.configure({ types: ['heading', 'paragraph'], alignments: ['left', 'center', 'right'], defaultAlignment: null }),
      // 表格：启用 column resizing（拖拽列边缘调整宽度）。
      // v3.22.3 序列化为 <td colwidth="X,Y">（plain 属性，非 data-*）+ <col style="width:Xpx">，
      // 服务端 HtmlSanitizer 已追加 td/th + colwidth 白名单。
      Table.configure({ resizable: true, allowTableNodeSelection: true }),
      DocTableRow,         // extend TableRow → rowHeight attr（parseHTML/renderHTML via style="height:…"）
      TableHeader,
      TableCell,
      RowResizeExtension,  // 行高拖拽插件（mousemove→cursor row-resize + mousedown→drag→commit）
    ],
    editorProps: {
      handleDrop: (view, event) => handleImageInsert(event),
      handlePaste: (view, event) => handleImageInsert(event),
      // 双击渲染后的数学节点 → 弹出 LaTeX 编辑（预填当前 latex，原地更新）。
      // 不设扩展内置 onClick：保留单击=选中（NodeSelection）默认行为，工具栏 𝑥/∑ 才能识别"选中"态。
      handleDoubleClickOn: (view, _pos, node, nodePos, _event, direct) => {
        if (!direct) return false;
        if (node && (node.type.name === 'inlineMath' || node.type.name === 'blockMath')) {
          promptAndEditMath(node, nodePos);
          return true;
        }
        return false;
      },
    },
  });

  buildToolbar(toolbar, editor);
  onSaveCb = opts.onSave;
  onCancelCb = opts.onCancel;
  // 脏标记基线：用 editor.getHTML()（Tiptap 已对 initialHtml 完成 parse→serialize 规范化），
  // 而非原始 opts.initialHtml。原始 bodyHtml 多为导入/外部 HTML（含换行缩进、Link 注入
  // target/rel、属性顺序、空段落 <br> 等），与 getHTML() round-trip 从首字符即不一致，
  // 会导致打开后未编辑也判脏（关闭误弹"未保存"）。基线与比较对象同源 → 未编辑不脏、编辑才脏。
  lastSavedHtml = editor ? editor.getHTML() : (opts.initialHtml || '<p></p>');
  // D1：文档图片已内嵌进 body（data:image/...），重开时随 body 从 R2 回拉即可显示，无需 local-first 刷新。
  // #4：Ctrl/Cmd+S 保存（拦截浏览器打印框）。挂 document 以覆盖工具栏/正文任一焦点。
  _ctrlSHandler = function (e) {
    if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S')) {
      e.preventDefault();
      doSave();
    }
  };
  document.addEventListener('keydown', _ctrlSHandler);
  return editor;
}

function destroy() {
  closePromptDialog();
  closeColorPalette();
  closeMathDialog();
  if (_ctrlSHandler) { document.removeEventListener('keydown', _ctrlSHandler); _ctrlSHandler = null; }   // #4
  if (editor) { editor.destroy(); editor = null; }
  if (host) { host.innerHTML = ''; host.classList.remove('wpzl-doc-editor-root'); host = null; }
  onSaveCb = null;
  onCancelCb = null;
  currentDocWebUri = '';
  lastSavedHtml = '';   // #4
}

function getHTML() {
  return editor ? editor.getHTML() : '';
}

// 去掉用户在 prompt 里误带的 LaTeX 定界符。KaTeX 渲染的是纯 TeX 串，带 $$/$ 等定界符会渲染失败
// （throwOnError:false 时进入红色错误态）。统一剥掉 $$...$$ / $...$ / \[...\] / \(...\)。
function stripLatexDelimiters(tex) {
  if (tex == null) return tex;
  const s = String(tex).trim();
  let m;
  if ((m = s.match(/^\$\$\$([\s\S]*)\$\$\$$/))) return m[1].trim();     // $$$...$$$（块 InputRule 语法）
  if ((m = s.match(/^\$\$([\s\S]*)\$\$$/))) return m[1].trim();        // $$...$$  (display)
  if ((m = s.match(/^\\\[([\s\S]*)\\\]$/))) return m[1].trim();        // \[...\]  (display)
  if ((m = s.match(/^\\\(([\s\S]*)\\\)$/))) return m[1].trim();        // \(...\)  (inline)
  if ((m = s.match(/^\$([\s\S]*)\$$/)) && !s.startsWith('$$')) return m[1].trim();  // $...$ (inline)
  return s;
}

// —— 通用单行输入弹层（插入链接 / 插入图片 URL 共用）——
// 替代原生 window.prompt：扩展页面（chrome-extension://）下原生 prompt 在窗口失焦时会被
// 浏览器自动关闭，且 prompt 触发的窗口变暗层不一定恢复 → 整个浏览器卡在暗色（用户可感知
// 的卡死）。自定义弹层焦点完全可控（Enter 确认 / Esc 取消 / 点击遮罩取消），样式复用
// wpzl-math-modal-*（overlay 上重声明了 --wpzl-doc-* 变量，自包含）。
let _promptDialog = null;
function openPromptDialog(opts) {
  // opts: { title, placeholder, okLabel, initial, onConfirm: (value:string)=>void }
  closePromptDialog();
  const overlay = document.createElement('div');
  overlay.className = 'wpzl-math-modal-overlay';
  overlay.innerHTML =
    '<div class="wpzl-math-modal" role="dialog" aria-modal="true">'
    + '<div class="wpzl-math-modal-header">'
    + '<span class="wpzl-math-modal-title"></span>'
    + '<button class="wpzl-math-modal-close" type="button" aria-label="Close">×</button>'
    + '</div>'
    + '<div class="wpzl-math-modal-body">'
    + '<input class="wpzl-prompt-input" type="text" spellcheck="false" autocomplete="off" />'
    + '</div>'
    + '<div class="wpzl-math-modal-footer">'
    + '<button class="wpzl-math-modal-btn wpzl-math-modal-cancel" type="button">Cancel</button>'
    + '<button class="wpzl-math-modal-btn wpzl-math-modal-primary wpzl-math-modal-insert" type="button"></button>'
    + '</div>'
    + '</div>';
  document.body.appendChild(overlay);
  const titleEl = overlay.querySelector('.wpzl-math-modal-title');
  const inputEl = overlay.querySelector('.wpzl-prompt-input');
  const insertBtn = overlay.querySelector('.wpzl-math-modal-insert');
  const cancelBtn = overlay.querySelector('.wpzl-math-modal-cancel');
  const closeBtn = overlay.querySelector('.wpzl-math-modal-close');
  titleEl.textContent = opts.title || '';
  insertBtn.textContent = opts.okLabel || 'OK';
  inputEl.placeholder = opts.placeholder || '';
  inputEl.value = opts.initial || '';
  function confirm() {
    const v = inputEl.value.trim();
    const cb = opts.onConfirm;
    closePromptDialog();
    if (cb) cb(v);
  }
  function onKey(e) {
    if (e.key === 'Escape') { e.preventDefault(); closePromptDialog(); }
    else if (e.key === 'Enter') { e.preventDefault(); confirm(); }
  }
  inputEl.addEventListener('keydown', onKey);
  insertBtn.addEventListener('click', confirm);
  cancelBtn.addEventListener('click', closePromptDialog);
  closeBtn.addEventListener('click', closePromptDialog);
  overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) closePromptDialog(); });
  setTimeout(() => { inputEl.focus(); inputEl.select(); }, 0);
  _promptDialog = { overlay };
}
function closePromptDialog() {
  if (!_promptDialog) return;
  if (_promptDialog.overlay && _promptDialog.overlay.parentNode) {
    _promptDialog.overlay.parentNode.removeChild(_promptDialog.overlay);
  }
  _promptDialog = null;
}

// —— 导入 HTML 检测到不支持元素时的二选一弹窗（只读导入 / 过滤导入）——
// 复用 wpzl-math-modal-* 容器样式。resolve 'readonly' | 'filter' | 'cancel'（取消=不导入）。
let _importChoiceDialog = null;
function openImportChoiceDialog(opts) {
  // opts: { title, desc, unsupportedTags:string[], filterLabel, readOnlyLabel }
  return new Promise(function (resolve) {
    closeImportChoiceDialog();
    const overlay = document.createElement('div');
    overlay.className = 'wpzl-math-modal-overlay';
    const modal = document.createElement('div');
    modal.className = 'wpzl-math-modal wpzl-import-choice-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');

    const header = document.createElement('div');
    header.className = 'wpzl-math-modal-header';
    const titleEl = document.createElement('span');
    titleEl.className = 'wpzl-math-modal-title';
    titleEl.textContent = opts.title || i18n('docImportUnsupportedDialogTitle', '检测到不支持的富元素');
    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'wpzl-math-modal-close';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.textContent = '×';
    header.appendChild(titleEl);
    header.appendChild(closeBtn);

    const body = document.createElement('div');
    body.className = 'wpzl-math-modal-body';
    const desc = document.createElement('p');
    desc.className = 'wpzl-import-choice-desc';
    desc.textContent = opts.desc || '';
    body.appendChild(desc);
    const tags = (opts.unsupportedTags || []).map(function (t) { return '<' + t + '>'; }).join('、');
    if (tags) {
      const tagsEl = document.createElement('p');
      tagsEl.className = 'wpzl-import-choice-tags';
      tagsEl.textContent = tags;
      body.appendChild(tagsEl);
    }

    const footer = document.createElement('div');
    footer.className = 'wpzl-math-modal-footer';
    const filterBtn = document.createElement('button');
    filterBtn.type = 'button';
    filterBtn.className = 'wpzl-math-modal-btn wpzl-math-modal-cancel';
    filterBtn.textContent = opts.filterLabel || i18n('docImportFilter', '过滤导入');
    const readOnlyBtn = document.createElement('button');
    readOnlyBtn.type = 'button';
    readOnlyBtn.className = 'wpzl-math-modal-btn wpzl-math-modal-primary';
    readOnlyBtn.textContent = opts.readOnlyLabel || i18n('docImportReadOnly', '只读导入');
    footer.appendChild(filterBtn);
    footer.appendChild(readOnlyBtn);

    modal.appendChild(header);
    modal.appendChild(body);
    modal.appendChild(footer);
    overlay.appendChild(modal);

    function finish(choice) {
      closeImportChoiceDialog();
      resolve(choice);
    }
    function onKey(e) {
      if (e.key === 'Escape') { e.preventDefault(); finish('cancel'); }
    }
    closeBtn.addEventListener('click', function () { finish('cancel'); });
    filterBtn.addEventListener('click', function () { finish('filter'); });
    readOnlyBtn.addEventListener('click', function () { finish('readonly'); });
    overlay.addEventListener('mousedown', function (e) { if (e.target === overlay) finish('cancel'); });
    document.addEventListener('keydown', onKey);

    document.body.appendChild(overlay);
    _importChoiceDialog = { overlay: overlay, onKey: onKey };
    setTimeout(function () { readOnlyBtn.focus(); }, 0);
  });
}
function closeImportChoiceDialog() {
  if (!_importChoiceDialog) return;
  if (_importChoiceDialog.onKey) document.removeEventListener('keydown', _importChoiceDialog.onKey);
  if (_importChoiceDialog.overlay && _importChoiceDialog.overlay.parentNode) {
    _importChoiceDialog.overlay.parentNode.removeChild(_importChoiceDialog.overlay);
  }
  _importChoiceDialog = null;
}

// —— 颜色调色板弹层（文字颜色 / 背景高亮共用）——
// 复用 wpzl-math-modal-* 容器（overlay 上重声明了 --wpzl-doc-* 变量，自包含），body 渲染色块网格。
// 点击色块 → onPick(hex)；「×」清除 → onClear()；点遮罩 / Esc 关闭。
let _colorPalette = null;
function openColorPalette(opts) {
  // opts: { title, colors:[hex], current:hex|'', onPick:(hex)=>void, onClear:()=>void }
  closeColorPalette();
  const overlay = document.createElement('div');
  overlay.className = 'wpzl-math-modal-overlay wpzl-color-palette-overlay';
  const modal = document.createElement('div');
  modal.className = 'wpzl-math-modal wpzl-color-palette-modal';
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');

  const header = document.createElement('div');
  header.className = 'wpzl-math-modal-header';
  const titleEl = document.createElement('span');
  titleEl.className = 'wpzl-math-modal-title';
  titleEl.textContent = opts.title || '';
  const closeBtn = document.createElement('button');
  closeBtn.type = 'button';
  closeBtn.className = 'wpzl-math-modal-close';
  closeBtn.setAttribute('aria-label', 'Close');
  closeBtn.textContent = '×';
  closeBtn.addEventListener('click', closeColorPalette);
  header.appendChild(titleEl);
  header.appendChild(closeBtn);

  const grid = document.createElement('div');
  grid.className = 'wpzl-color-palette';
  const cur = String(opts.current || '').toLowerCase();
  opts.colors.forEach((hex) => {
    const sw = document.createElement('button');
    sw.type = 'button';
    sw.className = 'wpzl-color-swatch';
    sw.title = hex;
    sw.style.background = hex;
    if (cur && hex.toLowerCase() === cur) sw.classList.add('is-current');
    sw.addEventListener('click', () => { const cb = opts.onPick; closeColorPalette(); if (cb) cb(hex); });
    grid.appendChild(sw);
  });
  if (typeof opts.onClear === 'function') {
    const clr = document.createElement('button');
    clr.type = 'button';
    clr.className = 'wpzl-color-swatch wpzl-color-swatch-clear';
    clr.title = i18n('clearColor', '清除颜色');
    clr.textContent = '×';
    clr.addEventListener('click', () => { const cb = opts.onClear; closeColorPalette(); if (cb) cb(); });
    grid.appendChild(clr);
  }

  const body = document.createElement('div');
  body.className = 'wpzl-math-modal-body';
  body.appendChild(grid);

  modal.appendChild(header);
  modal.appendChild(body);
  overlay.appendChild(modal);
  overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) closeColorPalette(); });
  function onKey(e) { if (e.key === 'Escape') { e.preventDefault(); closeColorPalette(); } }
  document.addEventListener('keydown', onKey);
  document.body.appendChild(overlay);
  _colorPalette = { overlay, onKey };
}
function closeColorPalette() {
  if (!_colorPalette) return;
  document.removeEventListener('keydown', _colorPalette.onKey);
  if (_colorPalette.overlay && _colorPalette.overlay.parentNode) {
    _colorPalette.overlay.parentNode.removeChild(_colorPalette.overlay);
  }
  _colorPalette = null;
}

// —— LaTeX 输入弹层（工具栏 𝑥/∑ 插入 + 双击/选中编辑共用）——
// 替代原生 window.prompt：多行 textarea + 实时 KaTeX 预览。挂到 document.body，样式自包含。
let _mathDialog = null;

function openMathDialog(opts) {
  // opts: { mode: 'inline'|'display', initial?: string, isEdit?: boolean, onConfirm: (rawTex) => void }
  closeMathDialog();
  const isDisplay = opts.mode === 'display';
  const initial = opts.initial || '';

  const overlay = document.createElement('div');
  overlay.className = 'wpzl-math-modal-overlay';
  overlay.innerHTML =
    '<div class="wpzl-math-modal" role="dialog" aria-modal="true">'
    + '<div class="wpzl-math-modal-header">'
    + '<span class="wpzl-math-modal-title"></span>'
    + '<button class="wpzl-math-modal-close" type="button" aria-label="Close">×</button>'
    + '</div>'
    + '<div class="wpzl-math-modal-body">'
    + '<textarea class="wpzl-math-modal-input" rows="4" spellcheck="false"></textarea>'
    + '<div class="wpzl-math-modal-preview">'
    + '<div class="wpzl-math-modal-preview-label">Preview</div>'
    + '<div class="wpzl-math-modal-preview-render"></div>'
    + '</div>'
    + '</div>'
    + '<div class="wpzl-math-modal-footer">'
    + '<span class="wpzl-math-modal-hint">Ctrl+Enter to confirm · Esc to cancel</span>'
    + '<button class="wpzl-math-modal-btn wpzl-math-modal-cancel" type="button">Cancel</button>'
    + '<button class="wpzl-math-modal-btn wpzl-math-modal-primary wpzl-math-modal-insert" type="button"></button>'
    + '</div>'
    + '</div>';
  document.body.appendChild(overlay);

  const titleEl = overlay.querySelector('.wpzl-math-modal-title');
  const inputEl = overlay.querySelector('.wpzl-math-modal-input');
  const previewRender = overlay.querySelector('.wpzl-math-modal-preview-render');
  const insertBtn = overlay.querySelector('.wpzl-math-modal-insert');
  const cancelBtn = overlay.querySelector('.wpzl-math-modal-cancel');
  const closeBtn = overlay.querySelector('.wpzl-math-modal-close');

  titleEl.textContent = isDisplay ? 'Display LaTeX' : 'Inline LaTeX';
  insertBtn.textContent = opts.isEdit ? 'Update' : 'Insert';
  inputEl.placeholder = 'Enter LaTeX, e.g. \\frac{a}{b}  (surrounding $$ / $ are auto-stripped)';

  function renderPreview() {
    const tex = stripLatexDelimiters(inputEl.value);
    previewRender.classList.remove('is-empty', 'is-error');
    if (!tex) {
      previewRender.classList.add('is-empty');
      previewRender.textContent = 'Enter LaTeX to preview';
      return;
    }
    try {
      katex.render(tex, previewRender, { displayMode: isDisplay, throwOnError: false });
    } catch (e) {
      previewRender.classList.add('is-error');
      previewRender.textContent = inputEl.value;
    }
  }

  function confirm() {
    const raw = inputEl.value;
    const cb = opts.onConfirm;
    closeMathDialog();
    if (cb) cb(raw);
  }

  function onDocKeyDown(e) {
    if (e.key === 'Escape') { e.preventDefault(); closeMathDialog(); }
    else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); confirm(); }
  }

  inputEl.addEventListener('input', renderPreview);
  insertBtn.addEventListener('click', confirm);
  cancelBtn.addEventListener('click', closeMathDialog);
  closeBtn.addEventListener('click', closeMathDialog);
  overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) closeMathDialog(); });
  document.addEventListener('keydown', onDocKeyDown);

  inputEl.value = initial;
  renderPreview();
  setTimeout(() => { inputEl.focus(); const n = initial.length; inputEl.setSelectionRange(n, n); }, 0);

  _mathDialog = { overlay, onDocKeyDown };
}

function closeMathDialog() {
  if (!_mathDialog) return;
  document.removeEventListener('keydown', _mathDialog.onDocKeyDown);
  if (_mathDialog.overlay && _mathDialog.overlay.parentNode) {
    _mathDialog.overlay.parentNode.removeChild(_mathDialog.overlay);
  }
  _mathDialog = null;
}

// 编辑已有数学节点：弹层预填当前 latex → 去定界符 → updateInlineMath/updateBlockMath 原地更新。
// 类型跟随被选节点（不做 inline↔block 转换，避免段落分裂等边界问题）。
function promptAndEditMath(node, pos) {
  if (!editor || !node) return;
  const isBlock = node.type.name === 'blockMath';
  const existing = node.attrs.latex || '';
  openMathDialog({
    mode: isBlock ? 'display' : 'inline',
    initial: existing,
    isEdit: true,
    onConfirm: (tex) => {
      const cleaned = stripLatexDelimiters(tex);
      if (!cleaned) return;
      if (isBlock) editor.chain().focus().updateBlockMath({ latex: cleaned, pos }).run();
      else editor.chain().focus().updateInlineMath({ latex: cleaned, pos }).run();
    },
  });
}

function insertMath(latex, display) {
  if (!editor || !latex) return;
  const cleaned = stripLatexDelimiters(latex);
  if (!cleaned) return;
  const type = display ? 'blockMath' : 'inlineMath';
  editor.chain().focus().insertContent({ type, attrs: { latex: cleaned } }).run();
}

function getPageWidth() { return _pageWidth; }

// 设置页面宽度（工具栏下拉 onChange / PDF 导入自适应页宽 复用）。
// 写 _pageWidth + 同步 CSS var --wpzl-doc-page-width 到 .wpzl-doc-content。
function setPageWidth(v) {
  if (!v) return;
  _pageWidth = v;
  const root = host ? host.querySelector('.wpzl-doc-content') : null;
  if (root) root.style.setProperty('--wpzl-doc-page-width', _pageWidth);
}

// 导入本地文件（PDF/Word/Excel/HTML/Markdown）→ 转 HTML → 写入编辑器。失败 reject，由调用方提示。
// 注意：转换全程在本地完成，原文件不上传服务端。
// 大 PDF / Office 解析 + 渲染可能耗时数秒到数十秒，转换期间显示持久加载条（成功/失败都关）。

// 只读导入二选一（D-30 放开，2026-09-05）：2026-08-18 曾以「功能尚未完善」临时屏蔽，此后
// 服务端链路已经 S8-7 全链验证（is_read_only 落库 → /d/ 只读白名单渲染 → 客户端拉回 → manager
// 隐藏编辑钮），此前屏蔽导致只读文档无任何创建入口（死配置）。HTML 导入恢复「只读/过滤」二选一；
// 服务端 is_read_only / HtmlSanitizer 只读白名单均已就绪。
const IMPORT_READONLY_IMPORT_ENABLED = true;

async function importFile(file) {
  if (!editor) throw new Error('editor not ready');
  if (!file) throw new Error('no file');
  // 文案带文件类型，让用户知道在转什么（PDF/Word/Excel 比 HTML/MD 慢得多，提前打个招呼）
  const ext = (String(file.name || '').split('.').pop() || '').toUpperCase();
  const typeLabel =
    ext === 'PDF' ? 'PDF' :
    ext === 'DOCX' ? 'Word' :
    (ext === 'XLSX' || ext === 'XLS') ? 'Excel' :
    (ext === 'MD' || ext === 'MARKDOWN') ? 'Markdown' :
    (ext === 'HTML' || ext === 'HTM') ? 'HTML' : '';
  const tip = i18n('docImportLoading', '正在转换并加载…')
    + (typeLabel ? '（' + typeLabel + '）' : '');
  showLoadingBar(tip);
  try {
    const out = await convertToHtml(file);
    const html = (out && out.html) || '';
    if (!html || !String(html).trim()) throw new Error('empty');
    // HTML 检测到编辑器无法表示的元素（canvas/svg/video/audio/iframe/…）→ 弹窗二选一。
    // 只读：不写编辑器，返回 readOnlyHtml 交给 manager 直接以只读文档入库；取消：不导入。
    // D-30：开关已放开（true）——2026-08-18 曾临时屏蔽，见文件头 IMPORT_READONLY_IMPORT_ENABLED 注释。
    if (IMPORT_READONLY_IMPORT_ENABLED && out && out.needsChoice) {
      hideLoadingBar();   // 弹窗前收起加载条，避免遮挡对话框
      const choice = await openImportChoiceDialog({
        title: i18n('docImportUnsupportedDialogTitle', '检测到不支持的富元素'),
        desc: i18n('docImportUnsupportedDesc', '该 HTML 含富文本编辑器无法表示的元素。只读导入可保留 canvas/svg/video/audio，但 script/iframe/embed/object/form 仍会剥离；过滤导入会丢弃不支持元素，页面可能发生较大变化。'),
        unsupportedTags: out.unsupportedTags || [],
        filterLabel: i18n('docImportFilter', '过滤导入'),
        readOnlyLabel: i18n('docImportReadOnly', '只读导入')
      });
      if (choice === 'readonly') return { mode: 'readonly', html: out.readOnlyHtml || html };
      if (choice === 'cancel') return { mode: 'cancel' };
      // 'filter' → 落到下面正常 setHTML 流程
    }
    // PDF 导入带建议页宽：按其页宽自适应编辑器页宽（在写内容前设置，让图片直接以正确页宽布局）
    if (out && out.pageWidth) setPageWidth(out.pageWidth);
    setHTML(html);
    return { mode: 'edit', html: html };
  } catch (e) {
    // 转换失败：manager 侧 toast 只显示 2.5s、一闪即逝，这里把完整错误（文件名/大小/类型/堆栈）
    // 落到控制台便于排查。不吞错误——rethrow 让调用方继续走 toast 提示。
    console.error('[doc-editor] 导入文件失败', {
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type,
      kind: typeLabel || ext || '(unknown)',
      error: e
    });
    throw e;
  } finally {
    hideLoadingBar();
  }
}

window.WPZL_docEditor = { mount, destroy, getHTML, insertMath, insertImageBlob, markSaved, isDirty, getPageWidth, setPageWidth, importFile, importImages, chooseImageImportOptions };
