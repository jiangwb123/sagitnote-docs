// ============================================================
// Sagitnote - Service Worker (Background Script)
// 职责: 1) 管理集中式 IndexedDB 存储层  2) 处理来自 content script 的 DB 请求
//        3) 服务器 API 通信（认证、Pro 状态） 4) 状态缓存管理
// ============================================================

// Import MD5 util (与服务器 Md5Util.md5 一致；用于 page/folder 同步的 URL_MD5)
importScripts('md5.js');
// Import server API module (auth, Pro status, token management)
importScripts('server-api.js');
importScripts('sync-engine.js');
importScripts('asset-uploader.js');
importScripts('image-sync-downloader.js');
importScripts('doc-sync-downloader.js');

// ---------- 日期格式化工具（原 Date.prototype polyfill，工具函数化——上架整改 §3.5） ----------
// 注意：必须用 function 声明（依赖 hoisting）——sync-engine.js 经 importScripts 先于本文件
// 语句执行，其调用点依赖这两个函数已可用；改成 const 箭头会 ReferenceError。
function wpzlFormatDate(d, fmt) {
  var o = {
    "M+": d.getMonth() + 1,
    "d+": d.getDate(),
    "H+": d.getHours(),
    "h+": d.getHours(),
    "m+": d.getMinutes(),
    "s+": d.getSeconds(),
    "q+": Math.floor((d.getMonth() + 3) / 3),
    "S": d.getMilliseconds()
  };
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (d.getFullYear() + "").substr(4 - RegExp.$1.length));
  }
  for (var k in o) {
    if (new RegExp("(" + k + ")").test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    }
  }
  return fmt;
}

// UTC 墙上钟格式化（Bug B 时区轴统一）：入库/上传/同步时钟一律存 UTC-naive
// "yyyy-MM-dd HH:mm:ss"。把 UTC 数值搬到"本地 getter 可读"的日期：shift = -tzOffset。
function wpzlFormatUTCDate(d, fmt) {
  return wpzlFormatDate(new Date(d.getTime() + (d.getTimezoneOffset() * 60000)), fmt);
}

// ---------- V69: 每日标注创建计数器（每日限额的前端门禁数据源） ----------
// chrome.storage.local['wpzl_daily_mark_count'] = { uid, date: 'YYYY-MM-DD'(本地), count }
// - 仅本地新建计数（saveAnnotation merge 前判定 !existing 递增）；同步下载不经 saveAnnotation，
//   撤销恢复（existing 存在）不计数——与服务端"复活不占当日额度"语义一致。
// - 客户端计数是 UX 预拦截（提前提示），服务端 server_created_at 计数才是权威；
//   多设备各计各的偏差由服务端软拒兜底。uid 变化（换号）或跨本地日自动重置。
var WPZL_DAILY_MARK_COUNT_KEY = 'wpzl_daily_mark_count';

function _wpzlLocalDateStr(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

/** 读当日已创建数（uid 不匹配/跨天/无记录 → 0）。sync-engine 预拦截与 content 初始化共用。 */
function wpzl_readDailyMarkCount(uid) {
  var today = _wpzlLocalDateStr(new Date());
  return chrome.storage.local.get(WPZL_DAILY_MARK_COUNT_KEY).then(function (items) {
    var rec = items && items[WPZL_DAILY_MARK_COUNT_KEY];
    if (!rec || String(rec.uid) !== String(uid) || rec.date !== today) return 0;
    return typeof rec.count === 'number' ? rec.count : 0;
  }).catch(function () { return 0; });
}

/** 本地新建 +1 并广播（fire-and-forget，失败不影响保存路径）。 */
function wpzl_bumpDailyMarkCount(uid) {
  if (uid == null || uid === '') return Promise.resolve();
  var today = _wpzlLocalDateStr(new Date());
  return chrome.storage.local.get(WPZL_DAILY_MARK_COUNT_KEY).then(function (items) {
    var rec = items && items[WPZL_DAILY_MARK_COUNT_KEY];
    if (!rec || String(rec.uid) !== String(uid) || rec.date !== today) {
      rec = { uid: String(uid), date: today, count: 0 };
    }
    rec.count = (rec.count || 0) + 1;
    var count = rec.count;
    return chrome.storage.local.set({ [WPZL_DAILY_MARK_COUNT_KEY]: rec }).then(function () {
      // 通知各 tab content script 更新 meta dataset（注入侧 gate 每次实时读，天然热更新）
      var msg = { type: 'wpzl-daily-mark-count-updated', count: count, uid: String(uid) };
      try { chrome.runtime.sendMessage(msg).catch(function () {}); } catch (e) { /* 无 listener */ }
      chrome.tabs.query({}, function (tabs) {
        (tabs || []).forEach(function (t) {
          if (t.id != null) {
            try { chrome.tabs.sendMessage(t.id, msg).catch(function () {}); } catch (e) { /* 无 content script */ }
          }
        });
      });
    });
  }).catch(function () {});
}

// ---------- v1.1.0: 生命周期标注创建计数 + 一次性评分邀请 ----------
// chrome.storage.local['wpzl_lifetime_mark_count'] = 纯数字（每安装一份）
// chrome.storage.local['wpzl_rating_usage_days']   = ['YYYY-MM-DD', ...] 使用日去重数组（弹过即停更）
// chrome.storage.local['wpzl_rating_invite_shown'] = 布尔一次性闸门
// - 与每日计数器不同：不按 uid 分桶、不判空 uid（游客本地模式同样计数——评分邀请面向所有用户）。
// - 计数口径与 V69 一致：仅本地新建（!existing）计数；同步下载/备份导入/撤销恢复不经此路径。
// - 触发条件（2026-11-01 口径调整：原"第 5 条"太快，用户尚未了解产品）：累计 ≥10 条 且 跨 ≥3 个
//   使用日（当天有本地新建即记一个使用日）——双条件都满足才弹，确保只邀请跨过新手期的留存用户。
// - 达标且未弹过 → 在同一次 storage.set 里原子写入计数/使用日/闸门（先置闸门再通知，杜绝并发双弹），
//   仅向创建方 tab+frame 投递 wpzl-show-rating-invite（content.js 转发给该 frame 的 bundle 弹窗）。
//   投递落空（frame 竞态/bundle 缺位）被 catch 吞掉：闸门已置、该安装永不再弹——一次性语义优先。
var WPZL_LIFETIME_MARK_COUNT_KEY = 'wpzl_lifetime_mark_count';
var WPZL_RATING_USAGE_DAYS_KEY = 'wpzl_rating_usage_days';
var WPZL_RATING_INVITE_SHOWN_KEY = 'wpzl_rating_invite_shown';
var WPZL_RATING_INVITE_THRESHOLD = 10;   // 累计新建条数门槛
var WPZL_RATING_INVITE_DAYS_THRESHOLD = 3; // 使用日数门槛（当天有新建即算）
// 串行互斥：两次近乎同时的新建保存（如批量高亮跨过阈值）经此链排队，读-改-写全程串行
var _wpzlLifetimeChain = Promise.resolve();

/**
 * 本地新建 +1、记使用日；双门槛都达标且未弹过时向创建方 frame 发一次性评分邀请
 * （fire-and-forget，不阻塞保存）。
 * @param sender db-operation 消息的 sender（含 tab.id / frameId；扩展页发起时 tab 可能为空）
 */
function wpzl_handleLifetimeMarkCreated(sender) {
  _wpzlLifetimeChain = _wpzlLifetimeChain.then(function () {
    return chrome.storage.local.get([WPZL_LIFETIME_MARK_COUNT_KEY, WPZL_RATING_USAGE_DAYS_KEY, WPZL_RATING_INVITE_SHOWN_KEY]).then(function (items) {
      var count = (items && typeof items[WPZL_LIFETIME_MARK_COUNT_KEY] === 'number') ? items[WPZL_LIFETIME_MARK_COUNT_KEY] : 0;
      var shown = !!(items && items[WPZL_RATING_INVITE_SHOWN_KEY]);
      if (shown) return; // 已弹过：不再递增、不再打扰
      var days = (items && Array.isArray(items[WPZL_RATING_USAGE_DAYS_KEY])) ? items[WPZL_RATING_USAGE_DAYS_KEY].slice() : [];
      var today = _wpzlLocalDateStr(new Date());
      if (days.indexOf(today) === -1) days.push(today);
      count = count + 1;
      var shouldInvite = count >= WPZL_RATING_INVITE_THRESHOLD && days.length >= WPZL_RATING_INVITE_DAYS_THRESHOLD;
      // 单次 set 原子写入：达标时同笔落计数/使用日/闸门，两帧并发跨过阈值也只有一次"未弹"判定成立
      var payload = shouldInvite
        ? { [WPZL_LIFETIME_MARK_COUNT_KEY]: count, [WPZL_RATING_USAGE_DAYS_KEY]: days, [WPZL_RATING_INVITE_SHOWN_KEY]: true }
        : { [WPZL_LIFETIME_MARK_COUNT_KEY]: count, [WPZL_RATING_USAGE_DAYS_KEY]: days };
      return chrome.storage.local.set(payload).then(function () {
        // v1.2.0: 首启庆祝——本安装的第一条标注创建成功即弹一次（任意页面触发；count===1 与
        // 评分邀请阈值 10 条+3 使用日永无交集，链内串行无竞态；落空即错过不补弹）。
        if (count === 1 && sender && sender.tab && sender.tab.id != null) {
          try {
            var _wmMsg = chrome.i18n.getMessage('welcomeFirstMarkToast') || '';
            if (_wmMsg) {
              chrome.tabs.sendMessage(sender.tab.id,
                { type: 'wpzl-show-toast', message: _wmMsg, duration: 4000 },
                { frameId: sender.frameId }).catch(function () { /* ignore */ });
            }
          } catch (e) { /* ignore */ }
        }
        if (!shouldInvite) return;
        if (!sender || !sender.tab || sender.tab.id == null) return; // 无来源 tab：只置闸门不通知（理论不发生）
        try {
          chrome.tabs.sendMessage(sender.tab.id, { type: 'wpzl-show-rating-invite' }, { frameId: sender.frameId })
            .catch(function () { /* 该 frame 无 content script：接受落空，永不再弹 */ });
        } catch (e) { /* ignore */ }
      });
    });
  }).catch(function (e) {
    console.warn('[RatingInvite] lifetime count failed:', e);
  });
}

// ---------- IndexedDB 存储层（集中式，所有页面共享） ----------
class AnnotationDB {
  constructor() {
    this.dbName = 'webpz-lite-db';
    // dbVersion 10（强制登录模型）：新增复合索引保证用户隔离读取
    //   - annotations.userId_domain_webUri：getAnnotations 按 [uid, domain, webUri] 精确查
    //   - imageData.userId_pageKey：getImageDataByPage 按 [uid, pageKey] 精确查
    //   - tags.userId：tags store 历史无 USER_ID，新增索引 + 写路径补字段
    // 同时回填存量 USER_ID（从 AUTHOR_ID 复制）—— dbVersion 6/7/9 没做 in-place 回填，
    // 靠 _rewriteLocalOwnershipToUser 在登录时完成；升级到强制登录模型后必须立即有 USER_ID，
    // 否则未登录态访问 getAnnotations 会查不到任何数据。
    // dbVersion 11（同步重试机制重构）：annotations/pages/folders/imageData 回填重试计数字段
    //   （SYNC_RETRY_COUNT/SYNC_EXHAUSTED/SYNC_LAST_ERROR/SYNC_LAST_ATTEMPT_AT；
    //    retryCount/exhausted/lastError/lastAttemptAt/firstPendingAt）。
    //   **无新索引**——SYNC_EXHAUSTED/exhausted 是 boolean，IDB 不支持 boolean 索引键；
    //   getSyncFailures 经既有 syncStatus 索引（pending/local/error）查询后内存过滤。
    // dbVersion 12（自建文档功能）：新增 documents store（keyPath=docId）+ 索引
    // dbVersion 13（网页快照功能）：新增 snapshots store（keyPath=snapId）+ 索引（与 documents 同构）
    //   syncStatus/userId/webUri/folderId/urlMd5。纯新建 store，无 backfill。
    //   文档作为真实 https 页面由服务端在 <manager_domain>/d/<docId> 渲染，批注按 webUri 绑定，
    //   同步走统一 /api/v1/sync（第 5 类实体）。见 docs 计划 + V27 迁移。
    // dbVersion 24（2026-09-30 事故修正）：线上库被测试探针以 version=24 空升级顶高（schema 未变、
    // 数据完好），13 已无法打开（VersionError 致 SW 数据通道全瘫）。迁移链为累计式 + contains 守卫，
    // 提到 24 对存量库（无升级事件直开）与全新安装（oldVersion=0 走全链建 store）均安全。
    // dbVersion 25（P1-8，2026-10-05）：文档/快照 body 与元数据分仓，下一次真实 schema 迁移从 26 起。
    this.dbVersion = 25;
    this.db = null;
    this._urlMd5Cache = new Map(); // url → md5 缓存（pull 批量建 page 时避免重复 wpzl_md5）
  }

  async open() {
    if (this.db) return this.db;
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);

      request.onupgradeneeded = (e) => {
        const db = e.target.result;

        if (!db.objectStoreNames.contains('annotations')) {
          const store = db.createObjectStore('annotations', { keyPath: 'MARK_INFO_ID' });
          store.createIndex('domain', 'DOMAIN', { unique: false });
          store.createIndex('webUri', 'WEB_URI', { unique: false });
          store.createIndex('domain_webUri', ['DOMAIN', 'WEB_URI'], { unique: false });
          store.createIndex('updateTime', 'UPDATE_TIME', { unique: false });
        }

        if (!db.objectStoreNames.contains('pages')) {
          const pageStore = db.createObjectStore('pages', { keyPath: 'url' });
          pageStore.createIndex('domain', 'domain', { unique: false });
          pageStore.createIndex('lastVisited', 'lastVisited', { unique: false });
        }

        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }

        if (!db.objectStoreNames.contains('imageData')) {
          const imgStore = db.createObjectStore('imageData', { keyPath: 'id' });
          imgStore.createIndex('pageKey', 'pageKey', { unique: false });
          imgStore.createIndex('imageKey', 'imageKey', { unique: false });
          imgStore.createIndex('pageKey_imageKey', ['pageKey', 'imageKey'], { unique: true });
        }

        if (!db.objectStoreNames.contains('tags')) {
          var tagStore = db.createObjectStore('tags', { keyPath: 'name' });
          tagStore.createIndex('lastUsed', 'lastUsed', { unique: false });
        }

        // dbVersion 4: syncMeta store + syncStatus index
        if (!db.objectStoreNames.contains('syncMeta')) {
          db.createObjectStore('syncMeta', { keyPath: 'SYNC_KEY' });
        }
        if (e.oldVersion < 4 && db.objectStoreNames.contains('annotations')) {
          var annStore4 = e.target.transaction.objectStore('annotations');
          if (!annStore4.indexNames.contains('syncStatus')) {
            annStore4.createIndex('syncStatus', 'SYNC_STATUS', { unique: false });
          }
        }

        // dbVersion 5: pages store 同步索引 + folders store（页面级数据同步通道）
        if (e.oldVersion < 5) {
          if (db.objectStoreNames.contains('pages')) {
            var pageStore5 = e.target.transaction.objectStore('pages');
            if (!pageStore5.indexNames.contains('syncStatus')) {
              pageStore5.createIndex('syncStatus', 'SYNC_STATUS', { unique: false });
            }
            if (!pageStore5.indexNames.contains('urlMd5')) {
              pageStore5.createIndex('urlMd5', 'URL_MD5', { unique: false });
            }
          }
          if (!db.objectStoreNames.contains('folders')) {
            var folderStore5 = db.createObjectStore('folders', { keyPath: 'folderId' });
            folderStore5.createIndex('syncStatus', 'SYNC_STATUS', { unique: false });
            folderStore5.createIndex('parentFolderId', 'parentFolderId', { unique: false });
          }
        }

        // dbVersion 6: annotations store 加 USER_ID 字段 + userId index
        // USER_ID 语义 = "当前持有者"（谁导入/登录就归谁），与服务端 user.id 对齐；
        // 未登录时 USER_ID = AUTHOR_ID（本地随机 10 位 base62）。
        // 不做 in-place 回填，避免大数据迁移卡死 SW；回填由 _rewriteLocalOwnershipToUser 在登录时完成。
        if (e.oldVersion < 6 && db.objectStoreNames.contains('annotations')) {
          var annStore6 = e.target.transaction.objectStore('annotations');
          if (!annStore6.indexNames.contains('userId')) {
            annStore6.createIndex('userId', 'USER_ID', { unique: false });
          }
        }

        // dbVersion 7: pages/folders store 加 USER_ID 字段 + userId index
        // 与 annotations 对齐：pages/folders 也需要标识"当前持有者"以支持跨用户导入隔离。
        // 服务端 user_pages/user_folders 表本就有 user_id 列（V14），复合唯一约束保证账户隔离。
        // 不做 in-place 回填，回填由 _rewriteLocalOwnershipToUser 在登录时完成。
        if (e.oldVersion < 7) {
          if (db.objectStoreNames.contains('pages')) {
            var pageStore7 = e.target.transaction.objectStore('pages');
            if (!pageStore7.indexNames.contains('userId')) {
              pageStore7.createIndex('userId', 'USER_ID', { unique: false });
            }
          }
          if (db.objectStoreNames.contains('folders')) {
            var folderStore7 = e.target.transaction.objectStore('folders');
            if (!folderStore7.indexNames.contains('userId')) {
              folderStore7.createIndex('userId', 'USER_ID', { unique: false });
            }
          }
        }

        // dbVersion 8: localThumbnails store（决策 B：无图片上云权限等级的 pageRect thumbnail 本地存储）
        if (e.oldVersion < 8) {
          if (!db.objectStoreNames.contains('localThumbnails')) {
            db.createObjectStore('localThumbnails', { keyPath: 'annId' });
          }
        }

        // dbVersion 9: imageData store 加同步元数据索引（imageData 上云第4类）
        if (e.oldVersion < 9 && db.objectStoreNames.contains('imageData')) {
          var imgStore9 = e.target.transaction.objectStore('imageData');
          if (!imgStore9.indexNames.contains('syncStatus')) {
            imgStore9.createIndex('syncStatus', 'SYNC_STATUS', { unique: false });
          }
          if (!imgStore9.indexNames.contains('userId')) {
            imgStore9.createIndex('userId', 'USER_ID', { unique: false });
          }
        }

        // dbVersion 10：强制登录模型 — 用户隔离复合索引 + tags.userId + USER_ID 回填。
        // 见 this.dbVersion 注释。回填逻辑：每条记录的 USER_ID 优先保留，否则从 AUTHOR_ID 复制；
        // imageData 无 AUTHOR_ID，回填为字符串 'local'（仅用于升级前临时隔离，登录后由
        // _rewriteLocalOwnershipToUser 改写为服务端 user.id）。
        if (e.oldVersion < 10) {
          if (db.objectStoreNames.contains('annotations')) {
            var annStore10 = e.target.transaction.objectStore('annotations');
            if (!annStore10.indexNames.contains('userId_domain_webUri')) {
              annStore10.createIndex('userId_domain_webUri', ['USER_ID', 'DOMAIN', 'WEB_URI'], { unique: false });
            }
          }
          if (db.objectStoreNames.contains('imageData')) {
            var imgStore10 = e.target.transaction.objectStore('imageData');
            if (!imgStore10.indexNames.contains('userId_pageKey')) {
              imgStore10.createIndex('userId_pageKey', ['USER_ID', 'pageKey'], { unique: false });
            }
          }
          if (db.objectStoreNames.contains('tags')) {
            var tagStore10 = e.target.transaction.objectStore('tags');
            if (!tagStore10.indexNames.contains('userId')) {
              tagStore10.createIndex('userId', 'USER_ID', { unique: false });
            }
          }

          // USER_ID 回填（annotations/pages/folders/imageData/tags）。在 upgrade 事务内同步进行。
          // 不依赖任何外部函数，避免 SW 还未完全初始化时调用 db.getUserIdentity()。
          var backfillStores = ['annotations', 'pages', 'folders', 'imageData', 'tags'];
          for (var bs = 0; bs < backfillStores.length; bs++) {
            var sname = backfillStores[bs];
            if (!db.objectStoreNames.contains(sname)) continue;
            var s = e.target.transaction.objectStore(sname);
            try {
              (function (store, storeName) {
                var openReq = store.openCursor();
                openReq.onsuccess = function (ev) {
                  var cursor = ev.target.result;
                  if (!cursor) return;
                  var rec = cursor.value;
                  if (rec) {
                    var changed = false;
                    if (!rec.USER_ID) {
                      // annotations/pages/folders 有 AUTHOR_ID → 复制；imageData/tags 无 → 用 'local'
                      rec.USER_ID = rec.AUTHOR_ID || 'local';
                      changed = true;
                    }
                    if (changed) cursor.update(rec);
                  }
                  cursor.continue();
                };
                openReq.onerror = function () { /* 回填失败不阻断升级 */ };
              })(s, sname);
            } catch (err) { /* ignore */ }
          }
        }

        // dbVersion 11: 同步重试机制重构 — 重试计数字段回填（无新索引，理由见 this.dbVersion 注释）。
        // annotations/pages/folders: SYNC_RETRY_COUNT/SYNC_EXHAUSTED/SYNC_LAST_ERROR/SYNC_LAST_ATTEMPT_AT
        // imageData: retryCount/exhausted/lastError/lastAttemptAt/firstPendingAt（FIFO 稳定排序键）
        // 见 webpz-lite/docs/2026-07-03-sync-retry-redesign.md 第 1 节 +「核心设计决策增补」。
        if (e.oldVersion < 11) {
          var _nowIso11 = new Date().toISOString();
          var _bfStores11 = ['annotations', 'pages', 'folders', 'imageData'];
          for (var bi11 = 0; bi11 < _bfStores11.length; bi11++) {
            var _sname11 = _bfStores11[bi11];
            if (!db.objectStoreNames.contains(_sname11)) continue;
            var _s11 = e.target.transaction.objectStore(_sname11);
            try {
              (function (store, storeName, nowIso) {
                var openReq = store.openCursor();
                openReq.onsuccess = function (ev) {
                  var cursor = ev.target.result;
                  if (!cursor) return;
                  var rec = cursor.value;
                  if (rec) {
                    var changed = false;
                    if (storeName === 'imageData') {
                      if (rec.retryCount == null) { rec.retryCount = 0; changed = true; }
                      if (rec.exhausted == null) { rec.exhausted = false; changed = true; }
                      if (rec.lastError === undefined) { rec.lastError = null; changed = true; }
                      if (rec.lastAttemptAt === undefined) { rec.lastAttemptAt = null; changed = true; }
                      // 首次进入 pending 且无 cloudUrl 的图：补 firstPendingAt 作为 FIFO 稳定排序键
                      if (!rec.firstPendingAt && rec.data && !rec.cloudUrl) {
                        rec.firstPendingAt = nowIso;
                        changed = true;
                      }
                    } else {
                      if (rec.SYNC_RETRY_COUNT == null) { rec.SYNC_RETRY_COUNT = 0; changed = true; }
                      if (rec.SYNC_EXHAUSTED == null) { rec.SYNC_EXHAUSTED = false; changed = true; }
                      if (rec.SYNC_LAST_ERROR === undefined) { rec.SYNC_LAST_ERROR = null; changed = true; }
                      if (rec.SYNC_LAST_ATTEMPT_AT === undefined) { rec.SYNC_LAST_ATTEMPT_AT = null; changed = true; }
                    }
                    if (changed) cursor.update(rec);
                  }
                  cursor.continue();
                };
                openReq.onerror = function () { /* 回填失败不阻断升级 */ };
              })(_s11, _sname11, _nowIso11);
            } catch (err) { /* ignore */ }
          }
        }

        // dbVersion 12: documents store（自建文档，keyPath=docId）。纯新建，无 backfill。
        if (e.oldVersion < 12) {
          if (!db.objectStoreNames.contains('documents')) {
            var docStore = db.createObjectStore('documents', { keyPath: 'docId' });
            docStore.createIndex('syncStatus', 'SYNC_STATUS', { unique: false });
            docStore.createIndex('userId', 'USER_ID', { unique: false });
            docStore.createIndex('webUri', 'webUri', { unique: false });
            docStore.createIndex('folderId', 'folderId', { unique: false });
            docStore.createIndex('urlMd5', 'urlMd5', { unique: false });
          }
        }
        // dbVersion 13: snapshots store（网页快照，与 documents 同构的一类实体，keyPath=snapId）。纯新建，无 backfill。
        if (e.oldVersion < 13) {
          if (!db.objectStoreNames.contains('snapshots')) {
            var snapStore = db.createObjectStore('snapshots', { keyPath: 'snapId' });
            snapStore.createIndex('syncStatus', 'SYNC_STATUS', { unique: false });
            snapStore.createIndex('userId', 'USER_ID', { unique: false });
            snapStore.createIndex('webUri', 'webUri', { unique: false });
            snapStore.createIndex('folderId', 'folderId', { unique: false });
            snapStore.createIndex('urlMd5', 'urlMd5', { unique: false });
            snapStore.createIndex('sourceUrlMd5', 'sourceUrlMd5', { unique: false });
          }
        }

        // dbVersion 25（P1-8，2026-10-05 bulktest_10k 报告）：文档/快照 body 与元数据分仓。
        // 根因：documents/snapshots 记录内联 bodyHtml，getAllDocuments/getAllSnapshots 消息在
        // ~1GiB body 库下超出 runtime 消息通道上限 → 端口死 → manager 文档列表静默清空
        //（vals[0] || [] 吞掉 undefined）。分仓后元数据记录恒 KB 级，列表消息天然安全。
        // 迁移：升级事务内 openCursor 流式搬移（body → body store + 剥记录字段，峰值=单条），
        // docBodies 额外预计算 bodyText（剥标签纯文本，供 SW 侧正文搜索，规则与旧 manager
        // 内联搜索一致——剥标签、不去实体、不折叠空白，匹配语义不变）。
        if (e.oldVersion < 25) {
          if (!db.objectStoreNames.contains('docBodies')) {
            db.createObjectStore('docBodies', { keyPath: 'docId' });
          }
          if (!db.objectStoreNames.contains('snapBodies')) {
            db.createObjectStore('snapBodies', { keyPath: 'snapId' });
          }
          var _v25Migrate = function (metaStoreName, bodyStoreName, keyField) {
            if (!db.objectStoreNames.contains(metaStoreName)) return;
            var tx25 = e.target.transaction;
            var metaS = tx25.objectStore(metaStoreName);
            var bodyS = tx25.objectStore(bodyStoreName);
            var openReq25 = metaS.openCursor();
            openReq25.onsuccess = function (ev25) {
              var cursor25 = ev25.target.result;
              if (!cursor25) return;
              var rec25 = cursor25.value;
              if (rec25 && rec25.bodyHtml !== undefined) {
                if (rec25.bodyHtml) {
                  var bodyRec = {};
                  bodyRec[keyField] = rec25[keyField];
                  bodyRec.bodyHtml = rec25.bodyHtml;
                  if (bodyStoreName === 'docBodies') bodyRec.bodyText = _wpzlHtmlToText(rec25.bodyHtml);
                  bodyS.put(bodyRec);
                }
                delete rec25.bodyHtml;
                cursor25.update(rec25);
              }
              cursor25.continue();
            };
            openReq25.onerror = function () { /* 搬移失败不阻断升级：分仓前旧 SW 不再运行，残留字段无害 */ };
          };
          _v25Migrate('documents', 'docBodies', 'docId');
          _v25Migrate('snapshots', 'snapBodies', 'snapId');
        }
      };

      request.onsuccess = (e) => {
        this.db = e.target.result;
        resolve(this.db);
      };

      request.onerror = (e) => reject(e.target.error);
    });
  }

  _tx(storeName, mode) {
    const tx = this.db.transaction(storeName, mode);
    return tx.objectStore(storeName);
  }

  // ---- 批操作 helper（避免循环里跨 await 复用单事务导致 TransactionInactiveError）----
  // IDB 事务在没有挂起请求的瞬间会自动提交失活。下列 helper 均遵循"一个事务内并发派发所有请求、
  // 不跨 await"的模式：读用并发 get + 计数收敛；写/删用同步派发 + 等 tx.oncomplete。

  // 批量按主键读：一个 readonly 事务并发派发所有 get，一次 await 拿全部。
  // 返回数组顺序与 keys 严格一致（不存在的 key、非法 key 对应 undefined）。
  // 跳过 undefined/null key（来自无效 DTO 的空 webUri/folderId），避免 IDB DataError。
  async getByKeys(storeName, keys) {
    if (!keys || keys.length === 0) return [];
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const results = new Array(keys.length);
      let pending = 0;
      let failed = false;
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        if (k === undefined || k === null) {
          results[i] = undefined;
          continue;
        }
        pending++;
        const req = store.get(k);
        req.onsuccess = () => { results[i] = req.result; if (--pending === 0) resolve(results); };
        req.onerror = () => { if (!failed) { failed = true; reject(req.error); } };
      }
      if (pending === 0) resolve(results); // 全部为非法 key（无请求派发），事务将自动结束
    });
  }

  // 批量写：一个 readwrite 事务并发派发所有 put（同步派发，不跨 await），等事务 complete。
  async putMany(storeName, items) {
    if (!items || items.length === 0) return;
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      for (let i = 0; i < items.length; i++) store.put(items[i]);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  // 批量按主键删：一个 readwrite 事务并发派发所有 delete，等事务 complete。
  async deleteByKeys(storeName, keys) {
    if (!keys || keys.length === 0) return;
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      for (let i = 0; i < keys.length; i++) store.delete(keys[i]);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  // 全表读便捷封装（独立 readonly 事务，与调用方事务隔离）。
  async getAll(storeName) {
    return new Promise((resolve, reject) => {
      const store = this._tx(storeName, 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async getAnnotations(domain, webUri) {
    // 决策 4：按 uid 隔离读取。强制登录模型下调用方都已登录，但为防御性兼容
    // （升级瞬间 SW 启动早于 _finalizeAuth），uid 取不到时返回空数组而不是跨用户全表读。
    var identity = await this.getUserIdentity();
    var uid = identity && (identity.userId || identity.authorId);
    if (!uid) return [];
    const store = this._tx('annotations', 'readonly');
    const index = store.index('userId_domain_webUri');
    const range = IDBKeyRange.only([String(uid), domain, webUri]);
    return new Promise((resolve, reject) => {
      const req = index.getAll(range);
      // 过滤软删态：启用同步时删除只标 pending_deleted，需等推送确认后才硬删。
      // 加载阶段必须排除，否则会出现"删除后刷新仍显示，多次刷新才消失"。
      req.onsuccess = () => {
        const all = req.result || [];
        resolve(all.filter(a => a.SYNC_STATUS !== 'pending_deleted'));
      };
      req.onerror = () => reject(req.error);
    });
  }

  // P1-21: 同步状态内部字段归 SW/sync-engine 所有，不允许来自页面/manager 内存
  // （多 tab 各自持有 stale 快照，透传会在 merge 时互相覆盖同步状态、产生幽灵推送）。
  // commitData fieldMap 已移除这些键，此处对任意调用方兜底过滤。
  // SOURCE（2026-11-05）同列：协作标记判定依据，只认 sync-engine 下载落库的值，页面内存不得覆写。
  static get SYNC_OWNED_KEYS() {
    return ['SYNC_STATUS', 'SYNC_VERSION', 'SERVER_UPDATE_TIME', 'DIRTY_BITS', 'SYNCED_AT', 'SYNC_RETRY_COUNT', 'SOURCE'];
  }

  async saveAnnotation(annotation, pageTitle, scheme, onCreated, pagePort) {
    // 决策 4：写路径强制注入 USER_ID（不信任调用方）
    var identity = await this.getUserIdentity();
    var uid = identity && (identity.userId || identity.authorId);
    if (uid) annotation.USER_ID = String(uid);
    // P1-21: 丢弃 incoming 的同步内部字段；existing 的值在下方 merge 保留，新记录由
    // dispatcher 钩子的 markDirty 统一置 pending 重推。
    for (var _sk of AnnotationDB.SYNC_OWNED_KEYS) delete annotation[_sk];
    const store = this._tx('annotations', 'readwrite');
    return new Promise((resolve, reject) => {
      // merge 模式（读-改-写）：先取现有记录，保留 incoming 未携带的 SW 内部字段
      // （THUMBNAIL_PENDING、_pageKey、CREATE_TIME 等 commitData fieldMap 未收录的字段），
      // 避免 webpage 端 commitData 整体 put 覆盖导致这些字段丢失。incoming 携带的字段仍以其为准。
      const getReq = store.get(annotation.MARK_INFO_ID);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        let toPut = annotation;
        if (existing) {
          toPut = Object.assign({}, existing, annotation);
          // 保护 SW 异步上云回写的 THUMBNAIL（objectKey/dataUrl）：
          // 网页端内存 ann.THUMBNAIL 常为截图后遗留的 null/空（上云由 SW flush 回写 IDB，
          // 不反射回网页内存）。若任其覆盖 existing 已上云的 objectKey，manager 详情页与
          // 跨设备读图都会失败（pageRect 截图后填批注/标签即触发此回归）。
          var incomingThumb = annotation.THUMBNAIL;
          // incoming 为空 / "null" / "undefined"（网页端 ann.THUMBNAIL=null 经 formatParams 序列化成 "null" 字符串等过时占位）
          // → 用 existing.objectKey；existing 也没有则删除字段（保持缺失，让读路径走 localThumbnails 兜底），绝不把脏 "null" 写进 IDB
          if (!incomingThumb || incomingThumb === '' || incomingThumb === 'null' || incomingThumb === 'undefined') {
            if (existing.THUMBNAIL) toPut.THUMBNAIL = existing.THUMBNAIL;
            else delete toPut.THUMBNAIL;
          }
        }
        const req = store.put(toPut);
        req.onsuccess = async () => {
          // V69: 本地新建（merge 前无 existing）计入当日创建数；fire-and-forget 不阻塞保存
          if (!existing) {
            wpzl_bumpDailyMarkCount(uid);
            // v1.1.0: 生命周期计数 + 一次性评分邀请（同样 fire-and-forget；回调异常不得影响保存）
            try { if (onCreated) onCreated(); } catch (e) { /* ignore */ }
          }
          await this._updatePageRecord(toPut, pageTitle || '', scheme, pagePort);
          resolve(toPut);
        };
        req.onerror = () => reject(req.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 按 MARK_INFO_ID 取单条标注（含已软删的 tombstone）。删除流程读它判断是否需回收 R2 截图对象。
  async getAnnotation(markInfoId) {
    const store = this._tx('annotations', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(markInfoId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async deleteAnnotation(markInfoId) {
    const store = this._tx('annotations', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.delete(markInfoId);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async updateAnnotation(markInfoId, updates) {
    // P1-21 说明：同步内部字段（SYNC_* 等）的过滤在 dispatcher case 'updateAnnotation'
    // 做外部入口过滤；本方法保持中立——SW 内部合法路径（软删除 L4493 写
    // SYNC_STATUS='pending_deleted'、flush 回写等）直接调用本方法不受过滤影响。
    const store = this._tx('annotations', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(markInfoId);
      getReq.onsuccess = () => {
        const obj = getReq.result;
        if (!obj) {
          reject(new Error('Annotation not found: ' + markInfoId));
          return;
        }
        // P1-20: 保护已上云的 THUMBNAIL（objectKey）。网页端 char_update 的 THUMBNAIL
        // 常为截图后遗留的 null（上云由 SW flush 回写 IDB，不反射回网页内存），裸
        // Object.assign 会把 objectKey 擦成 null（manager 详情页/跨设备读图失败）。
        // 与 saveAnnotation 同模式：显式传空值 → 保留 existing，existing 也没有则删除字段；
        // 未携带（undefined）不进保护分支；有效值（flush 回写 cloudUrl）正常采纳。
        var _incomingThumb = updates.THUMBNAIL;
        var _prevThumb = obj.THUMBNAIL;
        Object.assign(obj, updates);
        if (_incomingThumb !== undefined &&
            (!_incomingThumb || _incomingThumb === '' || _incomingThumb === 'null' || _incomingThumb === 'undefined')) {
          if (_prevThumb) obj.THUMBNAIL = _prevThumb;
          else delete obj.THUMBNAIL;
        }
        const putReq = store.put(obj);
        putReq.onsuccess = () => resolve(obj);
        putReq.onerror = () => reject(putReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  async getAllPages() {
    // 决策 4：按 uid 隔离读取
    var identity = await this.getUserIdentity();
    var uid = identity && (identity.userId || identity.authorId);
    if (!uid) return [];
    const store = this._tx('pages', 'readonly');
    const index = store.index('userId');
    const range = IDBKeyRange.only(String(uid));
    return new Promise((resolve, reject) => {
      const req = index.getAll(range);
      req.onsuccess = () => {
        // 过滤软删 tombstone（pending_deleted），与 getAnnotations 一致
        // 否则 sidebar 会继续显示已删除的页面
        const all = req.result || [];
        resolve(all.filter(p => p.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED));
      };
      req.onerror = () => reject(req.error);
    });
  }

  // 整页批注：写 PAGE_NOTE + 标脏同步（DIRTY_BIT_PAGE_NOTE）。noteData 复用 summary 的 blocks 结构。
  async savePageNote(url, noteData) {
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';
    const store = this._tx('pages', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(url);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        var noteTime = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
        if (existing) {
          if (!existing.USER_ID) existing.USER_ID = uid;
          existing.PAGE_NOTE = noteData || null;
          existing.PAGE_NOTE_UPDATED_AT = noteData ? noteTime : null;
          if (existing.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED) {
            existing.SYNC_STATUS = (existing.SYNC_STATUS === SYNC_STATUS_SYNCED) ? SYNC_STATUS_PENDING : (existing.SYNC_STATUS || SYNC_STATUS_PENDING);
            existing.DIRTY_BITS = (existing.DIRTY_BITS || 0) | DIRTY_BIT_PAGE_NOTE;
            // 关键：bump lastVisited（=同步 updatedAt），否则服务端 LWW(clientTime.isAfter) 会因 updatedAt 未变而拒绝整条 pageNote 更新
            existing.lastVisited = noteTime;
            try { console.log('[Sync][Page] dirty PAGE_NOTE: url=' + url + ' source=savePageNote'); } catch (e) { /* ignore */ }
          }
          const putReq = store.put(existing);
          putReq.onsuccess = () => resolve(existing);
          putReq.onerror = () => reject(putReq.error);
        } else {
          var domain = '';
          try { domain = new URL(url).hostname; } catch (e) { /* normalized url may lack protocol */ }
          var newPage = {
            url: url,
            URL_MD5: wpzl_md5(url),
            domain: domain,
            title: (noteData && noteData.title) || '',
            PAGE_NOTE: noteData || null,
            PAGE_NOTE_UPDATED_AT: noteData ? noteTime : null,
            FAVORITE: false,
            FOLDER_ID: null,
            USER_ID: uid,
            annotationCount: 0,
            createdAt: noteTime,
            lastVisited: noteTime,
            SYNC_STATUS: SYNC_STATUS_LOCAL,
            SYNC_VERSION: 0,
            DIRTY_BITS: DIRTY_BIT_PAGE_NOTE,
            SERVER_UPDATE_TIME: null
          };
          const putReq2 = store.put(newPage);
          putReq2.onsuccess = () => resolve(newPage);
          putReq2.onerror = () => reject(putReq2.error);
        }
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 收藏切换：写 pages.FAVORITE + 标脏同步（DIRTY_BIT_FAVORITE）。与 savePageNote 同构。
  async setFavorite(url, isFavorite) {
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';
    const store = this._tx('pages', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(url);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        if (existing) {
          if (!existing.USER_ID) existing.USER_ID = uid;
          existing.FAVORITE = !!isFavorite;
          if (existing.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED) {
            existing.SYNC_STATUS = (existing.SYNC_STATUS === SYNC_STATUS_SYNCED) ? SYNC_STATUS_PENDING : (existing.SYNC_STATUS || SYNC_STATUS_PENDING);
            existing.DIRTY_BITS = (existing.DIRTY_BITS || 0) | DIRTY_BIT_FAVORITE;
            // bump lastVisited（=同步 updatedAt），确保服务端 LWW 接受 favorite 变更
            existing.lastVisited = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
          }
          const putReq = store.put(existing);
          putReq.onsuccess = () => resolve(existing);
          putReq.onerror = () => reject(putReq.error);
        } else {
          var domain = '';
          try { domain = new URL(url).hostname; } catch (e) { /* normalized url may lack protocol */ }
          var ts = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
          var newPage = {
            url: url,
            URL_MD5: wpzl_md5(url),
            domain: domain,
            title: '',
            FAVORITE: !!isFavorite,
            FOLDER_ID: null,
            USER_ID: uid,
            annotationCount: 0,
            createdAt: ts,
            lastVisited: ts,
            SYNC_STATUS: SYNC_STATUS_LOCAL,
            SYNC_VERSION: 0,
            DIRTY_BITS: DIRTY_BIT_FAVORITE,
            SERVER_UPDATE_TIME: null
          };
          const putReq2 = store.put(newPage);
          putReq2.onsuccess = () => resolve(newPage);
          putReq2.onerror = () => reject(putReq2.error);
        }
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 读取完整 pages 记录（含 PAGE_NOTE / FAVORITE / FOLDER_ID 等同步字段）。无则 null。
  async getPageRecord(url) {
    const store = this._tx('pages', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(url);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  // 设置页面所属目录：写 pages.FOLDER_ID + 标脏同步（DIRTY_BIT_FOLDER）。与 setFavorite 同构。
  async setPageFolderId(url, folderId) {
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';
    const store = this._tx('pages', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(url);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        var targetId = folderId || null;
        if (existing) {
          if (!existing.USER_ID) existing.USER_ID = uid;
          existing.FOLDER_ID = targetId;
          if (existing.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED) {
            existing.SYNC_STATUS = (existing.SYNC_STATUS === SYNC_STATUS_SYNCED) ? SYNC_STATUS_PENDING : (existing.SYNC_STATUS || SYNC_STATUS_PENDING);
            existing.DIRTY_BITS = (existing.DIRTY_BITS || 0) | DIRTY_BIT_FOLDER;
            // bump lastVisited（=同步 updatedAt），确保服务端 LWW 接受 folder 归属变更
            existing.lastVisited = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
          }
          const putReq = store.put(existing);
          putReq.onsuccess = () => resolve(existing);
          putReq.onerror = () => reject(putReq.error);
        } else {
          var domain = '';
          try { domain = new URL(url).hostname; } catch (e) { /* normalized url may lack protocol */ }
          var ts = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
          var newPage = {
            url: url,
            URL_MD5: wpzl_md5(url),
            domain: domain,
            title: '',
            FAVORITE: false,
            FOLDER_ID: targetId,
            USER_ID: uid,
            annotationCount: 0,
            createdAt: ts,
            lastVisited: ts,
            SYNC_STATUS: SYNC_STATUS_LOCAL,
            SYNC_VERSION: 0,
            DIRTY_BITS: DIRTY_BIT_FOLDER,
            SERVER_UPDATE_TIME: null
          };
          const putReq2 = store.put(newPage);
          putReq2.onsuccess = () => resolve(newPage);
          putReq2.onerror = () => reject(putReq2.error);
        }
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 重命名页面：写 pages.CUSTOM_TITLE + 标脏同步（DIRTY_BIT_CUSTOM_TITLE）。与 setFavorite/setPageFolderId 同构。
  // customTitle 为空串/null 时表示"清除自定义标题，回退到自动抓取的 title"。
  async setCustomTitle(url, customTitle) {
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';
    const store = this._tx('pages', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(url);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        // 规范化：去首尾空白；空串/null 都视为"清除自定义标题"
        var normalized = (typeof customTitle === 'string') ? customTitle.trim() : '';
        var target = normalized ? normalized : null;
        if (existing) {
          if (!existing.USER_ID) existing.USER_ID = uid;
          existing.CUSTOM_TITLE = target;
          if (existing.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED) {
            existing.SYNC_STATUS = (existing.SYNC_STATUS === SYNC_STATUS_SYNCED) ? SYNC_STATUS_PENDING : (existing.SYNC_STATUS || SYNC_STATUS_PENDING);
            existing.DIRTY_BITS = (existing.DIRTY_BITS || 0) | DIRTY_BIT_CUSTOM_TITLE;
            // bump lastVisited（=同步 updatedAt），确保服务端 LWW 接受 customTitle 变更
            existing.lastVisited = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
          }
          const putReq = store.put(existing);
          putReq.onsuccess = () => resolve(existing);
          putReq.onerror = () => reject(putReq.error);
        } else {
          var domain = '';
          try { domain = new URL(url).hostname; } catch (e) { /* normalized url may lack protocol */ }
          var ts = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
          var newPage = {
            url: url,
            URL_MD5: wpzl_md5(url),
            domain: domain,
            title: '',
            CUSTOM_TITLE: target,
            FAVORITE: false,
            FOLDER_ID: null,
            USER_ID: uid,
            annotationCount: 0,
            createdAt: ts,
            lastVisited: ts,
            SYNC_STATUS: SYNC_STATUS_LOCAL,
            SYNC_VERSION: 0,
            DIRTY_BITS: DIRTY_BIT_CUSTOM_TITLE,
            SERVER_UPDATE_TIME: null
          };
          const putReq2 = store.put(newPage);
          putReq2.onsuccess = () => resolve(newPage);
          putReq2.onerror = () => reject(putReq2.error);
        }
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 目录树拖拽重排：批量写排序号 + 标脏同步。updates: [{kind:'page'|'document'|'snapshot',
  // url/docId/snapId, sortOrder}]。只更新已存在记录（重排只发生在树内可见条目上），缺失项跳过。
  // pages 与 setFavorite/setCustomTitle 同构（DIRTY_BIT_SORT_ORDER + bump lastVisited 过服务端 LWW）；
  // docs/snaps 与 putDocument 同构（整记录同步：updatedAt=now、SYNCED→PENDING），不动 bodyDirty/bodyHtml。
  async setSortOrders(updates) {
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';
    var ts = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
    var pageUps = [], docUps = [], snapUps = [];
    (updates || []).forEach(function (u) {
      if (!u || typeof u.sortOrder !== 'number') return;
      if (u.kind === 'page' && u.url) pageUps.push(u);
      else if (u.kind === 'document' && u.docId) docUps.push(u);
      else if (u.kind === 'snapshot' && u.snapId) snapUps.push(u);
    });

    // 同一 tx 上并行的 get→put 链：每个 onsuccess 立即发 put 维持事务存活（缺失项不发请求，无风险）
    const _applyOne = (store, key, mutate) => new Promise((resolve, reject) => {
      const getReq = store.get(key);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        if (!existing) { resolve(null); return; }
        mutate(existing);
        const putReq = store.put(existing);
        putReq.onsuccess = () => resolve(existing);
        putReq.onerror = () => reject(putReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });

    if (pageUps.length) {
      const store = this._tx('pages', 'readwrite');
      await Promise.all(pageUps.map((u) => _applyOne(store, u.url, (rec) => {
        if (!rec.USER_ID) rec.USER_ID = uid;
        rec.SORT_ORDER = u.sortOrder;
        if (rec.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED) {
          rec.SYNC_STATUS = (rec.SYNC_STATUS === SYNC_STATUS_SYNCED) ? SYNC_STATUS_PENDING : (rec.SYNC_STATUS || SYNC_STATUS_PENDING);
          rec.DIRTY_BITS = (rec.DIRTY_BITS || 0) | DIRTY_BIT_SORT_ORDER;
          // bump lastVisited（=同步 updatedAt），确保服务端 LWW 接受 sortOrder 变更
          rec.lastVisited = ts;
        }
      })));
    }
    if (docUps.length) {
      const store = this._tx('documents', 'readwrite');
      await Promise.all(docUps.map((u) => _applyOne(store, u.docId, (rec) => {
        rec.sortOrder = u.sortOrder;
        rec.updatedAt = ts;
        rec.DIRTY_BITS = 0xFF;
        if (rec.SYNC_STATUS === SYNC_STATUS_SYNCED) rec.SYNC_STATUS = SYNC_STATUS_PENDING;
      })));
    }
    if (snapUps.length) {
      const store = this._tx('snapshots', 'readwrite');
      await Promise.all(snapUps.map((u) => _applyOne(store, u.snapId, (rec) => {
        rec.sortOrder = u.sortOrder;
        rec.updatedAt = ts;
        rec.DIRTY_BITS = 0xFF;
        if (rec.SYNC_STATUS === SYNC_STATUS_SYNCED) rec.SYNC_STATUS = SYNC_STATUS_PENDING;
      })));
    }
    return true;
  }

  // 读取所有 folder（folders store 原始记录，含 PENDING_DELETED，由调用方过滤）。
  async getAllFolders() {
    const store = this._tx('folders', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  // 写入/更新 folder（get-then-put）：name/parent/order 变化时若已 SYNCED 则标 PENDING 推送（确保改名同步）。
  // folder = { folderId, name, parentFolderId, orderSeq }。folderId 由调用方生成。
  async putFolder(folder) {
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';
    const store = this._tx('folders', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(folder.folderId);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        var ts = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
        var record;
        if (existing) {
          record = Object.assign({}, existing, {
            name: folder.name != null ? folder.name : existing.name,
            parentFolderId: folder.parentFolderId !== undefined ? folder.parentFolderId : existing.parentFolderId,
            orderSeq: folder.orderSeq != null ? folder.orderSeq : existing.orderSeq,
            updatedAt: ts,
            DIRTY_BITS: 0xFF
          });
          if (!record.USER_ID) record.USER_ID = uid;
          // 已是 SYNCED 基线 → 标 PENDING 触发推送（改名/移动/排序）
          if (record.SYNC_STATUS === SYNC_STATUS_SYNCED) {
            record.SYNC_STATUS = SYNC_STATUS_PENDING;
          }
        } else {
          record = {
            folderId: folder.folderId,
            name: folder.name || '',
            parentFolderId: folder.parentFolderId || null,
            orderSeq: folder.orderSeq || 0,
            USER_ID: uid,
            updatedAt: ts,
            SYNC_STATUS: SYNC_STATUS_LOCAL,
            SYNC_VERSION: 0,
            SERVER_UPDATE_TIME: null,
            DIRTY_BITS: 0xFF
          };
        }
        const putReq = store.put(record);
        putReq.onsuccess = () => resolve(record);
        putReq.onerror = () => reject(putReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 软删 folder（标 PENDING_DELETED，等待推送后由 sync-engine 硬删）。
  async softDeleteFolder(folderId) {
    // 默认目录(root) 被删：记 per-user 标记，_ensureRootFolder 据此永不重建（policy 级，尊重用户删除）
    if (folderId === 'root') {
      try {
        const identity = await this.getUserIdentity();
        const uid = (identity && identity.userId) || (identity && identity.authorId) || '';
        if (uid) chrome.storage.local.set({ ['wpzl_df_del_' + uid]: true });
      } catch (e) { /* ignore */ }
    }
    const store = this._tx('folders', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(folderId);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        if (!existing) { resolve(null); return; }
        existing.SYNC_STATUS = SYNC_STATUS_PENDING_DELETED;
        existing.DIRTY_BITS = 0xFF;
        const putReq = store.put(existing);
        putReq.onsuccess = () => resolve(existing);
        putReq.onerror = () => reject(putReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 硬删 folder（非 Pro / 未启用同步时直接物理删除，避免 tombstone 累积）。
  async deleteFolder(folderId) {
    const store = this._tx('folders', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.delete(folderId);
      req.onsuccess = () => resolve({ folderId: folderId, deleted: true });
      req.onerror = () => reject(req.error);
    });
  }

  // ===== documents store（自建文档，dbVersion 12；P1-8 dbVersion 25 起 body 分仓）=====
  // 记录形态：{ docId, webUri, domain, urlMd5, title, folderId, tags, kind:'document',
  //   bodyObjectKey, bodyContentHash, bodyDirty, pageWidth, isReadOnly, sortOrder,
  //   USER_ID, updatedAt, SYNC_STATUS, SYNC_VERSION, SERVER_UPDATE_TIME, DIRTY_BITS,
  //   SYNC_RETRY_COUNT, SYNC_EXHAUSTED, SYNC_LAST_ERROR, SYNC_LAST_ATTEMPT_AT }
  // bodyHtml 不在此（dbVersion 25 分仓）——在 docBodies {docId, bodyHtml, bodyText}；
  // 读取走 getDocBody*/getDocumentBody（本地优先），写入走 putDocument/saveDocBody/
  // saveDocumentBodyFromCloud。与 folders/pages 同步字段约定一致；webUri/urlMd5 由调用方
  //（manager）构造，服务端在 <manager_domain>/d/<docId> 渲染该文档，批注按 webUri 绑定。
  // tags = 分号分隔串（与 annotations.TAGS 同语义）；整记录上传 DIRTY_BITS=0xFF。

  async getDocument(docId) {
    const store = this._tx('documents', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(docId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async getAllDocuments() {
    const store = this._tx('documents', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => {
        const all = req.result || [];
        // 过滤软删 tombstone（pending_deleted），与 getAnnotations/getAllPages 一致
        // 否则 sidebar 会继续显示已删除的文档（删除看似无效）
        resolve(all.filter(d => d.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED));
      };
      req.onerror = () => reject(req.error);
    });
  }

  // D3：后台下载器/编辑器回拉把从 R2 取回的 bodyHtml 写入 docBodies（P1-8 分仓后 body 落脚点）。
  // 与 putDocument 不同：不标 bodyDirty、不动 SYNC_STATUS/DIRTY_BITS——这是"从云读回本地"，
  // 不是用户编辑，不应触发下次同步重传 body。保留 bodyObjectKey/bodyContentHash 等既有字段。
  // P1-7：下载侧重试字段（dlRetryCount/dlExhausted/dlLastError/dlNextAt）并入本次
  // documents get-then-put 一并复位（省一次大记录整读整写）。
  // P1-8：documents 与 docBodies 同事务写（原子：记录标记与 body 落地不脱节）。
  async saveDocumentBodyFromCloud(docId, bodyHtml) {
    const tx = this.db.transaction(['documents', 'docBodies'], 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = tx.objectStore('documents').get(docId);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        if (!existing) { resolve(null); return; }
        existing.bodyDirty = false;
        // 不动 SYNC_STATUS / DIRTY_BITS / bodyObjectKey / bodyContentHash
        if (existing.dlRetryCount || existing.dlExhausted || existing.dlLastError || existing.dlNextAt) {
          existing.dlRetryCount = 0;
          existing.dlExhausted = false;
          existing.dlLastError = null;
          existing.dlNextAt = 0;
        }
        tx.objectStore('documents').put(existing);
        tx.objectStore('docBodies').put({ docId: docId, bodyHtml: bodyHtml, bodyText: _wpzlHtmlToText(bodyHtml) });
        tx.oncomplete = () => resolve(existing);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // ===== docBodies / snapBodies store（dbVersion 25，P1-8 body/元数据分仓）=====
  // documents/snapshots 记录只留元数据；bodyHtml（文档另含检索用 bodyText）独立成 store。
  // 列表类读取（getAllDocuments/getAllSnapshots/同步 dirty 收集/进度扫描）从此不物化 body。

  async getDocBody(docId) {
    const store = this._tx('docBodies', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(docId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async getDocBodyHtml(docId) {
    const rec = await this.getDocBody(docId);
    return (rec && rec.bodyHtml) || '';
  }

  async getDocBodyKeySet() {
    const store = this._tx('docBodies', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.getAllKeys();
      req.onsuccess = () => resolve(new Set(req.result || []));
      req.onerror = () => reject(req.error);
    });
  }

  // 中性 body 写入（putDocument/putSnapshot/restore 用）：只落 body store，不动 documents 任何字段
  //（区别 saveDocumentBodyFromCloud 的"云读回"语义——那里会清 bodyDirty/复位下载重试）。
  async saveDocBody(docId, bodyHtml) {
    const store = this._tx('docBodies', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.put({ docId: docId, bodyHtml: bodyHtml, bodyText: _wpzlHtmlToText(bodyHtml) });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async saveSnapBody(snapId, bodyHtml) {
    const store = this._tx('snapBodies', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.put({ snapId: snapId, bodyHtml: bodyHtml });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async getSnapBody(snapId) {
    const store = this._tx('snapBodies', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(snapId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async getSnapBodyHtml(snapId) {
    const rec = await this.getSnapBody(snapId);
    return (rec && rec.bodyHtml) || '';
  }

  // 批量删 body（文档/快照删除级联；keys 为空 no-op）。同事务并发派发，等 complete。
  async deleteBodies(storeName, keys) {
    if (!keys || keys.length === 0) return;
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      for (let i = 0; i < keys.length; i++) {
        if (keys[i] !== undefined && keys[i] !== null) store.delete(keys[i]);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  // P1-15: 下载重试元数据专用 patch（get-then-put merge）。中立性契约与 saveDocumentBodyFromCloud
  // 同：不碰 SYNC_STATUS/DIRTY_BITS/bodyDirty/bodyObjectKey——dlRetryCount/dlExhausted/dlLastError
  // 是下载侧状态，与上传侧 SYNC_RETRY_COUNT 语义互不干扰。缺行 no-op。
  async updateDocumentFields(docId, patch) {
    if (!docId || !patch) return null;
    const store = this._tx('documents', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(docId);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        if (!existing) { resolve(null); return; }
        Object.assign(existing, patch);
        const putReq = store.put(existing);
        putReq.onsuccess = () => resolve(existing);
        putReq.onerror = () => reject(putReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 写入/更新 document（get-then-put）。doc = { docId, webUri, domain, urlMd5, title, bodyHtml, folderId, tags }。
  // 字段 null/undefined 表示不修改（差量）；bodyHtml 为文档正文（图片仅存 src 引用）。
  // P1-8（dbVersion 25）：bodyHtml 不进 documents 记录——非 null 时落 docBodies（bodyText 一并预计算）。
  async putDocument(doc) {
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';
    const store = this._tx('documents', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(doc.docId);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        var ts = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
        var record;
        if (existing) {
          record = Object.assign({}, existing, {
            webUri: doc.webUri != null ? doc.webUri : existing.webUri,
            domain: doc.domain != null ? doc.domain : existing.domain,
            urlMd5: doc.urlMd5 != null ? doc.urlMd5 : existing.urlMd5,
            title: doc.title != null ? doc.title : existing.title,
            // body 上云：保存即标 bodyDirty，触发下次同步重传 body（服务端覆盖同一 R2 对象）。
            // bodyObjectKey/bodyContentHash 保留既有（Object.assign 不覆盖），同步成功后由下载合并刷新 hash。
            bodyDirty: doc.bodyHtml != null ? true : !!(existing.bodyDirty),
            folderId: doc.folderId !== undefined ? doc.folderId : existing.folderId,
            tags: doc.tags !== undefined ? doc.tags : existing.tags,
            pageWidth: doc.pageWidth != null ? doc.pageWidth : (existing.pageWidth || '820px'),
            isReadOnly: doc.isReadOnly != null ? doc.isReadOnly : existing.isReadOnly,
            updatedAt: ts,
            DIRTY_BITS: 0xFF
          });
          if (!record.USER_ID) record.USER_ID = uid;
          if (record.SYNC_STATUS === SYNC_STATUS_SYNCED) {
            record.SYNC_STATUS = SYNC_STATUS_PENDING;
          }
        } else {
          record = {
            docId: doc.docId,
            webUri: doc.webUri || '',
            domain: doc.domain || '',
            urlMd5: doc.urlMd5 || '',
            title: doc.title || '',
            bodyObjectKey: existing && existing.bodyObjectKey ? existing.bodyObjectKey : null,
            bodyContentHash: existing && existing.bodyContentHash ? existing.bodyContentHash : null,
            bodyDirty: true,
            folderId: doc.folderId || null,
            tags: doc.tags != null ? doc.tags : '',
            pageWidth: doc.pageWidth || '820px',
            isReadOnly: !!doc.isReadOnly,
            kind: 'document',
            USER_ID: uid,
            createdAt: ts,
            updatedAt: ts,
            SYNC_STATUS: SYNC_STATUS_LOCAL,
            SYNC_VERSION: 0,
            SERVER_UPDATE_TIME: null,
            DIRTY_BITS: 0xFF,
            SYNC_RETRY_COUNT: 0,
            SYNC_EXHAUSTED: false,
            SYNC_LAST_ERROR: null,
            SYNC_LAST_ATTEMPT_AT: null
          };
        }
        const putReq = store.put(record);
        putReq.onsuccess = () => {
          // P1-8：body 落分仓 store（非 null 才写——差量更新不动既有 body）
          if (doc.bodyHtml != null) {
            try { this.saveDocBody(doc.docId, doc.bodyHtml); } catch (e) { /* ignore */ }
          }
          // P1-7：本地已有 body（用户新建/编辑保存）→ 出后台下载清单（防 ghost 项被无谓重下）
          if (doc.bodyHtml != null && typeof _removeDocDlPendingByIds === 'function') {
            try { _removeDocDlPendingByIds([record.docId]); } catch (e) { /* ignore */ }
          }
          resolve(record);
        };
        putReq.onerror = () => reject(putReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 软删 document（标 PENDING_DELETED，等待推送后由 sync-engine 硬删）。
  async softDeleteDocument(docId) {
    const store = this._tx('documents', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(docId);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        if (!existing) { resolve(null); return; }
        existing.SYNC_STATUS = SYNC_STATUS_PENDING_DELETED;
        existing.DIRTY_BITS = 0xFF;
        const putReq = store.put(existing);
        putReq.onsuccess = () => {
          // P1-8：body 同删（本地分仓 body；服务端副本由推送删除清理）
          try { this.deleteBodies('docBodies', [docId]); } catch (e) { /* ignore */ }
          // P1-7：软删即出下载清单（硬删路径 _applyDeletedDocuments 另有出队兜底）
          if (typeof _removeDocDlPendingByIds === 'function') {
            try { _removeDocDlPendingByIds([docId]); } catch (e) { /* ignore */ }
          }
          resolve(existing);
        };
        putReq.onerror = () => reject(putReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 硬删 document（非 Pro / 未启用同步时直接物理删除）。
  async deleteDocument(docId) {
    const store = this._tx('documents', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.delete(docId);
      req.onsuccess = () => {
        // P1-8：body 同删
        try { this.deleteBodies('docBodies', [docId]); } catch (e) { /* ignore */ }
        // P1-7：硬删即出下载清单
        if (typeof _removeDocDlPendingByIds === 'function') {
          try { _removeDocDlPendingByIds([docId]); } catch (e) { /* ignore */ }
        }
        resolve({ docId: docId, deleted: true });
      };
      req.onerror = () => reject(req.error);
    });
  }

  // ===== snapshots store（网页快照，dbVersion 13；P1-8 dbVersion 25 起 body 分仓，与 documents 同构）=====
  // 记录形态：{ snapId, webUri, domain, urlMd5, title, sourceWebUri, sourceUrlMd5, snapType,
  //   folderId, kind:'snapshot', bodyObjectKey, bodyContentHash, USER_ID, updatedAt, SYNC_STATUS,
  //   SYNC_VERSION, SERVER_UPDATE_TIME, DIRTY_BITS, SYNC_RETRY_COUNT, SYNC_EXHAUSTED, SYNC_LAST_ERROR, SYNC_LAST_ATTEMPT_AT }
  // bodyHtml 不在此（dbVersion 25 分仓）——在 snapBodies {snapId, bodyHtml}。
  // webUri = <manager_domain>/snap/<snapId>，服务端在该 URL 渲染快照，批注按 webUri 绑定。

  async getSnapshot(snapId) {
    const store = this._tx('snapshots', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(snapId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async getAllSnapshots() {
    const store = this._tx('snapshots', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => {
        const all = req.result || [];
        // 过滤软删 tombstone（pending_deleted），与 getAllDocuments 一致
        resolve(all.filter(s => s.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED));
      };
      req.onerror = () => reject(req.error);
    });
  }

  // 按 source_url_md5 取最新一条快照（manager「快照」按钮定位用）。返回 null 表示无快照。
  async getLatestSnapshotBySource(sourceUrlMd5) {
    const store = this._tx('snapshots', 'readonly');
    const index = store.index('sourceUrlMd5');
    return new Promise((resolve, reject) => {
      const req = index.getAll(sourceUrlMd5);
      req.onsuccess = () => {
        const all = (req.result || []).filter(s => s.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED);
        if (all.length === 0) { resolve(null); return; }
        // 最新 = updatedAt 最大（采集时间）；兜底 snapId 字典序
        all.sort(function (a, b) {
          var ta = a.updatedAt || '', tb = b.updatedAt || '';
          if (ta === tb) return (a.snapId < b.snapId) ? 1 : -1;
          return (ta < tb) ? 1 : -1;
        });
        resolve(all[0]);
      };
      req.onerror = () => reject(req.error);
    });
  }

  // 按 source_url_md5 取全部快照（按 updatedAt 倒序），供详情页快照列表渲染。
  // 与 getLatestSnapshotBySource 同构，但不截断、过滤 PENDING_DELETED tombstone。
  async getSnapshotsBySource(sourceUrlMd5) {
    const store = this._tx('snapshots', 'readonly');
    const index = store.index('sourceUrlMd5');
    return new Promise((resolve, reject) => {
      const req = index.getAll(sourceUrlMd5);
      req.onsuccess = () => {
        const all = (req.result || []).filter(s => s.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED);
        all.sort(function (a, b) {
          var ta = a.updatedAt || '', tb = b.updatedAt || '';
          if (ta === tb) return (a.snapId < b.snapId) ? 1 : -1;
          return (ta < tb) ? 1 : -1;
        });
        resolve(all);
      };
      req.onerror = () => reject(req.error);
    });
  }

  // 写入/更新 snapshot（get-then-put）。snap = { snapId, webUri, domain, urlMd5, title, bodyHtml, sourceWebUri, sourceUrlMd5, folderId }。
  // 字段 null/undefined 表示不修改（差量）；bodyHtml 为纯原始网页快照 HTML（采集即定稿，通常仅新建时写入）。
  // P1-8（dbVersion 25）：bodyHtml 不进 snapshots 记录——非 null 时落 snapBodies。
  async putSnapshot(snap) {
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';
    const store = this._tx('snapshots', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(snap.snapId);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        var ts = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
        var record;
        if (existing) {
          record = Object.assign({}, existing, {
            webUri: snap.webUri != null ? snap.webUri : existing.webUri,
            domain: snap.domain != null ? snap.domain : existing.domain,
            urlMd5: snap.urlMd5 != null ? snap.urlMd5 : existing.urlMd5,
            title: snap.title != null ? snap.title : existing.title,
            sourceWebUri: snap.sourceWebUri != null ? snap.sourceWebUri : existing.sourceWebUri,
            sourceUrlMd5: snap.sourceUrlMd5 != null ? snap.sourceUrlMd5 : existing.sourceUrlMd5,
            folderId: snap.folderId !== undefined ? snap.folderId : existing.folderId,
            snapType: snap.snapType != null ? snap.snapType : (existing.snapType || 'full'),
            updatedAt: ts,
            DIRTY_BITS: 0xFF
          });
          if (!record.USER_ID) record.USER_ID = uid;
          if (record.SYNC_STATUS === SYNC_STATUS_SYNCED) {
            record.SYNC_STATUS = SYNC_STATUS_PENDING;
          }
        } else {
          record = {
            snapId: snap.snapId,
            webUri: snap.webUri || '',
            domain: snap.domain || '',
            urlMd5: snap.urlMd5 || '',
            title: snap.title || '',
            sourceWebUri: snap.sourceWebUri || '',
            sourceUrlMd5: snap.sourceUrlMd5 || '',
            folderId: snap.folderId || null,
            snapType: snap.snapType || 'full',
            kind: 'snapshot',
            USER_ID: uid,
            createdAt: ts,
            updatedAt: ts,
            SYNC_STATUS: SYNC_STATUS_LOCAL,
            SYNC_VERSION: 0,
            SERVER_UPDATE_TIME: null,
            DIRTY_BITS: 0xFF,
            SYNC_RETRY_COUNT: 0,
            SYNC_EXHAUSTED: false,
            SYNC_LAST_ERROR: null,
            SYNC_LAST_ATTEMPT_AT: null
          };
        }
        const putReq = store.put(record);
        putReq.onsuccess = () => {
          // P1-8：body 落分仓 store（非 null 才写——差量更新如重命名/移动目录不动既有 body）
          if (snap.bodyHtml != null) {
            try { this.saveSnapBody(snap.snapId, snap.bodyHtml); } catch (e) { /* ignore */ }
          }
          resolve(record);
        };
        putReq.onerror = () => reject(putReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 快照采集时为「源页」补建 pages 记录（仅当不存在），保证「仅生成快照、无标注」的源页也出现在侧栏。
  // sourceWebUri 来自 snapshot-capture 的 wpzl_normalizeWebpath(window.location)（host+path+search，无协议），与 pages.url 同族。
  // get-then-put：已存在则只补缺失的 USER_ID/URL_MD5，绝不覆盖业务字段（避免压掉真用户的标注/摘要/收藏等）。
  async ensurePageForSnapshot(sourceWebUri, sourceUrlMd5, domain, title) {
    if (!sourceWebUri) return null;
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';
    const store = this._tx('pages', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(sourceWebUri);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        if (existing) {
          // 已有真用户 page 记录：仅补缺失的 USER_ID / URL_MD5，不动其它业务字段
          var changed = false;
          if (!existing.USER_ID && uid) { existing.USER_ID = uid; changed = true; }
          if (!existing.URL_MD5 && sourceUrlMd5) { existing.URL_MD5 = sourceUrlMd5; changed = true; }
          if (changed) {
            const putReq = store.put(existing);
            putReq.onsuccess = () => resolve(existing);
            putReq.onerror = () => reject(putReq.error);
          } else {
            resolve(existing);
          }
          return;
        }
        // 不存在：新建最小 page 记录。字段对齐 _updatePageRecord 本地新建分支
        // （SYNC_STATUS=local + DIRTY_BITS=128|2048 = TITLE|VISITED）。
        var ts = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
        var record = {
          url: sourceWebUri,
          URL_MD5: sourceUrlMd5 || wpzl_md5(sourceWebUri),
          domain: domain || '',
          scheme: '',                                  // 未知，留待真实访问时 _updatePageRecord 补
          title: title || '',
          annotationCount: 0,
          createdAt: ts,
          lastVisited: ts,
          FAVORITE: false,
          FOLDER_ID: null,
          USER_ID: uid,
          SYNC_STATUS: SYNC_STATUS_LOCAL,
          SYNC_VERSION: 0,
          SERVER_UPDATE_TIME: null,
          DIRTY_BITS: 128 | 2048                       // TITLE(1<<7) | VISITED(1<<11)
        };
        const putReq2 = store.put(record);
        putReq2.onsuccess = () => resolve(record);
        putReq2.onerror = () => reject(putReq2.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 软删 snapshot（标 PENDING_DELETED，等待推送后由 sync-engine 硬删）。
  async softDeleteSnapshot(snapId) {
    const store = this._tx('snapshots', 'readwrite');
    return new Promise((resolve, reject) => {
      const getReq = store.get(snapId);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        if (!existing) { resolve(null); return; }
        existing.SYNC_STATUS = SYNC_STATUS_PENDING_DELETED;
        existing.DIRTY_BITS = 0xFF;
        const putReq = store.put(existing);
        putReq.onsuccess = () => {
          // P1-8：body 同删（服务端副本由推送删除清理）
          try { this.deleteBodies('snapBodies', [snapId]); } catch (e) { /* ignore */ }
          resolve(existing);
        };
        putReq.onerror = () => reject(putReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
    });
  }

  // 硬删 snapshot（非 Pro / 未启用同步时直接物理删除）。
  async deleteSnapshot(snapId) {
    const store = this._tx('snapshots', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.delete(snapId);
      req.onsuccess = () => {
        // P1-8：body 同删
        try { this.deleteBodies('snapBodies', [snapId]); } catch (e) { /* ignore */ }
        resolve({ snapId: snapId, deleted: true });
      };
      req.onerror = () => reject(req.error);
    });
  }

  // 软删 page：单事务级联标脏 page + 所有匹配的 annotation。
  // annotation 通过 WEB_URI+DOMAIN 软链接 page（无 FK），必须主动级联查询。
  // 用 domain_webUri 索引（不限 uid，孤儿标注也清理），事务覆盖 pages + annotations 保证原子性。
  async softDeletePage(url, domain) {
    const tx = this.db.transaction(['pages', 'annotations'], 'readwrite');
    const pageStore = tx.objectStore('pages');
    const annStore = tx.objectStore('annotations');
    return new Promise((resolve, reject) => {
      const results = { page: null, annotations: 0 };
      const pageGet = pageStore.get(url);
      pageGet.onsuccess = () => {
        const page = pageGet.result;
        let effDomain = domain, effUrl = url;
        if (page) {
          effDomain = page.domain || domain;
          effUrl = page.url || url;
          page.SYNC_STATUS = SYNC_STATUS_PENDING_DELETED;
          page.DIRTY_BITS = 0xFF; // 全字段脏，与 softDeleteFolder 一致
          pageStore.put(page);
          results.page = page;
        }
        // 级联：标脏所有匹配 domain+webUri 的 annotation
        const annIdx = annStore.index('domain_webUri');
        const annReq = annIdx.openCursor(IDBKeyRange.only([effDomain, effUrl]));
        annReq.onsuccess = () => {
          const c = annReq.result;
          if (!c) return;
          const a = c.value;
          if (a.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED) {
            a.SYNC_STATUS = SYNC_STATUS_PENDING_DELETED;
            a.DIRTY_BITS = (1 << 5); // DIRTY_BIT_DELETED
            c.update(a);
            results.annotations++;
          }
          c.continue();
        };
        annReq.onerror = () => reject(annReq.error);
      };
      pageGet.onerror = () => reject(pageGet.error);
      tx.oncomplete = () => resolve(results);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  // 硬删 page：非同步模式回退。物理删 page + annotation + imageData + localThumbnails。
  async hardDeletePage(url, domain) {
    const tx = this.db.transaction(['pages', 'annotations', 'imageData', 'localThumbnails'], 'readwrite');
    const pStore = tx.objectStore('pages');
    const aStore = tx.objectStore('annotations');
    const iStore = tx.objectStore('imageData');
    const tStore = tx.objectStore('localThumbnails');
    return new Promise((resolve, reject) => {
      let urlMd5 = null;
      const pageGet = pStore.get(url);
      pageGet.onsuccess = () => {
        const page = pageGet.result;
        if (page) {
          urlMd5 = page.URL_MD5 || null;
          pStore.delete(url);
        }
        const effDomain = (page && page.domain) || domain;
        // annotation + 其关联的 localThumbnail（keyPath = annId）
        const annIdx = aStore.index('domain_webUri');
        const annReq = annIdx.openCursor(IDBKeyRange.only([effDomain, url]));
        annReq.onsuccess = () => {
          const c = annReq.result;
          if (!c) return;
          const a = c.value;
          try { tStore.delete(a.MARK_INFO_ID); } catch (e) { /* thumbnail 可能不存在 */ }
          c.delete();
          c.continue();
        };
        annReq.onerror = () => reject(annReq.error);
        // page 级 imageData（keyPath = pageKey_imageKey，按 pageKey 索引）
        if (urlMd5) {
          const imgIdx = iStore.index('pageKey');
          const imgReq = imgIdx.openCursor(IDBKeyRange.only(urlMd5));
          imgReq.onsuccess = () => {
            const c = imgReq.result;
            if (!c) return;
            c.delete();
            c.continue();
          };
          imgReq.onerror = () => reject(imgReq.error);
        }
      };
      pageGet.onerror = () => reject(pageGet.error);
      tx.oncomplete = () => resolve({ url: url, urlMd5: urlMd5 });
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  // D2：物理删除某 page 的全部本地 imageData（按 pageKey 索引）。
  // 删页级联用：服务端已（批端点/同步页墓碑）删该页 R2 对象，本地副本同步清掉，避免被 _collectDirtyImageData
  // 当作 active 重新推送而"复活"服务端 tombstone。返回删除条数。
  async deleteImageDataByPageKey(pageKey) {
    if (!pageKey) return 0;
    const tx = this.db.transaction('imageData', 'readwrite');
    const store = tx.objectStore('imageData');
    const idx = store.index('pageKey');
    let deleted = 0;
    return new Promise((resolve, reject) => {
      const req = idx.openCursor(IDBKeyRange.only(pageKey));
      req.onsuccess = () => {
        const c = req.result;
        if (!c) return;
        c.delete();
        deleted++;
        c.continue();
      };
      req.onerror = () => reject(req.error);
      tx.oncomplete = () => resolve(deleted);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  // 取 page 记录的 URL_MD5（pages store 以 url 为 keyPath）。供快照查看由 url → urlMd5 → 服务端取快照。
  async getPageUrlMd5(url) {
    const store = this._tx('pages', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(url);
      req.onsuccess = () => resolve(req.result ? (req.result.URL_MD5 || null) : null);
      req.onerror = () => reject(req.error);
    });
  }

  async searchAnnotations(query) {
    var self = this;
    var q = query.toLowerCase();

    // Load pages for title matching
    var pagesStore = self._tx('pages', 'readonly');
    var pagesMap = await new Promise(function(resolve, reject) {
      var req = pagesStore.getAll();
      req.onsuccess = function() {
        var map = {};
        (req.result || []).forEach(function(p) { map[p.url] = p.title || ''; });
        resolve(map);
      };
      req.onerror = function() { reject(req.error); };
    });

    // Search annotations across user-visible text fields
    var store = self._tx('annotations', 'readonly');
    return new Promise(function(resolve, reject) {
      var req = store.getAll();
      req.onsuccess = function() {
        var results = (req.result || []).filter(function(a) {
          // 排除软删态：避免管理面板搜索结果显示已删除标注
          if (a.SYNC_STATUS === 'pending_deleted') return false;
          // CONTEXT: skip data URLs (base64 images) and coordinate JSON
          var contextMatch = false;
          if (a.CONTEXT) {
            var ctx = a.CONTEXT;
            if (ctx.indexOf('data:') !== 0 && ctx.indexOf('[{') !== 0 && ctx.indexOf('img:') !== 0) {
              contextMatch = ctx.toLowerCase().includes(q);
            }
          }
          return contextMatch ||
                 (a.COMMENT_TEXT && a.COMMENT_TEXT.toLowerCase().includes(q)) ||
                 (a.TAGS && a.TAGS.toLowerCase().includes(q)) ||
                 (a.DOMAIN && a.DOMAIN.toLowerCase().includes(q)) ||
                 (a.WEB_URI && pagesMap[a.WEB_URI] && pagesMap[a.WEB_URI].toLowerCase().includes(q));
        });
        resolve(results);
      };
      req.onerror = function() { reject(req.error); };
    });
  }

  async getAllTags() {
    if (!this.db.objectStoreNames.contains('tags')) return [];
    // 决策 4：按 uid 隔离读取（tags.userId index 在 dbVersion 10 建立）
    var identity = await this.getUserIdentity();
    var uid = identity && (identity.userId || identity.authorId);
    if (!uid) return [];
    const store = this._tx('tags', 'readonly');
    return new Promise(function (resolve, reject) {
      var tags = [];
      // 如果 tags store 还没 userId index（老库未升级路径），fallback 到 lastUsed 全表 + filter
      var idx = store.indexNames.contains('userId') ? store.index('userId') : null;
      var openReq = idx
        ? idx.openCursor(IDBKeyRange.only(String(uid)), 'prev')
        : store.index('lastUsed').openCursor(null, 'prev');
      openReq.onsuccess = function (e) {
        var cursor = e.target.result;
        if (cursor) {
          // fallback 路径需要按 USER_ID 过滤；index 路径下结果已精确
          if (!idx) {
            if (cursor.value.USER_ID === String(uid) || (!cursor.value.USER_ID && uid === 'local')) {
              tags.push(cursor.value);
            }
          } else {
            tags.push(cursor.value);
          }
          cursor.continue();
        } else {
          resolve(tags);
        }
      };
      openReq.onerror = function () { reject(openReq.error); };
    });
  }

  async searchByTag(tagName) {
    // 决策 4：search 也按 uid 隔离，通过 getAnnotations 思路不够（searchByTag 跨 URL），
    // 改用 userId index → 一次拿到本用户所有标注，再过滤 TAGS
    var identity = await this.getUserIdentity();
    var uid = identity && (identity.userId || identity.authorId);
    if (!uid) return [];
    var store = this._tx('annotations', 'readonly');
    return new Promise(function(resolve, reject) {
      var idx = store.indexNames.contains('userId') ? store.index('userId') : null;
      var req = idx ? idx.getAll(IDBKeyRange.only(String(uid))) : store.getAll();
      req.onsuccess = function() {
        var q = tagName.toLowerCase();
        var results = (req.result || []).filter(function(a) {
          if (!a.TAGS) return false;
          // idx 路径已按 uid 过滤；fallback 路径再校验一次
          if (!idx && a.USER_ID && a.USER_ID !== String(uid)) return false;
          var tags = a.TAGS.split(';');
          return tags.some(function(t) { return t.trim().toLowerCase() === q; });
        });
        resolve(results);
      };
      req.onerror = function() { reject(req.error); };
    });
  }

  async saveTag(name) {
    if (!this.db.objectStoreNames.contains('tags')) return null;
    // 决策 4：tag 写入也带 USER_ID（与读路径 getAllTags 的过滤对齐）
    var identity = await this.getUserIdentity();
    var uid = identity && (identity.userId || identity.authorId) || 'local';
    // tag 主键是 name（全局唯一），不同用户用同名 tag 时如何隔离？
    // tags store 的 keyPath='name' 决定了同名 tag 必然冲突。改造方向是改 keyPath，但 dbVersion
    // 升级改 keyPath 需删旧 store 重建，会丢用户已有 tags（小成本，可接受）。
    // 当前阶段：保留 keyPath=name，用 USER_ID 字段做软隔离；getAllTags 读路径按 USER_ID 过滤。
    // 不同用户创建同名 tag 会互相覆盖 USER_ID — 后续 P1 阶段把 keyPath 改为 [userId, name]。
    var store = this._tx('tags', 'readwrite');
    return new Promise(function (resolve, reject) {
      var getReq = store.get(name);
      getReq.onsuccess = function () {
        var record = getReq.result || { name: name };
        record.USER_ID = String(uid);
        record.lastUsed = new Date().toISOString();
        var putReq = store.put(record);
        putReq.onsuccess = function () { resolve(record); };
        putReq.onerror = function () { reject(putReq.error); };
      };
      getReq.onerror = function () { reject(getReq.error); };
    });
  }

  async exportAll() {
    const annotations = await new Promise((resolve, reject) => {
      const store = this._tx('annotations', 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    // 补全空的 AUTHOR_ID/AUTHOR_NAME → 当前用户身份
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';
    var uname = (identity && identity.authorName) || '';
    for (var i = 0; i < annotations.length; i++) {
      var a = annotations[i];
      if (!a.AUTHOR_ID) a.AUTHOR_ID = uid;
      if (!a.AUTHOR_NAME) a.AUTHOR_NAME = uname;
    }
    return annotations;
  }

  /**
   * 把指定 URL 下所有标注的 AUTHOR_ID / AUTHOR_NAME / USER_ID 改为当前用户，
   * 并标记为脏（待同步）。用于"全部转为我的标注"按钮。
   *
   * 业务语义：
   * - 导入他人备份 → 现在想把整页都"认领"为可编辑
   * - 旧版脏数据（AUTHOR_ID=null 或 legacy）→ 一键清理
   *
   * 写路径：DOMAIN + WEB_URI 索引扫描，cursor.update()。
   * 同步路径：调用方负责 requestSync('normal')（与 saveAnnotation 一致）。
   */
  async claimPageAnnotations(domain, webUri) {
    const identity = await this.getUserIdentity();
    const uid = identity && (identity.userId || identity.authorId);
    const authorName = identity && identity.authorName;
    if (!uid) throw new Error(chrome.i18n.getMessage('claimNotLoggedInReason'));
    const targetUid = String(uid);

    // 用 domain_webUri 复合索引读到本 URL 全部标注（不限 USER_ID，含 legacy 脏数据）
    const all = await new Promise((resolve, reject) => {
      const store = this._tx('annotations', 'readonly');
      const idx = store.index('domain_webUri');
      const req = idx.getAll(IDBKeyRange.only([domain, webUri]));
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });

    // 一个 readwrite 事务批量更新
    const tx = this.db.transaction('annotations', 'readwrite');
    const store = tx.objectStore('annotations');
    let changed = 0;
    const updateTime = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
    await new Promise((resolve, reject) => {
      let pending = all.length;
      if (pending === 0) { resolve(); return; }
      for (let i = 0; i < all.length; i++) {
        const ann = all[i];
        const needUpdate = String(ann.AUTHOR_ID) !== targetUid
          || ann.USER_ID !== targetUid
          || ann.AUTHOR_NAME !== authorName;
        if (!needUpdate) {
          if (--pending === 0) resolve();
          continue;
        }
        ann.AUTHOR_ID = targetUid;
        ann.AUTHOR_NAME = authorName;
        ann.USER_ID = targetUid;
        ann.SYNC_STATUS = 'pending';
        // DIRTY_BITS 全置位（与 saveAnnotation 一致：整条标注都视为变更，确保服务端覆盖）
        ann.DIRTY_BITS = (ann.DIRTY_BITS || 0) | 0xFF;
        ann.UPDATE_TIME = updateTime;
        const putReq = store.put(ann);
        putReq.onsuccess = () => {
          changed++;
          if (--pending === 0) resolve();
        };
        putReq.onerror = () => reject(putReq.error);
      }
    });

    return { changed, total: all.length };
  }

  // 本地标注条数（用于切换账号时判断本地是否已有数据）
  async countAnnotations() {
    return new Promise((resolve, reject) => {
      const store = this._tx('annotations', 'readonly');
      const req = store.count();
      req.onsuccess = () => resolve(req.result || 0);
      req.onerror = () => reject(req.error);
    });
  }

  // P0-6: 换号判定的"本地是否有数据"必须覆盖全部用户数据 store（对齐
  // _rewriteLocalOwnershipToUser 的 storeNames）。此前只数 annotations——
  // 账号 A 仅创建过文档/快照（无网页标注）时，登录账号 B 走"静默切换"分支，
  // A 的私有文档被改写归属并上传进 B 的云端（跨账号数据越权）。
  async hasAnyUserData() {
    const stores = ['annotations', 'pages', 'folders', 'documents', 'snapshots'];
    for (const s of stores) {
      if (!this.db || !this.db.objectStoreNames.contains(s)) continue;
      const n = await new Promise((resolve, reject) => {
        const req = this._tx(s, 'readonly').count();
        req.onsuccess = () => resolve(req.result || 0);
        req.onerror = () => reject(req.error);
      });
      if (n > 0) return true;
    }
    return false;
  }

  // 游客档登录前预检专用（2026-09-29）：「本地是否有值得保护 / 需要清空的用户数据」。
  // 与 hasAnyUserData 的唯一差异在 folders——initDB 会经 _ensureRootFolder 自动补建一条
  // 纯净默认目录（folderId='root'、顶层、未改名、无子目录）。它不是用户数据，却让
  // hasAnyUserData 恒为 true：游客什么都没做，登录时也永远弹「清空本地数据」确认框；
  // 更隐蔽的是预检本身就会触发 initDB → 补建 root（自证预言，场景13 实测复现）。
  // 判定：内容 store（annotations/pages/documents/snapshots）任一非空 → 有数据；
  //       folders 里存在任一条非纯净 root（子目录/非 root/已删除/改过名）→ 有数据。
  // hasAnyUserData 语义保持不变：账号切换 P0-6 拦截仍按「任何本地数据」判定，本方法
  // 不替换它（见 _finalizeAuth 不同账号分支的说明）。
  async hasAnyProtectableData() {
    const contentStores = ['annotations', 'pages', 'documents', 'snapshots'];
    for (const s of contentStores) {
      if (!this.db || !this.db.objectStoreNames.contains(s)) continue;
      const n = await new Promise((resolve, reject) => {
        const req = this._tx(s, 'readonly').count();
        req.onsuccess = () => resolve(req.result || 0);
        req.onerror = () => reject(req.error);
      });
      if (n > 0) return true;
    }
    if (!this.db || !this.db.objectStoreNames.contains('folders')) return false;
    const folders = await new Promise((resolve, reject) => {
      const req = this._tx('folders', 'readonly').getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    if (!folders.length) return false;
    let defaultName = '';
    try { defaultName = chrome.i18n.getMessage('defaultFolderName') || ''; } catch (e) { defaultName = ''; }
    // 纯净 root：顶层 + 未删除 + （未改名 或 它是 folders 里唯一的记录）。
    // 后一个条件是为了容忍 UI 语言切换后再比对不上默认目录名（否则会退回"永远弹框"的老毛病）；
    // stores 里只有一条 root 时本就没有任何可丢的东西。
    const isPristineRoot = (f) => !!f
      && f.folderId === 'root'
      && !f.parentFolderId
      && f.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED
      && (String(f.name || '') === defaultName || folders.length === 1);
    for (let i = 0; i < folders.length; i++) {
      if (!isPristineRoot(folders[i])) return true;
    }
    return false;
  }

  // 游客档登录自动认领（2026-11）：本地数据归属分类。只在 hasAnyProtectableData()=true
  // 且 owner=null 时调用（见 wpzl-has-local-data / _finalizeAuth），空库零成本。返回：
  //   isForeign   5 个核心 store 存在 USER_ID ∉ 自有集合的记录（阻断信号：人工确认才可清空）
  //   foreignAt   {store, uid} 首个外来属主样本（日志/调试用，不上 UI——不把他人 uid 泄漏给页面）
  //   claimable   各 store 记录数 + total（认领条数，供前端正向文案）
  // 自有集合谓词（含 legacy「K 谓词」）：''/缺失 / 'local'（v10 回填占位）/ baseline（游客身份）/
  //   targetUid（记录本就属于目标账号 → 认领是无害空转，legacy 同号重登场景）。
  //   纯数字 baseline 是 legacy 登录身份改写残留（旧版登录把 identity.authorId 改写成服务端 id），
  //   本地随机游客 ID 是 10 位 base62（全数字概率 ~1e-18 可忽略）——登录时点传了 targetUid 可精确
  //   区分同号（认领回原账号）/异号（必须拦截）；预检时点（未登录，无 targetUid）一律保守判外来，
  //   否则任意下一个登录者（含他人）都会静默认领这批数据。
  // imageData/tags 不参与 isForeign（restoreBackup 对二者原样导入保留原属主，纳入会误拦合法的
  // 「游客导入他人备份」场景）；folders 参与判定但不计入 claimable 展示。
  // 抛错由调用方 fail-closed（按外来处理走人工确认）；db 未就绪直接抛（同 fail-closed）。
  async classifyLocalOwnership(baselineAuthorId, targetUid) {
    // 守卫口径同 hasAnyProtectableData：this.db 即 IDBDatabase（有 objectStoreNames），无 .db 二级属性
    if (!this.db || !this.db.objectStoreNames) throw new Error('db not ready');
    var self = this;
    var baseline = baselineAuthorId != null ? String(baselineAuthorId) : '';
    var target = (targetUid != null && targetUid !== '') ? String(targetUid) : null;
    var isOwnUid = function (key) {
      if (!key) return true;                                  // ''/缺失 → 可认领（认领路径无条件覆写）
      if (key === 'local') return true;                       // v10 imageData 回填占位
      if (target && key === target) return true;              // 已属目标账号 → 认领空转，无害
      if (baseline && key === baseline) {
        if (/^\d+$/.test(key)) return false;                  // legacy 纯数字身份：异号登录 = 他人数据
        return true;                                          // 常规本地随机游客身份（base62）
      }
      return false;
    };
    // 阻断判定集合 = 认领改写的 5 个 store（语义自洽：凡是要被改写归属的记录里出现第三方属主，
    // 才需要人来决定）；tags/imageData 只在认领时无条件改写，不阻断。
    var FOREIGN_STORES = ['annotations', 'pages', 'folders', 'documents', 'snapshots'];
    var COUNT_STORES = ['annotations', 'pages', 'documents', 'snapshots', 'tags', 'imageData'];
    var scanStores = FOREIGN_STORES.concat(['tags', 'imageData']);
    var foreignAt = null;
    for (var i = 0; i < scanStores.length; i++) {
      var name = scanStores[i];
      if (!this.db.objectStoreNames.contains(name)) continue;
      var store = self._tx(name, 'readonly');
      var hasIdx = store.indexNames.contains('userId');
      // 属主去重：prevunique 每个 USER_ID 值只回一次——代价取决于不同属主个数而非记录数
      //（5000 条同属主库只回调 1 次）；命中首个外来即整体早退（阻断决策已定）。
      var ownerKeys = await new Promise(function (resolve) {
        var out = [];
        var req = hasIdx ? store.index('userId').openCursor(null, 'prevunique') : store.openCursor();
        req.onsuccess = function (e) {
          var c = e.target.result;
          if (!c) { resolve(out); return; }
          out.push(hasIdx
            ? (c.key == null ? '' : String(c.key))
            : (c.value && c.value.USER_ID != null ? String(c.value.USER_ID) : ''));
          c.continue();   // 同步调用保事务活跃（同 _rewriteLocalOwnershipToUser 内注释）
        };
        req.onerror = function () { resolve(out); };
      });
      for (var k = 0; k < ownerKeys.length; k++) {
        if (!isOwnUid(ownerKeys[k]) && FOREIGN_STORES.indexOf(name) !== -1) {
          foreignAt = { store: name, uid: ownerKeys[k] };
          break;
        }
      }
      if (foreignAt) break;
    }
    // 展示总数：store.count() 求和——IndexedDB 不索引 undefined，索引游标看不到 USER_ID 缺失的
    // 记录（老库未回填），用索引计数做展示数字会偏小；此处口径与 hasAnyProtectableData 一致。
    // 外来场景不算数（阻断决策已定，前端走 askForeign 不展示认领条数）。
    var claimable = null;
    var total = 0;
    if (!foreignAt) {
      claimable = {};
      for (var j = 0; j < COUNT_STORES.length; j++) {
        var cname = COUNT_STORES[j];
        if (!this.db.objectStoreNames.contains(cname)) continue;
        var n = await new Promise(function (resolve) {
          var req = self._tx(cname, 'readonly').count();
          req.onsuccess = function () { resolve(req.result || 0); };
          req.onerror = function () { resolve(0); };
        });
        claimable[cname] = n;
        total += n;
      }
    }
    return { isForeign: !!foreignAt, foreignAt: foreignAt, claimable: claimable, total: total };
  }

  // 清空本地全部用户数据（用户在设置页主动触发，用于切换账号前清理；device_id 保留）
  // 必须覆盖所有承载用户数据的 store；新增 store 时务必在此补清，否则切账号后会残留上一个用户的数据
  async clearAllLocalData() {
    await this._clearStore('annotations');
    await this._clearStore('pages');
    await this._clearStore('settings');
    if (this.db.objectStoreNames.contains('imageData')) {
      await this._clearStore('imageData');
    }
    if (this.db.objectStoreNames.contains('tags')) {
      await this._clearStore('tags');
    }
    if (this.db.objectStoreNames.contains('folders')) {
      await this._clearStore('folders');
    }
    if (this.db.objectStoreNames.contains('syncMeta')) {
      await this._clearStore('syncMeta');
    }
    if (this.db.objectStoreNames.contains('localThumbnails')) {
      await this._clearStore('localThumbnails');
    }
    if (this.db.objectStoreNames.contains('documents')) {
      await this._clearStore('documents');
    }
    if (this.db.objectStoreNames.contains('snapshots')) {
      await this._clearStore('snapshots');
    }
    // P1-8 分仓 body store（V25/dbVersion 25 新增）——2026-10-06 补漏：此前漏清导致
    // 切号/登出/设置页清空后 docBodies/snapBodies 残留上一账号正文（磁盘膨胀 + docId
    // 碰撞时跨账号 body 串扰）。三条调用路径：登出切号 / 切号预清 / 设置页清空。
    if (this.db.objectStoreNames.contains('docBodies')) {
      await this._clearStore('docBodies');
    }
    if (this.db.objectStoreNames.contains('snapBodies')) {
      await this._clearStore('snapBodies');
    }
  }

  async getSetting(key) {
    const store = this._tx('settings', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async saveSetting(data) {
    const store = this._tx('settings', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.put(data);
      req.onsuccess = () => resolve(data);
      req.onerror = () => reject(req.error);
    });
  }

  // 生成随机作者标识和名字
  _generateAuthorIdentity() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let authorId = '';
    const arr = new Uint8Array(10);
    crypto.getRandomValues(arr);
    for (let i = 0; i < 10; i++) authorId += chars[arr[i] % chars.length];
    const authorName = chrome.i18n.getMessage('defaultAuthorName') + (1000 + Math.floor(Math.random() * 9000));
    // USER_ID 在未登录时与 AUTHOR_ID 同值；登录后被批量改写为服务端 user.id
    return { key: 'userIdentity', authorId, authorName, userId: authorId };
  }

  async getUserIdentity() {
    let identity = await this.getSetting('userIdentity');
    if (!identity || !identity.authorId) {
      identity = this._generateAuthorIdentity();
      await this.saveSetting(identity);
    }
    // 补充 loginId（旧版 identity 只存了 authorId/userId/authorName，不含 loginId）
    if (identity && !identity.loginId) {
      try {
        var owner = await _getLocalDataOwner();
        if (owner && owner.loginId) {
          identity.loginId = owner.loginId;
          await this.saveSetting(identity);
        }
      } catch (e) { /* ignore */ }
    }
    return identity;
  }

  async updateAuthorName(authorId, newName) {
    // 更新 settings 中的身份
    const identity = await this.getSetting('userIdentity');
    if (identity && identity.authorId === authorId) {
      identity.authorName = newName;
      await this.saveSetting(identity);
    }
    // 批量更新所有匹配的标注
    const store = this._tx('annotations', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.openCursor();
      let count = 0;
      req.onsuccess = (e) => {
        const cursor = e.target.result;
        if (cursor) {
          const record = cursor.value;
          if (record.AUTHOR_ID === authorId) {
            record.AUTHOR_NAME = newName;
            cursor.update(record);
            count++;
          }
          cursor.continue();
        } else {
          resolve({ updated: count });
        }
      };
      req.onerror = () => reject(req.error);
    });
  }

  async backupAll() {
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';
    var uname = (identity && identity.authorName) || '';

    const annotations = await new Promise((resolve, reject) => {
      const store = this._tx('annotations', 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    // 补全空的 AUTHOR_ID/AUTHOR_NAME → 当前用户身份
    for (var i = 0; i < annotations.length; i++) {
      var a = annotations[i];
      if (!a.AUTHOR_ID) a.AUTHOR_ID = uid;
      if (!a.AUTHOR_NAME) a.AUTHOR_NAME = uname;
    }

    const pages = await new Promise((resolve, reject) => {
      const store = this._tx('pages', 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    const imageData = await new Promise((resolve, reject) => {
      if (!this.db.objectStoreNames.contains('imageData')) { resolve([]); return; }
      const store = this._tx('imageData', 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    const tags = await new Promise((resolve, reject) => {
      if (!this.db.objectStoreNames.contains('tags')) { resolve([]); return; }
      const store = this._tx('tags', 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    const folders = await new Promise((resolve, reject) => {
      if (!this.db.objectStoreNames.contains('folders')) { resolve([]); return; }
      const store = this._tx('folders', 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    const localThumbnails = await new Promise((resolve, reject) => {
      if (!this.db.objectStoreNames.contains('localThumbnails')) { resolve([]); return; }
      const store = this._tx('localThumbnails', 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    const documents = await new Promise((resolve, reject) => {
      if (!this.db.objectStoreNames.contains('documents')) { resolve([]); return; }
      const store = this._tx('documents', 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    const snapshots = await new Promise((resolve, reject) => {
      if (!this.db.objectStoreNames.contains('snapshots')) { resolve([]); return; }
      const store = this._tx('snapshots', 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    // P1-8（dbVersion 25）：body 分仓后单独导出 body store（备份格式 v7；v6 老文件 documents/
    // snapshots 记录内联 bodyHtml，restoreBackup 兼容拆分）。body 是大字段，逐 store 独立数组
    // 与流式 backupChunk 路径（store 列表加 docBodies/snapBodies）对齐。
    const docBodies = await new Promise((resolve, reject) => {
      if (!this.db.objectStoreNames.contains('docBodies')) { resolve([]); return; }
      const store = this._tx('docBodies', 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    const snapBodies = await new Promise((resolve, reject) => {
      if (!this.db.objectStoreNames.contains('snapBodies')) { resolve([]); return; }
      const store = this._tx('snapBodies', 'readonly');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    return {
      _meta: {
        version: 7,
        exportDate: new Date().toISOString(),
        stores: { annotations: annotations.length, pages: pages.length, imageData: imageData.length, tags: tags.length, folders: folders.length, documents: documents.length, snapshots: snapshots.length, localThumbnails: localThumbnails.length, docBodies: docBodies.length, snapBodies: snapBodies.length }
      },
      annotations: annotations,
      pages: pages,
      imageData: imageData,
      tags: tags,
      folders: folders,
      documents: documents,
      snapshots: snapshots,
      localThumbnails: localThumbnails,
      docBodies: docBodies,
      snapBodies: snapBodies
    };
  }

  async _clearStore(storeName) {
    return new Promise((resolve, reject) => {
      const store = this._tx(storeName, 'readwrite');
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async restoreBackup(data) {
    const strategy = data.strategy || 'skip';
    const result = {
      inserted: { annotations: 0, pages: 0, settings: 0, imageData: 0, tags: 0, folders: 0, documents: 0, snapshots: 0, localThumbnails: 0, docBodies: 0, snapBodies: 0 },
      skipped: { annotations: 0, pages: 0, settings: 0, imageData: 0, tags: 0, folders: 0, documents: 0, snapshots: 0, localThumbnails: 0, docBodies: 0, snapBodies: 0 },
      skippedForeignSnapshots: 0
    };

    // overwrite 策略：put 覆盖同 key 已有记录，不删除无关数据
    // skip 策略：add 跳过同 key 已有记录
    // 两种策略都不清空 store（导入数据应增量合并，不破坏已有数据）

    // 先 folders → pages → annotations，保证 page.FOLDER_ID 能找到 folder，annotation.WEB_URI 能找到 page
    // 提前获取 currentUserId，避免在 IDB 事务内 await 导致事务自动提交超时
    var preflightUserId = '';
    try { preflightUserId = await _getCurrentUserIdForImport(); } catch (e) { /* ignore */ }
    // G-3 跨账号快照合规门（2026-10-06 定案：完全跳过）：网页快照（snapshots+snapBodies）含
    // 第三方页面内容，跨账号复制+上云会让服务端成为再分发方——对齐「快照分享已暂停」合规位，
    // 仅用户自创资产（标注/文档）可跨账号复制。按备份粒度判定一次：导出端 USER_ID 均匀回填
    //（manager 8184-8188），取首个非空比对当前属主；游客备份（本地 hash）同样命中——保守侧，
    // 合规优先。同账号导入自己的备份不受影响。
    var foreignSnapshotBackup = false;
    if (preflightUserId && Array.isArray(data.snapshots)) {
      var _fsOwner = null;
      for (var _fsI = 0; _fsI < data.snapshots.length; _fsI++) {
        if (data.snapshots[_fsI] && data.snapshots[_fsI].USER_ID) { _fsOwner = data.snapshots[_fsI].USER_ID; break; }
      }
      foreignSnapshotBackup = !!(_fsOwner && String(_fsOwner) !== String(preflightUserId));
    }
    if (foreignSnapshotBackup) {
      console.info('[import] foreign backup detected — snapshots/snapBodies will be skipped (compliance gate)');
    }
    // 跨用户导入时被重新生成的 MARK_INFO_ID 映射（旧 id → 新 id）：
    // localThumbnails 按 annId 关联标注，导入阶段用该映射同步重写，否则缩略图指向不存在的旧 id
    var thumbIdRemap = {};
    // 导入中置位/携带 THUMBNAIL_PENDING 的标注 id（导入完成后合并进 thumb_pending_ids 清单）
    var importedThumbPendingIds = [];
    // 缩略图分档统计（诊断用：这次导入有多少条截图可补传 / 有多少条够不到）
    var importedThumbBuckets = {};
    const storeNames = ['settings', 'folders', 'pages', 'annotations', 'imageData', 'tags', 'localThumbnails', 'documents', 'snapshots', 'docBodies', 'snapBodies'];
    for (const storeName of storeNames) {
      if (data[storeName] && data[storeName].length > 0) {
        // G-3：外来备份的快照元数据 + body 一律跳过（不写 IDB，防第三方内容落仓/上云）
        if (foreignSnapshotBackup && (storeName === 'snapshots' || storeName === 'snapBodies')) {
          result.skippedForeignSnapshots += data[storeName].length;
          continue;
        }
        const store = this._tx(storeName, 'readwrite');
        // 本批含 data: URL 缩略图时需同步写 localThumbnails（_applyImportedThumb 的 seed 档）。
        // 必须在 map **之前**开事务：map 回调是同步的，其中所有 put 在同一任务内派发，
        // 事务不会中途自动提交；若改到回调里 await 再开，annotations 事务会先提交而报错。
        var _ltStore = null;
        if (storeName === 'annotations' && this.db.objectStoreNames.contains('localThumbnails')) {
          try { _ltStore = this._tx('localThumbnails', 'readwrite'); } catch (e) { /* ignore */ }
        }
        // P1-8：v6 老备份 documents/snapshots 记录内联 bodyHtml → 导入时拆进 body store
        //（v7 备份 body 已是独立数组，记录无该字段，此拆分为 no-op）。同 _ltStore 模式：
        // map 回调同步派发，事务必须在 map 之前开。
        var _bodyStore = null;
        if ((storeName === 'documents' && this.db.objectStoreNames.contains('docBodies'))
            || (storeName === 'snapshots' && this.db.objectStoreNames.contains('snapBodies'))) {
          try { _bodyStore = this._tx((storeName === 'documents') ? 'docBodies' : 'snapBodies', 'readwrite'); } catch (e) { /* ignore */ }
        }
        const promises = data[storeName].map(record => new Promise((resolve) => {
          // 保护用户身份标识不被备份覆盖
          if (storeName === 'settings' && record.key === 'userIdentity') {
            result.skipped[storeName]++;
            resolve();
            return;
          }
          // annotations/pages/folders 导入时强制 USER_ID = 当前用户（导入即认领）
          // AUTHOR_ID/AUTHOR_NAME 保留原始（记录谁创建的）
          if (storeName === 'annotations' || storeName === 'pages' || storeName === 'folders' || storeName === 'documents' || storeName === 'snapshots') {
            try {
              var currentUserId = preflightUserId;
              if (currentUserId) {
                // 跨用户导入 → annotations 生成全新 MARK_INFO_ID 去重（并记录映射供 localThumbnails 重写）
                if (storeName === 'annotations' && record.USER_ID && String(record.USER_ID) !== String(currentUserId)) {
                  var newMarkId = _generateNewMarkInfoId(record.MARK_INFO_ID);
                  thumbIdRemap[record.MARK_INFO_ID] = newMarkId;
                  record.MARK_INFO_ID = newMarkId;
                }
                // 强制覆盖：导入到谁名下这些数据就属于谁
                record.USER_ID = String(currentUserId);
              } else if (!record.USER_ID) {
                // 无当前用户（脱机导入）→ 保留原 USER_ID 或留空
                record.USER_ID = record.USER_ID || '';
              }
              // 属主变更 → 复位记录级同步状态（含文件里可能带来的 SYNC_EXHAUSTED/SYNC_LAST_ERROR）。
              // 必须在 try 内、写入前调用：函数抛错由外层 catch 吞掉，不影响导入主流程。
              _resetRecordSyncState(record);
              // V70 导入豁免（spec §6.1）：导入记录置位 IS_IMPORTED——首次创建同步豁免每日限额
              //（受服务端共享 daily_import_limit 约束）。仅标注/文档/快照三类有每日限额语义。
              if (storeName === 'annotations' || storeName === 'documents' || storeName === 'snapshots') {
                record.IS_IMPORTED = 1;
              }
              // THUMBNAIL（pageRect 截图）拷贝认领：外来命名空间 objectKey 本机永远签名 403。
              // 分档处理见 _applyImportedThumb（flag/seed/unknown/keep/clear）。
              if (storeName === 'annotations' && currentUserId && record.THUMBNAIL) {
                try {
                  var _tb = _applyImportedThumb(record, currentUserId, _ltStore);
                  importedThumbBuckets[_tb] = (importedThumbBuckets[_tb] || 0) + 1;
                } catch (e) { /* ignore */ }
              }
              // 置位/携带 PENDING 的标注 id 记入清单补记集合（含备份里本就 PENDING 未传完的——
              // thumb_pending_ids 清单不进备份，恢复后需重新可见）
              if (storeName === 'annotations' && currentUserId && record.THUMBNAIL_PENDING && record.MARK_INFO_ID) {
                importedThumbPendingIds.push(record.MARK_INFO_ID);
              }
              // 文档 tags 归一化：旧导出无 tags 字段时补 ''（与 putDocument 新记录默认一致）
              if (storeName === 'documents' && record.tags == null) record.tags = '';
              // P1-8：v6 老备份内联 bodyHtml → 拆进 body store 后从记录剥除（键不变，docId/snapId 对齐）
              if ((storeName === 'documents' || storeName === 'snapshots') && record.bodyHtml !== undefined) {
                if (record.bodyHtml && _bodyStore) {
                  var _bodyRec = { bodyHtml: record.bodyHtml };
                  _bodyRec[(storeName === 'documents') ? 'docId' : 'snapId'] = (storeName === 'documents') ? record.docId : record.snapId;
                  if (storeName === 'documents') _bodyRec.bodyText = _wpzlHtmlToText(record.bodyHtml);
                  _bodyStore.put(_bodyRec);
                }
                delete record.bodyHtml;
              }
            } catch (e) { /* ignore */ }
          }
          // imageData 原样导入（不认领 USER_ID），但外来命名空间的 cloudUrl（u/他人/...）对本机
          // 永远无法签名解析（服务端按属主校验，403），且会被 P1-17 容量治理当"已上云"记录、
          // 按最老 SYNCED_AT 优先清掉本地 data → 图必然丢。导入即拷贝认领：清外来 key；有本地
          // data 的置 pending，交 _uploadPendingImages 把二进制补传到**当前账号**命名空间
          // （u/{uid}/...，与新生成的截图同一条上传管道：权限门禁/配额/积压上限/重试全生效，
          // 成功后服务端回填新 cloudUrl + 建本账号 image_assets 行）；无 data 的死记录（导出前
          // 已被治理清掉）只清 key。自己的备份（u/自己/...）原样保留，不受影响。
          if (storeName === 'imageData' && preflightUserId && record.cloudUrl &&
              String(record.cloudUrl).indexOf('u/' + preflightUserId + '/') !== 0) {
            record.cloudUrl = null;
            // 属主变更 → 复位记录级失败状态（同 _resetRecordSyncState 说明；imageData 的
            // DIRTY_BITS 约定为 0，故不直接复用该 helper）。两套字段并行存在：大写是元数据
            // 上传侧（_markImageAssetUploadResult），小写是 R2 上传侧，都要清。
            record.SYNC_LAST_ERROR = null;
            record.SYNC_LAST_ATTEMPT_AT = null;
            record.SYNC_EXHAUSTED = false;
            record.SYNC_RETRY_COUNT = 0;
            record.lastError = null;
            record.exhausted = false;
            record.retryCount = 0;
            if (record.data) {
              record.SYNC_STATUS = 'pending';
              record.DIRTY_BITS = 0;
              record.firstPendingAt = new Date().toISOString();
            }
          }
          // 缩略图按 annId 跟随重生成后的标注 id（storeNames 顺序保证 annotations 先于 localThumbnails 处理）
          if (storeName === 'localThumbnails' && record.annId && thumbIdRemap[record.annId]) {
            record.annId = thumbIdRemap[record.annId];
          }
          // skip 策略下若 key 已存在会触发 onerror，已计入 skipped
          const writeMethod = (strategy === 'skip') ? 'add' : 'put';
          const req = store[writeMethod](record);
          req.onsuccess = () => { result.inserted[storeName]++; resolve(); };
          req.onerror = (e) => { e.preventDefault(); result.skipped[storeName]++; resolve(); };
        }));
        await Promise.all(promises);

        // Tags 导入去重（独立循环，避免 await 在非 async 回调中）
        // 注意：必须开新事务——上方事务在 await Promise.all 后已自动提交，
        // 复用旧 store 会抛 TransactionInactiveError（曾导致带 tags 的备份导入必失败）
        if (storeName === 'tags') {
          for (var ti = 0; ti < data[storeName].length; ti++) {
            var tagRecord = data[storeName][ti];
            const tagTx = this.db.transaction('tags', 'readwrite');
            const tagStore = tagTx.objectStore('tags');
            var existingTag = await new Promise(function (r) {
              var gr = tagStore.get(tagRecord.name);
              gr.onsuccess = function () { r(gr.result); };
              gr.onerror = function () { r(null); };
            });
            if (existingTag) {
              if (tagRecord.lastUsed && (!existingTag.lastUsed || tagRecord.lastUsed > existingTag.lastUsed)) {
                existingTag.lastUsed = tagRecord.lastUsed;
              }
              if (tagRecord.USER_ID && !existingTag.USER_ID) {
                existingTag.USER_ID = tagRecord.USER_ID;
              }
              await new Promise(function (r) {
                var pr = tagStore.put(existingTag);
                pr.onsuccess = function () { r(); };
                pr.onerror = function () { r(); };
              });
            }
          }
        }
      }
    }

    // 找不到 folder 的 page 落默认外层
    try {
      const validFolderIds = new Set((await this.getAllFolders()).map(f => f.folderId));
      const allPages = await this.getAllPages();
      const pageStore = this._tx('pages', 'readwrite');
      for (const p of allPages) {
        if (p.FOLDER_ID && !validFolderIds.has(p.FOLDER_ID)) {
          p.FOLDER_ID = null;
          await new Promise((resolve) => {
            const r = pageStore.put(p);
            r.onsuccess = () => resolve();
            r.onerror = () => resolve();
          });
        }
      }
    } catch (e) { /* ignore */ }

    // 找不到 folder 的 document 落默认外层（document 的 folderId 是 camelCase，独立于 pages 的 FOLDER_ID）
    try {
      if (this.db.objectStoreNames.contains('documents') && data.documents && data.documents.length > 0) {
        const validFolderIds = new Set((await this.getAllFolders()).map(f => f.folderId));
        const allDocs = await this.getAllDocuments();
        const docStore = this._tx('documents', 'readwrite');
        for (const d of allDocs) {
          if (d.folderId && !validFolderIds.has(d.folderId)) {
            d.folderId = null;
            await new Promise((resolve) => {
              const r = docStore.put(d);
              r.onsuccess = () => resolve();
              r.onerror = () => resolve();
            });
          }
        }
      }
    } catch (e) { /* ignore */ }

    // 找不到 folder 的 snapshot 落默认外层（snapshot 的 folderId 是 camelCase，与 document 同）
    try {
      if (this.db.objectStoreNames.contains('snapshots') && data.snapshots && data.snapshots.length > 0) {
        const validFolderIds = new Set((await this.getAllFolders()).map(f => f.folderId));
        const allSnaps = await this.getAllSnapshots();
        const snapStore = this._tx('snapshots', 'readwrite');
        for (const s of allSnaps) {
          if (s.folderId && !validFolderIds.has(s.folderId)) {
            s.folderId = null;
            await new Promise((resolve) => {
              const r = snapStore.put(s);
              r.onsuccess = () => resolve();
              r.onerror = () => resolve();
            });
          }
        }
      }
    } catch (e) { /* ignore */ }

    // Auto-create missing page records for imported annotations
    if (data.annotations && data.annotations.length > 0) {
      await this._ensurePagesForAnnotations(data.annotations);
    }

    // 导入完成：把置位 PENDING 的标注 id 合并进 thumb_pending_ids 有界清单——清单（syncMeta）
    // 不在备份文件内，必须显式补记，否则 _flushPendingThumbnails 取不到导入的待传缩略图。
    try { await _wpzlMergeThumbPendingIds(importedThumbPendingIds); } catch (e) { /* ignore */ }

    // 缩略图分档统计（诊断：多少条截图可补传 / 多少条够不到）
    var _bucketKeys = Object.keys(importedThumbBuckets);
    if (_bucketKeys.length > 0) {
      result.thumbBuckets = importedThumbBuckets;
      console.log('[import] thumbnail buckets: ' + JSON.stringify(importedThumbBuckets));
    }

    return result;
  }

  // P1-32: 分块导出——getAllKeys（key-only 读，不载记录）切片后 getByKeys 批取，
  // 供 manager 流式 NDJSON 导出（替代 backupAll 整库一次性过消息通道）。
  // P0-C 导出会话键表缓存：传 session 时同一 store 只做一次 getAllKeys，后续分块从缓存切片。
  // 此前 offset 步进每块全量 getAllKeys 一次——1M 标注 5001 块 = O(n²/chunkSize) 全扫，
  // 是导出侧唯一的二次方热点。缓存生命周期 = 一个导出会话（session 变化即弃）；
  // restoreChunk/restoreBackup/clearAllData 写路径顺带清空（防跨会话陈旧）。导出期间新增
  // 记录可能不入本次导出（与"边导出边标注"的既有语义偏差可接受，total 取缓存口径一致）。
  async getStoreChunk(storeName, offset, limit, session) {
    if (!this.db.objectStoreNames.contains(storeName)) return { records: [], total: 0 };
    let keys;
    if (session) {
      if (!this._exportKeyCache || this._exportKeyCache.session !== session) {
        this._exportKeyCache = { session: session, keys: {} };
      }
      if (!this._exportKeyCache.keys[storeName]) {
        this._exportKeyCache.keys[storeName] = await this._getAllKeysOfStore(storeName);
      }
      keys = this._exportKeyCache.keys[storeName];
    } else {
      keys = await this._getAllKeysOfStore(storeName);
    }
    const slice = keys.slice(offset, offset + limit);
    const records = slice.length > 0 ? await this.getByKeys(storeName, slice) : [];
    return { records: records, total: keys.length };
  }

  _getAllKeysOfStore(storeName) {
    const store = this._tx(storeName, 'readonly');
    return new Promise((resolve, reject) => {
      const r = store.getAllKeys();
      r.onsuccess = () => resolve(r.result || []);
      r.onerror = () => reject(r.error);
    });
  }

  // P0-C：导出键表缓存失效（写路径调用；无缓存时为空操作）
  _invalidateExportKeyCache() {
    this._exportKeyCache = null;
  }

  // P1-32: 流式导入（NDJSON v8）——按 store 分块走 restoreBackup 同款语义（导入即认领/
  // 跨用户 MARK_INFO_ID 重生成/SYNC pending+0xFF/tags 去重/缩略图 remap），finalize 收尾做
  // folder 修正与缺页补建。旧 restoreBackup op 原样保留（legacy .json.gz 整文件路径仍走它）。
  // 跨块状态：thumbIdRemap 经响应回传、调用方逐块回显（SW 中途被杀也不丢映射）；
  // urlMap 在 SW 会话内累积（仅唯一 URL 数量级，内存有界）。
  async restoreBackupChunk(data) {
    const strategy = data.strategy || 'skip';
    if (!this._importStream || this._importStream.strategy !== strategy) {
      var _preflightUid = data.preflightUserId;
      if (!_preflightUid) {
        try { _preflightUid = await _getCurrentUserIdForImport(); } catch (e) { _preflightUid = ''; }
      }
      this._importStream = { strategy: strategy, preflightUserId: _preflightUid, thumbIdRemap: {}, urlMap: {}, thumbPendingIds: [], foreignSnap: null };
    }
    if (data.thumbIdRemap) {
      Object.assign(this._importStream.thumbIdRemap, data.thumbIdRemap);
    }
    const st = this._importStream;
    const storeName = data.store;
    const result = { inserted: 0, skipped: 0, thumbIdRemap: st.thumbIdRemap, preflightUserId: st.preflightUserId, skippedForeignSnapshots: 0 };
    const records = data.records || [];

    // G-3 跨账号快照合规门（同 restoreBackup 同名注释）：snapshots 首块判定一次备份属主
    //（NDJSON 导出顺序 snapshots 先于 snapBodies）；命中外来 → 两店全部跳过。
    if (st.foreignSnap === null && storeName === 'snapshots' && records.length > 0) {
      var _fscRec = null;
      for (var _fscI = 0; _fscI < records.length; _fscI++) {
        if (records[_fscI] && records[_fscI].USER_ID) { _fscRec = records[_fscI]; break; }
      }
      if (_fscRec) {
        st.foreignSnap = !!(_fscRec.USER_ID && st.preflightUserId
          && String(_fscRec.USER_ID) !== String(st.preflightUserId));
        if (st.foreignSnap) console.info('[import] foreign backup detected — snapshots/snapBodies will be skipped (compliance gate)');
      }
    }
    if (st.foreignSnap === true && (storeName === 'snapshots' || storeName === 'snapBodies')) {
      result.skippedForeignSnapshots = records.length;
    }
    // 注意：不提前 return——finalize（folder 修正/缺页补建）搭载在最后一块上，全量导出的
    // 最后一块正是 snapBodies，提前返回会跳过收尾。
    var _skipForeignStore = result.skippedForeignSnapshots > 0;

    if (!_skipForeignStore && records.length > 0 && this.db.objectStoreNames.contains(storeName)) {
      const store = this._tx(storeName, 'readwrite');
      // 同 restoreBackup：seed 档需同步写 localThumbnails，事务必须在 map 之前开
      //（map 回调同步派发全部 put，中途 await 会让事务自动提交）。
      var _ltStore2 = null;
      if (storeName === 'annotations' && this.db.objectStoreNames.contains('localThumbnails')) {
        try { _ltStore2 = this._tx('localThumbnails', 'readwrite'); } catch (e) { /* ignore */ }
      }
      // P1-8：老格式记录内联 bodyHtml → 拆进 body store（同 restoreBackup；v8 NDJSON 正常已分 store，此处 no-op 兜底）
      var _bodyStore2 = null;
      if ((storeName === 'documents' && this.db.objectStoreNames.contains('docBodies'))
          || (storeName === 'snapshots' && this.db.objectStoreNames.contains('snapBodies'))) {
        try { _bodyStore2 = this._tx((storeName === 'documents') ? 'docBodies' : 'snapBodies', 'readwrite'); } catch (e) { /* ignore */ }
      }
      const promises = records.map(record => new Promise((resolve) => {
        // 保护用户身份标识不被备份覆盖
        if (storeName === 'settings' && record.key === 'userIdentity') {
          result.skipped++;
          resolve();
          return;
        }
        // 与 restoreBackup 逐条同款：导入即认领 + 跨用户 ID 重生成 + SYNC pending
        if (storeName === 'annotations' || storeName === 'pages' || storeName === 'folders' || storeName === 'documents' || storeName === 'snapshots') {
          try {
            var currentUserId = st.preflightUserId;
            if (currentUserId) {
              if (storeName === 'annotations' && record.USER_ID && String(record.USER_ID) !== String(currentUserId)) {
                var newMarkId = _generateNewMarkInfoId(record.MARK_INFO_ID);
                st.thumbIdRemap[record.MARK_INFO_ID] = newMarkId;
                record.MARK_INFO_ID = newMarkId;
              }
              record.USER_ID = String(currentUserId);
            } else if (!record.USER_ID) {
              record.USER_ID = record.USER_ID || '';
            }
            // 属主变更 → 复位记录级同步状态（同 restoreBackup 内同名调用说明）
            _resetRecordSyncState(record);
            // V70 导入豁免（spec §6.1）：导入记录置位 IS_IMPORTED——首次创建同步豁免每日限额
            //（受服务端共享 daily_import_limit 约束）。仅标注/文档/快照三类有每日限额语义。
            if (storeName === 'annotations' || storeName === 'documents' || storeName === 'snapshots') {
              record.IS_IMPORTED = 1;
            }
            // THUMBNAIL 拷贝认领——同 restoreBackup 内同名分支说明（分档：flag/seed/unknown/keep/clear）
            if (storeName === 'annotations' && currentUserId && record.THUMBNAIL) {
              try {
                var _tb2 = _applyImportedThumb(record, currentUserId, _ltStore2);
                st.thumbBuckets = st.thumbBuckets || {};
                st.thumbBuckets[_tb2] = (st.thumbBuckets[_tb2] || 0) + 1;
              } catch (e) { /* ignore */ }
            }
            // 置位/携带 PENDING 的标注 id 记入跨块集合（finalize 时合并进 thumb_pending_ids 清单）
            if (storeName === 'annotations' && currentUserId && record.THUMBNAIL_PENDING && record.MARK_INFO_ID) {
              st.thumbPendingIds.push(record.MARK_INFO_ID);
            }
            if (storeName === 'documents' && record.tags == null) record.tags = '';
            // P1-8：老备份内联 bodyHtml → 拆 body store 后剥除（同 restoreBackup 同名分支）
            if ((storeName === 'documents' || storeName === 'snapshots') && record.bodyHtml !== undefined) {
              if (record.bodyHtml && _bodyStore2) {
                var _bodyRec2 = { bodyHtml: record.bodyHtml };
                _bodyRec2[(storeName === 'documents') ? 'docId' : 'snapId'] = (storeName === 'documents') ? record.docId : record.snapId;
                if (storeName === 'documents') _bodyRec2.bodyText = _wpzlHtmlToText(record.bodyHtml);
                _bodyStore2.put(_bodyRec2);
              }
              delete record.bodyHtml;
            }
          } catch (e) { /* ignore */ }
        }
        // imageData 原样导入（不认领 USER_ID），外来命名空间 cloudUrl 认领拷贝——同 restoreBackup
        // 内同名分支的完整说明：清外来 key + 有 data 置 pending 交 FIFO 补传到当前账号命名空间。
        if (storeName === 'imageData' && st.preflightUserId && record.cloudUrl &&
            String(record.cloudUrl).indexOf('u/' + st.preflightUserId + '/') !== 0) {
          record.cloudUrl = null;
          // 属主变更 → 复位记录级失败状态（同 restoreBackup 内同名分支说明）
          record.SYNC_LAST_ERROR = null;
          record.SYNC_LAST_ATTEMPT_AT = null;
          record.SYNC_EXHAUSTED = false;
          record.SYNC_RETRY_COUNT = 0;
          record.lastError = null;
          record.exhausted = false;
          record.retryCount = 0;
          if (record.data) {
            record.SYNC_STATUS = 'pending';
            record.DIRTY_BITS = 0;
            record.firstPendingAt = new Date().toISOString();
          }
        }
        if (storeName === 'localThumbnails' && record.annId && st.thumbIdRemap[record.annId]) {
          record.annId = st.thumbIdRemap[record.annId];
        }
        // 缺页补建的 urlMap 累积（_ensurePagesForAnnotations 只用 WEB_URI/PAGE_TITLE/DOMAIN）
        if (storeName === 'annotations') {
          const _u = record.WEB_URI;
          if (_u && !st.urlMap[_u]) st.urlMap[_u] = { PAGE_TITLE: record.PAGE_TITLE || '', DOMAIN: record.DOMAIN || '' };
        }
        const writeMethod = (strategy === 'skip') ? 'add' : 'put';
        const req = store[writeMethod](record);
        req.onsuccess = () => { result.inserted++; resolve(); };
        req.onerror = (e) => { e.preventDefault(); result.skipped++; resolve(); };
      }));
      await Promise.all(promises);

      // tags 逐条去重（与 restoreBackup 同款；必须开新事务）
      if (storeName === 'tags') {
        for (var ti = 0; ti < records.length; ti++) {
          var tagRecord = records[ti];
          const tagTx = this.db.transaction('tags', 'readwrite');
          const tagStore = tagTx.objectStore('tags');
          var existingTag = await new Promise(function (r) {
            var gr = tagStore.get(tagRecord.name);
            gr.onsuccess = function () { r(gr.result); };
            gr.onerror = function () { r(null); };
          });
          if (existingTag) {
            if (tagRecord.lastUsed && (!existingTag.lastUsed || tagRecord.lastUsed > existingTag.lastUsed)) {
              existingTag.lastUsed = tagRecord.lastUsed;
            }
            if (tagRecord.USER_ID && !existingTag.USER_ID) {
              existingTag.USER_ID = tagRecord.USER_ID;
            }
            await new Promise(function (r) {
              var pr = tagStore.put(existingTag);
              pr.onsuccess = function () { r(); };
              pr.onerror = function () { r(); };
            });
          }
        }
      }
    }

    // finalize：folder 修正 + 缺页补建（storesSeen 门控 doc/snap 修正，避免无谓全表扫）
    if (data.finalize) {
      const storesSeen = data.storesSeen || [];
      try {
        const validFolderIds = new Set((await this.getAllFolders()).map(f => f.folderId));
        const allPages = await this.getAllPages();
        const pageStore = this._tx('pages', 'readwrite');
        for (const p of allPages) {
          if (p.FOLDER_ID && !validFolderIds.has(p.FOLDER_ID)) {
            p.FOLDER_ID = null;
            await new Promise((resolve) => {
              const r = pageStore.put(p);
              r.onsuccess = () => resolve();
              r.onerror = () => resolve();
            });
          }
        }
      } catch (e) { /* ignore */ }
      if (storesSeen.indexOf('documents') >= 0 && this.db.objectStoreNames.contains('documents')) {
        try {
          const validFolderIds = new Set((await this.getAllFolders()).map(f => f.folderId));
          const allDocs = await this.getAllDocuments();
          const docStore = this._tx('documents', 'readwrite');
          for (const d of allDocs) {
            if (d.folderId && !validFolderIds.has(d.folderId)) {
              d.folderId = null;
              await new Promise((resolve) => {
                const r = docStore.put(d);
                r.onsuccess = () => resolve();
                r.onerror = () => resolve();
              });
            }
          }
        } catch (e) { /* ignore */ }
      }
      if (storesSeen.indexOf('snapshots') >= 0 && this.db.objectStoreNames.contains('snapshots')) {
        try {
          const validFolderIds = new Set((await this.getAllFolders()).map(f => f.folderId));
          const allSnaps = await this.getAllSnapshots();
          const snapStore = this._tx('snapshots', 'readwrite');
          for (const s of allSnaps) {
            if (s.folderId && !validFolderIds.has(s.folderId)) {
              s.folderId = null;
              await new Promise((resolve) => {
                const r = snapStore.put(s);
                r.onsuccess = () => resolve();
                r.onerror = () => resolve();
              });
            }
          }
        } catch (e) { /* ignore */ }
      }
      const urls = Object.keys(st.urlMap);
      if (urls.length > 0) {
        const synth = urls.map(u => ({ WEB_URI: u, PAGE_TITLE: st.urlMap[u].PAGE_TITLE, DOMAIN: st.urlMap[u].DOMAIN }));
        await this._ensurePagesForAnnotations(synth);
      }
      // 缩略图分档统计（诊断：多少条截图可补传 / 多少条够不到）——必须在清 _importStream 之前取
      if (st.thumbBuckets) {
        result.thumbBuckets = st.thumbBuckets;
        console.log('[import] thumbnail buckets: ' + JSON.stringify(st.thumbBuckets));
      }
      this._importStream = null;   // 会话结束，释放累积状态
      // 导入完成：合并本流置位的 PENDING id 进 thumb_pending_ids 清单——同 restoreBackup 尾部。
      try { await _wpzlMergeThumbPendingIds(st.thumbPendingIds); } catch (e) { /* ignore */ }
      // 清 24h 对账节流，让下次 init 的 _reconcilePendingWorkLists 全表重建清单。
      // restoreBackup（legacy 整文件路径）尾部有这一步，流式路径此前漏了——导入后清单不重建，
      // 被 THUMB_PENDING_MAX 截掉的尾部只能干等 24h。
      try {
        if (typeof wpzlSyncEngine !== 'undefined' && wpzlSyncEngine._syncClearReconcileGates) {
          wpzlSyncEngine._syncClearReconcileGates();
        }
      } catch (e) { /* ignore */ }
    }
    return result;
  }

  // Ensure page records exist for every annotation's WEB_URI
  async _ensurePagesForAnnotations(annotations) {
    var identity = await this.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';

    // Collect unique urls from annotations（原逻辑保留）
    const urlMap = {};
    annotations.forEach(a => {
      const url = a.WEB_URI;
      if (!url) return;
      if (!urlMap[url]) {
        // PAGE_TITLE is not a standard annotation field — derive a title from URL as fallback
        let title = a.PAGE_TITLE || '';
        if (!title) {
          try {
            const u = new URL(url);
            // Use the last meaningful path segment, or hostname if path is just '/'
            const path = u.pathname.replace(/\/+$/, '').replace(/^\/+/, '');
            if (path) {
              const segments = path.split('/');
              title = decodeURIComponent(segments[segments.length - 1]).replace(/[._-]/g, ' ');
            } else {
              title = u.hostname;
            }
          } catch (e) {
            title = '';
          }
        }
        urlMap[url] = { domain: a.DOMAIN || '', title: title };
      }
    });

    const urls = Object.keys(urlMap);
    if (urls.length === 0) return;

    // 批量读 existing：一个 readonly 事务并发 get，避免循环里跨 await 复用写事务失活
    const existingList = await this.getByKeys('pages', urls);

    // 收集缺失的 page，整理 domain / title
    const missing = [];
    for (let i = 0; i < urls.length; i++) {
      if (!existingList[i]) {
        const url = urls[i];
        const info = urlMap[url];
        let domain = info.domain;
        if (!domain) {
          try { domain = new URL(url).hostname; } catch (e) { domain = ''; }
        }
        missing.push({ url: url, domain: domain, title: info.title });
      }
    }
    if (missing.length === 0) return;

    // 对缺失且无 title 的，批量按 domain 回查（一次 readonly 事务并发 getAll 每个 domain）
    // handles imported pages whose URL differs from annotations' WEB_URI
    const domainSet = new Set();
    const domainsToLookup = [];
    for (const m of missing) {
      if (!m.title && m.domain && !domainSet.has(m.domain)) {
        domainSet.add(m.domain);
        domainsToLookup.push(m.domain);
      }
    }
    if (domainsToLookup.length > 0) {
      const domainTitleMap = await new Promise((resolve, reject) => {
        const tx = this.db.transaction('pages', 'readonly');
        const store = tx.objectStore('pages');
        const idx = store.index('domain');
        const resultMap = {};
        let pending = domainsToLookup.length;
        let failed = false;
        domainsToLookup.forEach(d => {
          const r = idx.getAll(d);
          r.onsuccess = () => {
            const pages = r.result || [];
            const match = pages.find(p => p.title);
            if (match) resultMap[d] = match.title;
            if (--pending === 0) resolve(resultMap);
          };
          r.onerror = () => { if (!failed) { failed = true; reject(r.error); } };
        });
      });
      for (const m of missing) {
        if (!m.title && m.domain && domainTitleMap[m.domain]) {
          m.title = domainTitleMap[m.domain];
        }
      }
    }

    // 构造新 page 数组，批量写（一个 readwrite 事务并发 put，不跨 await）
    // Bug B：时间统一为 UTC-naive FMT（勿用 ISO —— 与其它 page 写入形不一致）
    const nowUtc = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
    const newPages = missing.map(m => ({
      url: m.url,
      URL_MD5: this._md5Url(m.url),
      domain: m.domain,
      title: m.title,
      USER_ID: uid,
      annotationCount: 0,
      createdAt: nowUtc,
      lastVisited: nowUtc,
      // 补同步字段（漏点2）：否则导入补建的 page 永远不被 push 收集（push 只收 pending/local/error）
      SYNC_STATUS: SYNC_STATUS_PENDING,
      DIRTY_BITS: 0xFF,
      SERVER_UPDATE_TIME: null
    }));
    await this.putMany('pages', newPages);
  }

  async getStatistics() {
    // 决策 4：按 uid 隔离统计（避免跨用户累计计数）
    var identity = await this.getUserIdentity();
    var uid = identity && (identity.userId || identity.authorId);
    if (!uid) return { totalAnnotations: 0, totalPages: 0, todayCount: 0 };
    var uidStr = String(uid);
    const annotations = await new Promise((resolve, reject) => {
      const store = this._tx('annotations', 'readonly');
      var idx = store.indexNames.contains('userId') ? store.index('userId') : null;
      var req = idx ? idx.getAll(IDBKeyRange.only(uidStr)) : store.getAll();
      req.onsuccess = () => {
        var list = req.result || [];
        if (!idx) list = list.filter(function(a) { return !a.USER_ID || a.USER_ID === uidStr; });
        resolve(list);
      };
      req.onerror = () => reject(req.error);
    });
    const pages = await this.getAllPages();
    const today = wpzlFormatDate(new Date(), 'yyyy-MM-dd');
    // UPDATE_TIME 已为 UTC-naive，需按本地日期归组（Bug B：展示/计数用本地钟）
    const todayCount = annotations.filter(function (a) {
      if (!a.UPDATE_TIME) return false;
      var s = String(a.UPDATE_TIME);
      var d = new Date(s.indexOf('T') < 0 ? s.replace(' ', 'T') + 'Z' : s);
      return !isNaN(d.getTime()) && wpzlFormatDate(d, 'yyyy-MM-dd') === today;
    }).length;
    return {
      totalAnnotations: annotations.length,
      totalPages: pages.length,
      todayCount: todayCount
    };
  }

  // 合并迁移数据（来自各页面 origin 的旧 IndexedDB）
  async mergeMigratedData(data) {
    let merged = 0;
    let skipped = 0;

    if (data.annotations && data.annotations.length > 0) {
      // 标脏同步（漏点1）：迁移过来的标注设 PENDING + 全字段脏，让 push 收集上云。
      // synced 的保留（已同步基线），其余（undefined/local）设 PENDING。
      data.annotations.forEach(a => {
        if (a.SYNC_STATUS !== SYNC_STATUS_SYNCED) {
          // 属主变更 → 复位记录级同步状态（见 _resetRecordSyncState 说明；synced 记录保持基线不动）
          _resetRecordSyncState(a);
        }
      });
      const store = this._tx('annotations', 'readwrite');
      const promises = data.annotations.map(a => new Promise((resolve) => {
        const req = store.put(a);
        req.onsuccess = () => { merged++; resolve(); };
        req.onerror = () => { skipped++; resolve(); };
      }));
      await Promise.all(promises);
    }

    if (data.pages && data.pages.length > 0) {
      // 标脏同步（漏点1）：迁移的 page 设 PENDING + 补 URL_MD5，让 push 收集上云
      data.pages.forEach(p => {
        if (p.SYNC_STATUS !== SYNC_STATUS_SYNCED) {
          // 属主变更 → 复位记录级同步状态（同上方 annotations 分支说明）
          _resetRecordSyncState(p);
        }
        if (!p.URL_MD5 && p.url) p.URL_MD5 = this._md5Url(p.url);
      });
      const pageStore = this._tx('pages', 'readwrite');
      const promises = data.pages.map(p => new Promise((resolve) => {
        const req = pageStore.put(p);
        req.onsuccess = () => resolve();
        req.onerror = () => resolve();
      }));
      await Promise.all(promises);
    }

    if (data.settings && data.settings.length > 0) {
      const settingStore = this._tx('settings', 'readwrite');
      const promises = data.settings.map(s => new Promise((resolve) => {
        const req = settingStore.put(s);
        req.onsuccess = () => resolve();
        req.onerror = () => resolve();
      }));
      await Promise.all(promises);
    }

    return { merged: merged, skipped: skipped };
  }

  // ---- imageData store methods ----

  async getImageData(pageKey, imageKey) {
    const store = this._tx('imageData', 'readonly');
    const index = store.index('pageKey_imageKey');
    const range = IDBKeyRange.only([pageKey, imageKey]);
    return new Promise((resolve, reject) => {
      const req = index.get(range);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async saveImageData(record) {
    const store = this._tx('imageData', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.put(record);
      req.onsuccess = () => resolve(record);
      req.onerror = () => reject(req.error);
    });
  }

  // P1-19: imageData read-merge 写入。saveImageData 是整记录 put 盲覆盖——调用方持有的
  // 往往是创建时的闭包快照，期间 ISD 下载回填（data）/删除墓碑/重试计数等并发写会被
  // 快照整体抹掉。统一走本方法：先读 fresh，patch 只覆盖目标字段，其余保留 fresh 值。
  // patch 不含 data 时 fresh 的 data（含 ISD 回填）天然保留；fresh 不存在时以最小骨架兜底
  // （新建语义，此时调用方 patch 应携带完整必要字段）。
  async mergeImageData(pageKey, imageKey, patch) {
    var fresh = await this.getImageData(pageKey, imageKey);
    var base = fresh || { id: pageKey + '_' + imageKey, pageKey: pageKey, imageKey: imageKey };
    var merged = Object.assign({}, base, patch);
    return this.saveImageData(merged);
  }

  async deleteImageData(id) {
    const store = this._tx('imageData', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getImageDataByPage(pageKey) {
    // 决策 4：按 uid 隔离读取（dbVersion 10 建 userId_pageKey 复合索引）
    var identity = await this.getUserIdentity();
    var uid = identity && (identity.userId || identity.authorId);
    if (!uid) return [];
    const store = this._tx('imageData', 'readonly');
    return new Promise((resolve, reject) => {
      // 老库未升级路径 fallback：单字段 pageKey index + JS filter
      var idx = store.indexNames.contains('userId_pageKey')
        ? store.index('userId_pageKey')
        : store.index('pageKey');
      var req = idx === store.index('userId_pageKey')
        ? idx.getAll(IDBKeyRange.only([String(uid), pageKey]))
        : idx.getAll(IDBKeyRange.only(pageKey));
      req.onsuccess = () => {
        var list = req.result || [];
        if (idx !== store.index('userId_pageKey')) {
          // fallback 路径按 USER_ID 过滤
          var uidStr = String(uid);
          list = list.filter(function(r) { return !r.USER_ID || r.USER_ID === uidStr; });
        }
        resolve(list);
      };
      req.onerror = () => reject(req.error);
    });
  }

  async getImageDataByImageKey(imageKey) {
    // 决策 4：按 uid 隔离读取
    var identity = await this.getUserIdentity();
    var uid = identity && (identity.userId || identity.authorId);
    if (!uid) return [];
    var uidStr = String(uid);
    const store = this._tx('imageData', 'readonly');
    const index = store.index('imageKey');
    const range = IDBKeyRange.only(imageKey);
    return new Promise((resolve, reject) => {
      const req = index.getAll(range);
      req.onsuccess = () => {
        var list = req.result || [];
        // imageKey 没有专用复合索引，用 JS filter；imageKey 冲突概率本就低
        list = list.filter(function(r) { return !r.USER_ID || r.USER_ID === uidStr; });
        resolve(list);
      };
      req.onerror = () => reject(req.error);
    });
  }

  // dbVersion 8：无图片上云权限等级的 pageRect thumbnail 本地存储（决策 B）
  async saveLocalThumbnail(annId, pageKey, dataURL) {
    const store = this._tx('localThumbnails', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.put({ annId: annId, pageKey: pageKey, data: dataURL, ts: Date.now() });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // 修复 D：删除标注时级联清理 localThumbnails，避免孤儿缩略图长期占用 IDB。
  async deleteLocalThumbnail(annId) {
    const store = this._tx('localThumbnails', 'readwrite');
    return new Promise(function (resolve) {
      const req = store.delete(annId);
      req.onsuccess = function () { resolve(); };
      req.onerror = function () { resolve(); }; // thumbnail 可能本就不存在，静默
    });
  }

  async getLocalThumbnail(annId) {
    const store = this._tx('localThumbnails', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(annId);
      req.onsuccess = () => resolve(req.result ? req.result.data : null);
      req.onerror = () => resolve(null);
    });
  }

  async getAllLocalThumbnails() {
    if (!this.db.objectStoreNames.contains('localThumbnails')) return [];
    const store = this._tx('localThumbnails', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async checkImageReferences(webUri, imageUrl) {
    const store = this._tx('annotations', 'readonly');
    const index = store.index('webUri');
    const range = IDBKeyRange.only(webUri);
    return new Promise((resolve, reject) => {
      const req = index.getAll(range);
      req.onsuccess = () => {
        const count = (req.result || []).filter(a => a.END_TAG_NAME === imageUrl).length;
        resolve({ count: count });
      };
      req.onerror = () => reject(req.error);
    });
  }

  _updatePageRecord(annotation, pageTitle, scheme, pagePort) {
    var self = this;
    var url = annotation.WEB_URI;
    if (!url) return Promise.resolve();
    // 协议规整：仅 http/https 入库，其余（file/chrome 等）置空，由使用方兜底 https
    var cleanScheme = (scheme === 'http' || scheme === 'https') ? scheme : '';
    // 端口规整（scheme 配套）：url 身份键 = hostname+path 不含端口，非默认端口单独存
    // page.port 供「打开页面」/导出拼接 host:port。本地展示字段，不参与同步（服务端无此列，
    // 下载合并走 Object.assign({}, existing) 字段级 merge，本地 port 天然保留）。
    var cleanPort = /^\d+$/.test(pagePort || '') ? pagePort : '';
    return new Promise(function (resolve, reject) {
      try {
        var tx = self.db.transaction('pages', 'readwrite');
        var pageStore = tx.objectStore('pages');
        // 决策 4：写路径强制 USER_ID（与 annotation.USER_ID 同步）
        var uidStr = annotation.USER_ID
          ? String(annotation.USER_ID)
          : null;
        // 用标注的 UPDATE_TIME 作为时间戳，确保跨设备排序一致
        var visitedTime = annotation.UPDATE_TIME || wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd hh:mm:ss');
        var urlMd5 = self._md5Url(url);
        var getReq = pageStore.get(url);
        getReq.onsuccess = function () {
          var existing = getReq.result;

          // 标题来源优先级：真实 document.title（pageTitle 非空，权威）> 已有 title > URL 派生
          var resolvedTitle;
          var titleDirty = false;
          if (pageTitle) {
            if (!existing || existing.title !== pageTitle) { resolvedTitle = pageTitle; titleDirty = true; }
            else resolvedTitle = existing.title;
            if (existing && existing.CUSTOM_TITLE) titleDirty = false;
          } else if (existing && existing.title) {
            resolvedTitle = existing.title;
          } else {
            resolvedTitle = _deriveTitleFromUrl(url);
          }

          if (existing) {
            var changed = false;
            if (existing.SYNC_STATUS === SYNC_STATUS_PENDING_DELETED) {
              existing.SYNC_STATUS = SYNC_STATUS_PENDING;
              existing.DIRTY_BITS = 0xFF;
              changed = true;
              try { console.log('[Sync][Page] revive tombstone: url=' + url + ' source=saveAnnotation status=' + existing.SYNC_STATUS); } catch (e) { /* ignore */ }
            }
            if (!existing.USER_ID && uidStr) { existing.USER_ID = uidStr; changed = true; }
            if (resolvedTitle !== existing.title) { existing.title = resolvedTitle; changed = true; }
            if (!existing.URL_MD5) { existing.URL_MD5 = urlMd5; changed = true; }
            // 修正快照/摘要等非标注路径写入的错误/空 domain（如快照误写 127.0.0.1、摘要硬编码空串）。
            // 标注携带的 DOMAIN 是页面真实域名，仅在现有 domain 明显错误时修正，避免覆盖合法值。
            var annDomain = annotation.DOMAIN || '';
            if (annDomain && annDomain.indexOf('127.') !== 0 && annDomain.indexOf('localhost') !== 0) {
              if (!existing.domain || existing.domain === '' || existing.domain.indexOf('127.') === 0 || existing.domain.indexOf('localhost') === 0) {
                if (existing.domain !== annDomain) {
                  try { console.log('[Sync][Page] fix bad domain: url=' + url + ' old=' + existing.domain + ' new=' + annDomain + ' source=saveAnnotation'); } catch (e) { /* ignore */ }
                  existing.domain = annDomain;
                  changed = true;
                }
              }
            }
            if (!existing.lastVisited || visitedTime > existing.lastVisited) {
              existing.lastVisited = visitedTime; changed = true;
            }
            // 协议捕获：incoming 非空且与现存不同才写入；同步态置脏触发推送（scheme 为常发字段）
            if (cleanScheme && existing.scheme !== cleanScheme) {
              existing.scheme = cleanScheme;
              changed = true;
              if (existing.SYNC_STATUS === SYNC_STATUS_SYNCED) {
                existing.SYNC_STATUS = SYNC_STATUS_PENDING;
                existing.DIRTY_BITS = (existing.DIRTY_BITS || 0) | 2048; // DIRTY_BIT_VISITED
              }
            }
            // 端口捕获：set-if-changed，本地展示字段不置脏（不参与同步推送）
            if (cleanPort && existing.port !== cleanPort) {
              existing.port = cleanPort;
              changed = true;
            }
            if (titleDirty && existing.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED) {
              existing.SYNC_STATUS = (existing.SYNC_STATUS === SYNC_STATUS_SYNCED) ? SYNC_STATUS_PENDING : (existing.SYNC_STATUS || SYNC_STATUS_PENDING);
              existing.DIRTY_BITS = (existing.DIRTY_BITS || 0) | 128;
              changed = true;
              try {
                console.log('[Sync][Page] dirty TITLE: url=' + url +
                  ' oldTitle="' + (existing.title || '').slice(0, 60) + '"' +
                  ' newTitle="' + (resolvedTitle || '').slice(0, 60) + '"' +
                  ' source=saveAnnotation(_updatePageRecord)');
              } catch (e) { /* ignore */ }
            }
            // 本地真实标注（有 pageTitle）落在已同步的页面上 → 强制标脏推送。
            // 否则仅用 titleDirty 判断时，"标题相同不脏"导致已删页面无法复活（is_deleted 不变）。
            if (!titleDirty && pageTitle && existing.SYNC_STATUS === SYNC_STATUS_SYNCED) {
              existing.SYNC_STATUS = SYNC_STATUS_PENDING;
              existing.DIRTY_BITS = (existing.DIRTY_BITS || 0) | 2048; // DIRTY_BIT_VISITED
              changed = true;
              try {
                console.log('[Sync][Page] dirty VISITED (force push): url=' + url +
                  ' title="' + (resolvedTitle || '').slice(0, 60) + '" source=saveAnnotation');
              } catch (e) { /* ignore */ }
            }
            if (changed) pageStore.put(existing);
            self._scheduleRecountAnnotationCount(url);
          } else {
            var isLocalSave = !!pageTitle;
            try { console.log('[Sync][Page] NEW page: url=' + url + ' isLocalSave=' + isLocalSave + ' title=' + resolvedTitle + ' status=' + (isLocalSave ? 'LOCAL' : 'SYNCED')); } catch (e) { /* ignore */ }
            pageStore.put({
              url: url,
              URL_MD5: urlMd5,
              domain: annotation.DOMAIN,
              scheme: cleanScheme,
              port: cleanPort,
              title: resolvedTitle,
              annotationCount: 1,
              createdAt: visitedTime,
              lastVisited: visitedTime,
              FAVORITE: false,
              FOLDER_ID: null,
              USER_ID: uidStr || 'local',
              SYNC_STATUS: isLocalSave ? SYNC_STATUS_LOCAL : SYNC_STATUS_SYNCED,
              SYNC_VERSION: 0,
              DIRTY_BITS: isLocalSave ? (128 | 2048) : 0,
              SERVER_UPDATE_TIME: null
            });
          }
        };
        getReq.onerror = function () { reject(getReq.error); };
        tx.oncomplete = function () { resolve(); };
        tx.onerror = function () { reject(tx.error); };
        tx.onabort = function () { reject(tx.error); };
      } catch (e) {
        // 非关键操作，静默完成
        resolve();
      }
    });
  }

  // url → md5 缓存：pull 批量建 page 时同一 url 多标注只算一次 wpzl_md5（Bug 12）
  _md5Url(url) {
    var cached = this._urlMd5Cache.get(url);
    if (cached) return cached;
    var md5 = wpzl_md5(url);
    // 极端场景防无界增长（URL 数通常有限，5 万足够）
    if (this._urlMd5Cache.size > 50000) this._urlMd5Cache.clear();
    this._urlMd5Cache.set(url, md5);
    return md5;
  }

  // 批量更新 pull 下载的新标注对应的 page 记录（替代逐条 _updatePageRecord，Bug 12）。
  // 按 url 去重 + 一个 readonly 事务批量读 + 一个 readwrite 事务批量写，
  // 避免 N 条标注 = N 次独立 pages 事务 + N 次 wpzl_md5 重算。
  // pull 场景 pageTitle 空：保留 existing.title（无则派生），不触发 titleDirty 标脏（单条版 saveAnnotation 才需要）。
  async _updatePageRecordsForPulled(annotations) {
    if (!annotations || annotations.length === 0) return;
    // 修复：补建 page 时必须填 USER_ID（与 _applyDownloadedPages 对齐）。
    // 否则新建的 page 不进 userId 索引，getAllPages 按 uid 隔离查询会漏掉它 → manager 列表隐身
    // （曾表现为：某设备本地 page 总数 == 服务器活跃数，但其中 USER_ID 缺失的被过滤，manager 显示偏少）。
    var identity = await this.getUserIdentity();
    var uid = (identity && (identity.userId || identity.authorId)) || '';
    // 按 url 去重，取每 url 最新 UPDATE_TIME 的标注
    var urlToInfo = {};
    for (var i = 0; i < annotations.length; i++) {
      var ann = annotations[i];
      var url = ann.WEB_URI;
      if (!url) continue;
      var visitedTime = ann.UPDATE_TIME || wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd hh:mm:ss');
      if (!urlToInfo[url] || visitedTime > urlToInfo[url].visitedTime) {
        urlToInfo[url] = { annotation: ann, visitedTime: visitedTime };
      }
    }
    var urls = Object.keys(urlToInfo);
    if (urls.length === 0) return;

    var existingList = await this.getByKeys('pages', urls);
    var toPut = [];
    for (var j = 0; j < urls.length; j++) {
      var url = urls[j];
      var info = urlToInfo[url];
      var existing = existingList[j];
      var urlMd5 = this._md5Url(url);
      var visitedTime = info.visitedTime;

      if (existing) {
        var resolvedTitle = existing.title || _deriveTitleFromUrl(url);
        var changed = false;
        // 用户已自定义标题时跳过 title fallback 填充（CUSTOM_TITLE 在显示层优先，无谓写入可省）
        if (!existing.CUSTOM_TITLE && resolvedTitle !== existing.title) { existing.title = resolvedTitle; changed = true; }
        if (!existing.URL_MD5) { existing.URL_MD5 = urlMd5; changed = true; }
        if (!existing.lastVisited || visitedTime > existing.lastVisited) { existing.lastVisited = visitedTime; changed = true; }
        if (changed) toPut.push(existing);
      } else {
        // 新建 page（pull 场景 isLocalSave=false：SYNCED，不标脏，title 用派生）
        toPut.push({
          url: url,
          URL_MD5: urlMd5,
          USER_ID: uid,
          domain: info.annotation.DOMAIN,
          title: _deriveTitleFromUrl(url),
          annotationCount: 1,
          createdAt: visitedTime,
          lastVisited: visitedTime,
          FAVORITE: false,
          FOLDER_ID: null,
          SYNC_STATUS: SYNC_STATUS_SYNCED,
          SYNC_VERSION: 0,
          DIRTY_BITS: 0,
          SERVER_UPDATE_TIME: null
        });
      }
    }
    if (toPut.length > 0) await this.putMany('pages', toPut);
    // 懒重算 annotationCount（per url 节流；单标注 page no-op，多标注才修正）
    for (var k = 0; k < urls.length; k++) {
      this._scheduleRecountAnnotationCount(urls[k]);
    }
  }

  // 标注增删后懒重算 page.annotationCount（节流 500ms），修复原累加逻辑导致的计数虚高
  _scheduleRecountAnnotationCount(url) {
    if (!this._recountTimers) this._recountTimers = {};
    if (this._recountTimers[url]) return;
    var self = this;
    this._recountTimers[url] = setTimeout(function () {
      delete self._recountTimers[url];
      try {
        var annStore = self.db.transaction('annotations', 'readonly').objectStore('annotations');
        // 仅计活跃标注：软删（pending_deleted）行仍留在 IDB 等同步确认后硬删，
        // 原始 index.count 会把墓碑也算进去导致计数虚高；游标过滤与 getAnnotations 口径一致。
        var cursorReq = annStore.index('webUri').openCursor(url);
        var realCount = 0;
        cursorReq.onsuccess = function () {
          var cur = cursorReq.result;
          if (cur) {
            if (!cur.value || cur.value.SYNC_STATUS !== 'pending_deleted') realCount++;
            cur.continue();
            return;
          }
          var pageStore = self.db.transaction('pages', 'readwrite').objectStore('pages');
          var getReq = pageStore.get(url);
          getReq.onsuccess = function () {
            var p = getReq.result;
            if (p && (p.annotationCount || 0) !== realCount) {
              p.annotationCount = realCount;
              pageStore.put(p);
            }
          };
        };
      } catch (e) { /* ignore */ }
    }, 500);
  }
}

// ---------- 从 URL 提取可读标题（同步下载时 page title 不可用） ----------
function _deriveTitleFromUrl(url) {
  if (!url) return '';
  try {
    // url 格式: domain/path?query 或纯路径
    var parts = url.split('/');
    // 取最后一个非空路径段
    var last = '';
    for (var i = parts.length - 1; i >= 0; i--) {
      if (parts[i]) { last = parts[i]; break; }
    }
    // 去掉 query string 和 fragment
    if (last.indexOf('?') >= 0) last = last.substring(0, last.indexOf('?'));
    if (last.indexOf('#') >= 0) last = last.substring(0, last.indexOf('#'));
    // URL decode
    try { last = decodeURIComponent(last); } catch (e) { /* keep as-is */ }
    return last || url;
  } catch (e) {
    return url;
  }
}

// ---------- MD5 工具（service worker 中生成 key） ----------
// ---- Toast 通知：SW → 活动 tab → content.js → bundle.js wpzl_showToast ----
// 用于 SW 上下文（无法直接调 wpzl_showToast）向前端活动 tab 派发 toast 通知
function _notifyToastToActiveTab(message, options) {
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (!tabs || !tabs.length) return;
      chrome.tabs.sendMessage(tabs[0].id, {
        type: 'wpzl-show-toast',
        message: message,
        clickable: !!(options && options.clickable),
        duration: (options && options.duration) || 2500
      });
    });
  } catch (e) { /* ignore */ }
}

// P1-25: 内联图上云失败留痕（有界环形数组，chrome.storage.local）——供诊断"cloudUrl 为何没回写"。
// 页面侧有 toast，这里只记结构化事实（时间/标注/错误/serverCode）。
var INLINE_UPLOAD_ERR_MAX = 20;
function _recordInlineUploadError(annId, e) {
  try {
    chrome.storage.local.get(['wpzl_inline_upload_last_error'], function (x) {
      var arr = (x && x.wpzl_inline_upload_last_error) || [];
      arr.push({
        at: Date.now(),
        annId: annId || null,
        message: String((e && e.message) || '').slice(0, 200),
        serverCode: (e && e.serverCode) || null
      });
      if (arr.length > INLINE_UPLOAD_ERR_MAX) arr = arr.slice(arr.length - INLINE_UPLOAD_ERR_MAX);
      try { chrome.storage.local.set({ wpzl_inline_upload_last_error: arr }); } catch (e2) { /* ignore */ }
    });
  } catch (e3) { /* ignore */ }
}

// 识别服务端 QuotaExceededException（HTTP 400, code=40001, message 含「配额超限」）
function _isQuotaExceededError(e) {
  if (!e) return false;
  // 优先匹配机器可读业务码（server-api 抛错时附带 serverCode=data.code，配额超限=40001）
  if (e.serverCode === 40001) return true;
  // 「配额超限」子串匹配服务端中文错误消息，作为无 serverCode 路径的兜底
  var msg = (e && e.message) || '';
  return msg.indexOf('配额超限') >= 0;
}

// ---- SVG → PNG 栅格化（offscreen document）----
// 背景：服务端图片云上传白名单仅收 webp/jpeg/png（AssetService ImageMagicBytesValidator，
// D-12 安全加固），SVG 字节必被拒（如 xkw 试卷预览 cdn-preview.xkw.com/.../svg/1.svg），
// 且 MV3 SW 无 DOM——createImageBitmap / ImageDecoder 均不支持 SVG 解码（实测 Chrome 135），
// 唯一可靠路径是 offscreen document 里的 Image + canvas。栅格化成功 → 以 PNG 走本地存储与
// 云上传；失败 → 保留 SVG 仅本地，置 exhausted 停止注定失败的重试（不广播打扰）。
var _wpzlOffscreenCreating = null;
var _wpzlSvgRasterSeq = 0;
var WPZL_SVG_RASTER_TIMEOUT_MS = 15000;
// SVG 记录转不了 PNG 时的失败原因（存 imageData.lastError，同步失败弹窗直接展示）
var WPZL_SVG_LOCAL_ONLY_ERROR = 'SVG 无法转为 PNG，仅本地保存';

// 确保 offscreen document 存在（chrome.offscreen 需 manifest "offscreen" 权限，Chrome 109+）
async function _wpzlEnsureOffscreenDocument() {
  if (typeof chrome.offscreen === 'undefined' || !chrome.runtime.getContexts) return false;
  try {
    var contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (contexts && contexts.length > 0) return true;
    if (!_wpzlOffscreenCreating) {
      _wpzlOffscreenCreating = chrome.offscreen.createDocument({
        url: 'offscreen/offscreen.html',
        reasons: ['DOM_SCRAPING'],
        justification: '将 SVG 图片经 Image+canvas 栅格化为 PNG（SW 无 DOM），以支持图片云上传格式白名单'
      }).then(function () { return true; }).catch(function (e) {
        console.warn('[imgData] offscreen createDocument failed:', e && e.message);
        return false;
      }).finally(function () { _wpzlOffscreenCreating = null; });
    }
    return await _wpzlOffscreenCreating;
  } catch (e) {
    console.warn('[imgData] ensure offscreen failed:', e && e.message);
    return false;
  }
}

// SVG data URL → PNG data URL；任何失败返回 null（调用方走「仅本地保存」分支）。
// offscreen 页返回的 pngDataUrl 必须以 data:image/png; 开头才采纳（防消息伪造/串线）。
async function _wpzlRasterizeSvgDataUrl(svgDataUrl) {
  var ready = await _wpzlEnsureOffscreenDocument();
  if (!ready) return null;
  var reqId = ++_wpzlSvgRasterSeq;
  try {
    var resp = await Promise.race([
      chrome.runtime.sendMessage({ type: 'wpzl-rasterize-svg', requestId: reqId, svgDataUrl: svgDataUrl }),
      new Promise(function (resolve) { setTimeout(function () { resolve(null); }, WPZL_SVG_RASTER_TIMEOUT_MS); })
    ]);
    if (resp && resp.ok && resp.requestId === reqId && typeof resp.pngDataUrl === 'string'
        && resp.pngDataUrl.indexOf('data:image/png;') === 0) {
      return resp.pngDataUrl;
    }
    return null;
  } catch (e) {
    return null;
  }
}

// data URL → Blob 复用既有 _wpzlDataUrlToBlob（本文件下方，头像上传引入）——base64 data URL 通用。

// 尝试上传图片到 R2（含积压检查 + 一次重试）
function _tryUploadImageWithBacklogCheck(blob, pageKey, imageKey, record) {
  wpzl_isImageCloudUploadAllowed().then(function (allowed) {
    if (!allowed) return;
    // 检查积压上限：超过 50 张未上云时跳过，避免无限堆积冲击 R2
    if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._checkPendingImageLimit === 'function') {
      return wpzlSyncEngine._checkPendingImageLimit().then(function (overLimit) {
        if (overLimit) {
          console.warn('[imgData] pending backlog full, skipping upload for', imageKey);
          if (typeof wpzlSyncEngine._maybeShowImageBacklogToast === 'function') {
            wpzlSyncEngine._maybeShowImageBacklogToast();
          }
          return;
        }
        _doUploadWithRetry(blob, pageKey, imageKey, record);
      });
    }
    _doUploadWithRetry(blob, pageKey, imageKey, record);
  });
}

// 折叠为单次尝试（计划 4c）：失败置 SYNC_STATUS=pending + 首次 firstPendingAt，
// 交由 _uploadPendingImages 统一按项计数（计数权威唯一，避免"立即 5s 重试 + 下一轮"双计数）。
function _doUploadWithRetry(blob, pageKey, imageKey, record) {
  wpzl_uploadImage(blob, pageKey, imageKey).then(function (resp) {
    if (resp && resp.cloudUrl) {
      // P1-19: record 是 saveImageFromUrl/Base64 闭包快照——上传在飞期间 ISD 回填 data、
      // 墓碑标记等并发写会被整记录 put 抹掉。改 read-merge（patch 不含 data，fresh 的
      // data/其它字段保留）。
      db.mergeImageData(pageKey, imageKey, {
        cloudUrl: resp.cloudUrl,
        contentHash: resp.contentHash || null,
        SYNC_STATUS: 'synced',
        DIRTY_BITS: 1,
        retryCount: 0,
        exhausted: false
      });
      // P1-18b: "SYNCED+bits" 不在 syncStatus 索引脏值里——记入 meta-dirty 清单，
      // 供 _collectDirtyImageData 索引化收集（替代每 push 周期全表 getAll）
      if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._noteImageMetaDirty === 'function') {
        try { wpzlSyncEngine._noteImageMetaDirty(record.id); } catch (e) { /* ignore */ }
      }
    } else {
      db.mergeImageData(pageKey, imageKey, {
        SYNC_STATUS: 'pending',
        firstPendingAt: record.firstPendingAt || new Date().toISOString()
      });
    }
  }).catch(function (e) {
    console.warn('[imgData] upload failed, deferring to _uploadPendingImages:', e && e.message);
    if (_isQuotaExceededError(e)) {
      // 配额满提示走 30 分钟冷却节流（批量截图不刷屏）+ 置阻断标志（配额释放后自动恢复重传）；
      // sync-engine 未加载时退回直弹（旧行为）
      if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._maybeShowQuotaToast === 'function') {
        wpzlSyncEngine._setQuotaBlocked(true);
        wpzlSyncEngine._maybeShowQuotaToast();
      } else {
        _notifyToastToActiveTab(chrome.i18n.getMessage('cloudQuotaFullToast'), { clickable: true, duration: 4000 });
      }
    }
    db.mergeImageData(pageKey, imageKey, {
      SYNC_STATUS: 'pending',
      firstPendingAt: record.firstPendingAt || new Date().toISOString()
    });
  });
}

// P1-13: 删除 imageData 的统一入口语义——同步开启且已上云（cloudUrl）→ 标墓碑
// pending_deleted 随统一 sync 的 deletedImageAssetKeys 上行传播（服务端 processImageAssetTombstone
// 软删行+删 R2+释放配额，对端经下行 active 集收敛）；未上云或同步关闭 → 物理删（服务端无行，
// 无传播需求）。data 清空减少墓碑滞留期占用（上行确认后整行硬删）。
// 注意：deletePage 级联不走这里——服务端页面墓碑已级联 hardDeleteByPageKey 删图，
// 级联路径保持本地物理删（db.deleteImageDataByPageKey），标墓碑反而会造成对端二次删除请求。
async function _deleteImageDataWithTombstone(delRec) {
  var syncOn = typeof wpzlSyncEngine !== 'undefined' && wpzlSyncEngine.isEnabled();
  if (syncOn && delRec.cloudUrl) {
    await db.mergeImageData(delRec.pageKey, delRec.imageKey, {
      SYNC_STATUS: 'pending_deleted',
      deletedAt: new Date().toISOString(),
      data: null,
      DIRTY_BITS: 0
    });
    try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
    return 'tombstoned';
  }
  await db.deleteImageData(delRec.id);
  return 'deleted';
}

// ---- 页面矩形缩略图后台补传 ----
// 缩略图先存 localThumbnails IDB（save_local_thumbnail.do），标记 THUMBNAIL_PENDING=true。
// 本函数在 SW 启动和 online 事件时被调用，从 IDB 读数据后分批上云。
var THUMBNAIL_FLUSH_BATCH = 8;
var THUMBNAIL_PENDING_MAX = 50;
var _thumbnailFlushActive = false;

async function _flushPendingThumbnails() {
  if (_thumbnailFlushActive) return;
  // 脱机整体休眠：不可达时跳过逐张补传，避免每张都发注定失败的 R2 上传请求
  if (typeof wpzl_getSyncState === 'function' && wpzl_getSyncState() === 'offline') return;
  _thumbnailFlushActive = true;
  try {
    var allowed = await wpzl_isImageCloudUploadAllowed();
    if (!allowed) return;

    // 修复 G：按当前账号 uid 过滤，避免多账号切换时把他人 PENDING 标注串号上传到当前账号空间。
    // 实时读 db.getUserIdentity()（无 stale）。USER_ID 未设的老数据 _thumbUidStr 为空 → 保守不过滤。
    var _thumbId = null;
    try { _thumbId = await db.getUserIdentity(); } catch (e) { /* ignore */ }
    var _thumbUidStr = _thumbId && (_thumbId.userId || _thumbId.authorId) ? String(_thumbId.userId || _thumbId.authorId) : '';

    // P1-18c: 此前每次 db.getAll('annotations') 全表扫（含 CONTEXT 大字段，每 tick/启动/保存缩略图都跑）。
    // 改读 syncMeta 的 thumb_pending_ids 有界清单 → getByKeys 批取 → 对账式过滤（缺失或已无
    // THUMBNAIL_PENDING 的 id 顺手从清单清除，自愈漂移）。清单由 saveLocalThumbnail 写入、
    // init 时 _reconcilePendingWorkLists 全表重建兜底。
    var _thumbIds = [];
    try {
      if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._getThumbPendingIds === 'function') {
        _thumbIds = await wpzlSyncEngine._getThumbPendingIds();
      }
    } catch (e) { /* ignore */ }
    var allAnns = _thumbIds.length > 0 ? await db.getByKeys('annotations', _thumbIds) : [];
    var pending = [];
    var totalPending = 0;
    var _stillPendingIds = [];
    // 本轮留在清单里、且真正可补传（未耗尽、且属当前账号）的项数。补货触发器靠它判断
    // "清单里已无活可干"。⚠️ 三段式缺一不可：uid 不匹配项在下面被无条件 push 进清单且不计入
    // totalPending，若把它们算成 live，_liveRemaining 永远不为 0 → 触发器永不触发。
    var _liveRemaining = 0;
    for (var i = 0; i < allAnns.length; i++) {
      var _ta = allAnns[i];
      if (!_ta) continue;   // 记录已删：出清单
      if (_thumbUidStr && _ta.USER_ID && String(_ta.USER_ID) !== _thumbUidStr) { _stillPendingIds.push(_thumbIds[i]); continue; }
      if (_ta.THUMBNAIL_PENDING) {
        _stillPendingIds.push(_thumbIds[i]);
        totalPending++;
        if (!_ta.THUMB_EXHAUSTED) {
          _liveRemaining++;
          // P1-24: 耗尽的不进批（THUMB_EXHAUSTED，镜像 image 侧 dlExhausted 跳过），但留清单：
          // 复位走 _resetExhaustedState→_resetThumbExhausted（有界清单读，避免全表扫）。
          if (pending.length < THUMBNAIL_FLUSH_BATCH) pending.push(_ta);
        }
      }
      // 已无 THUMBNAIL_PENDING：出清单（对账自清理）
    }
    // 本轮实际会处理的项从 live 计数里扣掉：它们要么上传成功出清单，要么转终态出清单，
    // 不会留在清单里 → 判断"清单里还有没有活"必须排除它们。
    _liveRemaining -= pending.length;
    if (_liveRemaining < 0) _liveRemaining = 0;

    // 对账自清理：只**剔除**确认已不再是 PENDING / 记录已删的 id，并发新增的一律保留。
    // 不整体写回 _stillPendingIds——那是"用本地快照覆盖清单"，会把 3170 读清单之后并发追加的
    // id（saveLocalThumbnail → _noteThumbPending）一起抹掉，丢掉的 id 静默饿死。
    //（_dropThumbPendingIds 在 sync-engine 的串行链内重读清单，无丢更新窗口。）
    if (_thumbIds.length !== _stillPendingIds.length) {
      try {
        if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._dropThumbPendingIds === 'function') {
          var _keep = {};
          for (var _ki = 0; _ki < _stillPendingIds.length; _ki++) _keep[_stillPendingIds[_ki]] = 1;
          var _deadIds = [];
          for (var _di = 0; _di < _thumbIds.length; _di++) { if (!_keep[_thumbIds[_di]]) _deadIds.push(_thumbIds[_di]); }
          if (_deadIds.length) await wpzlSyncEngine._dropThumbPendingIds(_deadIds);
        }
      } catch (e) { /* ignore */ }
    }

    // C 修复：清单里已无可补传项（全部耗尽/为空），但清单可能被 THUMB_PENDING_MAX 截断过——
    // 尾部还在 DB 里等着，而 _reconcilePendingWorkLists 有 24h 节流。此刻即时重建清单补货。
    // ⚠️ 必须放在下面 `if (pending.length === 0) return;` 之前：清单全为已处理项时
    // pending.length === 0，那正是最需要补货的状态，放在循环之后就是死代码。
    // truncated === undefined（升级后首次、尚无标志）也补一次货，兼容历史遗留的孤儿清单。
    if (_liveRemaining === 0) {
      try {
        var _truncated = await wpzlSyncEngine._getThumbPendingTruncated();
        // true      → 清单确被截断过，尾部在 DB 里等着（这是要修的主场景）
        // undefined → 升级后首次、尚未写过标志，补一次货以带回历史遗留的孤儿清单项
        // false     → 清单已完整，稳态零开销，不重扫
        if (_truncated !== false) {
          var _stillTruncated = await wpzlSyncEngine._refreshThumbPendingIds();
          if (_stillTruncated) console.log('[thumbFlush] work list topped up, still truncated');
        }
      } catch (e) { /* ignore */ }
    }

    if (pending.length === 0) return;
    console.log('[thumbFlush] found ' + totalPending + ' pending thumbnails, flushing ' + pending.length);

    if (totalPending > THUMBNAIL_PENDING_MAX && typeof _maybeShowImageBacklogToast === 'function') {
      _maybeShowImageBacklogToast();
    }

    var successCount = 0;
    for (var j = 0; j < pending.length; j++) {
      var ann = pending[j];
      try {
        // P1-24B: 上传前重读 fresh 记录——扫描快照可能已过时（标注被删/软删，给墓碑传图 = R2 孤儿；
        // 或已被并发路径处理过 THUMBNAIL_PENDING=false）。两种情况都不上传，只清标记出清单。
        var _freshAnn = await db.getAnnotation(ann.MARK_INFO_ID);
        if (!_freshAnn || _freshAnn.SYNC_STATUS === SYNC_STATUS_PENDING_DELETED || !_freshAnn.THUMBNAIL_PENDING) {
          if (_freshAnn && _freshAnn.THUMBNAIL_PENDING) {
            try { await db.updateAnnotation(ann.MARK_INFO_ID, { THUMBNAIL_PENDING: false }); } catch (e0) { /* ignore */ }
          }
          if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._removeThumbPending === 'function') {
            try { await wpzlSyncEngine._removeThumbPending(ann.MARK_INFO_ID); } catch (e0) { /* ignore */ }
          }
          continue;
        }
        ann = _freshAnn; // 后续读取/回写均用 fresh 快照
        var localThumb = await db.getLocalThumbnail(ann.MARK_INFO_ID);
        if (!localThumb) {
          // 本地字节确实不存在 → 不可恢复的终态（不是瞬时失败：重试多少次都没有字节可传）。
          // 必须置一个**用户可见**的终态标记，而不是像以前那样只清 PENDING 就 continue——
          // 那样做等于把失败伪装成成功：面板计数每 tick 掉 8，THUMBNAIL 一直是 null，
          // 用户只看到数字在降、以为在同步，实际截图永久丢失且无从得知（本函数的设计缺陷）。
          // 不用 THUMB_EXHAUSTED 承载：它表示"字节在、传了 10 次没成功"，会被
          // _resetExhaustedState 在重登/配额释放时复位 → 每轮 9 次空转 churn + 反复弹窗；
          // 且 _resetThumbExhausted 只读有界清单，50 张新截图后终态记录就被挤出、重试按钮再次失效。
          // 出清单（不占工作队列名额），由 collectThumbPending 单独扫出来呈现。
          console.warn('[thumbFlush] local thumbnail missing, marking terminal: ' + ann.MARK_INFO_ID);
          await db.updateAnnotation(ann.MARK_INFO_ID, {
            THUMBNAIL_PENDING: false,
            THUMB_LOCAL_MISSING: true,
            THUMB_LAST_ERROR: 'local_thumbnail_missing',
            THUMB_RETRY_COUNT: 0,
            THUMB_EXHAUSTED: false
          });
          if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._removeThumbPending === 'function') {
            try { await wpzlSyncEngine._removeThumbPending(ann.MARK_INFO_ID); } catch (e) { /* ignore */ }
          }
          continue;
        }
        // C2：异步解码 dataURL，消除同步 atob+逐字节填充的内存峰值（原方案约 3-4x dataURL 体积）。
        // 不改 localThumbnails schema（仍存 dataURL 字符串）。fetch dataURL 失败回退同步 atob（兼容性保险）。
        var assetBlob;
        try {
          var _thumbAb = await fetch(localThumb).then(function (r) { return r.arrayBuffer(); });
          assetBlob = new Blob([_thumbAb], { type: 'image/webp' });
        } catch (e) {
          var ltBytes = atob(localThumb.split(',')[1]);
          var ltNums = new Array(ltBytes.length);
          for (var lti = 0; lti < ltBytes.length; lti++) ltNums[lti] = ltBytes.charCodeAt(lti);
          assetBlob = new Blob([new Uint8Array(ltNums)], { type: 'image/webp' });
        }

        // pageKey：优先用持久化的 _pageKey（saveLocalThumbnail 写入）；缺失则由 WEB_URI 现算。
        // WEB_URI 在创建端 = wpzl_normalizeWebpath(window.location)，SW 的 wpzl_md5 与注入层
        // wpzl_imageStorageMd5 同为真实 MD5（同一标准、同输入同输出），故 wpzl_md5(WEB_URI) 与
        // _pageKey 等价。现算兜底覆盖两类：(a)本修复部署前创建的存量 PENDING 标注（无 _pageKey，
        // 即用户当前在 manager 看到的「同步失败」截图）；(b)任何 _pageKey 丢失的边角情况。
        var pageKey = ann._pageKey || (ann.WEB_URI ? wpzl_md5(ann.WEB_URI) : '');
        // imageKey 必须为 32 位 hex：服务端 OBJECT_KEY_PATTERN = ^u/(\d+)/([0-9a-fA-F]{32})/([0-9a-fA-F]{32})\.webp$，
        // signObject/deleteAsset 都过该校验。原用 ann.MARK_INFO_ID（形如 g1707…）非 32-hex → 上传能过
        // （upload 只校验空值）但跨设备签名取图 / 删除回收会抛「非法 objectKey」。改用 _swMd5 哈希成 32-hex：
        // 每条页面截图独占一个 R2 对象，imageKey 不与其它实体共享，哈希口径自洽即可。
        var imageKey = (await _swMd5(ann.MARK_INFO_ID)) || ann.MARK_INFO_ID;
        var resp = await wpzl_uploadImage(assetBlob, pageKey, imageKey);
        if (resp && resp.cloudUrl) {
          // 修复 BUG-3：原 |4 是 DIRTY_BIT_TAGS，buildDiffUploadDto 只认 DIRTY_BIT_THUMBNAIL(1<<6=64)，
          // 否则上云后的 cloudUrl 永不进入 push DTO → 服务端永远 null → 跨设备空白。
          // 写 THUMBNAIL + 清 PENDING（缩略图已上云）。
          await db.updateAnnotation(ann.MARK_INFO_ID, {
            THUMBNAIL: resp.cloudUrl,
            THUMBNAIL_PENDING: false,
            // P1-24A: 成功复位重试计数（历史失败过的缩略图此轮终于成功）
            THUMB_RETRY_COUNT: 0,
            THUMB_EXHAUSTED: false,
            THUMB_LAST_ERROR: null,
            THUMB_LOCAL_MISSING: false   // 终态复位：同一 id 若曾被判过本地缺失，此处已成功上云
          });
          // P1-18c: 上云成功，出清单
          if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._removeThumbPending === 'function') {
            try { await wpzlSyncEngine._removeThumbPending(ann.MARK_INFO_ID); } catch (e) { /* ignore */ }
          }
          // 标注立即同步策略下，标注可能在缩略图上云前就已 push（THUMBNAIL=null）并标 synced。
          // 这里 markDirty(DIRTY_BIT_THUMBNAIL) 重新标 pending，确保 cloudUrl 被推送；
          // buildDiffUploadDto 在 bits & DIRTY_BIT_THUMBNAIL 时输出 thumbnail=cloudUrl。
          // requestSync('immediate') 让 cloudUrl 即时推送，缩略图尽快在对端补齐。
          if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.markDirty === 'function') {
            try {
              await wpzlSyncEngine.markDirty(ann.MARK_INFO_ID, DIRTY_BIT_THUMBNAIL);
              wpzlSyncEngine.requestSync('immediate');
            } catch (e) { console.warn('[thumbFlush] markDirty/requestSync failed:', e.message); }
          }
          // 更新内存中的 ann 对象（后续循环如果引用同一对象可避免重复读）
          ann.THUMBNAIL = resp.cloudUrl;
          ann.THUMBNAIL_PENDING = false;
          successCount++;
        }
      } catch (e) {
        console.warn('[thumbFlush] upload failed for ' + ann.MARK_INFO_ID + ':', e.message);
        // P1-24A: 计数 + 耗尽（此前每 tick 无限重试 8 张永不停）。耗尽后 collector 跳过但留清单，
        // 复位走 _resetExhaustedState→_resetThumbExhausted（重登/手动重试）。广播按 false→true 跃迁触发。
        try {
          var _maxThumbR = 10;
          if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._getSyncMaxRetries === 'function') {
            _maxThumbR = await wpzlSyncEngine._getSyncMaxRetries();
          }
          var _tc = (ann.THUMB_RETRY_COUNT || 0) + 1;
          var _thumbExhaustNow = _tc >= _maxThumbR && !ann.THUMB_EXHAUSTED;
          await db.updateAnnotation(ann.MARK_INFO_ID, {
            THUMB_RETRY_COUNT: _tc,
            THUMB_EXHAUSTED: ann.THUMB_EXHAUSTED || _tc >= _maxThumbR,
            THUMB_LAST_ERROR: String((e && e.message) || '').slice(0, 200) || null
          });
          ann.THUMB_RETRY_COUNT = _tc;
          if (_thumbExhaustNow) {
            console.warn('[thumbFlush] upload exhausted after ' + _tc + ' retries: ' + ann.MARK_INFO_ID);
            if (typeof _broadcastSyncExhausted === 'function') {
              _broadcastSyncExhausted({ kind: 'thumbnail', id: ann.MARK_INFO_ID, retryCount: _tc });
            }
          }
        } catch (e2) { /* ignore */ }
      }
    }
    if (successCount > 0) console.log('[thumbFlush] uploaded ' + successCount + '/' + pending.length);
  } catch (e) {
    console.warn('[thumbFlush] scan failed:', e.message);
  } finally {
    _thumbnailFlushActive = false;
  }
}

function _swMd5(str) {
  // 简单确定性哈希，用于生成 pageKey/imageKey（非加密用途）
  // 使用 SubtleCrypto SHA-256 取前 32 位十六进制
  if (!str) return '';
  var encoder = new TextEncoder();
  var data = encoder.encode(str);
  return crypto.subtle.digest('SHA-256', data).then(function (hash) {
    var bytes = new Uint8Array(hash);
    var hex = '';
    for (var i = 0; i < Math.min(16, bytes.length); i++) {
      hex += bytes[i].toString(16).padStart(2, '0');
    }
    return hex;
  });
}

// ---------- 文档图片清理（编辑移除图片 / 整篇文档删除时）----------
// 文档 <img data-image-key="K"> 中的 K 即 imageData 的 imageKey（= _swMd5(原始 imageUrl)）；
// pageKey = _swMd5(docWebUri)。移除一张图时需清理本地 imageData（待传/已传）与已上云的 R2 对象。

// 从 bodyHtml 提取所有非空 data-image-key（去重）。SW 无 DOM，用正则。
function extractDocImageKeys(html) {
  if (!html || typeof html !== 'string') return [];
  var keys = [];
  var seen = Object.create(null);
  var re = /data-image-key="([^"]+)"/g;
  var m;
  while ((m = re.exec(html)) !== null) {
    var k = m[1];
    if (k && !seen[k]) { seen[k] = 1; keys.push(k); }
  }
  return keys;
}

// 该文档页是否有批注引用本图：按 objectKey / 原始 imageUrl 做「包含」匹配。
// 批注 END_TAG_NAME/CONTEXT 存的是渲染页看到的（签名）URL，难以精确等值匹配，故用包含；
// 服务端 assets refcount 为最终兜底（跨页/跨记录共享同一 blob 时由 refcount 保护）。
function _docImageReferencedByAnnotation(webUri, needle) {
  if (!needle) return Promise.resolve(false);
  try {
    var store = db._tx('annotations', 'readonly');
    var index = store.index('webUri');
    var range = IDBKeyRange.only(webUri);
    return new Promise(function (resolve, reject) {
      var req = index.getAll(range);
      req.onsuccess = function () {
        var hit = (req.result || []).some(function (a) {
          var tag = a && a.END_TAG_NAME ? String(a.END_TAG_NAME) : '';
          var ctx = a && a.CONTEXT ? String(a.CONTEXT) : '';
          return (tag && tag.indexOf(needle) >= 0) || (ctx && ctx.indexOf(needle) >= 0);
        });
        resolve(hit);
      };
      req.onerror = function () { resolve(false); };
    });
  } catch (e) {
    return Promise.resolve(false);
  }
}

// 清理一组 data-image-key 对应的文档图片（本地 imageData + 云对象）。
// 被同页批注引用的图整图跳过（保守保留）；网络/异常仅告警，不抛出（不阻断文档保存/删除）。
async function cleanupDocImages(webUri, keys) {
  if (!webUri || !Array.isArray(keys) || keys.length === 0) return;
  var pageKey = await _swMd5(webUri);
  if (!pageKey) return;
  for (var i = 0; i < keys.length; i++) {
    var imageKey = keys[i];
    if (!imageKey) continue;
    try {
      var rec = await db.getImageData(pageKey, imageKey);
      if (!rec) continue;
      // 同页批注引用检查：被引用则跳过（不删本地、不删云）
      if (rec.cloudUrl && await _docImageReferencedByAnnotation(webUri, rec.cloudUrl)) continue;
      if (rec.imageUrl && await _docImageReferencedByAnnotation(webUri, rec.imageUrl)) continue;
      // 已上云：服务端递减 refcount（归零才真删 R2 并释放配额）
      if (rec.cloudUrl && typeof wpzl_assetDelete === 'function') {
        try { await wpzl_assetDelete(rec.cloudUrl); }
        catch (e) { console.warn('[cleanupDocImages] assetDelete failed:', e && e.message); }
      }
      // 清本地 imageData（待传/已传记录）
      try { await db.deleteImageData(rec.id); }
      catch (e) { console.warn('[cleanupDocImages] deleteImageData failed:', e && e.message); }
    } catch (e) {
      console.warn('[cleanupDocImages] key failed:', imageKey, e && e.message);
    }
  }
}

// 整篇文档删除前的图片清理（遗留）。
// D1 起：文档图片内嵌进 body（data:image/...;base64），随 body 存 R2；删除文档即删除 body R2
// 对象，图片随之清理。故此处不再需要按 data-image-key 清理 imageData/云对象。保留函数与调用点
// 为 no-op，避免改动删除流程；旧 cleanupDocImages/extractDocImageKeys/_docImageReferencedByAnnotation
// 暂留待后续清理。
async function _cleanupDocImagesBeforeDelete(docId) {
  return;
}

// P1-8（dbVersion 25）: HTML → 检索用纯文本。规则与旧 manager 内联搜索完全一致
//（manager.js 旧 1946 行：剥标签、不去实体、不折叠空白），保证分仓前后正文命中集不变。
// SW 无 DOMParser，用正则（与旧行为同源）。写入时预计算存 docBodies.bodyText。
function _wpzlHtmlToText(html) {
  return String(html || '').replace(/<[^>]+>/g, ' ');
}

// ---------- 初始化 DB ----------
const db = new AnnotationDB();
let dbReady = false;

// 存量快照回填：升级前已采集、但源页未进 pages store 的快照，补建源页记录，
// 避免本次改造（快照从侧栏移除）后这些快照变成「孤儿」无法访问。
// 一次性 best-effort：chrome.storage.local 守卫只跑一次；失败不阻塞 initDB（下次启动重试）。
async function _backfillPagesForSnapshots() {
  if (!db || !db.db) return 0;
  if (!db.db.objectStoreNames.contains('snapshots')) return 0;
  if (!db.db.objectStoreNames.contains('pages')) return 0;
  var guard = await new Promise(function (resolve) {
    try {
      chrome.storage.local.get(['wpzl_snapBackfillDone'], function (r) { resolve(!!(r && r.wpzl_snapBackfillDone)); });
    } catch (e) { resolve(false); }
  });
  if (guard) return 0;
  try {
    var snaps = await db.getAllSnapshots();
    if (!snaps || snaps.length === 0) {
      try { chrome.storage.local.set({ wpzl_snapBackfillDone: true }); } catch (e) { /* ignore */ }
      return 0;
    }
    var sourceUrls = snaps.map(function (s) { return s.sourceWebUri; }).filter(Boolean);
    var existing = [];
    try { existing = await db.getByKeys('pages', sourceUrls); } catch (e) { existing = []; }
    // 同源多快照去重：sourceUrl → 是否已有 page 记录
    var existingMap = {};
    for (var k = 0; k < sourceUrls.length; k++) {
      var su = sourceUrls[k];
      if (!(su in existingMap)) existingMap[su] = existing[k];
    }
    var backfilled = 0;
    for (var i = 0; i < snaps.length; i++) {
      var snap = snaps[i];
      if (!snap.sourceWebUri) continue;
      if (existingMap[snap.sourceWebUri]) continue;
      try {
        await db.ensurePageForSnapshot(snap.sourceWebUri, snap.sourceUrlMd5, snap.domain, snap.title);
        existingMap[snap.sourceWebUri] = true; // 防同源多快照重复 ensure
        backfilled++;
      } catch (e) { /* continue */ }
    }
    try { chrome.storage.local.set({ wpzl_snapBackfillDone: true }); } catch (e) { /* ignore */ }
    try { console.log('[Backfill] pages for snapshots: ' + backfilled); } catch (e) { /* ignore */ }
    return backfilled;
  } catch (e) {
    return 0; // 失败不阻塞；guard 未 set，下次启动重试
  }
}

async function initDB() {
  if (dbReady) return;
  await db.open();
  // 数据迁移在 dbReady=true 之前完成 —— onMessage 的 await initDB() 会自然等到迁移结束，
  // 避免「迁移未跑完就处理 db-operation」的竞态（folder 迁移尤其关键）。
  await _migratePagesToV5();
  await _cleanupDerivedTitleDirty();
  await _fixBrokenHourTimestamps();
  await _migrateFoldersFromSettings(false);
  await _ensureRootFolder();
  // _backfillPagesForSnapshots 已废弃：快照现直接进侧栏，不再需要为源页补建 pages 记录（会造成侧栏重复）。
  dbReady = true;
}

// dbVersion 5 升级：为现有 pages 记录补同步字段（URL_MD5/SYNC_STATUS/FAVORITE/FOLDER_ID）。
// 幂等：用 syncMeta 的 'v5_pages_migrated' 标记。设 SYNC_STATUS=synced 视为已同步基线，
// 避免升级后立即触发全量上传；仅当服务端该 url_md5 的 title 为 NULL 时，由 _updatePageRecord 在下次访问时补传真标题。
async function _migratePagesToV5() {
  try {
    var done = await _syncGetMeta('v5_pages_migrated');
    if (done) return;
    var tx = db.db.transaction('pages', 'readwrite');
    var store = tx.objectStore('pages');
    var all = await new Promise(function (resolve, reject) {
      var r = store.getAll();
      r.onsuccess = function () { resolve(r.result || []); };
      r.onerror = function () { reject(r.error); };
    });
    var changed = 0;
    for (var i = 0; i < all.length; i++) {
      var p = all[i];
      var modified = false;
      if (!p.URL_MD5 && p.url) { p.URL_MD5 = wpzl_md5(p.url); modified = true; }
      if (p.SYNC_STATUS == null) { p.SYNC_STATUS = SYNC_STATUS_SYNCED; modified = true; }
      if (p.SYNC_VERSION == null) { p.SYNC_VERSION = 0; modified = true; }
      if (p.DIRTY_BITS == null) { p.DIRTY_BITS = 0; modified = true; }
      if (p.FAVORITE == null) { p.FAVORITE = false; modified = true; }
      if (p.FOLDER_ID === undefined) { p.FOLDER_ID = null; modified = true; }
      if (modified) { store.put(p); changed++; }
    }
    await new Promise(function (resolve) {
      tx.oncomplete = function () { resolve(); };
      tx.onerror = function () { resolve(); };
    });
    await _syncSetMeta('v5_pages_migrated', true);
    console.log('[DB] pages v5 迁移完成:', changed, '/', all.length);
  } catch (e) {
    console.warn('[DB] pages v5 迁移失败:', e);
  }
}

// 清理"派生 title 被标脏"的假脏 page（旧版 pull 副作用：派生串被标 DIRTY_BIT_TITLE 推送，覆盖服务端真标题）。
// 规则：title 恰好等于 URL 派生串 且标了 DIRTY_BIT_TITLE(128) → 清掉该 bit；若无其他脏字段则改 SYNCED。
// 真实标题（≠派生）的脏记录保留（待推送真标题）。幂等：syncMeta 'cleanup_derived_title_dirty'。
async function _cleanupDerivedTitleDirty() {
  try {
    var done = await _syncGetMeta('cleanup_derived_title_dirty');
    if (done) return;
    var tx = db.db.transaction('pages', 'readwrite');
    var store = tx.objectStore('pages');
    var all = await new Promise(function (resolve, reject) {
      var r = store.getAll();
      r.onsuccess = function () { resolve(r.result || []); };
      r.onerror = function () { reject(r.error); };
    });
    var cleaned = 0;
    for (var i = 0; i < all.length; i++) {
      var p = all[i];
      if (!p.url) continue;
      if ((p.DIRTY_BITS & 128) && p.title === _deriveTitleFromUrl(p.url)) {
        p.DIRTY_BITS = p.DIRTY_BITS & ~128; // 清 DIRTY_BIT_TITLE
        if (p.DIRTY_BITS === 0 && (p.SYNC_STATUS === SYNC_STATUS_LOCAL || p.SYNC_STATUS === SYNC_STATUS_PENDING)) {
          p.SYNC_STATUS = SYNC_STATUS_SYNCED; // 无其他脏 → 已同步基线
        }
        store.put(p);
        cleaned++;
      }
    }
    await new Promise(function (resolve) {
      tx.oncomplete = function () { resolve(); };
      tx.onerror = function () { resolve(); };
    });
    await _syncSetMeta('cleanup_derived_title_dirty', true);
    console.log('[DB] 清理派生 title 假脏 page:', cleaned);
  } catch (e) {
    console.warn('[DB] 清理派生 title 假脏失败:', e);
  }
}

// 一次性修复：Date.format polyfill 的 "HH" bug 导致历史时间戳小时位是字面 "HH"
// （如 "2026-06-17 HH:30:45"），服务端 parseDateTime 解析失败 → LWW 拒绝所有 page/folder 更新。
// 把含 " HH:" 的时间戳小时位改成 "00"（保留日期/分/秒，丢失的精确小时无法恢复）。
// 幂等：syncMeta 'fix_broken_hour_ts'。
async function _fixBrokenHourTimestamps() {
  try {
    var done = await _syncGetMeta('fix_broken_hour_ts');
    if (done) return;
    var tx = db.db.transaction('pages', 'readwrite');
    var store = tx.objectStore('pages');
    var all = await new Promise(function (resolve, reject) {
      var r = store.getAll();
      r.onsuccess = function () { resolve(r.result || []); };
      r.onerror = function () { reject(r.error); };
    });
    function fixTs(s) {
      return (typeof s === 'string' && s.indexOf(' HH:') >= 0) ? s.replace(' HH:', ' 00:') : s;
    }
    var fields = ['lastVisited', 'SERVER_UPDATE_TIME', 'PAGE_NOTE_UPDATED_AT', 'createdAt'];
    var fixed = 0;
    for (var i = 0; i < all.length; i++) {
      var p = all[i];
      var modified = false;
      for (var f = 0; f < fields.length; f++) {
        var nv = fixTs(p[fields[f]]);
        if (nv !== p[fields[f]]) { p[fields[f]] = nv; modified = true; }
      }
      if (modified) { store.put(p); fixed++; }
    }
    await new Promise(function (resolve) { tx.oncomplete = function () { resolve(); }; tx.onerror = function () { resolve(); }; });

    // folders store 同样可能有 HH 时间戳（updatedAt / SERVER_UPDATE_TIME）
    var folderFields = ['updatedAt', 'SERVER_UPDATE_TIME'];
    var ffixed = 0;
    if (db.db.objectStoreNames.contains('folders')) {
      var ftx = db.db.transaction('folders', 'readwrite');
      var fstore = ftx.objectStore('folders');
      var fallen = await new Promise(function (resolve, reject) {
        var r = fstore.getAll();
        r.onsuccess = function () { resolve(r.result || []); };
        r.onerror = function () { reject(r.error); };
      });
      for (var fi = 0; fi < fallen.length; fi++) {
        var ff = fallen[fi];
        var fmod = false;
        for (var ffld = 0; ffld < folderFields.length; ffld++) {
          var fnv = fixTs(ff[folderFields[ffld]]);
          if (fnv !== ff[folderFields[ffld]]) { ff[folderFields[ffld]] = fnv; fmod = true; }
        }
        if (fmod) { fstore.put(ff); ffixed++; }
      }
      await new Promise(function (resolve) { ftx.oncomplete = function () { resolve(); }; ftx.onerror = function () { resolve(); }; });
    }
    await _syncSetMeta('fix_broken_hour_ts', true);
    if (fixed + ffixed > 0) console.log('[DB] 修复 HH 时间戳 bug: pages=' + fixed + ' folders=' + ffixed);
  } catch (e) {
    console.warn('[DB] 修复 HH 时间戳失败:', e);
  }
}

// 从 settings 迁移 folder 数据到 folders store + pages.FOLDER_ID（dbVersion 5 之后）。
// 幂等：syncMeta 'folders_migrated_from_settings'。force=true 时强制重跑（导入旧备份后用）。
// 关键决策：root 节点不进 folders store（内存默认）；expanded 不入 store（chrome.storage.local 纯 UI）。
// 迁移接入 initDB() 内（dbReady=true 之前），避免 onMessage 的 await initDB() 与迁移竞态。
async function _migrateFoldersFromSettings(force) {
  try {
    if (!force) {
      var done = await _syncGetMeta('folders_migrated_from_settings');
      if (done) return;
    }

    // 读 settings.folderTree + settings.pageFolderMap
    var folderTreeData = await new Promise(function (resolve, reject) {
      var s = db._tx('settings', 'readonly');
      var r = s.get('folderTree');
      r.onsuccess = function () { resolve(r.result); };
      r.onerror = function () { reject(r.error); };
    });
    var pageFolderData = await new Promise(function (resolve, reject) {
      var s = db._tx('settings', 'readonly');
      var r = s.get('pageFolderMap');
      r.onsuccess = function () { resolve(r.result); };
      r.onerror = function () { reject(r.error); };
    });
    var oldFolders = (folderTreeData && Array.isArray(folderTreeData.folders)) ? folderTreeData.folders : [];
    var oldMap = (pageFolderData && pageFolderData.map) ? pageFolderData.map : {};

    // 无旧数据 → 直接标记完成
    if (oldFolders.length === 0 && Object.keys(oldMap).length === 0) {
      await _syncSetMeta('folders_migrated_from_settings', true);
      return;
    }

    var ts = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
    var folderInserted = 0;
    var pageUpdated = 0;

    // 1) 迁移 folder 节点（跳过 root）→ folders store，SYNCED 基线（不触发全量推送）
    if (oldFolders.length > 0) {
      var ftx = db.db.transaction('folders', 'readwrite');
      var fstore = ftx.objectStore('folders');
      for (var i = 0; i < oldFolders.length; i++) {
        var f = oldFolders[i];
        if (!f || !f.id || f.id === 'root') continue;
        fstore.put({
          folderId: f.id,
          name: f.name || '',
          // 保留 'root' 作为父引用（root 子目录嵌套在内存 root 下）；不要转 null，否则层级错乱
          parentFolderId: f.parentId || null,
          orderSeq: f.order || 0,
          updatedAt: ts,
          SYNC_STATUS: SYNC_STATUS_SYNCED,
          SYNC_VERSION: 0,
          SERVER_UPDATE_TIME: null,
          DIRTY_BITS: 0
        });
        folderInserted++;
      }
      await new Promise(function (resolve) { ftx.oncomplete = function () { resolve(); }; ftx.onerror = function () { resolve(); }; });
    }

    // 2) 回填 pages.FOLDER_ID（旧 url→folderId 映射）。指向 root/空 → null（未分类）。
    //    标脏推送（DIRTY_BIT_FOLDER + PENDING）让服务端拿到归属（一次性代价）。
    var urls = Object.keys(oldMap);
    if (urls.length > 0) {
      var ptx = db.db.transaction('pages', 'readwrite');
      var pstore = ptx.objectStore('pages');
      for (var k = 0; k < urls.length; k++) {
        var u = urls[k];
        var targetFid = (!oldMap[u] || oldMap[u] === 'root') ? null : oldMap[u];
        var ex = await new Promise(function (resolve, reject) {
          var r = pstore.get(u);
          r.onsuccess = function () { resolve(r.result); };
          r.onerror = function () { reject(r.error); };
        });
        if (ex) {
          // 仅回填无归属的旧记录（FOLDER_ID 为 null/undefined）；新备份/同步下来的归属不覆盖，避免污染
          if (ex.FOLDER_ID !== undefined && ex.FOLDER_ID !== null) continue;
          if (targetFid === null) continue; // 旧 map 也指向未分类，无需写
          ex.FOLDER_ID = targetFid;
          if (ex.SYNC_STATUS !== SYNC_STATUS_PENDING_DELETED) {
            ex.SYNC_STATUS = (ex.SYNC_STATUS === SYNC_STATUS_SYNCED) ? SYNC_STATUS_PENDING : (ex.SYNC_STATUS || SYNC_STATUS_PENDING);
            ex.DIRTY_BITS = (ex.DIRTY_BITS || 0) | DIRTY_BIT_FOLDER;
            // bump lastVisited（=同步 updatedAt），否则这次归属变更会被服务端 LWW 拒绝（旧时间 vs 服务端已同步时间）
            ex.lastVisited = ts;
          }
          pstore.put(ex);
          pageUpdated++;
        }
      }
      await new Promise(function (resolve) { ptx.oncomplete = function () { resolve(); }; ptx.onerror = function () { resolve(); }; });
    }

    await _syncSetMeta('folders_migrated_from_settings', true);
    console.log('[DB] folder 迁移完成: folders=' + folderInserted + ' pages=' + pageUpdated);
  } catch (e) {
    console.warn('[DB] folder 迁移失败:', e);
  }
}

// 确保默认目录（id='root'）作为【普通一级目录】存在于 folders store，仅对新用户一次性创建。
// root 现已无任何特殊逻辑，与普通 folder 完全同构（折叠/改名/同步/删除一致）。
// 策略：
//  - 用户已删除默认目录（wpzl_df_del_<uid>=true）→ 永不重建，尊重删除；
//  - 已存在 root 记录（active 或 tombstone）→ 不动（不再"复活"，避免与改名做 LWW 竞争打回旧名）；
//  - 全新用户（无记录、无删除标记）→ 创建 name=本地化默认目录名（defaultFolderName），orderSeq 走顶层 maxOrder+1（普通算法）。
async function _ensureRootFolder() {
  try {
    if (!db || !db.db) return;
    var identity = await db.getUserIdentity();
    var uid = (identity && identity.userId) || (identity && identity.authorId) || '';

    // 用户已删除默认目录 → 尊重删除，不重建
    var delFlagKey = 'wpzl_df_del_' + uid;
    var delFlag = await new Promise(function (resolve) {
      try {
        chrome.storage.local.get([delFlagKey], function (r) { resolve(!!(r && r[delFlagKey])); });
      } catch (e) { resolve(false); }
    });
    if (delFlag) return;

    // 已存在 root 记录（active 或 tombstone）→ 不动（含用户已改的名字；tombstone 不再复活）
    var existing = await new Promise(function (resolve, reject) {
      var s = db._tx('folders', 'readonly');
      var r = s.get('root');
      r.onsuccess = function () { resolve(r.result); };
      r.onerror = function () { reject(r.error); };
    });
    if (existing) return;

    // 全新用户：创建默认目录，orderSeq 走顶层 maxOrder+1（普通算法，新用户即 0）
    var topMaxOrder = await new Promise(function (resolve, reject) {
      var s = db._tx('folders', 'readonly');
      var r = s.getAll();
      r.onsuccess = function () {
        var mx = -1;
        (r.result || []).forEach(function (f) {
          if (!f || f.SYNC_STATUS === SYNC_STATUS_PENDING_DELETED) return;
          if (!f.parentFolderId) { mx = Math.max(mx, f.orderSeq || 0); }
        });
        resolve(mx);
      };
      r.onerror = function () { reject(r.error); };
    });
    var ts = wpzlFormatUTCDate(new Date(), 'yyyy-MM-dd HH:mm:ss');
    var record = {
      folderId: 'root',
      name: chrome.i18n.getMessage('defaultFolderName'),
      parentFolderId: null,
      orderSeq: topMaxOrder + 1,
      USER_ID: uid,
      updatedAt: ts,
      SYNC_STATUS: SYNC_STATUS_LOCAL,
      SYNC_VERSION: 0,
      SERVER_UPDATE_TIME: null,
      DIRTY_BITS: 0xFF
    };
    await new Promise(function (resolve, reject) {
      var s = db._tx('folders', 'readwrite');
      var r = s.put(record);
      r.onsuccess = function () { resolve(r.result); };
      r.onerror = function () { reject(r.error); };
    });
    console.log('[DB] 默认目录(root) 已创建（新用户）');
  } catch (e) {
    console.warn('[DB] _ensureRootFolder 失败:', e);
  }
}

// ---------- 安装事件 ----------
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    console.log('Sagitnote 已安装');
    // v1.2.0: 新装即开欢迎文档（fenxi 2026-11-01「最紧急 #1」）——30 秒完成第一条高亮。
    // 仅 install（存量用户 update 不打扰）；地址跟 WPZL_SERVER_BASE（开发=本机 server，发布由 apply-env 注入）；
    // tabs.create 免权限；离线/server 不可达时只是打开错误页，无崩溃路径。install 语义天然一次，无需存储标记。
    try {
      var _wpzlWelcomeBase = (typeof WPZL_SERVER_BASE !== 'undefined') ? String(WPZL_SERVER_BASE).replace(/\/+$/, '') : '';
      if (_wpzlWelcomeBase) chrome.tabs.create({ url: _wpzlWelcomeBase + '/d/welcome' });
    } catch (e) { /* ignore */ }
  } else if (details.reason === 'update') {
    console.log('Sagitnote 已更新到版本', chrome.runtime.getManifest().version);
  }
  await initDB();
  // 注册 Pro 到期检测 alarm（6 小时周期）
  try {
    chrome.alarms.create('pro-expiry-check', { periodInMinutes: 6 * 60 });
    // 兜底连通性检测：每 5 分钟检查 dirty 队列，非空才触发 sync
    chrome.alarms.create('connectivity-tick', { periodInMinutes: 5 });
  } catch (e) { /* ignore */ }
});

// ============================================================
// Sync State Machine (4 states: ONLINE / SYNCING / OFFLINE / TOKEN_EXPIRED)
// ============================================================

var wpzl_sync_state = 'offline'; // default; SW restart → real state set on first sync/check
var wpzl_sync_meta = { lastSyncAt: null, pushed: 0, pulled: 0 };
// P1-8: online 事件去抖——浏览器恢复联网时每个 tab/frame 的 content.js 各发一条
// wpzl-online-event，N 条 = N 次 2s 探活（sync 有 withSyncLock 串行，但探活是真实发出的）。
// SW 消息会重置空闲计时器，模块变量在突发窗口内存活；SW 被杀后归零，最坏多探活一次，无害。
var _lastOnlineHandledAt = 0;

function wpzl_setSyncState(newState, meta) {
  // token_expired 不去重：每次 sync 失败都要广播，确保新开的 tab/manager 能收到
  if (newState === wpzl_sync_state && !meta && newState !== 'token_expired') return;
  wpzl_sync_state = newState;
  if (meta) {
    wpzl_sync_meta = Object.assign({}, wpzl_sync_meta, meta);
    if (meta.lastSyncAt) wpzl_sync_meta.lastSyncAt = meta.lastSyncAt;
  }
  console.log('[SyncState] → ' + newState, wpzl_sync_meta);
  // 广播给所有标签页：chrome.runtime.sendMessage 只能到达扩展页（popup/manager），
  // content.js 必须用 chrome.tabs.sendMessage 才能收到。
  // callback 内必须读 chrome.runtime.lastError 以"消费"该错误，否则 Chrome 会报
  // "Unchecked runtime.lastError: Could not establish connection. Receiving end does not exist."
  // （对 chrome:// / 其它扩展页 / 还没注入 content.js 的 tab 是正常情况）
  var payload = {
    type: 'wpzl-sync-state',
    state: wpzl_sync_state,
    meta: wpzl_sync_meta
  };
  try {
    chrome.runtime.sendMessage(payload, function () { void chrome.runtime.lastError; });
  } catch (e) { /* ignore */ }
  chrome.tabs.query({}, function (tabs) {
    if (!tabs) return;
    tabs.forEach(function (tab) {
      if (!tab.id) return;
      try {
        chrome.tabs.sendMessage(tab.id, payload, function () { void chrome.runtime.lastError; });
      } catch (e) { /* ignore */ }
    });
  });
  // 持久化 lastSyncAt（SW 重启不丢）
  if (newState === 'online' && wpzl_sync_meta.lastSyncAt) {
    chrome.storage.local.set({ wpzl_last_sync_at: wpzl_sync_meta.lastSyncAt });
  }
}

// 读取同步状态机当前值（与 wpzl_setSyncState 对称）。所有发请求的入口（sync/flush）用它做
// 可达性 gate：脱机（offline）时直接短路，避免逐项发注定失败的请求。详见脱机整体休眠优化方案。
function wpzl_getSyncState() {
  return wpzl_sync_state;
}

// 广播 Pro 状态变更（等级/限额/到期）给所有 content/manager，让页面内 feature-gate 限额热刷新。
// 仿 wpzl_setSyncState：runtime.sendMessage 到扩展页 + tabs.sendMessage 到所有页面。
function _broadcastProStatusUpdated(pro) {
  if (!pro) return;
  var payload = {
    type: 'wpzl-pro-status-updated',
    isPro: !!pro.isPro,
    gradeConfig: pro.gradeConfig || null,
    defaultGradeConfig: pro.defaultGradeConfig || null,
    isLoggedIn: true,
    // 到期时间与完整限额随广播下发：manager 等级标签/限额 UI 热刷新需要
    //（content.js 只读已知字段，多出的字段无害）
    expiresAt: pro.expiresAt || null,
    limits: pro.limits || null,
    // snapSizeLimit 必须随广播下发：snapshot-capture 从 meta 读此值做采集前大小校验，
    // 缺失则长开页面永远停在加载时的旧值（即便 SW 缓存已刷新到新限额）。
    snapSizeLimit: (pro.limits && pro.limits.snapSizeLimit != null) ? pro.limits.snapSizeLimit : null,
    // 到期提醒提前天数（服务端判定：30=年付档/3=月付档/null=不提醒）：
    // manager 等级标签"临期"态与顶部横幅热刷新需要。
    expiryReminderDays: (pro.expiryReminderDays != null) ? pro.expiryReminderDays : null
  };
  try {
    chrome.runtime.sendMessage(payload, function () { void chrome.runtime.lastError; });
  } catch (e) { /* ignore */ }
  chrome.tabs.query({}, function (tabs) {
    if (!tabs) return;
    tabs.forEach(function (tab) {
      if (!tab.id) return;
      try {
        chrome.tabs.sendMessage(tab.id, payload, function () { void chrome.runtime.lastError; });
      } catch (e) { /* ignore */ }
    });
  });
}

// ---------- Pro 到期前提醒 ----------
// 规则（周期判定唯一真相源在服务端 /pro/status 的 expiryReminderDays）：
//   年付（窗口 30 天）：剩余≤30 天发一次系统通知，剩余≤3 天升档再发一次；
//   月付（窗口 3 天）：剩余≤3 天发一次。
// 去重状态锚定 expiresAt：续费后到期时间变化 → 状态整体自然重置，无需清理逻辑。
// SW 内存变量会被回收，状态必须落 chrome.storage.local（同 wpzl_exhausted_notify 先例）。

// 扩展页 tab 复用（登记制，免 "tabs" 权限）：
// 5297abd 移除 activeTab 后，无 "tabs" 权限的扩展在 chrome.tabs.query 里连自己
// chrome-extension:// 页面的 URL 都不可见，按 url 匹配一律落空 → 「已开则聚焦」
// 全部退化为重复开新 tab。改为扩展页（manager/upgrade）onload 用
// chrome.tabs.getCurrent() 把自己的 tabId 登记进 storage.session，打开方按 id
// tabs.get 探活：活着聚焦、失效新建（自愈），并辅以 onRemoved 除名双保险。
function _wpzlGetRegisteredTab(key, cb) {
  try {
    chrome.storage.session.get([key], function (r) {
      var id = r && r[key];
      if (id == null) { cb(null); return; }
      chrome.tabs.get(id, function (t) {
        if (chrome.runtime.lastError || !t || t.id == null) cb(null);
        else cb(t);
      });
    });
  } catch (e) { cb(null); }
}

// 登记表除名：tab 被关（含 popup 窗口被关）即清 key，避免 storage 里留死 id
chrome.tabs.onRemoved.addListener(function (tabId) {
  try {
    chrome.storage.session.get(['wpzl_mgr_tab_id', 'wpzl_upg_tab_id'], function (r) {
      if (!r) return;
      if (r.wpzl_mgr_tab_id === tabId) chrome.storage.session.remove('wpzl_mgr_tab_id');
      if (r.wpzl_upg_tab_id === tabId) chrome.storage.session.remove('wpzl_upg_tab_id');
    });
  } catch (e) { /* ignore */ }
});

// 升级面板 = 独立小弹窗（upgrade/upgrade.html）；已打开则聚焦其窗口，避免堆叠。
// 从 wpzl-open-upgrade 消息分支提取为独立函数：到期提醒的系统通知点击也要复用同一入口
//（manager 顶栏按钮 / popup / 注入面板更多菜单 / 到期通知点击 四入口统一）。
var _wpzlUpgOpening = false; // 开窗在途守卫：连点入口时不重复创建（登记键由页面异步写入，存在窗口期）
function _wpzlOpenUpgradePanel() {
  if (_wpzlUpgOpening) return;
  _wpzlUpgOpening = true;
  var _upgUrl = chrome.runtime.getURL('upgrade/upgrade.html');
  _wpzlGetRegisteredTab('wpzl_upg_tab_id', function (t) {
    if (t) {
      chrome.tabs.update(t.id, { active: true });
      if (t.windowId != null) chrome.windows.update(t.windowId, { focused: true });
      _wpzlUpgOpening = false;
    } else {
      // 760×720：与 upgrade/upgrade.css 的双栏布局（左侧套餐卡 + 权益对比 / 右侧 272px 结算摘要）匹配。
      // 窄屏由 Chrome 自行收敛，页面在 <720px 时降级为单列（见 upgrade.css 尾部媒体查询）。
      chrome.windows.create({ url: _upgUrl, type: 'popup', width: 760, height: 720 }, function (w) {
        // 立即登记新窗口 tabId：页面侧登记是加载后异步写的，不预登记时连点会再开一个面板
        var nt = w && w.tabs && w.tabs[0];
        if (nt && nt.id != null) {
          try { chrome.storage.session.set({ wpzl_upg_tab_id: nt.id }); } catch (e) { /* ignore */ }
        }
        _wpzlUpgOpening = false;
      });
    }
  });
}

// 同产品下单在途去重表（productCode → 待回复的 sendResponse 列表），见 payment-create-order 分支
var _wpzlPayCreateInFlight = {};

var WPZL_PRO_EXPIRY_NOTIFY_KEY = 'wpzl_pro_expiry_notify';
var WPZL_PRO_EXPIRY_NOTIFY_ID = 'wpzl-pro-expiry';

// 纯函数：距到期剩余天数（向上取整），解析失败返回 null。
// 服务端到期串为 UTC-naive：_wpzlSyncParseStoredDate 按 UTC 构造（裸 new Date 按本地时区解释会偏一个时区）；
// 非 naive 格式（ISO 带 Z/偏移等）交 Date.parse 兜底。
function _wpzlProExpiryDaysLeft(expiresAt) {
  var d = _wpzlSyncParseStoredDate(expiresAt);
  var ms = d ? d.getTime() : Date.parse(expiresAt);
  return isNaN(ms) ? null : Math.ceil((ms - Date.now()) / 86400000);
}

// 到期提醒评估：进入提醒窗口时发一次系统通知（固定 id，重复 create 是替换不堆叠）。
// 挂点：pro-expiry-check alarm（6h）/ onStartup / pro-status forceRefresh（打开 popup/manager 即评估）。
function _wpzlEvalProExpiryReminder(pro) {
  if (!pro || !pro.isPro || !pro.expiresAt || pro.expiryReminderDays == null) return;
  var daysLeft = _wpzlProExpiryDaysLeft(pro.expiresAt);
  if (daysLeft == null || daysLeft < 0) return;  // 已过期交给现有 expiredQuota 弹窗
  var windowDays = pro.expiryReminderDays;       // 30（年付）或 3（月付），服务端判定
  if (daysLeft > windowDays) return;             // 未进提醒窗口
  // 当前档：年付剩余≤3 天升到 3 档（升档再提醒一次）；月付恒为 3 档
  var tier = (windowDays >= 30 && daysLeft <= 3) ? 3 : windowDays;
  var tierKey = 'notified' + tier;               // notified30 / notified3（布尔置位，避免数值比较方向写反）
  chrome.storage.local.get([WPZL_PRO_EXPIRY_NOTIFY_KEY], function (r) {
    var st = (r && r[WPZL_PRO_EXPIRY_NOTIFY_KEY]) || null;
    if (st && st.expiresAt !== pro.expiresAt) st = null;  // 续费后 expiresAt 变化 → 整体重置
    if (st && st[tierKey]) return;                        // 本档已发过
    try {
      chrome.notifications.create(WPZL_PRO_EXPIRY_NOTIFY_ID, {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icons/icon128.png'),
        title: chrome.i18n.getMessage('proExpiryNotifyTitle') || 'Pro',
        message: chrome.i18n.getMessage('proExpiryNotifyMessage', [String(daysLeft)]) || '',
        priority: 2
      }, function () { void chrome.runtime.lastError; });  // 用户关系统通知权限时静默失败
    } catch (e) { /* ignore */ }
    var next = { expiresAt: pro.expiresAt, notified30: !!(st && st.notified30), notified3: !!(st && st.notified3) };
    next[tierKey] = true;
    chrome.storage.local.set({ [WPZL_PRO_EXPIRY_NOTIFY_KEY]: next }, function () { void chrome.runtime.lastError; });
  });
}

// 系统通知点击 → 打开升级面板（顶层同步注册：事件监听器不能放在回调里，SW 回收后需能重新挂上）
chrome.notifications.onClicked.addListener(function (id) {
  if (id !== WPZL_PRO_EXPIRY_NOTIFY_ID) return;
  _wpzlOpenUpgradePanel();
  try { chrome.notifications.clear(id, function () { void chrome.runtime.lastError; }); } catch (e) { /* ignore */ }
});

// 用户面板：把服务端返回的 UserInfoResponse 合并回 wpzl_auth.user（保留原 accessToken 等会话字段）。
async function _wpzlMergeAuthUser(user) {
  var auth = await new Promise(function (res) {
    chrome.storage.local.get(['wpzl_auth'], function (r) { res(r.wpzl_auth || null); });
  });
  if (auth) {
    auth.user = user;
    await new Promise(function (res) { chrome.storage.local.set({ wpzl_auth: auth }, res); });
  }
}

// 用户面板：本地头像缓存（chrome.storage.local），键内嵌 userId 防换号残留。
async function _wpzlSaveLocalAvatar(userId, dataUrl, updatedAt) {
  await new Promise(function (res) {
    chrome.storage.local.set({ wpzl_avatar: { userId: userId, dataUrl: dataUrl, updatedAt: updatedAt || null } }, res);
  });
}

// dataURL → Blob（头像上传用）。
function _wpzlDataUrlToBlob(dataUrl) {
  var m = /^data:([^;]+);base64,(.*)$/.exec(dataUrl);
  if (!m) throw new Error('invalid dataUrl');
  var contentType = m[1];
  var binary = atob(m[2]);
  var bytes = new Uint8Array(binary.length);
  for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: contentType });
}

// F-1: 私网/本地目标判定。页面 world 可经 saveImageFromUrl 等桥 op 驱动 SW fetch，
// SW 持 <all_urls> 且不受页面 CORS 约束——放行私网即构成借扩展身份的 SSRF/内网探测通道。
function _wpzlIsPrivateNetworkHost(hostname) {
  var h = String(hostname || '').toLowerCase().replace(/^\[|\]$/g, '');
  if (!h) return true;
  if (h === 'localhost' || h === '0.0.0.0' || h === '::' || h === '::1') return true;
  if (h.slice(-10) === '.localhost' || h.slice(-6) === '.local' || h.slice(-9) === '.internal') return true;
  // IPv4 直接量（含 ::ffff: 映射形式）
  var v4 = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(h) ? h : (/^::ffff:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$/.exec(h) || [])[1];
  if (v4) {
    var p = v4.split('.');
    var a = +p[0], b = +p[1];
    for (var i = 0; i < 4; i++) { if (+p[i] > 255) return false; } // 非合法 IP 按普通域名处理
    if (a === 0 || a === 10 || a === 127) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 169 && b === 254) return true;
    if (a === 100 && b >= 64 && b <= 127) return true; // CGNAT 100.64/10
    return false;
  }
  // IPv6：链路本地 fe80::/10 与唯一本地 fc00::/7（fc/fd 开头）保守拒绝
  if (h.indexOf(':') >= 0 && /^(fe8|fe9|fea|feb|fc|fd)/.test(h)) return true;
  return false;
}

// 预签名 URL → dataURL（头像拉取回填）。头像 ~50KB，手动 base64 足够。
// E-P2-3: 裸 fetch 无超时——签名 URL 挂起会永久卡住调用方，统一收口 30s。
async function _wpzlFetchBlobAsDataUrl(url) {
  var resp = await _wpzlFetchWithTimeout(url, {}, 30000);
  if (!resp.ok) throw new Error('avatar fetch failed: ' + resp.status);
  var buf = await resp.arrayBuffer();
  var bytes = new Uint8Array(buf);
  var binary = '';
  for (var i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return 'data:' + (resp.headers.get('Content-Type') || 'image/webp') + ';base64,' + btoa(binary);
}

// P1-36: db-operation 写操作 → 受影响 store 映射。dispatcher 成功后向扩展页广播
// wpzl-data-changed，多 manager tab 失效重拉（A 删 B 感知），防止 B 基于旧列表操作复活墓碑。
var _DB_WRITE_OP_STORES = {
  saveAnnotation: ['annotations', 'pages'],
  deleteAnnotation: ['annotations'],
  deletePage: ['pages', 'annotations', 'imageData'],
  updateAnnotation: ['annotations'],
  restoreBackup: ['annotations', 'pages', 'folders', 'documents', 'snapshots', 'imageData', 'tags', 'localThumbnails'],
  restoreChunk: ['annotations', 'pages', 'folders', 'documents', 'snapshots', 'imageData', 'tags', 'localThumbnails'],
  migrateData: ['annotations', 'pages'],
  migrateFoldersFromSettings: ['folders', 'pages'],
  clearAllData: ['*'],
  deleteImageData: ['imageData'],
  saveImageData: ['imageData'],
  saveImageFromUrl: ['imageData'],
  saveImageFromBase64: ['imageData'],
  backfillImageDataFromUrl: ['imageData'],
  cleanupImageReferences: ['imageData'],
  saveLocalThumbnail: ['localThumbnails', 'annotations'],
  backfillThumbnailFromCloud: ['annotations'],
  claimPageAnnotations: ['annotations', 'pages'],
  savePageNote: ['pages'],
  setFavorite: ['pages'],
  putFolder: ['folders'],
  softDeleteFolder: ['folders'],
  saveTag: ['tags'],
  setPageFolderId: ['pages'],
  renamePage: ['pages'],
  setSortOrders: ['pages', 'documents', 'snapshots'],
  putDocument: ['documents', 'docBodies'],
  softDeleteDocument: ['documents', 'docBodies'],
  deleteDocument: ['documents', 'docBodies'],
  putSnapshot: ['snapshots', 'snapBodies'],
  softDeleteSnapshot: ['snapshots', 'snapBodies'],
  deleteSnapshot: ['snapshots', 'snapBodies'],
  updateImageDataField: ['imageData'],
  updateAuthorName: ['annotations']
};
// 按 originTabId 分桶 500ms 去抖：合并同源突发（如连续 saveAnnotation），不同源各自广播
// （合并成一条会携带单一 originTabId，误吞其它源的 origin 过滤或误含 origin 自身）。
// 只走 chrome.runtime.sendMessage 单通道——manager/popup 是扩展页，content.js 对未知类型
// 无消费（其监听只认 auth-state-changed），无需 tabs.query 双通道（比 wpzl_setSyncState 省）。
// SW 内部直调 db.* 的路径（软删/同步引擎）不广播——同步驱动的变更已有 wpzl-sync-state
// online → manager 刷新链覆盖。
var _dataChangedTimers = {};   // originTabId -> { stores:Set, timer }
function _broadcastDataChanged(stores, originTabId) {
  var key = (originTabId == null) ? -1 : originTabId;
  var entry = _dataChangedTimers[key];
  if (!entry) {
    entry = { stores: new Set(), timer: null };
    _dataChangedTimers[key] = entry;
  }
  for (var i = 0; i < (stores || []).length; i++) entry.stores.add(stores[i]);
  if (entry.timer) clearTimeout(entry.timer);
  entry.timer = setTimeout(function () {
    delete _dataChangedTimers[key];
    try {
      chrome.runtime.sendMessage({
        type: 'wpzl-data-changed',
        stores: Array.from(entry.stores),
        originTabId: (key === -1) ? null : key
      }, function () { void chrome.runtime.lastError; });
    } catch (e) { /* ignore */ }
  }, 500);
}

// SW 启动时恢复 lastSyncAt
chrome.storage.local.get(['wpzl_last_sync_at'], function (r) {
  if (r.wpzl_last_sync_at) {
    wpzl_sync_meta.lastSyncAt = r.wpzl_last_sync_at;
  }
});

// 本地 IDB 数据只能由用户在 UI 手动「清空数据」/「退出并清空」清除（见 clearAllData /
// _wpzlLogoutAndClearLocal 消息处理）。任何自动场景（token 失效、断网、未登录、启动/升级自检）
// 都绝不清本地数据——这是产品铁律：插件要在 token 失效/离线时仍可用。
// 曾有的 _auditUserIDBConsistency「强制登录模型」自检会按鉴权状态自动清 IDB，已整函数移除。

// Pro 到期检测：每 6 小时主动刷新，Pro→Free 跌落时通知 sync engine 关同步
// P0-4: connectivity-tick 重排抽成独立 async 函数（自包含重读 health/backoff/queue 状态，
// 读取失败时 _cf/_sec 归 0 自然落最低档——与原内联逻辑一致）。由 tick handler 的 finally
// 调用：此前重排在 handler 末尾、外层 catch 不重排，主体任何异常即扯断闹钟链，而闹钟
// 只在 onInstalled 创建 → 本会话无自愈，兜底同步/图片补传/队列排空全部停摆。
async function _rescheduleConnectivityTick() {
  try {
    var _cf = 0;
    try {
      var _health = await wpzlSyncEngine.getHealth();
      _cf = (_health && _health.consecutiveFailures) || 0;
    } catch (e) { /* ignore */ }
    var _seBackoff = null;
    var _sePaused = false;
    if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._getServerErrBackoff === 'function') {
      try {
        _seBackoff = await wpzlSyncEngine._getServerErrBackoff();
        _sePaused = !!(_seBackoff && _seBackoff.pausedUntil > Date.now());
      } catch (e) { /* ignore */ }
    }
    // 服务端错误连续次数：与 _cf 合成有效失败档位。network 失败只走 _cf（保持现状升档）。
    var _sec = (_seBackoff && _seBackoff.serverErrorCount) || 0;
    var _eff = Math.max(_cf, _sec);
    // 排空循环：队列仍有非 exhausted 条目时钉最低档，直到空或再次失败升级（计划 4d.5）。
    // 修正：仅「无服务端错误」时才钉最低档——服务端 5xx 时逐轮打全量 sync 正是要抑制的场景，必须允许升档。
    var _queueDraining = false;
    try {
      if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._offlineQueueHasPending === 'function') {
        _queueDraining = await wpzlSyncEngine._offlineQueueHasPending();
      }
    } catch (e) { /* ignore */ }
    var jMin, jMax;
    if (_queueDraining && _sec === 0) { jMin = 3.5; jMax = 6.5; }
    else if (_eff <= 1)              { jMin = 3.5; jMax = 6.5; }
    else if (_eff <= 3)              { jMin = 7;   jMax = 13;  }
    else if (_eff <= 5)              { jMin = 15;  jMax = 25;  }
    else                             { jMin = 25;  jMax = 35;  }
    // 熔断激活时：下次 tick 排到冷却到期后 +1min 抖动（half-open），clamp 5-60min
    if (_sePaused && _seBackoff) {
      var _remainMin = Math.ceil(((_seBackoff.pausedUntil - Date.now()) / 60000) + 1);
      jMin = Math.max(5, Math.min(60, _remainMin));
      jMax = jMin + 2;
    }
    var nextDelay = jMin + Math.random() * (jMax - jMin);
    try { chrome.alarms.clear('connectivity-tick'); } catch (e) { /* ignore */ }
    chrome.alarms.create('connectivity-tick', { delayInMinutes: nextDelay });
  } catch (e) {
    console.warn('[Sync] reschedule connectivity-tick failed:', e && e.message);
  }
}

// P0-4: 兜底——闹钟链万一断裂（仅 onInstalled 创建，无其它恢复点），SW/浏览器启动时补建。
function ensureConnectivityAlarm() {
  try {
    chrome.alarms.get('connectivity-tick', function (existing) {
      if (!existing) {
        console.warn('[Sync] connectivity-tick 闹钟丢失，补建（1min 后进入抖动链自愈）');
        chrome.alarms.create('connectivity-tick', { delayInMinutes: 1 });
      }
    });
  } catch (e) { /* ignore */ }
}

chrome.alarms.onAlarm.addListener(async function (alarm) {
  if (alarm.name === 'sync-resume') {
    // 大同步断点续传兜底（Bug 7）：用户不活跃时由 alarm 唤醒 SW 续传
    if (typeof wpzlSyncEngine !== 'undefined') wpzlSyncEngine.requestSync('immediate');
    return;
  }
  if (alarm.name === 'sync-init-jitter') {
    // E-P2-4: init 末尾浪涌打散 alarm 到期——flush 期间累积的 pending 请求
    //（SW 若在等待期被回收，本 alarm 负责重新唤醒；无 pending 时为幂等 no-op）
    if (typeof wpzlSyncEngine !== 'undefined' && wpzlSyncEngine._flushPendingSyncRequest) {
      try { wpzlSyncEngine._flushPendingSyncRequest(); } catch (e) { /* ignore */ }
    }
    return;
  }
  if (alarm.name === 'image-sync-resume') {
    // image-sync-downloader 兜底：跨设备 pull 拿到 cloudUrl 后拉 blob 回填 data
    if (typeof _processImageSyncBatch === 'function') _processImageSyncBatch();
    return;
  }
  if (alarm.name === 'doc-sync-resume') {
    // doc-sync-downloader 兜底（D3）：跨设备 pull 拿到 bodyObjectKey 后后台拉 body 回填 docBodies
    if (typeof _processDocSyncBatch === 'function') _processDocSyncBatch();
    return;
  }
  if (alarm.name === 'connectivity-tick') {
    // 5 分钟兜底 + 随机抖动 + 连续失败退避
    try {
      // 脱机整体休眠：先探活，不可达则整体跳过所有发请求步骤（避免逐项烧注定失败的 R2/sync 请求）。
      // 探针失败也 bump consecutiveFailures，让退避矩阵自然升档到 25-35min 稳态。
      var online = await _wpzlCheckConnectivity();
      // 服务端错误熔断状态（一次读，gate 与排 alarm 共用；探活失败路径不读不写——network 侧保持现状）
      var _seBackoff = null;
      var _sePaused = false;
      if (online && typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._getServerErrBackoff === 'function') {
        try {
          _seBackoff = await wpzlSyncEngine._getServerErrBackoff();
          _sePaused = !!(_seBackoff && _seBackoff.pausedUntil > Date.now());
        } catch (e) { /* ignore */ }
      }
      if (!online) {
        wpzl_setSyncState('offline');
        try { await wpzlSyncEngine._updateHealth(false, 0, 0, 0, 0, 'connectivity probe failed'); } catch (e) { /* ignore */ }
      } else if (_sePaused) {
        // 熔断冷却期：探活通也不发业务同步请求（探活可达 ≠ /api/v1/sync 可用）。
        // 置 server_error 供 manager 展示并让各 gate 拿到正确状态；本地缩略图补传无服务器 sync 压力，保留。
        wpzl_setSyncState('server_error');
        if (typeof _flushPendingThumbnails === 'function') {
          try { await _flushPendingThumbnails(); } catch (e) { /* ignore */ }
        }
      } else {
        // 先置 online，让 _uploadPendingImages/_flushPendingThumbnails/flushOfflineQueue 的 offline gate 放行
        wpzl_setSyncState('online');
        // 断网积压补传：先尝试把本地未上云图片推到 R2
        if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._uploadPendingImages === 'function') {
          try { await wpzlSyncEngine._uploadPendingImages(); } catch (e) { /* ignore */ }
        }
        // 修复 BUG-4：缩略图补传挂到 connectivity-tick（原来仅 SW 启动/online 事件触发，瞬态失败要等 SW 重启）。
        // 复用本 alarm 的退避抖动 + clear/重建；_thumbnailFlushActive 重入锁保证并发安全。
        if (typeof _flushPendingThumbnails === 'function') {
          try { await _flushPendingThumbnails(); } catch (e) { /* ignore */ }
        }
        // 排空标记 FIFO 队列（断网期间积压的标注离线操作；计划 4d）。计数权威在 sync()。
        if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.flushOfflineQueue === 'function') {
          try { await wpzlSyncEngine.flushOfflineQueue(); } catch (e) { /* ignore */ }
        }
        // P1-23: R2 清理补偿队列重试（每 tick ≤10 条；成功/404 出队）
        if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._flushR2DeleteQueue === 'function') {
          try { await wpzlSyncEngine._flushR2DeleteQueue(); } catch (e) { /* ignore */ }
        }
        // P1-17: imageData 容量治理（7 天节流；超水位清冷数据的 data 留 cloudUrl 指针）
        if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._maybeEvictImageData === 'function') {
          try { await wpzlSyncEngine._maybeEvictImageData(); } catch (e) { /* ignore */ }
        }
        var dirtyCount = await wpzlSyncEngine.getDirtyCount();
        if (dirtyCount > 0) {
          wpzl_setSyncState('syncing');
          try {
            // 冷却刚过期的这一轮即 half-open 探测：正常走 sync，成功由 _updateHealth 全复位
            await wpzlSyncEngine.sync('manual');
          } catch (e) {
            console.warn('[Sync] connectivity-tick sync failed:', e.message);
          }
        } else {
          // P1-5：无脏也以非 manual 优先级调一次 sync——no_dirty_skip 块按"上次成功拉取"
          // 30min 冷却放行轻量 pull（多数 tick 在块内直接本地跳过、零请求），对端删除
          // 不再依赖打开页面/手动同步才可见。非 manual 优先级保证不会每 tick 都发请求。
          try {
            await wpzlSyncEngine.sync('probe');
          } catch (e) { /* ignore：探活已通过，此处失败由健康度体系接管 */ }
        }
      }
    } catch (e) {
      console.warn('[Sync] connectivity-tick error:', e.message);
    } finally {
      // P0-4: 重排必须在 finally —— 主体任何异常都不能扯断闹钟链（详见 _rescheduleConnectivityTick 注释）
      _rescheduleConnectivityTick();
    }
    return;
  }
  if (alarm.name !== 'pro-expiry-check') return;
  wpzl_getProStatus(true).then(function (pro) {
    _wpzlEvalProExpiryReminder(pro);
    chrome.storage.local.get(['wpzl_pro_last_ispro'], function (r) {
      var prev = r.wpzl_pro_last_ispro;
      chrome.storage.local.set({ wpzl_pro_last_ispro: !!pro.isPro });
      if (prev === true && !pro.isPro && typeof wpzlSyncEngine !== 'undefined') {
        wpzlSyncEngine.onProChanged(false);
      }
    });
  }).catch(function () { /* ignore */ });
});

// 浏览器启动时主动检查一次 Pro 状态
chrome.runtime.onStartup.addListener(function () {
  ensureConnectivityAlarm();  // P0-4: 启动兜底，防闹钟链断裂后本会话无自愈
  initDB().then(function () {
    return wpzl_getProStatus(true);
  }).then(function (pro) {
    _wpzlEvalProExpiryReminder(pro);
    if (!pro.isPro && typeof wpzlSyncEngine !== 'undefined') {
      wpzlSyncEngine.onProChanged(false);
    }
  }).catch(function () { /* ignore */ });
});

// 初始化 DB
initDB();

// 认领中断自愈（2026-11）：SW 每次冷启动检查一次认领标志——顶层执行天然覆盖 onStartup
//（后者只在浏览器启动时触发，覆盖不了 MV3 SW 空闲回收后重启）；无标志时一次 storage 读即返回。
try { _wpzlRepairPendingClaim(); } catch (e) { /* ignore */ }

// v1.1.0: 卸载原因收集 —— 浏览器原生接口：用户卸载扩展时自动打开问卷页（匿名，URL 无任何标识符/参数）。
// 地址跟随 WPZL_SERVER_BASE（源码默认本机 server，发布构建由 apply-env.mjs 注入生产地址）；
// 问卷页由 webpz-server 静态资源提供（/uninstall-survey.html，与提交接口同源），随 server 部署同步。
// 顶层执行 = 每次 SW 冷启动重注册（顶层 onStartup/onMessage 监听保证浏览器启动后 SW 必跑一次）。
try {
  var _wpzlUninstallBase = (typeof WPZL_SERVER_BASE !== 'undefined') ? String(WPZL_SERVER_BASE).replace(/\/+$/, '') : '';
  if (_wpzlUninstallBase) chrome.runtime.setUninstallURL(_wpzlUninstallBase + '/uninstall-survey.html');
} catch (e) { /* ignore */ }

// ---------- Sync Engine 初始化 + 周期同步 ----------

// Init sync engine after DB is ready (migrations now run inside initDB)
initDB().then(function () {
  if (typeof wpzlSyncEngine !== 'undefined') {
    wpzlSyncEngine.init().catch(function (e) {
      console.warn('[Sync] Init failed:', e);
    });
  }
  // 本地模式（游客档）：SW 启动即按登录态刷新工具栏 badge（未登录 → 橙色「!」）
  _wpzlRefreshActionBadge();
  // SW 启动后做一次连通性探测：若服务器可达且当前无 dirty 数据，
  // 直接进入 'online' 状态（避免 SW 重启后 stuck 在默认 'offline'）
  // 同时触发积压缩略图补传（用户关机重启后自动恢复上传）。
  if (typeof _wpzlCheckConnectivity === 'function') {
    _wpzlCheckConnectivity().then(async function (online) {
      // SW 重启后按持久化退避状态恢复：熔断在 storage 中，重启不重置（观感与实际防护一致）
      var _sePausedCs = false;
      try {
        if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._isServerErrPaused === 'function') {
          _sePausedCs = await wpzlSyncEngine._isServerErrPaused();
        }
      } catch (e) { /* ignore */ }
      if (online && wpzl_sync_state === 'offline') {
        wpzl_setSyncState(_sePausedCs ? 'server_error' : 'online');
      }
      if (online) {
        _flushPendingThumbnails().catch(function () { /* 静默 */ });
        // P1-6: 探活翻 online 后补跑离线队列排空——init() 内的 flushOfflineQueue 与本探活并发，
        // init 那次在 state 仍为 'offline' 时已早退（sync-engine 内部 state 门），此刻必须补跑，
        // 否则离线积压要等下一个 connectivity-tick。内部自检 state/paused/hasNonExhausted，无冗余 sync。
        if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.flushOfflineQueue === 'function') {
          wpzlSyncEngine.flushOfflineQueue().catch(function () { /* 静默 */ });
        }
      }
    }).catch(function () { /* ignore */ });
  }
});

// Periodic sync alarm listener — 已禁用定时同步
// chrome.alarms.onAlarm.addListener(function (alarm) {
//   if (alarm.name === 'sync-periodic') {
//     if (typeof wpzlSyncEngine !== 'undefined') {
//       wpzlSyncEngine.sync('normal').catch(function (e) {
//         console.warn('[Sync] Periodic sync failed:', e);
//       });
//     }
//   }
// });

// ---------- 未登录本地模式（游客档）常量 ----------
// 与服务端免费档（user_grades id=1, is_default=true）**现行值**人工对齐（2026-10-19 按线上免费用户
// /pro/status 实测：arrow/flag/rect/pageRect/rectFrame/elementMark/line/textAnnotation/imageAnnotation
// 均 5/页，highlight 不限；totalLimitPerPage 50，colors -1，exportFormats [json,csv,markdown]，
// customColorPicker false；docLimit 3，docSizeLimit 5000000，dailyMarkLimit 100，markLimit 50000，
// pageLimit -1，assetCountLimit -1）。
// ⚠️ 改服务端免费档配置时必须双改此处（见 webpz-lite-reference.md「未登录本地模式」章）。
// 结构性差异（游客无账号，非限额口径，保持禁用，勿改）：
//   - features cloudSync/collaboration/imageCloudUpload 全 false（登录后才有云侧能力）
//   - syncEnabled/shareLimit/shareReplyLimit/snapLimit/snapSizeLimit/cloudStorageMb 置 0/false
//     —— 其中 snapSizeLimit 0 兼作禁快照双保险（bundle 侧 meta 下发后 snapshot-capture 恒
//     throw snapshotForbidden）。
// 单一真相源：content.js（injectProGlobals 游客分支）与 manager（游客档加载）经 guest-grade-config
// 消息读取，勿在别处复制。
var WPZL_GUEST_GRADE_CONFIG = {
  perTypeLimits: {
    arrow: { enabled: true, limitPerPage: 5 },
    flag: { enabled: true, limitPerPage: 5 },
    rect: { enabled: true, limitPerPage: 5 },
    pageRect: { enabled: true, limitPerPage: 5 },
    rectFrame: { enabled: true, limitPerPage: 5 },
    elementMark: { enabled: true, limitPerPage: 5 },
    line: { enabled: true, limitPerPage: 5 },
    textAnnotation: { enabled: true, limitPerPage: 5 },
    imageAnnotation: { enabled: true, limitPerPage: 5 },
    highlight: { enabled: true, limitPerPage: -1 }
  },
  totalLimitPerPage: 50,
  colors: -1,
  customColorPicker: false,
  exportFormats: ['json', 'csv', 'markdown'],
  features: { cloudSync: false, collaboration: false, imageCloudUpload: false }
};
var WPZL_GUEST_LIMITS = {
  markLimit: 50000,
  docLimit: 3,
  docSizeLimit: 5000000,
  snapSizeLimit: 0,        // 0 = 禁快照（双保险，见上）
  dailyMarkLimit: 100,
  shareLimit: 0,
  snapLimit: 0,
  syncEnabled: false,
  cloudStorageMb: 0,
  exportFormats: ['json', 'csv', 'markdown'],
  pageLimit: -1,
  assetCountLimit: -1,
  shareReplyLimit: 0
};

// ---------- 本地数据归属（多账号隔离：切换账号拦截 + 设置页清空） ----------

// 本地数据归属的账号 {userId, loginId}。登录/注册通过时写入，设置页清空时清除；
// onLogout 不清（登出后仍需记得归谁，以便下次登录判断是否切换账号）。
async function _getLocalDataOwner() {
  return new Promise(function (resolve) {
    chrome.storage.local.get(['wpzl_local_data_owner'], function (x) {
      resolve(x.wpzl_local_data_owner || null);
    });
  });
}
async function _setLocalDataOwner(o) {
  return new Promise(function (resolve) {
    chrome.storage.local.set({ wpzl_local_data_owner: o }, resolve);
  });
}

// 导入时取当前持有者 USER_ID：优先 wpzl_local_data_owner.userId（登录后写入），
// 否则用 settings.userIdentity.userId（未登录时的本地身份）
async function _getCurrentUserIdForImport() {
  var owner = await _getLocalDataOwner();
  if (owner && owner.userId) return owner.userId;
  if (db) {
    try {
      var identity = await db.getUserIdentity();
      if (identity && identity.userId) return identity.userId;
      if (identity && identity.authorId) return identity.authorId;
    } catch (e) { /* ignore */ }
  }
  return '';
}

// 为跨用户导入的标注生成全新 MARK_INFO_ID。
// 格式：首字母（类型标识 t/a/r/p/f/i/c）+ 13 位时间戳 + 10 位 base62 随机 = 24 字符
// 保留原 ID 首字母以维持类型语义，时间戳+随机段全新，避免反复导出/导入导致前缀无限增长。
// ⚠️ 导入判定**刻意不按 objectKey 形状硬判**，别改成"匹配某个正则才算数"。原因：
//   1. R2 key 空间不止缩略图一种形状——u/{uid}/{32hex}/{32hex}.webp（缩略图/图片）、
//      u/{uid}/doc/{docId}.html（文档 body）、u/{uid}/snap/{hash}.html（快照 body）、
//      u/{uid}/avatar.webp（头像），目录段与扩展名各不相同。
//   2. 同一类 key 的格式本身会演进——缩略图已变过一次：u/{uid}/{64hex}.webp → 当前形状。
// 按形状判有两个方向的错：
//   - 判宽了（只要非空就置 PENDING）→ 给"本地根本没字节"的值排队，永远传不上去；
//   - 判窄了（只认当前正则，其余静默清空）→ **格式一变就无声丢数据**，且**旧格式备份若真带了
//     localThumbnails 字节也会被误判为"已丢失"**（能救的没救）。
// 正确做法：只看"源机上有过截图吗"，把"能不能传"交给 _flushPendingThumbnails 用本地字节裁决
//（有字节 → 真补传；无字节 → 置可见终态，不静默）。形状无关，天然抗格式演进。
function _classifyImportedThumb(value, currentUserId) {
  var v = String(value == null ? '' : value);
  if (!v) return 'clear';
  // 历史序列化脏值（网页侧 ann.THUMBNAIL=null 经 formatParams 变成字符串）：从来没截过图，无信息
  if (v === 'null' || v === 'undefined') return 'clear';
  // 本账号命名空间的 key：本机可签名，原样保留
  if (v.indexOf('u/' + currentUserId + '/') === 0) return 'keep';
  // 内联图：字节就在值里——不是远端对象，存本地再补传
  if (v.indexOf('data:image') === 0) return 'seed';
  // 其余非空值一律当"源机上有过截图"：置 PENDING 交补传器裁决（形状无关）
  return 'pending';
}

// 按分档就地改写导入记录。返回档名（仅用于日志/诊断）。
// ⚠️ 本函数在导入的**同步** map 回调里被调用：里面的 ltStore.put 绝不能 await ——
// 一旦 await 会让 annotations 事务在微任务间隙自动提交，其后 store.put 报 TransactionInactiveError。
function _applyImportedThumb(record, currentUserId, ltStore) {
  if (!record || !record.THUMBNAIL) return 'none';
  var bucket = _classifyImportedThumb(record.THUMBNAIL, currentUserId);
  if (bucket === 'keep') return bucket;
  if (bucket === 'seed' && ltStore && record.MARK_INFO_ID) {
    // pageKey 留空：_flushPendingThumbnails 取的是 ann._pageKey，缺失时自会由 WEB_URI 现算
    //（localThumbnails 记录的 pageKey 字段无人读取）。此处只保证字节进了本地库。
    try {
      ltStore.put({ annId: record.MARK_INFO_ID, pageKey: '', data: record.THUMBNAIL, ts: Date.now() });
    } catch (e) { /* ignore */ }
  }
  // 清空外来/旧格式 key（本机签不了名），改由补传器按本地字节重建自有 key
  record.THUMBNAIL = null;
  // 备份/上轮导入可能带来的失败与终态标记，随 THUMBNAIL 一并复位
  record.THUMB_RETRY_COUNT = 0;
  record.THUMB_EXHAUSTED = false;
  record.THUMB_LOCAL_MISSING = false;
  record.THUMB_LAST_ERROR = null;
  // seed 与 pending 都置 PENDING：由 _flushPendingThumbnails 裁决（有本地字节 → 真补传；
  // 没有 → 置可见终态 local_thumbnail_missing）。导入阶段不预判"能不能传"，否则会误杀
  // 那些"旧格式 key 但备份确实带了字节"的记录。
  record.THUMBNAIL_PENDING = true;
  return bucket;
}

function _generateNewMarkInfoId(originalId) {
  var prefix = (originalId && originalId.length > 0) ? originalId.charAt(0) : 't';
  var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var randomPart = '';
  var ts = String(Date.now());
  // 13 位时间戳（左侧补零到 13 位，防止 Date.now() 位数变化）
  while (ts.length < 13) ts = '0' + ts;
  randomPart += ts;
  // 10 位 base62 随机
  var arr = new Uint8Array(10);
  crypto.getRandomValues(arr);
  for (var j = 0; j < 10; j++) randomPart += chars[arr[j] % chars.length];
  return prefix + randomPart;
}

// 合并 annId 进 thumb_pending_ids 有界清单（一次读-并-写）。restoreBackup/认领路径批量置位
// THUMBNAIL_PENDING 后调用——清单（syncMeta）不进备份文件，导入侧必须显式补记。
// 不走 _reconcilePendingWorkLists：它有 pending_lists_reconciled_at 节流，SW 运行中调用
// 可能被静默跳过；此处直接写清单保证置位即可被 _flushPendingThumbnails 取走。
// 交 sync-engine 的 _mergeThumbPendingIds 处理：它在串行链内重读清单，避免与并发的
// _noteThumbPending 互相覆盖（此处若自己 get→union→set 就是同一个丢更新陷阱）。
async function _wpzlMergeThumbPendingIds(ids) {
  if (!ids || ids.length === 0) return;
  if (typeof wpzlSyncEngine === 'undefined' || !wpzlSyncEngine._mergeThumbPendingIds) return;
  try { await wpzlSyncEngine._mergeThumbPendingIds(ids); } catch (e) { /* ignore */ }
}

// 属主变更（备份导入 / 登录认领 / 旧数据迁移）时复位记录级同步状态。
// SYNC_EXHAUSTED / SYNC_LAST_ERROR / SYNC_RETRY_COUNT / SYNC_LAST_ATTEMPT_AT 是「上一个账号 +
// 上一次配额口径」的产物——迁到新账号后既无意义又致命：与 SYNC_STATUS='pending' 并存会构成
// pending+exhausted 的矛盾死状态（dirty 收集器按 !SYNC_EXHAUSTED 过滤 → 永不上传；限额类原因
// 又让 manager 隐藏重试按钮 → 用户无路可走；而唯一的自动恢复探测已因切号清标志而失效）。
// dl* 是下载侧同款账号口径状态（doc-sync-downloader / image-sync-downloader），一并复位。
// 不动 SYNC_VERSION / SERVER_UPDATE_TIME / SYNCED_AT / createdAt：那是内容版本的 LWW 记账，与账号无关。
function _resetRecordSyncState(rec) {
  if (!rec) return rec;
  rec.SYNC_STATUS = 'pending';
  rec.DIRTY_BITS = 0xFF;
  rec.SYNC_EXHAUSTED = false;
  rec.SYNC_RETRY_COUNT = 0;
  rec.SYNC_LAST_ERROR = null;
  rec.SYNC_LAST_ATTEMPT_AT = null;
  rec.dlExhausted = false;
  rec.dlRetryCount = 0;
  rec.dlLastError = null;
  return rec;
}

// 登录后批量改写本地持有权（annotations + pages + folders + documents + snapshots 五 store
// 一次遍历，外加 imageData / tags 两个补漏块）：
//   - USER_ID 无条件全改为登录用户（持有权总是归登录用户；imageData/tags 同口径，见各自块注释）
//   - annotations 额外：AUTHOR_ID === baselineAuthorId（或为空）→ 是自己创建的，作者身份也改为登录用户；
//     否则（导入的他人标注）→ AUTHOR_ID/AUTHOR_NAME 保留（原始创建者）
//   - 变更记录都标 SYNC_STATUS='pending' + DIRTY_BITS=0xFF，让同步把持有权变更推到服务端
//   - uidChanged 时置 IS_IMPORTED=1（V70 游客认领豁免每日限额）
async function _rewriteLocalOwnershipToUser(baselineAuthorId, userId, userName) {
  if (!db || !db.db) return { annotations: 0, pages: 0, folders: 0, documents: 0, snapshots: 0, tags: 0, imageData: 0 };
  var uid = String(userId);
  var uname = userName || '';
  var baseline = baselineAuthorId ? String(baselineAuthorId) : null;
  var result = { annotations: 0, pages: 0, folders: 0, documents: 0, snapshots: 0, tags: 0, imageData: 0 };
  var newlyPendingThumbIds = [];   // 认领中新置位 THUMBNAIL_PENDING 的标注 id（完成后并入清单）
  var storeNames = ['annotations', 'pages', 'folders', 'documents', 'snapshots'];
  for (var i = 0; i < storeNames.length; i++) {
    var storeName = storeNames[i];
    if (!db.db.objectStoreNames.contains(storeName)) continue;
    await new Promise(function (resolve, reject) {
      var store = db._tx(storeName, 'readwrite');
      var req = store.openCursor();
      req.onsuccess = function (e) {
        var cursor = e.target.result;
        if (cursor) {
          var record = cursor.value;
          if (!record) { cursor.continue(); return; }
          // 只在字段实际变化时才标 pending + 0xFF。
          // 设计原则：服务端同步下来的记录 SYNC_STATUS='synced'，不该被登录流程改成 pending 再次重传。
          // 首次登录 USER_ID 必变 → 标 pending 让首次推送带上 USER_ID；
          // 同账号重登时 USER_ID 已是登录用户 → 跳过，保持 synced。
          var changed = false;
          var uidChanged = false;   // V70: USER_ID 实际变更（=游客认领/缺属主补写），导入豁免置位条件
          var existingUid = record.USER_ID != null ? String(record.USER_ID) : '';
          if (existingUid !== uid) {
            record.USER_ID = uid;
            changed = true;
            uidChanged = true;
          }
          if (storeName === 'annotations') {
            var aid = record.AUTHOR_ID != null ? String(record.AUTHOR_ID) : '';
            if (!aid || aid === baseline) {
              if (record.AUTHOR_ID !== uid) { record.AUTHOR_ID = uid; changed = true; }
              if (record.AUTHOR_NAME !== uname) { record.AUTHOR_NAME = uname; changed = true; }
            }
            // THUMBNAIL 拷贝认领——同 restoreBackup 内同名分支说明：清外来命名空间 objectKey
            // + 置 PENDING 交 _flushPendingThumbnails 用本地截图补传到登录账号命名空间。
            if (record.THUMBNAIL && String(record.THUMBNAIL).indexOf('u/' + uid + '/') !== 0) {
              record.THUMBNAIL = null;
              record.THUMBNAIL_PENDING = true;
              record.THUMB_RETRY_COUNT = 0;
              record.THUMB_EXHAUSTED = false;
              changed = true;
              if (record.MARK_INFO_ID) newlyPendingThumbIds.push(record.MARK_INFO_ID);
            }
          }
          if (storeName === 'documents' || storeName === 'snapshots') {
            // bodyObjectKey 指向他人命名空间对象（跨账号残留，key 形如 u/{旧uid}/doc|snap/...）：
            // 清 key+hash，让下次上传走「无 key → 带 bodyHtml」分支把 body 落到本账号
            //（不清则上传恒发 bodyHtml=null，服务端永不落 body——存储视图/管理页文档恒空）。
            if (record.bodyObjectKey && String(record.bodyObjectKey).indexOf('u/' + uid + '/') !== 0) {
              record.bodyObjectKey = null;
              record.bodyContentHash = null;
              changed = true;
            }
          }
          if (changed) {
            // 属主变更 → 复位记录级同步状态（见 _resetRecordSyncState 说明）：上一账号留下的
            // 失败原因/耗尽标志对新账号无意义，只改状态不清它们会产出 pending+exhausted 死状态。
            _resetRecordSyncState(record);
            // V70 游客认领豁免（spec §6.1）：USER_ID 实际变更 = 游客档/无主数据首次归属登录账号，
            // 历史回灌首次创建同步豁免每日限额。跨账号切换路径已被 needsClear 拦截/清空不命中；
            // 同账号重登 USER_ID 不变不命中——所以必须用 uidChanged 而非 changed（后者含
            // AUTHOR_NAME/缩略图认领等非属主变更）。
            if (uidChanged && (storeName === 'annotations' || storeName === 'documents' || storeName === 'snapshots')) {
              record.IS_IMPORTED = 1;
            }
            cursor.update(record);
            result[storeName]++;
          }
          // 必须同步调用 cursor.continue() 保持事务活跃；
          // 不能用 setTimeout 让出事件循环 — IDB 事务会在闲置时自动提交，后续 continue 会抛 TransactionInactiveError。
          cursor.continue();
        } else {
          resolve();
        }
      };
      req.onerror = function () { reject(req.error); };
    });
  }
  // imageData 块（USER_ID 无条件改写 + 外来命名空间 cloudUrl 认领）。外来 cloudUrl（u/他人/...，
  // 脱机导入未登录时无法判断命名空间，登录走本函数是认领点）：本机永远无法签名解析（属主 403），
  // 且会被 P1-17 当"已上云"按最老 SYNCED_AT 优先清 data → 图丢。导入即拷贝认领：清外来 key；
  // 有本地 data 的置 pending 交 _uploadPendingImages 补传到登录账号命名空间（与新生成的图
  // 同一条管道：权限门禁/配额/积压上限全生效）；无 data 的死记录只清 key。
  if (db.db.objectStoreNames.contains('imageData')) {
    await new Promise(function (resolve) {
      var store = db._tx('imageData', 'readwrite');
      var req = store.openCursor();
      req.onsuccess = function (e) {
        var cursor = e.target.result;
        if (!cursor) { resolve(); return; }
        var record = cursor.value;
        if (record) {
          var changed = false;
          // 游客认领补漏（2026-11）：USER_ID 无条件改写为登录 uid——与上方 5 个核心 store 的
          // 持有权处理对齐（那里同样无条件改 USER_ID、仅有条件保留 AUTHOR 署名，「保留外来」的
          // 类比不成立）。不改则 restoreBackup 导入的标注（核心 store 已改游客 ID、imageData 仍
          // 原属主）认领后按 userId_pageKey 复合索引（getImageDataByPage）查不到 → 图片批注整批
          // 隐形。外来属主不阻断，见 classifyLocalOwnership 头注释。
          if (record.USER_ID == null || String(record.USER_ID) !== uid) {
            record.USER_ID = uid;
            changed = true;
            result.imageData++;
          }
          if (record.cloudUrl && String(record.cloudUrl).indexOf('u/' + uid + '/') !== 0) {
            record.cloudUrl = null;
            // 属主变更 → 复位记录级失败状态（同 restoreBackup 内同名分支说明：大写=元数据上传侧、
            // 小写=R2 上传侧，两套都在用，都要清）
            record.SYNC_LAST_ERROR = null;
            record.SYNC_LAST_ATTEMPT_AT = null;
            record.SYNC_EXHAUSTED = false;
            record.SYNC_RETRY_COUNT = 0;
            record.lastError = null;
            record.exhausted = false;
            record.retryCount = 0;
            if (record.data) {
              record.SYNC_STATUS = 'pending';
              record.DIRTY_BITS = 0;
              record.firstPendingAt = new Date().toISOString();
            }
            changed = true;
          }
          if (changed) cursor.update(record);
        }
        // 同上：continue 必须同步调用，保持 IDB 事务活跃
        cursor.continue();
      };
      req.onerror = function () { resolve(); };
    });
  }
  // 游客认领补漏（2026-11）：tags USER_ID 全量改写为登录 uid。登录后 getAllTags 按 tags.userId
  // 索引过滤，不改写则游客创建/导入的标签登录后全部不可见。tags 主键是 name、跨用户同名互覆
  // 本就是现状（见 saveTag 内注释），全量改写安全；tags 不在同步通道（无 syncStatus 索引、
  // 不在 push 实体列表），不置 pending（置了无人消费）。外来属主不阻断，同 imageData。
  if (db.db.objectStoreNames.contains('tags')) {
    await new Promise(function (resolve) {
      var store = db._tx('tags', 'readwrite');
      var req = store.openCursor();
      req.onsuccess = function (e) {
        var cursor = e.target.result;
        if (!cursor) { resolve(); return; }
        var record = cursor.value;
        if (record && (record.USER_ID == null || String(record.USER_ID) !== uid)) {
          record.USER_ID = uid;
          cursor.update(record);
          result.tags++;
        }
        cursor.continue();
      };
      req.onerror = function () { resolve(); };
    });
  }
  // 认领完成：把新置位 PENDING 的 id 并入 thumb_pending_ids 有界清单——本函数置位的
  // THUMBNAIL_PENDING（含脱机导入后登录场景）立即可被 _flushPendingThumbnails 取走。
  try { await _wpzlMergeThumbPendingIds(newlyPendingThumbIds); } catch (e) { /* ignore */ }
  return result;
}

// 认领中断自愈（2026-11，P0-2）。背景：分支①把 token+owner+wpzl_claim_pending 一次原子写入后、
// _rewriteLocalOwnershipToUser + identity 重写完成前 SW 被杀/浏览器崩溃 → owner==auth，
// manager 属主守卫放行、全部读路径按新 uid 过滤 → 本地数据**隐形（未删）**；用户此时登出走
// 物理清空 = 真丢。repair 幂等补完整条认领尾序（改写只在字段实际变化时写；identity/目录
// 重建均为幂等写），正常路径（登录流程走完 / 登出清库）都会消费掉标志，本函数空转一次 storage 读。
// 触发点：SW 每次冷启动（顶层，onStartup 只在浏览器启动时触发、覆盖不了 MV3 空闲回收重启）
// + manager DOMContentLoaded（wpzl-repair-claim 消息，先 repair 再渲染，保证认领数据先可见）。
// 校验 auth.user.id === owner.userId 才执行（防跨账号误改写；不变量破坏时交 manager 分裂态守卫兜底）。
async function _wpzlRepairPendingClaim() {
  try {
    var stored = await new Promise(function (resolve) {
      chrome.storage.local.get(['wpzl_claim_pending', 'wpzl_auth', 'wpzl_local_data_owner'], function (x) { resolve(x); });
    });
    if (!stored || !stored.wpzl_claim_pending) return { repaired: false, reason: 'no-pending' };
    var auth = stored.wpzl_auth;
    var owner = stored.wpzl_local_data_owner;
    if (!auth || !auth.user || !owner || String(owner.userId) !== String(auth.user.id)) {
      // 不变量被破坏（跨账号/半登出）：不改写不清标志，交由 manager 阻断对话框兜底
      return { repaired: false, reason: 'owner-mismatch' };
    }
    if (!dbReady) { try { await initDB(); } catch (e) { /* ignore */ } }
    if (!db || !db.db) return { repaired: false, reason: 'db-unavailable' };
    var identity = null;
    try { identity = await db.getUserIdentity(); } catch (e) { /* ignore */ }
    // 中断点在「改写 → identity 重写」序内，identity.authorId 仍是原始游客 id（正确 baseline）；
    // 若 identity 已重写（= 序列实际已走完，只剩标志未清），改写幂等空转、补写 identity/目录后清标志。
    var baseline = identity && identity.authorId;
    var uid = String(owner.userId);
    var uname = (auth.user && auth.user.name) || (identity && identity.authorName) || '';
    var rw = await _rewriteLocalOwnershipToUser(baseline, uid, uname);
    try {
      await db.saveSetting({ key: 'userIdentity', authorId: uid, userId: uid, authorName: uname, loginId: owner.loginId || (auth.user && auth.user.loginId) || '' });
    } catch (e) { /* ignore */ }
    try { await _ensureRootFolder(); } catch (e) { /* ignore */ }
    await new Promise(function (resolve) { chrome.storage.local.remove(['wpzl_claim_pending'], resolve); });
    console.log('[Auth] claim repair done:', JSON.stringify(rw));
    return { repaired: true, result: rw };
  } catch (e) {
    // 失败保留标志：下次冷启动/manager 打开再试
    console.warn('[Auth] claim repair failed (kept pending):', e && e.message);
    return { repaired: false, reason: 'error', error: e && e.message };
  }
}

// 第三方登录（OAuth）：拉起 provider 授权页（launchWebAuthFlow）拿到授权码，
// 再调服务端换本系统 token。返回 user 供 _finalizeAuth 复用归属判定。
// 取消授权 / 无 code → 抛错（由路由 catch 转 {success:false,error}）。
async function wpzl_handleOAuthLogin(provider) {
  var redirectUri = chrome.identity.getRedirectURL();
  var authorizeUrl = await wpzl_getOAuthAuthorizeUrl(provider, redirectUri);
  var callbackUrl = await new Promise(function (resolve) {
    chrome.identity.launchWebAuthFlow({ url: authorizeUrl, interactive: true }, function (cbUrl) {
      if (chrome.runtime.lastError || !cbUrl) {
        resolve(null);
      } else {
        resolve(cbUrl);
      }
    });
  });
  if (!callbackUrl) {
    var canceled = new Error(chrome.i18n.getMessage('authOauthCanceled') || 'Authorization canceled.');
    canceled.kind = 'canceled';
    throw canceled;
  }
  var callbackUrlObj = new URL(callbackUrl);
  var code = callbackUrlObj.searchParams.get('code');
  // SEC-05（2026-09-19 审计复核）：state 由服务端 authorize-url 生成并随授权 URL 下发，
  // provider 原样回传到落地页——提取后随换码请求上送，服务端一次性校验（防 login CSRF：
  // 受害者被诱导提交攻击者的授权码时，攻击者的 state 未曾在本地发起过，校验必败）。
  var oauthState = callbackUrlObj.searchParams.get('state');
  if (!code) {
    throw new Error(chrome.i18n.getMessage('authOauthFailed') || 'Third-party sign-in failed.');
  }
  return await wpzl_oauthLogin(provider, code, redirectUri, oauthState);
}

// 登录/注册成功拿到 user 后的归属判定（auth-login / auth-register / auth-oauth 共用）。
// authData：登录函数构造的 wpzl_auth 待写对象（_wpzlSetTokensData 产物）——通过分支才落盘。
// 返回给 UI 的响应对象：
//   {success:true, data:user}              通过（首次/同账号/空库静默切换）
//   {success:false, blocked:true, ...}     不同账号且本地有数据 → 拦截，UI 弹通知（仅关闭）；拦截分支零写入（原会话保持）
// D-13: 登录成功广播 auth-state-changed{isLoggedIn:true}。接收方（content.js 热激活/
// manager 等）早已就位，但此前全扩展无发送方——登录后已打开页面永无面板，reload 才恢复。
// 双通道与 wpzl_setSyncState 同因：chrome.runtime.sendMessage 只达扩展页（popup/manager），
// content.js 必须用 chrome.tabs.sendMessage 才能收到；lastError 必须消费（对 chrome:// 等
// 无接收端的 tab 是正常情况）。
function _broadcastAuthStateChanged(payload) {
  try {
    chrome.runtime.sendMessage(payload, function () { void chrome.runtime.lastError; });
  } catch (e) { /* ignore */ }
  try {
    chrome.tabs.query({}, function (tabs) {
      if (!tabs) return;
      tabs.forEach(function (tab) {
        if (!tab.id) return;
        try {
          chrome.tabs.sendMessage(tab.id, payload, function () { void chrome.runtime.lastError; });
        } catch (e2) { /* ignore */ }
      });
    });
  } catch (e) { /* ignore */ }
  // 登录/登出广播后同步刷新工具栏 badge（本地模式警示/清空）
  _wpzlRefreshActionBadge();
}

// 未登录本地模式（游客档）：工具栏 badge 警示。
// 未登录 → 橙色「!」（全局，提示当前为本地模式）；已登录 → 清空（sync 连败警示由
// sync-engine 随后自行复写）。已知限制：登录瞬间清 badge 可能抹一次 sync 连败警示
//（新会话重新累计，可接受）；sync-engine 的 badge 写入点不改。
function _wpzlRefreshActionBadge() {
  try {
    chrome.storage.local.get(['wpzl_auth'], function (r) {
      var _loggedIn = !!(r && r.wpzl_auth && r.wpzl_auth.user);
      if (_loggedIn) {
        chrome.action.setBadgeText({ text: '' });
      } else {
        chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
        chrome.action.setBadgeText({ text: '!' });
      }
    });
  } catch (e) { /* ignore */ }
}

async function _finalizeAuth(user, authData, opts) {
  // 确保数据库已初始化（countAnnotations 依赖 db）
  if (!dbReady) {
    try { await initDB(); } catch (e) { /* ignore */ }
  }
  // 取登录前的本地身份，用于判定"这条标注是不是我自己创建的"
  var preLoginIdentity = null;
  try { preLoginIdentity = await db.getUserIdentity(); } catch (e) { /* ignore */ }
  var baselineAuthorId = preLoginIdentity && preLoginIdentity.authorId;

  var owner = await _getLocalDataOwner();
  var isSame = owner && String(owner.userId) === String(user.id);

  if (!owner) {
    // 未登录本地模式（游客档，2026-09-29 引入；2026-11-05 改造为归属分流，见
    // docs/plan/2026-11-05-guest-data-login-claim.md）：本地有数据时先做归属分类
    //（classifyLocalOwnership，与 wpzl-has-local-data 的 preAction 同一决策源）——
    //   - 全部游客自有（USER_ID ∈ 自有集合）→ 不再拦截/清空，直接落入下方「首次登录/注册」
    //     认领路径（_rewriteLocalOwnershipToUser 改写持有权 + IS_IMPORTED=1 走 V70 导入限额豁免）。
    //     即使调用方误传 forceClearLocal 也【忽略】——本地数据持久化铁律：清空只能由用户在 UI
    //     显式确认，而新 UI 对自有数据根本不会弹确认；把「想清空」降级为「保留并认领」是更安全的
    //     方向（此分支只为兜住「扩展更新瞬间旧 auth.js 页面还在内存」的窗口）。勿"修复"回去。
    //   - 含外来属主记录（他人数据）→ 维持既有硬约束：未显式确认清空（opts.forceClearLocal）
    //     → 拦截兜底——漏预检的调用方（bundle 内联登录、旧前端、直接消息）绝不静默认领；
    //     确认过则先清空再认领（库已空，认领空转无害）。
    //   - 分类/探测抛错 → fail-closed 一律按外来处理（IDB 本身有故障时放行认领 = 静默吞数据）。
    var _hasData = false;
    // 用 hasAnyProtectableData（排除自动补建的纯净默认目录）——hasAnyUserData 在这里会
    // 恒为 true（initDB→_ensureRootFolder 补建 root），导致游客永远被弹「清空本地数据」。
    try { _hasData = await db.hasAnyProtectableData(); } catch (e) { _hasData = true; }   // fail-closed：探测异常视为有数据 → 走外来确认
    var _foreign = false;
    if (_hasData) {
      try {
        var _cls = await db.classifyLocalOwnership(baselineAuthorId, String(user.id));
        _foreign = !!_cls.isForeign;
      } catch (e) {
        console.warn('[Auth] classifyLocalOwnership failed → fail-closed foreign:', e && e.message);
        _foreign = true;
      }
    }
    if (_hasData && _foreign) {
      if (!(opts && opts.forceClearLocal)) {
        return {
          success: false,
          blocked: true,
          needsClear: true,
          currentOwner: owner,            // owner 为 null：前端按 foreignData 选「其他用户的数据」文案
          newUser: { loginId: user.loginId },
          foreignData: true               // 2026-11：UI 据此选 foreign 文案；不把 foreignAt.uid 塞进
                                          // currentOwner（防他人 uid 泄漏到页面层）
        };
      }
      if (opts && opts.forceClearLocal) {
        var _clr = await _wpzlClearLocalForLogin('pre-login-clear');
        if (!_clr.success) return { success: false, error: _clr.error || 'local_clear_failed' };
      }
    }
    // R2：游客档登录 = 换身份持有权，清 sync_token 让登录后首次同步走「认领数据上推 + 服务端
    // 全量下拉」（对齐静默切换分支；顺带清历史限额阻断标志。_wpzlClearLocalForLogin 内部已做，
    // 这里补自有认领/空库两条路径）。
    if (!_foreign && typeof wpzlSyncEngine !== 'undefined') {
      try { await wpzlSyncEngine.resetSyncState(); } catch (e) { /* ignore */ }
    }
    // 首次登录/注册（含访客→用户）：认领本地数据
    // token + owner + wpzl_claim_pending 一次 set() 原子写入（spec 改动 A + R2 自愈标志）：
    // 不变量「登录账号=数据属主」在落盘瞬间成立。wpzl_claim_pending 兜住「落盘后、认领尾序
    // 完成前 SW 被杀」的窗口——此时数据隐形且用户登出即真丢，_wpzlRepairPendingClaim 幂等补完。
    // 标志在认领尾序的最后一步清除（见下），任何中途被杀都留有自愈入口。
    await new Promise(function (resolve) {
      chrome.storage.local.set({
        wpzl_auth: authData,
        wpzl_local_data_owner: { userId: String(user.id), loginId: user.loginId },
        wpzl_claim_pending: true
      }, resolve);
    });
    await _wpzlPostLoginStorage(authData);
    var _claimResult = null;
    try {
      var _rw = await _rewriteLocalOwnershipToUser(baselineAuthorId, String(user.id), user.name);
      // 认领计数（含 tags/imageData 补漏块）→ 短命键 wpzl_claim_result 供 manager/面板 toast，
      // 并随登录响应回传给 auth 页（additive 字段，旧调用方忽略）。
      var _tot = (_rw.annotations || 0) + (_rw.pages || 0) + (_rw.folders || 0) + (_rw.documents || 0) +
                 (_rw.snapshots || 0) + (_rw.tags || 0) + (_rw.imageData || 0);
      if (_tot > 0) {
        _claimResult = { at: Date.now(), userId: String(user.id), loginId: user.loginId || '', total: _tot };
        try { chrome.storage.local.set({ wpzl_claim_result: _claimResult }, function () { /* ignore */ }); } catch (e) { /* ignore */ }
      }
    } catch (e) {
      // 认领改写异常不阻断登录：wpzl_claim_pending 仍在，repair 会幂等补完
      console.warn('[Auth] ownership rewrite failed → repair pending kept:', e && e.message);
    }
    try {
      await db.saveSetting({ key: 'userIdentity', authorId: String(user.id), userId: String(user.id), authorName: user.name, loginId: user.loginId });
    } catch (e) { /* ignore */ }
    // 确保默认目录存在（新用户首次登录时 initDB 已跑过，需要这里补建）
    try { await _ensureRootFolder(); } catch (e) { /* ignore */ }
    // 认领尾序完成 → 清自愈标志（最后一步：任何上方步骤中断都留有 repair 入口）
    try { await new Promise(function (resolve) { chrome.storage.local.remove(['wpzl_claim_pending'], resolve); }); } catch (e) { /* ignore */ }
    if (typeof wpzlSyncEngine !== 'undefined') {
      wpzlSyncEngine.onLogin().catch(function (e) { console.warn('[Sync] onLogin failed:', e); });
    }
    // 预热等级缓存：登录成功立即 forceRefresh 拉取 pro-status 并写入 wpzl_pro_cache，
    // 否则 manager/popup 首次加载会读到空缓存（症状：刚登录跳转 manager 显示“免费版”、无同步按钮）。
    // await 让登录响应等到缓存就绪后再返回，跳转后的 manager 即可读到正确等级。网络失败不阻断登录。
    try { await wpzl_getProStatus(true); } catch (e) { /* 脱机/超时：后续 onLogin→sync 链路会兜底填充 */ }
    // D-13: 登录成功 → 广播 auth-state-changed，已打开页面热激活（免 reload）
    _broadcastAuthStateChanged({ type: 'auth-state-changed', isLoggedIn: true, userId: String(user.id) });
    return { success: true, data: user, claim: _claimResult };
  }
  if (isSame) {
    // 同账号重登：保留数据与同步状态（增量）。USER_ID/AUTHOR_ID 已是登录用户（首次登录时改写过），
    // 仅做兜底：万一升级前已有数据缺 USER_ID，这里补一次。
    // token + owner 一次 set() 原子写入（spec 改动 A）：不变量「登录账号=数据属主」在落盘瞬间成立，
    // 消除 SW 在两写之间被杀的分裂窗口。
    await new Promise(function (resolve) {
      chrome.storage.local.set({
        wpzl_auth: authData,
        wpzl_local_data_owner: { userId: String(user.id), loginId: user.loginId }
      }, resolve);
    });
    await _wpzlPostLoginStorage(authData);
    await _rewriteLocalOwnershipToUser(baselineAuthorId, String(user.id), user.name);
    try {
      await db.saveSetting({ key: 'userIdentity', authorId: String(user.id), userId: String(user.id), authorName: user.name, loginId: user.loginId });
    } catch (e) { /* ignore */ }
    // 确保默认目录存在（新用户首次登录时 initDB 已跑过，需要这里补建）
    try { await _ensureRootFolder(); } catch (e) { /* ignore */ }
    if (typeof wpzlSyncEngine !== 'undefined') {
      wpzlSyncEngine.onLogin().catch(function (e) { console.warn('[Sync] onLogin failed:', e); });
    }
    // 预热等级缓存：登录成功立即 forceRefresh 拉取 pro-status 并写入 wpzl_pro_cache，
    // 否则 manager/popup 首次加载会读到空缓存（症状：刚登录跳转 manager 显示“免费版”、无同步按钮）。
    // await 让登录响应等到缓存就绪后再返回，跳转后的 manager 即可读到正确等级。网络失败不阻断登录。
    try { await wpzl_getProStatus(true); } catch (e) { /* 脱机/超时：后续 onLogin→sync 链路会兜底填充 */ }
    // D-13: 登录成功 → 广播 auth-state-changed，已打开页面热激活（免 reload）
    _broadcastAuthStateChanged({ type: 'auth-state-changed', isLoggedIn: true, userId: String(user.id) });
    return { success: true, data: user };
  }

  // —— 不同账号 ——
  var hasData = false;
  // P0-6: 多 store 计数（此前只数 annotations，documents/snapshots-only 数据被静默划给新账号）
  // 这里刻意保持 hasAnyUserData（宽口径，「有任何本地数据就拦」）而非 hasAnyProtectableData：
  // 本分支已有属主（owner 非空）时拦截是安全侧的既有行为（2026-09-29 游客档未改动它）。
  // 已知代价：A 只被自动补建过一条纯净默认目录时也会拦一次（历史行为，可用设置页
  // 「清空本地数据」解开）；改窄会削弱跨账号越权防护，不在本次范围内。
  try { hasData = await db.hasAnyUserData(); } catch (e) { hasData = false; }

  if (hasData) {
    // 未登录本地模式（2026-09-29）：用户已在 UI 完成备份确认（forceClearLocal）→ 先清空，
    // 成功则不再拦截，落入下方既有「不同账号但本地无数据」静默切换路径（token 原子写 +
    // 全量同步，服务端有副本可同步回来）；未带 forceClearLocal → 原样拦截。
    if (opts && opts.forceClearLocal) {
      var _clrDiff = await _wpzlClearLocalForLogin('pre-login-clear');
      if (!_clrDiff.success) {
        return { success: false, error: _clrDiff.error || 'local_clear_failed' };
      }
    } else {
      // 本地有数据 → 拦截。不写任何 storage：登录函数已不落盘（spec 改动 A），
      // 原会话（wpzl_auth/wpzl_local_data_owner）原样保留，数据属主与登录态保持一致。
      return {
        success: false,
        blocked: true,
        needsClear: true,
        currentOwner: owner,
        newUser: { loginId: user.loginId }
      };
    }
  }

  // 不同账号但本地无数据 → 静默切换；清 sync_token 让新账号全量同步
  if (typeof wpzlSyncEngine !== 'undefined') {
    try { await wpzlSyncEngine.resetSyncState(); } catch (e) { /* ignore */ }
  }
  // token + owner 一次 set() 原子写入（spec 改动 A）：不变量「登录账号=数据属主」在落盘瞬间成立，
  // 消除 SW 在两写之间被杀的分裂窗口。
  await new Promise(function (resolve) {
    chrome.storage.local.set({
      wpzl_auth: authData,
      wpzl_local_data_owner: { userId: String(user.id), loginId: user.loginId }
    }, resolve);
  });
  await _wpzlPostLoginStorage(authData);
  await _rewriteLocalOwnershipToUser(baselineAuthorId, String(user.id), user.name);
  try {
    await db.saveSetting({ key: 'userIdentity', authorId: String(user.id), userId: String(user.id), authorName: user.name, loginId: user.loginId });
  } catch (e) { /* ignore */ }
  // 确保默认目录存在（与首次登录/同账号分支一致）：clearAllLocalData 已清空 folders store，
  // 静默切换到新账号也需为该账号补建默认目录，否则新用户进 manager 目录树为空、且面板被隐藏成死锁。
  try { await _ensureRootFolder(); } catch (e) { /* ignore */ }
  if (typeof wpzlSyncEngine !== 'undefined') {
    wpzlSyncEngine.onLogin().catch(function (e) { console.warn('[Sync] onLogin failed:', e); });
  }
  // 预热等级缓存（同上三处成功分支）：静默切换到新账号后立即拉取该账号的 pro-status，
  // 避免 manager 首次加载读到上一个账号残留或空 wpzl_pro_cache。
  try { await wpzl_getProStatus(true); } catch (e) { /* 脱机/超时：后续 onLogin→sync 链路兜底填充 */ }
  // D-13: 登录成功 → 广播 auth-state-changed，已打开页面热激活（免 reload）
  _broadcastAuthStateChanged({ type: 'auth-state-changed', isLoggedIn: true, userId: String(user.id) });
  return { success: true, data: user };
}

// 未登录本地模式（游客档）：登录/注册/OAuth 前的显式清空（用户已在 UI 完成备份确认）。
// 只清本地 IDB + 同步状态 + 归属声明；不吊销服务端会话、不动 wpzl_auth（_finalizeAuth 随后
// 原子写入新值）、不广播 auth-state-changed:false（紧接着就是 true）。
// 清空失败上抛结构化失败，调用方中止登录（不清空绝不登录，数据安全优先）。

// P1 修复（登出×在途竞争，2026-10-07）：三条清空路径（登出切号/切号预清/设置页清空）统一守卫。
// 此前仅"非 force 且有 pending"分支做 flush+等锁——force 路径与预清路径完全裸奔，在飞 sync
// 周期的批应用把旧账号行写回已清空的库。守卫序：置中止标志（在飞周期在批边界丢弃一切应用）
// → 挡新周期 → 有界等在飞收尾（超时也继续清，中止标志兜底让迟到写全被丢弃）。
async function _guardSyncForLocalClear() {
  try {
    if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.setClearGuard === 'function') {
      wpzlSyncEngine.setClearGuard(true);
    }
    if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.waitForUnlock === 'function') {
      await wpzlSyncEngine.waitForUnlock(5000);
    }
  } catch (e) { /* ignore */ }
}
function _unguardSyncAfterLocalClear() {
  try {
    if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.setClearGuard === 'function') {
      wpzlSyncEngine.setClearGuard(false);
    }
  } catch (e) { /* ignore */ }
}

async function _wpzlClearLocalForLogin(reason) {
  console.log('[Auth] _wpzlClearLocalForLogin: reason=' + reason);
  if (!dbReady) {
    try { await initDB(); } catch (e) { console.warn('[Auth] initDB during pre-login clear failed:', e && e.message); }
  }
  if (!db || typeof db.clearAllLocalData !== 'function') {
    console.error('[Auth] abort pre-login clear: local DB not available');
    return { success: false, error: 'local_clear_failed' };
  }
  await _guardSyncForLocalClear();   // P1：预清路径此前无任何锁等待——在飞批写回的裸奔口
  try {
    await db.clearAllLocalData();
  } catch (e) {
    _unguardSyncAfterLocalClear();
    console.error('[Auth] abort pre-login clear: clearAllLocalData failed:', e && e.message);
    return { success: false, error: 'local_clear_failed', detail: e && e.message };
  }
  // 清后台下载闹钟（游客态本无；防御性对齐 _wpzlLogoutAndClearLocal）
  try {
    chrome.alarms.clear('doc-sync-resume');
    chrome.alarms.clear('image-sync-resume');
  } catch (e) { /* ignore */ }
  try {
    if (typeof wpzlSyncEngine !== 'undefined') await wpzlSyncEngine.resetSyncState();
  } catch (e) { /* ignore */ }
  _unguardSyncAfterLocalClear();
  await _setLocalDataOwner(null);
  _wpzlRefreshActionBadge();   // ④ 清空成功后刷新（此刻仍未登录，保持「!」）
  console.log('[Auth] _wpzlClearLocalForLogin complete');
  return { success: true };
}

// 强制登录模型（决策 3）：统一登出/切换清空函数。
// 步骤：clearAllLocalData → wpzl_logout（服务端吊销）→ 清 storage → 通知 UI
// 不 flush：用户已主动切账号 = 已决定丢弃本地状态。
// 历史 flushImmediate(5000) 会与 clearAllLocalData 竞争 —— Promise.race 无法取消底层 sync()，
// in-flight 周期收尾时把上一个账号的 syncToken 写回已被清空的 syncMeta，污染下一个账号的增量同步。
async function _wpzlLogoutAndClearLocal(reason, opts) {
  console.log('[Auth] _wpzlLogoutAndClearLocal: reason=' + reason);
  // 1) 清空 IDB 所有 store（保留 device_id — 它和账户无关，避免每次切换都重置全量同步基线）。
  // D-35: 本地清空是登出的硬前置——失败或未能执行时【中止整个登出】（不清 storage、不吊销、
  // 不广播、调用方不跳转并提示重试）。此前两个失败路径都会继续走后续步骤：
  //   ① db 未初始化时 `if (db && …)` 静默跳过清空（MV3 SW 冷启动竞态——登出消息唤醒 SW 时
  //      initDB 未跑完；实测复现：storage 已清而 IDB 残留 → 下个不同账号登录走「首次认领」
  //      把上一个账号的本地数据划归新账号）；
  //   ② clearAllLocalData 抛错仅 console.warn 后继续。
  // 补救：先确保 initDB（对齐 _finalizeAuth 开场），再把任何清空失败上抛为结构化失败。
  if (!dbReady) {
    try { await initDB(); } catch (e) { console.warn('[Auth] initDB during logout failed:', e && e.message); }
  }
  if (!db || typeof db.clearAllLocalData !== 'function') {
    console.error('[Auth] abort logout: local DB not available');
    return { success: false, error: 'local_clear_failed', reason: reason };
  }
  // P0(CL-01) 2026-09-19 审计复核：清空前保护未上云的本地修改（离线创建/编辑的标注、
  // 文档、快照）。原实现「登出=物理清空 10 store 且不 flush」，断网期间的草稿被不可恢复
  // 地销毁。处理序：①统计未同步修改（六 store pending 行 + offline_queue）→ ②有则先
  // flush（仅同步启用时；flush 后等同步锁释放——防 in-flight 周期收尾把旧账号 syncToken
  // 写回已清空的 syncMeta，即上方注释所述历史竞争的根源）→ ③仍排不掉且未 force → 返回
  // pending_unsynced 交 UI 确认；force=用户已确认删除（或 owner-mismatch 等必须清空的自动路径）。
  if (!(opts && opts.force)) {
    var _pendingN = 0;
    try {
      if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._countPendingLocalChanges === 'function') {
        _pendingN = await wpzlSyncEngine._countPendingLocalChanges();
      }
    } catch (e) { /* ignore */ }
    if (_pendingN > 0) {
      if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.isEnabled === 'function'
          && wpzlSyncEngine.isEnabled() && typeof wpzlSyncEngine.flushImmediate === 'function') {
        try {
          var _fr = await wpzlSyncEngine.flushImmediate(8000);
          // flush 超时/失败时底层 sync 可能仍在跑：等锁释放再清，防旧 token 回写新 syncMeta
          if (typeof wpzlSyncEngine.waitForUnlock === 'function') {
            await wpzlSyncEngine.waitForUnlock(15000);
          }
          if (_fr && _fr.flushed) {
            _pendingN = await wpzlSyncEngine._countPendingLocalChanges();
          }
        } catch (e) { console.warn('[Auth] pre-logout flush failed:', e && e.message); }
      }
      if (_pendingN > 0) {
        console.warn('[Auth] abort logout: ' + _pendingN + ' pending local changes unsynced');
        return { success: false, error: 'pending_unsynced', pendingCount: _pendingN, reason: reason };
      }
    }
  }
  await _guardSyncForLocalClear();   // P1：force 路径此前无锁等待；非 force 路径上方 flush 已含等待，此处幂等
  try {
    await db.clearAllLocalData();
    console.log('[Auth] clearAllLocalData done');
  } catch (e) {
    _unguardSyncAfterLocalClear();
    console.error('[Auth] abort logout: clearAllLocalData failed:', e && e.message);
    return { success: false, error: 'local_clear_failed', detail: e && e.message, reason: reason };
  }
  // 3) 调用服务端 logout（吊销 refresh token）；网络失败不阻断本地清理
  try {
    if (typeof wpzl_logout === 'function') await wpzl_logout();
  } catch (e) {
    console.warn('[Auth] wpzl_logout failed (continuing):', e && e.message);
  }
  // 4) 清 chrome.storage 中的 wpzl_auth / wpzl_user_profile / wpzl_pro_cache / 离线标识
  //    保留：device_id（账户无关）、statistics（聚合统计）
  try {
    await new Promise(function (resolve) {
      chrome.storage.local.remove([
        'wpzl_auth', 'wpzl_user_profile', 'wpzl_pro_cache', 'wpzl_offline_mode', 'wpzl_pro_last_ispro',
        'wpzl_unauthorized_count',   // P2-7: 换号偏好残留（401 计数属旧会话）
        'wpzl_local_data_owner',     // 数据已清空，归属声明同步失效（与设置页 clearAllData 路径对齐）
        'wpzl_avatar',               // 用户面板头像缓存（跨账号残留头像）
        'wpzl_grades_cache',         // 等级对比表缓存（等级列表随账号/后台调整变化）
        'wpzl_claim_pending',        // 认领中断自愈标志（2026-11）：登出=数据已物理清空，标志无意义
        'wpzl_claim_result'          // 认领结果短命键（2026-11）：防跨账号串号残留
      ], resolve);
    });
  } catch (e) { /* ignore */ }
  // P2-7: 清 wpzl_reply_src_* 前缀键（分享回复身份缓存属旧账号，换号不应继承）
  try {
    var _allKeys = await new Promise(function (resolve) {
      chrome.storage.local.get(null, function (x) { resolve(x ? Object.keys(x) : []); });
    });
    var _replySrcKeys = _allKeys.filter(function (k) { return k.indexOf('wpzl_reply_src_') === 0; });
    if (_replySrcKeys.length > 0) {
      await new Promise(function (resolve) { chrome.storage.local.remove(_replySrcKeys, resolve); });
    }
  } catch (e) { /* ignore */ }
  // 5) 重置同步引擎状态（清 sync_token / queue / health）
  try {
    if (typeof wpzlSyncEngine !== 'undefined') await wpzlSyncEngine.onLogout();
  } catch (e) { /* ignore */ }
  _unguardSyncAfterLocalClear();   // P1：清空完成，解除新周期禁入（下次登录 onLogin→sync 正常）
  // P2-7: 清后台下载 alarm（doc-sync-resume / image-sync-resume）——isEnabled 门禁会让它们
  // 空转，但每分钟仍无谓唤醒 SW；登出即清，下次登录有新数据时重新创建
  try {
    chrome.alarms.clear('doc-sync-resume');
    chrome.alarms.clear('image-sync-resume');
  } catch (e) { /* ignore */ }
  // 6) 通知所有 frame（扩展页 + 每个标签页的 content script）：auth-state-changed:false。
  //    本地模式（2026-09-29）改用双通道广播：此前只发 chrome.runtime.sendMessage（仅达
  //    扩展页），标签页 content.js 收不到——登出后已开页面无法热切换回本地模式。
  //    扩展页（manager/settings）行为不变（仍收 runtime 通道跳 auth.html / 降级本地模式）。
  _broadcastAuthStateChanged({ type: 'auth-state-changed', isLoggedIn: false, reason: reason });
  console.log('[Auth] _wpzlLogoutAndClearLocal complete');
  return { success: true, reason: reason };
}

// ---------- 消息处理 ----------
// D-25: 导出产物脱敏——剥同步引擎内部字段（SYNC_*/DIRTY_BITS/SERVER_UPDATE_TIME）。
// 仅作用于导出通道（exportAll/backupAll/backupChunk op），IDB 原记录不动；
// 导入端本就强制重置这些字段（SYNC_STATUS='pending'/DIRTY_BITS=0xFF），剥离无功能影响，
// 只避免泄漏内部状态与增大产物体积。
var _WPZL_EXPORT_STRIP_KEYS = {
  SYNC_STATUS: 1, SYNC_VERSION: 1, SYNCED_AT: 1, SERVER_UPDATE_TIME: 1,
  DIRTY_BITS: 1, SYNC_EXHAUSTED: 1, SYNC_RETRY_COUNT: 1,
  SYNC_LAST_ERROR: 1, SYNC_LAST_ATTEMPT_AT: 1
};
function _wpzlStripSyncFieldsForExport(record) {
  if (!record || typeof record !== 'object') return record;
  var had = false;
  for (var k in _WPZL_EXPORT_STRIP_KEYS) {
    if (record[k] !== undefined) { had = true; break; }
  }
  if (!had) return record;
  var out = {};
  for (var rk in record) {
    if (Object.prototype.hasOwnProperty.call(record, rk) && !_WPZL_EXPORT_STRIP_KEYS[rk]) out[rk] = record[rk];
  }
  return out;
}

// P1-7（2026-10-05 bulktest 10k 报告）：bg-download-progress 响应缓存（1s）+ 在途合并。
// 下载高峰期每张图/每篇文档完成都会 nudge 所有打开的 manager 页立即补拉
//（_reportBgDownloadProgress 扇出），多页 × nudge 会把轮询放大到远超 2s/页；
// 分类本身已 O(清单)（纯 roster 数学），缓存再兜住并发扇出与瞬态抖动。
var _bgProgCache = { at: 0, data: null, inflight: null };
var BG_PROG_CACHE_MS = 1000;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Badge 更新
  if (request.type === 'updateBadge') {
    var count = request.count || 0;
    var text = count > 0 ? String(count) : '';
    chrome.action.setBadgeText({
      text: text,
      tabId: sender.tab ? sender.tab.id : undefined
    });
    chrome.action.setBadgeBackgroundColor({ color: '#ff3c82' });
    sendResponse({ success: true });
    return false;
  }

  // D3：manager 左下角提示条轮询后台下载进度（文档 body + 图片 blob）。
  // 2026-10-04 重做：旧响应是批作用域内存进度（total 每批重置/重算，显示 0/8 横跳、7/9→7/12）。
  // 现改为：done=会话累计（_docDlSession/_imageDlSession，SW 存活期单调递增），
  // remaining/backing=清单真值实时分类（doc collector {due,backing} / image _classifyPendingImageDownloads）。
  // P1-7：两侧分类均为纯 roster 数学（零 IDB 记录物化）+ 上方 1s 缓存在途合并；
  // 冷启动先 initDB 防误报 0。
  if (request.type === 'bg-download-progress') {
    var _bgNow = Date.now();
    if (_bgProgCache.data && (_bgNow - _bgProgCache.at) < BG_PROG_CACHE_MS) {
      sendResponse({ success: true, data: _bgProgCache.data });
      return false;
    }
    if (_bgProgCache.inflight) {
      _bgProgCache.inflight.then(function (d) { sendResponse({ success: true, data: d }); });
      return true;
    }
    _bgProgCache.inflight = (async function () {
      var doc = { done: 0, remaining: 0, backing: 0 };
      var image = { done: 0, remaining: 0, backing: 0 };
      if (!dbReady) {
        try { await initDB(); } catch (e) { /* ignore */ }
      }
      try {
        if (typeof _collectPendingDocDownloads === 'function') {
          var _dp = await _collectPendingDocDownloads();
          if (_dp) {
            doc.remaining = _dp.due.length + _dp.backing;
            doc.backing = _dp.backing;
          }
        }
      } catch (e) { /* fail-open：按 0 */ }
      try {
        if (typeof _classifyPendingImageDownloads === 'function') {
          var _ip = await _classifyPendingImageDownloads();
          if (_ip) {
            image.remaining = _ip.due + _ip.backing;
            image.backing = _ip.backing;
          }
        }
      } catch (e) { /* fail-open：按 0 */ }
      // 第三批：done 读数走 session 水合（SW 重启后从 chrome.storage.session 恢复，
      // 进度条不再跳「已下 0」）；老兜底保留（storage.session 不可用时退回内存值）
      if (typeof _docDlSessionDone === 'function') doc.done = await _docDlSessionDone();
      else if (typeof _docDlSession !== 'undefined') doc.done = _docDlSession.done || 0;
      if (typeof _imageDlSessionDone === 'function') image.done = await _imageDlSessionDone();
      else if (typeof _imageDlSession !== 'undefined') image.done = _imageDlSession.done || 0;
      var out = { doc: doc, image: image };
      _bgProgCache.at = Date.now();
      _bgProgCache.data = out;
      return out;
    })();
    var _bgP = _bgProgCache.inflight;
    _bgP.then(function (d) { sendResponse({ success: true, data: d }); })
      .catch(function () { sendResponse({ success: true, data: null }); })
      .finally(function () { if (_bgProgCache.inflight === _bgP) _bgProgCache.inflight = null; });
    return true;
  }

  // 导出门禁（spec 2026-09-30-export-pending-download-gate）：实时统计后台待下载数
  // （文档 body + 图片 blob）——数 IDB 真值，非内存进度（内存进度在 SW 回收后归零、
  // alarm 未跑时漏报，不可作门禁依据）。fail-open：异常按 0 处理，绝不因统计故障堵导出。
  if (request.type === 'bg-download-pending-count') {
    (async function () {
      // 冷启动 SW 首次计数：确保 IDB 已初始化（对齐 wpzl-has-local-data 前置，避免首次误报 0）
      if (!dbReady) {
        try { await initDB(); } catch (e) { /* ignore */ }
      }
      var docPending = 0, imagePending = 0;
      try {
        if (typeof _collectPendingDocDownloads === 'function') {
          // {due, backing}（2026-10-04 方案1）：backing=dlNextAt 退避未到期，数据仍缺失，
          // 门禁同样要等它，计入 pending。null（瞬态）按 0（fail-open 语义不变）。
          var _docPend = await _collectPendingDocDownloads();
          docPending = _docPend ? (_docPend.due.length + _docPend.backing) : 0;
        }
      } catch (e) { /* fail-open */ }
      try {
        if (typeof _countPendingImageDownloadsAll === 'function') {
          imagePending = await _countPendingImageDownloadsAll();
        }
      } catch (e) { /* fail-open */ }
      sendResponse({ success: true, data: { doc: docPending, image: imagePending } });
    })();
    return true;
  }

  // 导出等待模式：立即跑一批下载（不等 1min alarm 周期）。
  // 两批处理器各有 _docSyncActive/_imageSyncActive 重入守卫，kick 重入安全；正常 alarm 照旧接管后续。
  if (request.type === 'bg-download-kick') {
    try { _processDocSyncBatch(); } catch (e) { /* ignore */ }
    try { _processImageSyncBatch(); } catch (e) { /* ignore */ }
    sendResponse({ success: true });
    return false;
  }

  // ---- Sync State Machine ----
  // 注意：listener 回调本身非 async（保持与既有 ~770 行 handler 兼容），
  // 异步 handler 用 IIFE 包裹，避免影响其它分支的 return true 语义。
  if (request.type === 'wpzl-online-event') {
    // P1-8: 10s 窗口去抖——N tab 的重复事件直接应答（调用方 fire-and-forget 不读结果）
    var _nowOnline = Date.now();
    if (_nowOnline - _lastOnlineHandledAt < 10000) {
      sendResponse({ success: true, debounced: true });
      return false;
    }
    _lastOnlineHandledAt = _nowOnline;
    // 浏览器 online 事件 → 真实验证网络 → 触发 sync
    (async function () {
      var online = await _wpzlCheckConnectivity();
      if (online) {
        // 熔断冷却期不 punch-through：网络恢复 ≠ 服务端恢复，只补缩略图不发 sync
        var _sePausedEv = false;
        try {
          if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._isServerErrPaused === 'function') {
            _sePausedEv = await wpzlSyncEngine._isServerErrPaused();
          }
        } catch (e) { /* ignore */ }
        if (_sePausedEv) {
          wpzl_setSyncState('server_error');
          _flushPendingThumbnails().catch(function () { /* 静默 */ });
          return;
        }
        wpzl_setSyncState('syncing');
        try {
          var onlineR = await wpzlSyncEngine.sync('manual');
          // sync() 失败时不 throw，返回 { error: ... }。内部已通过 wpzl_setSyncState
          // 正确设置了 token_expired/offline，此处不应覆盖。
          if (!onlineR || !onlineR.error) {
            // P1-8: sync('manual') 跳过 offline/server-error 门，唯一可达的"没同步"返回是
            // reason:'not_allowed'（未开启同步）——不污染 lastSyncAt 元数据
            var _okMeta = (onlineR && onlineR.reason) ? null : {
              lastSyncAt: Date.now(),
              pushed: (onlineR && onlineR.pushed) || 0,
              pulled: (onlineR && onlineR.pulled) || 0
            };
            wpzl_setSyncState('online', _okMeta);
          }
          // 补传积压的页面矩形缩略图
          _flushPendingThumbnails().catch(function () { /* 静默 */ });
        } catch (e) {
          if (wpzl_sync_state !== 'token_expired') {
            wpzl_setSyncState('offline');
          }
        }
      } else {
        wpzl_setSyncState('offline');
      }
    })();
    sendResponse({ success: true });
    return false;
  }

  if (request.type === 'wpzl-sync-now') {
    // 用户主动点"立即同步"
    (async function () {
      wpzl_setSyncState('syncing');
      try {
        var nowR = await wpzlSyncEngine.sync('manual');
        if (!nowR || !nowR.error) {
          wpzl_setSyncState('online', {
            lastSyncAt: Date.now(),
            pushed: (nowR && nowR.pushed) || 0,
            pulled: (nowR && nowR.pulled) || 0
          });
        }
      } catch (e) {
        if (wpzl_sync_state === 'token_expired') { /* 内部已正确设置 */ }
        else {
          var isAuth = (e && e.kind === 'unauthorized')
            || (e && e.message && e.message.indexOf('reason=unauthorized') >= 0);
          wpzl_setSyncState(isAuth ? 'token_expired' : 'offline');
        }
      }
    })();
    sendResponse({ success: true });
    return false;
  }

  if (request.type === 'wpzl-get-sync-state') {
    // 标签页冷启动拉取当前状态
    sendResponse({
      state: wpzl_sync_state,
      meta: wpzl_sync_meta
    });
    return false;
  }

  // 旧版 popup getStatistics
  if (request.type === 'getStatistics') {
    chrome.storage.local.get(['statistics'], (result) => {
      sendResponse(result.statistics || { totalAnnotations: 0, totalPages: 0 });
    });
    return true;
  }

  // ---- Auth / Pro operations (server API) ----

  if (request.type === 'auth-login') {
    wpzl_login(request.loginId, request.password)
      .then(function (r) { return _finalizeAuth(r.user, r.authData, { forceClearLocal: !!request.forceClearLocal }); })
      .then(function (resp) { sendResponse(resp); })
      .catch(function (err) { sendResponse({ success: false, error: err.message }); });
    return true;
  }

  // ---- Share management operations (Phase 4, owner, server API) ----
  // H1（2026-10-13 审计）纵深：share 写操作/全量读要求来自扩展页（manager 等扩展上下文——
  // sender 无 tab 或 url 为 chrome-extension://）或携带有效 panelGestureAt 见证（content.js
  // 手势门转发时附加）。content.js 桥门是第一道，此层防未来新增转发路径绕过桥门。
  var _wpzlShareGestureOk = !sender.tab
      || (sender.url && sender.url.indexOf('chrome-extension://') === 0)
      || (request.panelGestureAt && (Date.now() - request.panelGestureAt) < 10 * 60 * 1000);

  if (request.type === 'wpzl-create-share') {
    if (!_wpzlShareGestureOk) { sendResponse({ success: false, error: 'no-panel-gesture' }); return true; }
    wpzl_createShare(request.payload)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) {
        sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgCreateFailed'),
          serverCode: err && err.serverCode });   // 业务码（40311 等级门禁等）透传给分享弹窗分流文案
      });
    return true;
  }

  if (request.type === 'wpzl-list-shares') {
    wpzl_listShares()
      .then(function (data) {
        // H1 纵深：非扩展页来源且无有效手势见证时剥离 code（/share/{code} 的访问凭证）。
        // content.js 侧已对自动回退链脱敏，此层双保险；manager（扩展页）不受影响。
        if (!_wpzlShareGestureOk && Array.isArray(data)) {
          data = data.map(function (s) {
            if (s && typeof s === 'object') { var c = Object.assign({}, s); delete c.code; return c; }
            return s;
          });
        }
        sendResponse({ success: true, data: data });
      })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgLoadFailed') }); });
    return true;
  }

  if (request.type === 'wpzl-get-share') {
    wpzl_getShare(request.shareId)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgLoadFailed') }); });
    return true;
  }

  if (request.type === 'wpzl-update-share') {
    if (!_wpzlShareGestureOk) { sendResponse({ success: false, error: 'no-panel-gesture' }); return true; }
    wpzl_updateShare(request.shareId, request.payload)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) {
        sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgSaveFailed'),
          serverCode: err && err.serverCode });   // 业务码透传（40001 配额等），分享弹窗/manager 按码分流文案
      });
    return true;
  }

  if (request.type === 'wpzl-revoke-share') {
    if (!_wpzlShareGestureOk) { sendResponse({ success: false, error: 'no-panel-gesture' }); return true; }
    wpzl_revokeShare(request.shareId)
      .then(function () { sendResponse({ success: true }); })
      .catch(function (err) {
        sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgUndoFailed'),
          serverCode: err && err.serverCode });
      });
    return true;
  }

  if (request.type === 'wpzl-disable-share') {
    if (!_wpzlShareGestureOk) { sendResponse({ success: false, error: 'no-panel-gesture' }); return true; }
    wpzl_disableShare(request.shareId)
      .then(function () { sendResponse({ success: true }); })
      .catch(function (err) {
        sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgOpFailed'),
          serverCode: err && err.serverCode });
      });
    return true;
  }

  if (request.type === 'wpzl-enable-share') {
    if (!_wpzlShareGestureOk) { sendResponse({ success: false, error: 'no-panel-gesture' }); return true; }
    wpzl_enableShare(request.shareId)
      .then(function () { sendResponse({ success: true }); })
      .catch(function (err) {
        sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgOpFailed'),
          serverCode: err && err.serverCode });   // enable 重启用可被 40001 配额拒（ShareService.setActive 配额口）
      });
    return true;
  }

  if (request.type === 'wpzl-regenerate-share') {
    if (!_wpzlShareGestureOk) { sendResponse({ success: false, error: 'no-panel-gesture' }); return true; }
    wpzl_regenerateShare(request.shareId)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) {
        sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgRegenerateFailed'),
          serverCode: err && err.serverCode });
      });
    return true;
  }

  if (request.type === 'wpzl-delete-share') {
    if (!_wpzlShareGestureOk) { sendResponse({ success: false, error: 'no-panel-gesture' }); return true; }
    wpzl_deleteShare(request.shareId)
      .then(function () { sendResponse({ success: true }); })
      .catch(function (err) {
        sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgDeleteFailed'),
          serverCode: err && err.serverCode });
      });
    return true;
  }

  // ---- 属主侧回复（Req4：属主查看/回复/审删协作者回复）----

  if (request.type === 'wpzl-list-page-replies') {
    // H1：urlMd5 优先从 content.js 在 isolated world 计算的 webUri 权威求值（页面传入的
    // urlMd5 可伪造为任意页、拉属主在其它页的回复）；manager（扩展页直连）仍用其传入值。
    // 41b07e7 回归修复：此前误用 _swMd5——那是异步 SHA-256 截断哈希（pageKey/imageKey 专用，
    // 返回 Promise），同步引用只会把 '[object Promise]' 当 urlMd5 发给服务端，属主页聚合
    // 永远查空。改用同步真 MD5 wpzl_md5（md5.js，与服务端 Md5Util/页面 wpzl_hex_md5 同值域）。
    var _replyPageMd5 = (!sender.tab && request.urlMd5) ? request.urlMd5
        : ((request.webUri && typeof wpzl_md5 === 'function') ? wpzl_md5(request.webUri) : request.urlMd5);
    wpzl_listPageReplies(_replyPageMd5)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgLoadFailed') }); });
    return true;
  }

  if (request.type === 'wpzl-list-share-replies') {
    wpzl_listShareReplies(request.shareId, request.markId)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgLoadFailed') }); });
    return true;
  }

  if (request.type === 'wpzl-post-share-reply') {
    if (!_wpzlShareGestureOk) { sendResponse({ success: false, error: 'no-panel-gesture' }); return true; }
    wpzl_postShareReply(request.shareId, request.payload)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgReplyFailed') }); });
    return true;
  }

  if (request.type === 'wpzl-delete-share-reply') {
    if (!_wpzlShareGestureOk) { sendResponse({ success: false, error: 'no-panel-gesture' }); return true; }
    wpzl_deleteShareReply(request.shareId, request.replyId)
      .then(function () { sendResponse({ success: true }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgDeleteFailed') }); });
    return true;
  }

  // ---- active-share（当前页回复来源）持久化（chrome.storage.local，按 urlMd5 键）----

  if (request.type === 'wpzl-set-active-share') {
    if (!_wpzlShareGestureOk) { sendResponse({ success: false, error: 'no-panel-gesture' }); return true; }
    try {
      // H1：urlMd5 权威化（同 wpzl-list-page-replies——页面传入值可伪造）。
      // 同 41b07e7 回归修复：_swMd5 是异步 SHA-256 截断（返回 Promise），同步用会把键写成
      // 'wpzl_reply_src_[object Promise]'——全站共享一键，各页回复来源互相串台。改同步真 MD5。
      var _asMd5 = (!sender.tab && request.urlMd5) ? request.urlMd5
          : ((request.webUri && typeof wpzl_md5 === 'function') ? wpzl_md5(request.webUri) : request.urlMd5);
      var _asKey = 'wpzl_reply_src_' + (_asMd5 || '');
      var _setObj = {};
      _setObj[_asKey] = request.shareId || null;
      chrome.storage.local.set(_setObj, function () { sendResponse({ success: true, data: { shareId: request.shareId || null } }); });
    } catch (e) { sendResponse({ success: false, error: (e && e.message) || chrome.i18n.getMessage('bgSaveFailed') }); }
    return true;
  }

  if (request.type === 'wpzl-get-active-share') {
    try {
      // 同 41b07e7 回归修复：改同步真 MD5（详见 wpzl-list-page-replies 处注释）
      var _getMd5 = (!sender.tab && request.urlMd5) ? request.urlMd5
          : ((request.webUri && typeof wpzl_md5 === 'function') ? wpzl_md5(request.webUri) : request.urlMd5);
      var _getKey = 'wpzl_reply_src_' + (_getMd5 || '');
      chrome.storage.local.get(_getKey, function (res) {
        sendResponse({ success: true, data: { shareId: (res && res[_getKey]) || null } });
      });
    } catch (e) { sendResponse({ success: false, error: (e && e.message) || chrome.i18n.getMessage('bgReadFailed') }); }
    return true;
  }

  // ---- 页面快照已并入统一 sync（第6类实体 user_snapshots），旧独立通道（wpzl-save/get-snapshot）已移除 ----

  if (request.type === 'auth-captcha-fetch') {
    // 拉取滑块拼图验证码（发码前人机校验）：图片 base64 走 JSON，扩展页面不可跨域直取
    wpzl_fetchCaptcha()
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgSendFailed') }); });
    return true;
  }

  if (request.type === 'auth-send-code') {
    // 发送邮箱验证码：不涉及登录态，直接透传结果（含 cooldownSeconds 供前端倒计时）。
    // captchaId/captchaAnswer：滑块拼图答案（服务端强制校验）
    wpzl_sendVerifyCode(request.email, request.captchaId, request.captchaAnswer)
      .then(function (data) {
        sendResponse({ success: true, cooldownSeconds: data && data.cooldownSeconds });
      })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgSendFailed') }); });
    return true;
  }

  if (request.type === 'auth-forgot-password') {
    // 找回密码发送验证码：透传 cooldownSeconds（captchaId/captchaAnswer 同注册发码口径）
    wpzl_forgotPassword(request.email, request.captchaId, request.captchaAnswer)
      .then(function (data) {
        sendResponse({ success: true, cooldownSeconds: data && data.cooldownSeconds });
      })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgSendFailed') }); });
    return true;
  }

  if (request.type === 'auth-reset-password') {
    // 找回密码重置：仅返回成功/失败（成功后前端切回登录）
    wpzl_resetPassword(request.email, request.code, request.newPassword)
      .then(function () { sendResponse({ success: true }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || chrome.i18n.getMessage('bgResetFailed') }); });
    return true;
  }

  if (request.type === 'auth-register') {
    wpzl_register(request.loginId, request.password, request.email, request.name, request.code, request.marketingEmailOptIn)
      .then(function (r) { return _finalizeAuth(r.user, r.authData, { forceClearLocal: !!request.forceClearLocal }); })
      .then(function (resp) { sendResponse(resp); })
      .catch(function (err) { sendResponse({ success: false, error: err.message }); });
    return true;
  }

  if (request.type === 'auth-oauth') {
    // 第三方登录：launchWebAuthFlow 拿授权码 → 服务端换 token → _finalizeAuth 归属判定
    //（forceClearLocal 由前端授权前确认弹窗传入；未传时 _finalizeAuth 的 blocked 兜底拦截）
    wpzl_handleOAuthLogin(request.provider)
      .then(function (r) { return _finalizeAuth(r.user, r.authData, { forceClearLocal: !!request.forceClearLocal }); })
      .then(function (resp) { sendResponse(resp); })
      .catch(function (err) { sendResponse({ success: false, error: err.message }); });
    return true;
  }

  if (request.type === 'auth-logout') {
    // 决策 3：退出/切换与清空绑定 —— 通过统一函数 _wpzlLogoutAndClearLocal 处理。
    // P0(CL-01) 2026-09-19：request.force=用户已在 UI 确认「删除未同步数据」；
    // 未 force 时若本地有未上云修改，SW 会先尝试 flush，仍排不掉则返回 pending_unsynced
    // 交调用方弹确认（自动路径如 owner-mismatch 由调用方自带 force）。
    _wpzlLogoutAndClearLocal(request.reason || 'logout', { force: !!request.force })
      .then(function (resp) { sendResponse(resp); })
      .catch(function (err) { sendResponse({ success: false, error: err.message }); });
    return true;
  }

  if (request.type === 'auth-switch-user') {
    // 决策 3：切换用户与清空绑定 —— 走同一清空函数，区别仅在后续 UI 跳转
    _wpzlLogoutAndClearLocal('switch-user', { force: !!request.force })
      .then(function (resp) {
        // 切换用户：清空后直接打开 auth.html 让用户输入新账号
        if (resp.success) {
          try { chrome.tabs.create({ url: chrome.runtime.getURL('popup/auth.html') }); } catch (e) { /* ignore */ }
        }
        sendResponse(resp);
      })
      .catch(function (err) { sendResponse({ success: false, error: err.message }); });
    return true;
  }

  if (request.type === 'auth-status') {
    // 跳过连通性检查：manager/popup/settings/content 都只需查本地缓存登录态，
    // 不需要阻塞等 fetch /health 超时。Token 刷新由 sync engine 异步处理。
    wpzl_getAuthStatus({ skipConnectivityCheck: true })
      .then(function (status) { sendResponse({ success: true, data: status }); })
      .catch(function (err) { sendResponse({ success: false, error: err.message }); });
    return true;
  }

  // 本地是否有用户数据 + 数据属主。供 popup（未登录也显示「标注管理」入口）与
  // manager/settings 登录守卫（有数据则放行本地模式）使用——纯本地 IDB/storage 读，无网络。
  if (request.type === 'wpzl-has-local-data') {
    (async function () {
      try {
        if (!dbReady) {
          try { await initDB(); } catch (e) { /* ignore */ }
        }
        var owner = null;
        try { owner = await _getLocalDataOwner(); } catch (e) { /* ignore */ }
        var hasData = false;
        // 游客档预检口径：排除自动补建的纯净默认目录（详见 db.hasAnyProtectableData）。
        // 若用 hasAnyUserData，本 handler 自身就会触发 initDB→补建 root 使 hasData 恒 true，
        // 游客零数据也会看到提醒条 + 清空确认框。
        try { hasData = await db.hasAnyProtectableData(); } catch (e) { hasData = false; }
        // 游客档登录自动认领（2026-11）：SW 端单一决策源，前端只按 preAction 渲染、不自行拼判定
        //（判定顺序先 owner 后 foreign，防止 owner 存在场景被误判成游客自有而跳过弹框）。
        var preAction = 'none';
        var foreignData = false;
        var claimable = null;
        var total = 0;
        if (hasData && !owner) {
          // 未登录 + 有数据才做归属分类（已登录路径零额外开销）；targetUid 传 null（登录目标未知），
          // classifyLocalOwnership 对 legacy 纯数字身份保守判外来（见其头注释）。
          var _baseId = null;
          try { var _ident = await db.getUserIdentity(); _baseId = _ident && _ident.authorId; } catch (e) { /* ignore */ }
          try {
            var _cls = await db.classifyLocalOwnership(_baseId, null);
            foreignData = !!_cls.isForeign;
            claimable = _cls.claimable;
            total = _cls.total || 0;
          } catch (e) {
            foreignData = true;   // fail-closed：分类异常按外来处理，走人工确认，绝不静默认领
          }
          preAction = foreignData ? 'askForeign' : 'claim';
          if (!foreignData && total <= 0) preAction = 'askForeign';   // 保险丝：无可认领条数（理论不可达）也走确认
        } else if (hasData && owner) {
          // owner 存在：同号重登（豁免）还是换号（清空确认）取决于前端输入的 loginId，SW 不知道
          // 输入——给 askSwitch 提示，auth 页按 owner.loginId 比对后豁免/弹框（现状逻辑保留）。
          preAction = 'askSwitch';
        }
        sendResponse({ success: true, data: { hasData: hasData, owner: owner, preAction: preAction, foreignData: foreignData, claimable: claimable, total: total } });
      } catch (err) {
        sendResponse({ success: false, error: (err && err.message) || 'check failed' });
      }
    })();
    return true;
  }

  // 认领中断自愈（2026-11）：manager DOMContentLoaded 先发本消息等 repair 完成再渲染业务，
  // 保证认领数据先于列表可见；无标志时空转一次 storage 读。前端对 lastError 容错（消息异常
  // 照常走守卫，SW 顶层冷启动自检兜底）。
  if (request.type === 'wpzl-repair-claim') {
    _wpzlRepairPendingClaim().then(function (r) {
      sendResponse({ success: true, data: r });
    }).catch(function (err) {
      sendResponse({ success: false, error: (err && err.message) || 'repair failed' });
    });
    return true;
  }

  // 未登录本地模式（游客档）：游客等级配置/限额常量下发。无鉴权纯常量——
  // content.js（injectProGlobals 未登录分支）与 manager（游客档加载）经此读取（单一真相源）。
  if (request.type === 'guest-grade-config') {
    sendResponse({ success: true, data: { gradeConfig: WPZL_GUEST_GRADE_CONFIG, limits: WPZL_GUEST_LIMITS } });
    return false;
  }

  // ---- Page open operations (from control panel via content script) ----

  if (request.type === 'wpzl-open-auth') {
    // 同 popup 登录按钮：无痕窗口内的面板入口也要跟随点击窗口——SW 里 tabs.create
    // 不带 windowId 时默认目标永不选无痕窗口，需带上发起方（sender.tab）所在窗口 id；
    // 取不到 sender 时退回默认开法。
    var _wpzlAuthOpts = { url: chrome.runtime.getURL('popup/auth.html') };
    if (sender && sender.tab && typeof sender.tab.windowId === 'number') {
      _wpzlAuthOpts.windowId = sender.tab.windowId;
    }
    chrome.tabs.create(_wpzlAuthOpts);
    sendResponse({ success: true });
    return false;
  }

  if (request.type === 'wpzl-open-upgrade') {
    // 升级面板 = 独立小弹窗（upgrade/upgrade.html）；已打开则聚焦其窗口，避免堆叠
    // （manager 顶栏按钮 / popup / 注入面板更多菜单 三入口统一走本消息）
    _wpzlOpenUpgradePanel();
    sendResponse({ success: true });
    return false;
  }

  if (request.type === 'wpzl-open-manager') {
    // 已打开过管理页则直接切换到该 tab（并聚焦其窗口），避免重复开新标签。
    // 复用逻辑走登记制（_wpzlGetRegisteredTab，免 "tabs" 权限，见其注释）；
    // request.hash（如 '#pay-orders' 深链）：已开 tab 仅改 hash 导航（manager 的
    // hashchange 监听接住、不重载页面），新开 tab 则直达。
    var mgrUrl = chrome.runtime.getURL('manager/manager.html');
    _wpzlGetRegisteredTab('wpzl_mgr_tab_id', function (t) {
      if (t) {
        var upd = { active: true };
        if (request.hash) upd.url = mgrUrl + request.hash;
        chrome.tabs.update(t.id, upd);
        if (t.windowId != null) chrome.windows.update(t.windowId, { focused: true });
      } else {
        chrome.tabs.create({ url: mgrUrl + (request.hash || '') });
      }
    });
    sendResponse({ success: true });
    return false;
  }

  if (request.type === 'wpzl-open-auth-recovery') {
    // 内联登录框「忘记密码？」入口：新标签打开登录页并直达找回视图（auth.js 检测 #forgot）
    chrome.tabs.create({ url: chrome.runtime.getURL('popup/auth.html#forgot') });
    sendResponse({ success: true });
    return false;
  }

  if (request.type === 'wpzl-open-settings-tab') {
    chrome.tabs.create({ url: chrome.runtime.getURL('settings/settings.html') });
    sendResponse({ success: true });
    return false;
  }

  if (request.type === 'wpzl-open-docs') {
    // 帮助文档（manager 功能菜单 / 注入面板更多菜单 / popup 三入口统一走本消息）。
    // 默认即生产文档站；开发期可用 WEBPZ_DOCS_BASE 覆盖（见 apply-env.mjs）。
    // 浏览器界面语言 zh 开头的（zh-CN/zh-TW 等）给中文文档，其余给英文文档。
    var _docsUiLang = '';
    try { _docsUiLang = (chrome.i18n.getUILanguage && chrome.i18n.getUILanguage()) || ''; } catch (e) {}
    var _docsLangPath = (('' + _docsUiLang).toLowerCase().indexOf('zh') === 0) ? '/zh/' : '/en/';
    chrome.tabs.create({ url: 'https://www.webnoteshub.com/docs' + _docsLangPath });
    sendResponse({ success: true });
    return false;
  }

  if (request.type === 'pro-status') {
    wpzl_getProStatus(request.forceRefresh || false)
      .then(function (status) {
        // 用户主动「刷新用户状态」(forceRefresh)：广播让所有页面 content/manager 热刷新限额
        if (request.forceRefresh) {
          try { _broadcastProStatusUpdated(status); } catch (e) { /* ignore */ }
          // 到期提醒评估：打开 popup/manager 即触发（popup.js / manager.js 打开时都会 forceRefresh），
          // 不用等 6h 的 pro-expiry-check alarm
          _wpzlEvalProExpiryReminder(status);
          // Pro 升级后启用同步引擎（onProChanged 仅在被降级时调用，升级路径漏了）。
          // 条件含 cloudSync feature：管理员等 isPro=false 但有同步权限的等级同样需要启用
          //（onProChanged 内部按 effective features 重评估，不以此为门禁）
          var _featCloudSync = (((status || {}).gradeConfig || {}).features || {}).cloudSync === true;
          if ((status.isPro || _featCloudSync) && typeof wpzlSyncEngine !== 'undefined') {
            try { wpzlSyncEngine.onProChanged(true); } catch (e) { /* ignore */ }
          }
        }
        sendResponse({ success: true, data: status });
      })
      .catch(function (err) { sendResponse({ success: false, error: err.message }); });
    return true;
  }

  if (request.type === 'pro-cache-clear') {
    _wpzlClearProCache();
    wpzl_getProStatus(true)
      .then(function (status) { sendResponse({ success: true, data: status }); })
      .catch(function (err) { sendResponse({ success: false, error: err.message }); });
    return true;
  }

  // P2-15: 文档大小精确预检桥（manager → SW → server-api，JWT/401 自动刷新/错误分类白得）
  if (request.type === 'doc-size-check') {
    wpzl_docSizeCheck(request.html)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'size-check failed' }); });
    return true;
  }

  // ---- 用户信息面板（manager 右上角）----

  // 改名：成功后回写 wpzl_auth.user（含新 name/hasPassword/avatarUpdatedAt）+ IDB userIdentity.authorName
  //（新标注携带新名；服务端 annotations.authorName 是客户端透传冗余字段，旧标注保持旧名）→ 广播热更。
  if (request.type === 'user-profile-update') {
    wpzl_updateUserName(request.name)
      .then(async function (user) {
        await _wpzlMergeAuthUser(user);
        try { await db.saveSetting({ key: 'userIdentity', authorId: String(user.id), userId: String(user.id), authorName: user.name, loginId: user.loginId }); } catch (e) { /* ignore */ }
        try { chrome.runtime.sendMessage({ type: 'wpzl-user-profile-updated', user: user }).catch(function () { /* no receiver */ }); } catch (e) { /* ignore */ }
        sendResponse({ success: true, data: user });
      })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'update failed' }); });
    return true;
  }

  // 改密/设密：成功后回写 hasPassword=true + 广播。
  if (request.type === 'user-password-change') {
    wpzl_changePassword(request.currentPassword, request.newPassword)
      .then(async function (user) {
        await _wpzlMergeAuthUser(user);
        try { chrome.runtime.sendMessage({ type: 'wpzl-user-profile-updated', user: user }).catch(function () { /* no receiver */ }); } catch (e) { /* ignore */ }
        sendResponse({ success: true, data: user });
      })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'password change failed' }); });
    return true;
  }

  // 产品更新邮件偏好开关：成功后回写 wpzl_auth.user（含 marketingEmailOptIn）→ 复用广播热更。
  if (request.type === 'user-marketing-email-update') {
    wpzl_updateMarketingOptIn(request.optIn)
      .then(async function (user) {
        await _wpzlMergeAuthUser(user);
        try { chrome.runtime.sendMessage({ type: 'wpzl-user-profile-updated', user: user }).catch(function () { /* no receiver */ }); } catch (e) { /* ignore */ }
        sendResponse({ success: true, data: user });
      })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'update failed' }); });
    return true;
  }

  // 用户信息重拉（GET /users/me）：面板打开时兜底旧会话 wpzl_auth.user 缺新字段的问题，回写缓存。
  if (request.type === 'user-info-refresh') {
    wpzl_getUserInfo()
      .then(async function (user) {
        if (user) await _wpzlMergeAuthUser(user);
        sendResponse({ success: true, data: user || null });
      })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'fetch failed' }); });
    return true;
  }

  // 头像上传：dataURL → Blob → server-api → 写本地头像缓存 + 回写 auth.user.avatarUpdatedAt → 广播。
  if (request.type === 'avatar-upload') {
    (async function () {
      try {
        var blob = _wpzlDataUrlToBlob(request.dataUrl);
        var resp = await wpzl_uploadAvatar(blob);
        var user = resp.data || resp;
        await _wpzlMergeAuthUser(user);
        await _wpzlSaveLocalAvatar(user.id, request.dataUrl, user.avatarUpdatedAt);
        try { chrome.runtime.sendMessage({ type: 'wpzl-avatar-updated', dataUrl: request.dataUrl }).catch(function () { /* no receiver */ }); } catch (e) { /* ignore */ }
        sendResponse({ success: true, data: user });
      } catch (e) {
        sendResponse({ success: false, error: (e && e.message) || 'avatar upload failed' });
      }
    })();
    return true;
  }

  // 取头像 dataURL：本地缓存（userId 匹配）优先；miss 则从服务端预签名 URL 拉取回填（本地优先不重复拉取）。
  if (request.type === 'avatar-get') {
    (async function () {
      try {
        var auth = await new Promise(function (res) { chrome.storage.local.get(['wpzl_auth'], function (r) { res(r.wpzl_auth || null); }); });
        var userId = auth && auth.user && auth.user.id;
        var local = await new Promise(function (res) { chrome.storage.local.get(['wpzl_avatar'], function (r) { res(r.wpzl_avatar || null); }); });
        if (local && local.dataUrl && userId && String(local.userId) === String(userId)) {
          sendResponse({ success: true, data: { dataUrl: local.dataUrl, updatedAt: local.updatedAt || null } });
          return;
        }
        var info = await wpzl_getAvatarUrl();
        if (!info || !info.url) {
          sendResponse({ success: true, data: null });
          return;
        }
        var dataUrl = await _wpzlFetchBlobAsDataUrl(info.url);
        await _wpzlSaveLocalAvatar(userId, dataUrl, info.avatarUpdatedAt);
        sendResponse({ success: true, data: { dataUrl: dataUrl, updatedAt: info.avatarUpdatedAt } });
      } catch (e) {
        sendResponse({ success: false, error: (e && e.message) || 'avatar get failed' });
      }
    })();
    return true;
  }

  if (request.type === 'user-usage') {
    wpzl_getUsage()
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'usage failed' }); });
    return true;
  }

  // ---- 云存储管理（manager「云存储管理」弹窗）----

  if (request.type === 'storage-overview') {
    wpzl_storageOverview()
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'storage overview failed' }); });
    return true;
  }

  if (request.type === 'storage-list') {
    wpzl_storageList(request.listType, request.params)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'storage list failed' }); });
    return true;
  }

  if (request.type === 'storage-delete') {
    (async function () {
      try {
        var data = await wpzl_storageDelete(request.payload);
        // 删除走服务端墓碑，触发一次同步让本地副本尽快清理（失败不阻断响应）
        try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
        sendResponse({ success: true, data: data });
      } catch (err) {
        sendResponse({ success: false, error: (err && err.message) || 'storage delete failed' });
      }
    })();
    return true;
  }

  if (request.type === 'grade-list') {
    wpzl_getGrades(request.forceRefresh || false)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'grades failed' }); });
    return true;
  }

  if (request.type === 'upgrade-info') {
    wpzl_getUpgradeInfo()
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'upgrade info failed' }); });
    return true;
  }

  // ---- 支付（Waffo Pancake；manager 用户面板）----

  if (request.type === 'payment-products') {
    wpzl_getPaymentProducts()
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'payment products failed', serverCode: (err && err.serverCode) || 0 }); });
    return true;
  }

  if (request.type === 'payment-pay-hold') {
    wpzl_getPayHold()
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'pay hold failed', serverCode: (err && err.serverCode) || 0 }); });
    return true;
  }

  if (request.type === 'payment-create-order') {
    // 跨窗口在途去重（2026-11-08 双收银台事故）：升级面板是独立 popup 窗口，两个面板各自持有
    // 自己的 pendingOrderNo，单窗口内的按钮禁用来不及拦住另一窗口。同产品并发请求共享同一次
    // 下单结果，避免一次点击被打成两笔订单 / 两套结账会话。
    var _payKey = String(request.productCode || '');
    if (_wpzlPayCreateInFlight[_payKey]) {
      _wpzlPayCreateInFlight[_payKey].push(sendResponse);
      return true;
    }
    _wpzlPayCreateInFlight[_payKey] = [sendResponse];
    var _paySettle = function (payload) {
      var waiting = _wpzlPayCreateInFlight[_payKey] || [];
      delete _wpzlPayCreateInFlight[_payKey];
      waiting.forEach(function (fn) { try { fn(payload); } catch (e) { /* ignore */ } });
    };
    wpzl_createPaymentOrder(request.productCode)
      .then(function (data) { _paySettle({ success: true, data: data }); })
      .catch(function (err) { _paySettle({ success: false, error: (err && err.message) || 'create order failed', serverCode: (err && err.serverCode) || 0 }); });
    return true;
  }

  if (request.type === 'payment-orders') {
    wpzl_getMyOrders(request.limit)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'orders failed' }); });
    return true;
  }

  if (request.type === 'payment-order-status') {
    wpzl_getPaymentOrderStatus(request.orderNo)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'order status failed' }); });
    return true;
  }

  if (request.type === 'payment-refund') {
    wpzl_requestRefund(request.orderNo, request.reason)
      .then(function (data) { sendResponse({ success: true, data: data }); })
      .catch(function (err) { sendResponse({ success: false, error: (err && err.message) || 'refund failed', serverCode: (err && err.serverCode) || 0 }); });
    return true;
  }

  // ---- Sync operations ----

  if (request.type === 'get-sync-failures') {
    if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.getSyncFailures === 'function') {
      wpzlSyncEngine.getSyncFailures()
        .then(function (data) { sendResponse({ success: true, data: data }); })
        .catch(function (err) { sendResponse({ success: false, error: err.message }); });
      return true;
    }
    sendResponse({ success: false, error: 'sync engine unavailable' });
    return false;
  }

  if (request.type === 'retry-upload') {
    var _retryPayload = request.payload || {};
    // 截图未上云（THUMBNAIL_PENDING）：触发 pageRect 缩略图后台补传，不走标注 sync 重试
    if (_retryPayload.thumbPending && typeof _flushPendingThumbnails === 'function') {
      // 先复位耗尽：THUMB_EXHAUSTED 的项被补传器跳批（P1-24），不复位则本按钮点了什么也不发生。
      // 手动重传是用户显式意图，理应打破自动重试的耗尽闸门。
      var _resetFirst = Promise.resolve();
      if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._resetThumbExhausted === 'function') {
        _resetFirst = Promise.resolve(wpzlSyncEngine._resetThumbExhausted()).catch(function () { /* ignore */ });
      }
      // P1-9：孤儿项（记录 THUMBNAIL_PENDING=true 但 id 已不在清单）重传前必须回填清单，
      // 否则 flush 读空清单后原样返回 success，按钮无效。回填走串行链，与 note/drop 无丢更新窗口。
      _resetFirst = _resetFirst.then(function () {
        if (_retryPayload.id && typeof _wpzlMergeThumbPendingIds === 'function') {
          return _wpzlMergeThumbPendingIds([String(_retryPayload.id)]).catch(function () { /* ignore */ });
        }
      });
      _resetFirst
        .then(function () { return _flushPendingThumbnails(); })
        .then(function () { sendResponse({ success: true }); })
        .catch(function (err) { sendResponse({ success: false, error: err.message }); });
      return true;
    }
    if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.retryUpload === 'function') {
      wpzlSyncEngine.retryUpload(_retryPayload)
        .then(function (data) { sendResponse({ success: true, data: data }); })
        .catch(function (err) { sendResponse({ success: false, error: err.message }); });
      return true;
    }
    sendResponse({ success: false, error: 'sync engine unavailable' });
    return false;
  }

  if (request.type === 'discard-upload') {
    // 放弃单项上传：保留本地数据，仅清脏同步状态使其离开失败队列（thumbPending/image/mark 由 discardUpload 内部分支处理）
    if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.discardUpload === 'function') {
      wpzlSyncEngine.discardUpload(request.payload || {})
        .then(function (data) { sendResponse({ success: true, data: data }); })
        .catch(function (err) { sendResponse({ success: false, error: err.message }); });
      return true;
    }
    sendResponse({ success: false, error: 'sync engine unavailable' });
    return false;
  }

  if (request.type === 'retry-upload-all') {
    if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.retryUploadAll === 'function') {
      wpzlSyncEngine.retryUploadAll(request.payload || {})
        .then(function (data) { sendResponse({ success: true, data: data }); })
        .catch(function (err) { sendResponse({ success: false, error: err.message }); });
      return true;
    }
    sendResponse({ success: false, error: 'sync engine unavailable' });
    return false;
  }

  if (request.type === 'sync-status') {
    if (typeof wpzlSyncEngine !== 'undefined') {
      // 异步等待 init() 完成：MV3 SW 启动时 onMessage 同步注册、init() 通过 .then()
      // 链异步触发。若不等待，查询在 init 完成前到达会拿到 _syncEnabled=false，
      // 导致 manager 端「立即同步」按钮消失。
      (async function () {
        var _initSnapshot = wpzlSyncEngine.getInitState();
        console.log('[BG] sync-status query: initState=' + _initSnapshot.state +
          ', elapsedMs=' + _initSnapshot.elapsedMs +
          ', _syncEnabled=' + _initSnapshot.syncEnabled);
        // 仅当 init 尚未完成（pending / running）时等待，最多 3 秒
        if (_initSnapshot.state !== 'completed' && _initSnapshot.state !== 'failed') {
          console.log('[BG] sync-status: init pending, waiting up to 3000ms...');
          try {
            await wpzlSyncEngine.waitForInit(3000);
          } catch (e) {
            console.warn('[BG] sync-status: waitForInit threw:', e && e.message);
          }
        }
        try {
          var status = await wpzlSyncEngine.getStatus();
          console.log('[BG] sync-status respond: enabled=' + status.enabled +
            ', initState=' + status.initState +
            ', isLoggedIn=' + status.isLoggedIn +
            ', isPro=' + status.isPro +
            ', pending=' + status.pendingCount);
          sendResponse({ success: true, data: status });
        } catch (err) {
          console.warn('[BG] sync-status error:', err.message);
          sendResponse({ success: false, error: err.message });
        }
      })();
    } else {
      console.warn('[BG] sync-status: wpzlSyncEngine undefined');
      sendResponse({ success: true, data: { enabled: false } });
    }
    return true;
  }

  // 轻量同步状态查询（manager 轮询用，不触发网络/存储读，避免 sync-status 的 heavy path）
  if (request.type === 'sync-running') {
    var _eng2 = (typeof wpzlSyncEngine !== 'undefined') ? wpzlSyncEngine : null;
    var _init2 = _eng2 ? _eng2.getInitState() : { state: 'completed' };
    var _prog = (_eng2 && _eng2._getDownloadProgress) ? _eng2._getDownloadProgress() : { total: null, pulled: 0 };
    sendResponse({
      success: true,
      data: {
        syncing: !!(_eng2 && _eng2._isLocked && _eng2._isLocked()),
        state: wpzl_sync_state,
        initState: _init2.state,
        downloadTotal: _prog.total,
        downloadPulled: _prog.pulled
      }
    });
    return true;
  }

  // 云端资产签名 URL（manager.js / control-panel.js 读 objectKey 时调用）
  if (request.type === 'getSignedAssetUrl') {
    if (typeof wpzl_getSignedAssetUrl !== 'function') {
      sendResponse({ success: false, error: 'asset-uploader not loaded' });
      return false;
    }
    wpzl_getSignedAssetUrl(request.objectKey)
      .then(function (signedUrl) { sendResponse({ success: true, signedUrl: signedUrl }); })
      .catch(function (e) {
        console.warn('[BG] getSignedAssetUrl failed:', e.message);
        sendResponse({ success: false, error: e.message });
      });
    return true;
  }

  if (request.type === 'sync-trigger') {    if (typeof wpzlSyncEngine !== 'undefined') {
      // 等待可能正在进行的后台同步完成，再发起新的同步
      (async function () {
        try {
          // 在等待前记录展示基线，以涵盖等待期间完成的后台同步
          var baseline = await wpzlSyncEngine.getManualSyncBaseline();
          console.log('[BG] sync-trigger: baseline totalPushed=' + (baseline && baseline.totalPushed) +
            ' totalPulled=' + (baseline && baseline.totalPulled));
          // P1-9：等锁改进程内事件通知（wpzlSyncEngine.waitForUnlock——withSyncLock 释放时
          // resolve 全部 waiter，5min 超时兜底）。此前 200ms×1500 次 getStatus 轮询，
          // 每次轮询都跨 store 做 count 查询，后台同步长跑时是持续的本地点负载。
          if (wpzlSyncEngine._isLocked && wpzlSyncEngine._isLocked()) {
            console.log('[BG] sync-trigger: waiting for in-progress sync (event notified)');
            await wpzlSyncEngine.waitForUnlock(5 * 60 * 1000);
          }
          var result = await wpzlSyncEngine.sync('manual');
          if (!result || result.skipped) {
            console.log('[BG] sync-trigger: sync skipped (in_progress)');
            sendResponse({ success: false, error: 'sync_in_progress' });
            return;
          }
          if (result.error) {
            console.warn('[BG] sync-trigger: sync error:', result.error);
            sendResponse({ success: false, error: result.error });
            return;
          }
          // 用「自上次提示以来的累计增量」替换单次周期计数：
          // 后台（防抖推送/懒拉取）常抢先完成同步，导致单次周期 pushed/pulled 恒为 0
          var delta = await wpzlSyncEngine.commitManualSync(baseline);
          // 区分「本次触发」与「自上次查看以来累计（含自动同步）」：
          //   thisRunPush/Pull = 本次 sync() 实际推/拉的条目数
          //   autoPushed/Pulled = 累计 delta 中由本浏览器自动同步完成的部分（= delta - thisRun）
          // 主显示用 thisRun（与同步详情报告里的明细对齐），自动同步数用副文本提示。
          var thisRunPush = result.pushed || 0;
          var thisRunPull = result.pulled || 0;
          var autoPushed = Math.max(0, (delta.pushed || 0) - thisRunPush);
          var autoPulled = Math.max(0, (delta.pulled || 0) - thisRunPull);
          console.log('[BG] sync-trigger: this-run push=' + thisRunPush + ' pull=' + thisRunPull +
            ' | auto(synced since last view) push=' + autoPushed + ' pull=' + autoPulled +
            ' | delta(from baseline) push=' + delta.pushed + ' pull=' + delta.pulled +
            ' | attemptedPushAnn=' + (result.report && result.report.attemptedPushAnn));
          var data = Object.assign({}, result, {
            pushed: thisRunPush,
            pulled: thisRunPull,
            autoPushedSinceLastView: autoPushed,
            autoPulledSinceLastView: autoPulled,
            deltaPushed: delta.pushed,
            deltaPulled: delta.pulled
          });
          sendResponse({ success: true, data: data });
        } catch (err) {
          console.warn('[BG] sync-trigger: exception:', err.message);
          sendResponse({ success: false, error: err.message });
        }
      })();
    } else {
      sendResponse({ success: false, error: chrome.i18n.getMessage('syncNotAvailable') });
    }
    return true;
  }

  // 反馈与建议（SSO 到问题反馈系统 Apache Answer）—— popup / manager / 设置页 / 注入面板四个入口统一走这里
  // 注意：这是顶层 request.type 分支（不是 db-operation）；注入面板经 content.js 转发的 wpzl-open-feedback 也并入本分支。
  if (request.type === 'openFeedback' || request.type === 'wpzl-open-feedback') {
    (async function () {
      var _ofbFeedback = (typeof WPZL_FEEDBACK_URL !== 'undefined') ? WPZL_FEEDBACK_URL : '';
      _ofbFeedback = _ofbFeedback.replace(/\/+$/, '');
      if (!_ofbFeedback) { sendResponse({ success: false, error: 'feedback url missing' }); return; }
      var _ofbBase = (typeof WPZL_SERVER_BASE !== 'undefined') ? WPZL_SERVER_BASE : '';
      _ofbBase = _ofbBase.replace(/\/+$/, '');
      // 已登录则先用 access token 调 /api/v1/auth/page-session 写 wpzl_page cookie（SameSite=Lax），
      // 再开 Answer 连接器登录入口 —— 浏览器导航自动带 cookie，走 authorize→code→token→userinfo 自动进入（场景 A）。
      // 未登录则不写 cookie，仍开入口 → authorize 无会话 → 落到 webpz 网页登录页（场景 B）。
      var _ofbToken = '';
      try {
        var _ofbGat = await _wpzlGetTokens();
        if (_ofbGat && _wpzlIsTokenExpired(_ofbGat) && _ofbGat.refreshToken) {
          try { await _wpzlRefreshAccessToken(); _ofbGat = await _wpzlGetTokens(); } catch (e) { /* ignore */ }
        }
        _ofbToken = (_ofbGat && _ofbGat.accessToken) ? _ofbGat.accessToken : '';
      } catch (e) { _ofbToken = ''; }
      if (_ofbToken && _ofbBase) {
        try {
          await fetch(_ofbBase + '/api/v1/auth/page-session', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Authorization': 'Bearer ' + _ofbToken },
            signal: AbortSignal.timeout(10000) // E-P2-3: 挂起不再阻塞后续开 tab
          });
        } catch (e) { /* ignore */ }
      }
      chrome.tabs.create({ url: _ofbFeedback + '/answer/api/v1/connector/login/basic' });
     // chrome.tabs.create({ url: _ofbFeedback + '/' });
      sendResponse({ success: true });
    })();
    return true; // 异步 sendResponse，保持消息通道开启
  }

  // v1.1.0: 评分邀请弹窗「去评分」——注入面板经 content.js 转发的 wpzl-open-store-review。
  // 自动识别浏览器：Edge 跳 Edge Add-ons 条目页，其余（Chrome/Chromium 系）跳 CWS 评论区直达页。
  // chrome.tabs.create 不需要额外权限；URL 与 website/i18n.js 的商店链接保持一致。
  if (request.type === 'wpzl-open-store-review') {
    var _srIsEdge = false;
    try {
      var _srUad = navigator.userAgentData; // SW 上下文可用（Chromium 90+，manifest 最低 109）
      _srIsEdge = !!(_srUad && _srUad.brands && _srUad.brands.some(function (b) { return /Microsoft Edge/i.test(b.brand || ''); }))
        || /Edg\//.test(navigator.userAgent || '');
    } catch (e) {
      _srIsEdge = /Edg\//.test(navigator.userAgent || '');
    }
    var _srUrl = _srIsEdge
      ? 'https://microsoftedge.microsoft.com/addons/detail/nkepoeakeihkniefgjeofdfhmfmdaedd'
      : 'https://chromewebstore.google.com/detail/sagitnote/llajphjgjgmplakjdjoaghojmgogghic/reviews';
    chrome.tabs.create({ url: _srUrl });
    sendResponse({ success: true });
    return false;
  }

  // 数据库操作
  if (request.type === 'db-operation') {
    (async () => {
      try {
        if (!dbReady) await initDB();

        const { operation, params, pageTitle, pageScheme, pagePort } = request;

        // D-31 修复：db-operation 按 sender 分级。
        // 扩展页面（manager/settings/popup/auth，sender.url = chrome-extension://<id>/…）全量放行；
        // 网页侧 content.js 桥转发的消息（sender.url 为 http/https/file 页面）只放行注入 bundle 与
        // content.js 各桥实际使用的 op 白名单——bundle.js 与页面脚本同处 page world，来源不可区分，
        // 此前任意网页脚本 postMessage 即可驱动 clearAllData 清空本地库 / 触达管理面 op。
        // 批量读/重写 op（exportAll/backupAll/restoreBackup/claimPageAnnotations）在白名单内，
        // 但 content.js 桥上另有「真实用户手势」门（isTrusted 事件不可伪造，见 handleStorageRequest）。
        var _PAGE_BRIDGE_OPS = {
          // 标注读写（划词/面板抽屉/批注对话框核心链路）
          loadAnnotations: true, saveAnnotation: true, updateAnnotation: true,
          deleteAnnotation: true,
          getAllTags: true, saveTag: true,
          getUserIdentity: true, updateAuthorName: true,
          claimPageAnnotations: true,
          // 页面级字段（收藏/整页批注，page-summary 桥）
          savePageNote: true, getPageNote: true, setFavorite: true,
          // 图片链路（自动保存三级级联 + 上云 + 缩略图 + raw 旁路）
          getImageData: true, getImageDataByPageAndKey: true,
          getLocalThumbnail: true, saveLocalThumbnail: true,
          backfillThumbnailFromCloud: true, cleanupImageReferences: true,
          resolveImageKeys: true, uploadAsset: true, signAsset: true,
          saveImageFromUrl: true, saveImageFromBase64: true,
          captureTab: true,
          // 快照（页面快照创建/打开）
          putSnapshot: true, openSnapPage: true,
          // 面板导出/导入（content.js 桥另有「扩展 UI 手势」门，P0 2026-09-19）。
          // backupAll 已移出页面桥：注入侧无调用者（面板备份按钮 2026-09-05 已删），仅
          // manager 扩展页使用（extension sender 不经本白名单）——留在桥内即「一次点击
          // 外带全库 31.7MB」攻击面（SEC-03 实测复现，见 docs/fenxi/2026-09-19 复核报告）。
          exportAll: true, restoreBackup: true,
          // content.js 自用（file:// 读取 / 旧库迁移 / 服务端 base / 跳过注入判定）
          readFileUrl: true, migrateData: true, getServerBase: true
        };
        var _extOrigin = chrome.runtime.getURL('');
        var _fromExtPage = !!(sender && sender.url && sender.url.indexOf(_extOrigin) === 0);
        if (!_fromExtPage && !_PAGE_BRIDGE_OPS[operation]) {
          console.warn('[SW] db-operation rejected (web page sender, op not whitelisted):',
            operation, sender && sender.url);
          sendResponse({ success: false, error: 'operation not allowed from web page' });
          return;
        }

        // 决策 7：强制登录守卫
        // 业务读写操作（标注/页面/图片/标签/导出/导入）必须登录才能调用。
        // 工具类操作（readFileUrl / captureTab / clearAllData）允许未登录调用 —
        //   clearAllData 只清不写，且恰是「换号被拦截→要求清空→但已登出」死锁的唯一出口：
        //   换号拦截不写 token（_finalizeAuth 改动 A 后拦截分支零写入，原会话保持），此时未登录态若拒绝清空，
        //   owner/folders 残留 → hasAnyUserData 恒 true → 永远无法登录新账号。
        // 调用方未登录时直接 reject，避免下游函数因 uid=null 走兜底分支导致脏数据。
        var _AUTH_REQUIRED_OPS = {
          loadAnnotations: true, saveAnnotation: true, deleteAnnotation: true,
          updateAnnotation: true, getAllPages: true, searchAnnotations: true,
          searchByTag: true, getAllTags: true, saveTag: true,
          exportAll: true, getStatistics: true,
          backupAll: true, restoreBackup: true, migrateData: true,
          getImageData: true, saveImageData: true, deleteImageData: true,
          getImageDataByPage: true, getImageDataByImageKey: true,
          uploadAsset: true, saveLocalThumbnail: true, getLocalThumbnail: true,
          backfillThumbnailFromCloud: true,
          checkImageReferences: true,
          claimPageAnnotations: true,
          deletePage: true
        };
        if (_AUTH_REQUIRED_OPS[operation]) {
          // DB 读写路径跳过连通性检查：Trust 本地 token 缓存，不阻塞等 fetch /health 超时。
          // Token 真正过期由 sync engine 的 TOKEN_EXPIRED 广播 + manager reauth dialog 处理。
          var _authStatus = await wpzl_getAuthStatus({ skipConnectivityCheck: true });
          if (!_authStatus.isLoggedIn) {
            // 未登录本地模式（游客档，2026-09-29）：命中 _LOCAL_MODE_OPS 白名单的本地读写 op
            // 直接放行，且不要求 hasAnyUserData——游客空库首条标注必须可写。白名单只收纯本地 op；
            // 任何触网 op（uploadAsset/signAsset/backfillThumbnailFromCloud 等）不在表内，维持拒绝。
            // db 层 uid 隔离兜底：未登录 USER_ID=随机 base62 authorId（getUserIdentity）。
            var _LOCAL_MODE_OPS = {
              // 写（游客创建/编辑/删除/备份恢复/迁移链路）
              saveAnnotation: true, deleteAnnotation: true, updateAnnotation: true,
              saveTag: true, deletePage: true, claimPageAnnotations: true,
              saveImageData: true, deleteImageData: true, saveLocalThumbnail: true,
              restoreBackup: true, migrateData: true,
              // 读（原 _READ_ONLY_LOCAL_OPS 全量 + getImageData——标注缩略图绘制需要，原表漏收）
              loadAnnotations: true, getAllPages: true, searchAnnotations: true,
              searchByTag: true, getAllTags: true,
              getStatistics: true, getAllDocuments: true, getAllSnapshots: true,
              getAllFolders: true, getPageNote: true,
              backupAll: true, getLocalThumbnail: true,
              getImageDataByPage: true, getImageDataByImageKey: true,
              checkImageReferences: true, getImageData: true
            };
            if (!_LOCAL_MODE_OPS[operation]) {
              // 数据可达性优先（与 manager 守卫同一决策）：本地仍有用户数据 → 本地模式放行只读操作。
              // 场景：换号被拦截回滚 token / refresh 失效（连续 401）登出后，用户必须仍能查看本地数据，
              // 否则被锁死（登新账号被 hasAnyUserData 拦、原账号 token 已不可用、manager 空白）。
              // 写操作（save/delete/restore 等）维持强制登录，防止匿名态产生无法归属的脏数据。
              var _READ_ONLY_LOCAL_OPS = {
                loadAnnotations: true, getAllPages: true, searchAnnotations: true,
                searchByTag: true, getAllTags: true,
                getStatistics: true, getAllDocuments: true, getAllSnapshots: true,
                getAllFolders: true, getPageNote: true,
                backupAll: true, getLocalThumbnail: true,
                getImageDataByPage: true, getImageDataByImageKey: true,
                checkImageReferences: true
              };
              if (!_READ_ONLY_LOCAL_OPS[operation]) {
                sendResponse({ success: false, error: 'Authentication required', authRequired: true });
                return;
              }
              var _localData = false;
              try { _localData = await db.hasAnyUserData(); } catch (e) { _localData = false; }
              if (!_localData) {
                sendResponse({ success: false, error: 'Authentication required', authRequired: true });
                return;
              }
            }
          }
        }

        // 属主分裂态写操作拒止（spec 改动 B2）：已登录但本地数据属主≠登录账号时拒绝写操作
        // （manager 阻断对话框挡展示层，此处挡 bundle 经 content.js 的数据层写路径）。
        // 只读操作不在此集合，放行（数据可达性优先——分裂态仍可查看旧属主数据）。
        // 集合 = _AUTH_REQUIRED_OPS 的写 op + 4 个表外 bundle 可达写 op
        // （putSnapshot/saveImageFromUrl/saveImageFromBase64/cleanupImageReferences，
        //  经 content.js :2145/:908/:900/:915 可达；未登录时另有处理，此处只拦已登录分裂态）。
        // 已知不在集合的写 op：restoreChunk/updateAuthorName（manager 导入流程与 bundle 改名路径，
        // 前者被阻断对话框挡住，后者影响面小——spec 只要求 4 个表外 op，遵循之）。
        var _OWNER_WRITE_OPS = {
          saveAnnotation: true, deleteAnnotation: true, updateAnnotation: true,
          saveTag: true, deletePage: true, claimPageAnnotations: true,
          uploadAsset: true, saveImageData: true, deleteImageData: true,
          saveLocalThumbnail: true, backfillThumbnailFromCloud: true,
          restoreBackup: true, migrateData: true,
          putSnapshot: true, saveImageFromUrl: true, saveImageFromBase64: true, cleanupImageReferences: true
        };
        if (_OWNER_WRITE_OPS[operation] && await _isOwnerAuthMismatch()) {
          sendResponse({ success: false, error: 'owner mismatch', ownerMismatch: true });
          return;
        }

        let result;

        switch (operation) {
          case 'loadAnnotations': {
            const annotations = await db.getAnnotations(params.domain, params.webUri);
            const markList = {};
            for (const a of annotations) {
              markList[a.MARK_INFO_ID] = a;
            }
            result = markList;
            // Lazy pull (non-blocking)
            if (typeof wpzlSyncEngine !== 'undefined' && params.webUri) {
              wpzlSyncEngine.pullForUrlIfNeeded(params.webUri).catch(function (e) {
                console.warn('[Sync] lazy pull failed:', e);
              });
            }
            break;
          }
          case 'saveAnnotation': {
            // v1.1.0: 第 4 参 onCreated 回调 —— 仅本地新建（!existing）时触发，闭包捕获 sender
            // （tab.id/frameId）供评分邀请定向投递；回调随调用独立创建，无模块级暂存竞态。
            result = await db.saveAnnotation(params.annotation, pageTitle, pageScheme,
              function () { wpzl_handleLifetimeMarkCreated(sender); }, pagePort);
            // Sync hook: mark dirty
            if (typeof wpzlSyncEngine !== 'undefined') {
              wpzlSyncEngine.markDirty(params.annotation.MARK_INFO_ID, 0xFF)
                .catch(function (e) { console.warn('[Sync] markDirty failed:', e); });
              wpzlSyncEngine.requestSync('normal');
            }
            break;
          }
          case 'deleteAnnotation': {
            // 删除前先取标注：页面截图（$pageRect）的缩略图是「每标注独占」的 R2 对象
            // （objectKey = u/{uid}/{pageKey}/{imageKey}.webp，存在 annotation.THUMBNAIL）。
            // 删整页走 hardDeleteByPageKey 批清，覆盖不到「单条标注删除」→ 此处必须回收，否则
            // 云存储 + ImageAsset 行 + 配额永久泄漏。$pic 图备份为多标注共享（删页时清）、
            // $rectFrame/$elemMark/文字无截图，均不在此列。本机发起删除即负责清 R2：对端只收
            // 标注墓碑、无需触 R2。fire-and-forget，不阻断删除流程。
            var _delAnn = null;
            try { _delAnn = await db.getAnnotation(params.markInfoId); } catch (e) { /* ignore */ }
            var _delIsPageRect = !!(_delAnn && _delAnn.END_XPATH === '$pageRect');
            if (_delIsPageRect && _delAnn.THUMBNAIL && typeof wpzl_assetDelete === 'function') {
              wpzl_assetDelete(_delAnn.THUMBNAIL).catch(function (e) {
                console.warn('[deleteAnnotation] pageRect R2 cleanup failed:', e && e.message);
                // P1-23: 入补偿队列，connectivity-tick 重试（防对象+配额永久泄漏）
                if (typeof wpzlSyncEngine !== 'undefined' && wpzlSyncEngine._noteR2DeletePending) {
                  try { wpzlSyncEngine._noteR2DeletePending(_delAnn.THUMBNAIL, 'key'); } catch (e2) { /* ignore */ }
                }
              });
            }
            // Soft delete when sync enabled, hard delete otherwise
            if (typeof wpzlSyncEngine !== 'undefined' && wpzlSyncEngine.isEnabled()) {
              var _softUpdates = {
                SYNC_STATUS: 'pending_deleted',
                DIRTY_BITS: (1 << 5)
              };
              // 截图尚未上云就被删除（THUMBNAIL_PENDING=true）：清标记，否则 _flushPendingThumbnails
              // 仍会给这条已删标注补传截图→产生 R2 孤儿（删标注比 flush 早赢的竞态）。
              if (_delIsPageRect) _softUpdates.THUMBNAIL_PENDING = false;
              await db.updateAnnotation(params.markInfoId, _softUpdates);
              // P1-18c: 删除路径出清单（软删清 PENDING / 硬删记录消失都一样）
              if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._removeThumbPending === 'function') {
                try { wpzlSyncEngine._removeThumbPending(params.markInfoId); } catch (e) { /* ignore */ }
              }
              wpzlSyncEngine.requestSync('normal');
            } else {
              await db.deleteAnnotation(params.markInfoId);
              // 修复 D：硬删时级联清理 localThumbnails 孤儿（软删分支保留行与缩略图，不动）
              try { await db.deleteLocalThumbnail(params.markInfoId); } catch (e) { /* ignore */ }
              if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._removeThumbPending === 'function') {
                try { wpzlSyncEngine._removeThumbPending(params.markInfoId); } catch (e) { /* ignore */ }
              }
            }
            // 删除后重算该页 annotationCount（与 save 路径对称），否则侧栏徽标计数不更新
            if (_delAnn && _delAnn.WEB_URI) db._scheduleRecountAnnotationCount(_delAnn.WEB_URI);
            result = { success: true };
            break;
          }
          case 'deletePage': {
            // 级联软删 page + 所有匹配 annotation；非同步模式硬删 + 清理图片/缩略图。
            // 同步开启：等 init 完成（避免 SW 重启窗口期误走硬删）。
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { await wpzlSyncEngine.waitForInit(3000); } catch (e) { /* ignore */ }
            }
            if (typeof wpzlSyncEngine !== 'undefined' && wpzlSyncEngine.isEnabled()) {
              result = await db.softDeletePage(params.url, params.domain);
              // D2：删页级联清该页图片。服务端批端点立即删 R2+配额（幂等），同步页墓碑再触发一次为兜底；
              // 本地 imageData 物理清掉，避免被当 active 重新推送"复活"服务端 tombstone。fire-and-forget。
              try {
                var _pk = wpzl_md5(params.url);
                if (_pk) {
                  if (typeof wpzl_assetDeleteByPage === 'function') {
                    wpzl_assetDeleteByPage(_pk).catch(function (e) {
                      console.warn('[deletePage] image cloud cleanup:', e && e.message);
                      // P1-23: 入补偿队列重试
                      if (typeof wpzlSyncEngine !== 'undefined' && wpzlSyncEngine._noteR2DeletePending) {
                        try { wpzlSyncEngine._noteR2DeletePending(_pk, 'page'); } catch (e2) { /* ignore */ }
                      }
                    });
                  }
                  db.deleteImageDataByPageKey(_pk).catch(function (e) { console.warn('[deletePage] local imageData cleanup:', e && e.message); });
                }
              } catch (e) { /* ignore */ }
              wpzlSyncEngine.requestSync('normal');
            } else {
              // P0(CL-02) 2026-09-19 审计复核：同步未启用（或 SW 冷启动 waitForInit 3s 超时
              // 误判）时，原路径只删本地——该页云对象（u/{uid}/{pageKey}/*）与 image_assets
              // 行、配额永久泄漏。hardDeletePage 会物理删本地行，故先触发云端回收：删除失败/
              // 未登录则入 r2_delete_pending 补偿队列（sync 恢复后 connectivity-tick 重试）。
              // 服务端批端点幂等，页面从未上云时为无害 no-op。
              try {
                var _pkH = wpzl_md5(params.url);
                if (_pkH) {
                  var _noteR2Pending = (typeof wpzlSyncEngine !== 'undefined' && wpzlSyncEngine._noteR2DeletePending)
                    ? wpzlSyncEngine._noteR2DeletePending : null;
                  if (typeof wpzl_assetDeleteByPage === 'function') {
                    wpzl_assetDeleteByPage(_pkH).catch(function (e) {
                      console.warn('[deletePage] cloud cleanup (sync disabled):', e && e.message);
                      if (_noteR2Pending) { try { _noteR2Pending(_pkH, 'page'); } catch (e2) { /* ignore */ } }
                    });
                  } else if (_noteR2Pending) {
                    try { _noteR2Pending(_pkH, 'page'); } catch (e2) { /* ignore */ }
                  }
                }
              } catch (e) { /* ignore */ }
              result = await db.hardDeletePage(params.url, params.domain);
            }
            break;
          }
          case 'updateAnnotation': {
            // P1-21: 外部入口（页面/manager 消息）过滤同步内部字段——多 tab 各自持有
            // stale 快照，透传会覆盖同步状态/产生幽灵推送。SW 内部路径（软删 L4493 等）
            // 直调 db.updateAnnotation，不受此过滤影响。
            if (params.updates) {
              for (var _fk of AnnotationDB.SYNC_OWNED_KEYS) delete params.updates[_fk];
            }
            result = await db.updateAnnotation(params.markInfoId, params.updates);
            // Sync hook: mark dirty with computed bits
            if (typeof wpzlSyncEngine !== 'undefined') {
              var syncBits = wpzlSyncEngine._computeDirtyBits(params.updates);
              wpzlSyncEngine.markDirty(params.markInfoId, syncBits)
                .catch(function (e) { console.warn('[Sync] markDirty failed:', e); });
              wpzlSyncEngine.requestSync('normal');
            }
            break;
          }
          case 'getAllPages': {
            result = await db.getAllPages();
            break;
          }
          case 'searchAnnotations': {
            result = await db.searchAnnotations(params.query);
            break;
          }
          case 'exportAll': {
            result = await db.exportAll();
            // D-25: 导出脱敏（IDB 原记录不动）
            if (Array.isArray(result)) {
              for (var _ei = 0; _ei < result.length; _ei++) result[_ei] = _wpzlStripSyncFieldsForExport(result[_ei]);
            }
            break;
          }
          case 'claimPageAnnotations': {
            // 把指定 URL 下所有标注认领为当前用户的（改 AUTHOR_ID/NAME + USER_ID + 标脏）。
            result = await db.claimPageAnnotations(params.domain, params.webUri);
            // 触发推送（claimPageAnnotations 已把 SYNC_STATUS=pending, DIRTY_BITS=0xFF）
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'getStatistics': {
            result = await db.getStatistics();
            break;
          }
          case 'backupAll': {
            result = await db.backupAll();
            // D-25: 导出脱敏（IDB 原记录不动）——必须覆盖 backupAll 返回的**全部** store 数组。
            // 此处曾只剥 result.annotations，导致 documents/snapshots/pages/folders 带着
            // SYNC_EXHAUSTED/SYNC_LAST_ERROR 落进备份文件；再导入到别的账号时导入端只重置
            // SYNC_STATUS/DIRTY_BITS，失败原因被原样搬过去 → pending+exhausted 死状态
            //（既不上传、又不给重试按钮），用户看到上一个账号的限额报错。
            if (result) {
              for (var _bk in result) {
                if (!Object.prototype.hasOwnProperty.call(result, _bk)) continue;
                if (!Array.isArray(result[_bk])) continue;   // 跳过 _meta 等非数组字段
                for (var _bi = 0; _bi < result[_bk].length; _bi++) {
                  result[_bk][_bi] = _wpzlStripSyncFieldsForExport(result[_bk][_bi]);
                }
              }
            }
            break;
          }
          case 'backupChunk': {
            // P1-32: 分块导出。文本 store 200/批；imageData/localThumbnails 携带 base64 大字段，20/批
            // （消息通道 structured clone 约束，目标 ≤8MB/块）。
            var _bcLimit = (params.store === 'imageData' || params.store === 'localThumbnails')
              ? 20 : (parseInt(params.limit, 10) || 200);
            result = await db.getStoreChunk(params.store, parseInt(params.offset, 10) || 0, _bcLimit, params.session);
            // D-25: 导出脱敏（IDB 原记录不动；restore 端强制重置同步字段，无功能影响）
            if (result && Array.isArray(result.records)) {
              for (var _ci = 0; _ci < result.records.length; _ci++) {
                result.records[_ci] = _wpzlStripSyncFieldsForExport(result.records[_ci]);
              }
            }
            break;
          }
          case 'restoreChunk': {
            // P1-32: 流式导入（NDJSON v8）；finalize 后触发同步推送（与 restoreBackup 同款漏点防护）
            // P2：导入会话抑制自动同步——chunk 的长 IDB 写事务与 sync 事务同 store 互斥，
            // 并发实测批延迟 1.7s → 18-104s。finalize 先清标志再触发 requestSync 续传；
            // 导入中途异常（无 finalize）标志滞留由 SW 空闲回收自愈（MV3 idle 后重启即复位）。
            try {
              if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.setImportSession === 'function') {
                wpzlSyncEngine.setImportSession(true);
              }
              result = await db.restoreBackupChunk(params);
              db._invalidateExportKeyCache();   // P0-C：导入写库，弃导出键表缓存
            } finally {
              if (params.finalize && typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.setImportSession === 'function') {
                wpzlSyncEngine.setImportSession(false);
              }
            }
            if (params.finalize && typeof wpzlSyncEngine !== 'undefined') {
              try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'restoreBackup': {
            // P2：同 restoreChunk 的导入会话抑制（legacy 整文件导入）
            try {
              if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.setImportSession === 'function') {
                wpzlSyncEngine.setImportSession(true);
              }
              result = await db.restoreBackup(params);
            } finally {
              if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine.setImportSession === 'function') {
                wpzlSyncEngine.setImportSession(false);
              }
            }
            db._invalidateExportKeyCache();   // P0-C：导入写库，弃导出键表缓存
            // 恢复后触发同步推送（restoreBackup 内部已标 annotations/pages/folders PENDING，漏点2）
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
              // F-4/E-P2-8: 清对账/自愈节流时间戳，强制下次 init 重跑 _reconcilePendingWorkLists
              // 与图片下载清单全表重建——导入的数据不经常规写点，持久化清单是空的
              try {
                if (wpzlSyncEngine._syncClearReconcileGates) wpzlSyncEngine._syncClearReconcileGates();
              } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'migrateData': {
            result = await db.mergeMigratedData(params);
            // 迁移后触发同步推送（mergeMigratedData 已标 PENDING，漏点1）
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'clearAllData': {
            // 设置页「清空本地数据」：清全部本地 store + 同步状态 + 归属账号
            // P1：同登出/预清路径的清空守卫（在飞 sync 批应用不再写回已清库）；
            // try/finally 保证清空异常时守卫必被解除（外层 handler 吞错，滞留会永久禁同步）
            await _guardSyncForLocalClear();
            try {
              await db.clearAllLocalData();
              if (typeof wpzlSyncEngine !== 'undefined') {
                try { await wpzlSyncEngine.resetSyncState(); } catch (e) { /* ignore */ }
              }
            } finally {
              _unguardSyncAfterLocalClear();
            }
            await _setLocalDataOwner(null);
            result = { success: true };
            break;
          }
          case 'readFileUrl': {
            // file:// URL 在 service worker 中可用 fetch 读取（Chrome 99+）
            // F-2: 本 op 在页面桥白名单内且不要求登录，此前无任何校验——任意网页可让 SW fetch
            // 任意 file:// 路径（用户开启"允许访问文件网址"后）并把 base64 回传，构成任意本地文件读取。
            // 收紧为三条件：file: scheme + 恰为发送方当前页 URL + .pdf 后缀。唯一合法场景是
            // content.js 本地 PDF 标注流程（其传的就是 window.location.href，见 content.js PDF 分支）。
            var fileUrl = params.url;
            var _fu = null, _su = null;
            try { _fu = new URL(String(fileUrl || '')); _su = new URL((sender && sender.url) || ''); } catch (e) { /* 走 _allowed=false */ }
            var _rfuAllowed = !!(_fu && _su &&
              _fu.protocol === 'file:' && _su.protocol === 'file:' &&
              _fu.href === _su.href &&
              /\.pdf$/i.test(_fu.pathname));
            if (!_rfuAllowed) {
              throw new Error('readFileUrl only allowed for the current file:// PDF page');
            }
            var resp = await _wpzlFetchWithTimeout(fileUrl, {}, 30000);
            if (!resp.ok) throw new Error('fetch failed: ' + resp.status);
            var buf = await resp.arrayBuffer();
            // 转为 base64 传递（sendResponse 仅支持 JSON 可序列化对象）
            var bytes = new Uint8Array(buf);
            var CHUNK = 8192;
            var binary = '';
            for (var i = 0; i < bytes.length; i += CHUNK) {
              var chunk = bytes.subarray(i, Math.min(i + CHUNK, bytes.length));
              binary += String.fromCharCode.apply(null, chunk);
            }
            result = { data: btoa(binary), size: buf.byteLength };
            break;
          }
          case 'captureTab': {
            // 截取当前标签页可见区域，用于 pageRect 截图
            // 同时返回 tab 视口尺寸，供 iframe 内的截图坐标修正
            var tabId = sender.tab ? sender.tab.id : null;
            if (!tabId) throw new Error('No sender tab');
            var tab = await chrome.tabs.get(tabId);
            var dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
            result = { dataUrl: dataUrl, tabWidth: tab.width, tabHeight: tab.height };
            break;
          }
          case 'getImageData': {
            result = await db.getImageData(params.pageKey, params.imageKey);
            break;
          }
          case 'saveImageData': {
            // P1-19: 外部整记录写入改 read-merge——incoming 显式携带的字段（含新 data）以其
            // 为准，未携带的保留 fresh 现值，防止覆盖并发回填/回写的字段。src 内无发送方，
            // 属遗留外部 op 面，保守合并。
            if (params.record && params.record.pageKey && params.record.imageKey) {
              var _freshImg = await db.getImageData(params.record.pageKey, params.record.imageKey);
              result = await db.saveImageData(Object.assign({}, _freshImg || {}, params.record));
            } else {
              result = await db.saveImageData(params.record);
            }
            break;
          }
          case 'deleteImageData': {
            // P1-13: 已上云图片改标墓碑上行传播；未上云保持物理删
            var _delImgArr = [];
            try { _delImgArr = await db.getByKeys('imageData', [params.id]); } catch (e) { /* ignore */ }
            if (_delImgArr && _delImgArr[0]) {
              result = { success: true, mode: await _deleteImageDataWithTombstone(_delImgArr[0]) };
            } else {
              await db.deleteImageData(params.id);
              result = { success: true, mode: 'deleted' };
            }
            break;
          }
          case 'getImageDataByPage': {
            result = await db.getImageDataByPage(params.pageKey);
            break;
          }
          case 'getImageDataByImageKey': {
            result = await db.getImageDataByImageKey(params.imageKey);
            break;
          }
          case 'getImageDataByPageAndKey': {
            // Phase 9: 文档图片 local-first 精确查询。返回单 record（pageKey_imageKey 索引），
            // 避免 getImageDataByImageKey 返回数组 + 同 imageKey 不同文档歧义。
            var _gdpgPageKey = await _swMd5(params.pageUrl || '');
            result = params.imageKey ? await db.getImageData(_gdpgPageKey, params.imageKey) : null;
            break;
          }
          case 'uploadAsset': {
            // P1-25: 业务失败不再 throw（此前外层 catch 把一切抹成 error.message，注入层完全静默）——
            // 结构化 {uploadFailed:true, serverCode, message} 回传，页面侧按 serverCode 分流 toast。
            // 成功仍回传 {cloudUrl,...}。
            var allowed = await wpzl_isImageCloudUploadAllowed();
            if (!allowed) {
              result = { uploadFailed: true, serverCode: 40310, message: 'feature gate: image cloud upload not allowed' };
              break;
            }
            try {
              // blobBase64（dataURL）转 Blob
              var byteChars = atob(params.blobBase64.split(',')[1]);
              var byteNums = new Array(byteChars.length);
              for (var ui = 0; ui < byteChars.length; ui++) byteNums[ui] = byteChars.charCodeAt(ui);
              var assetBlob = new Blob([new Uint8Array(byteNums)], { type: 'image/webp' });
              result = await wpzl_uploadImage(assetBlob, params.pageKey, params.imageKey);
            } catch (e) {
              console.warn('[uploadAsset] failed:', e && e.message);
              _recordInlineUploadError(params.annId, e);
              result = { uploadFailed: true, serverCode: (e && e.serverCode) || null, message: (e && e.message) || 'upload failed' };
            }
            break;
          }
          case 'resolveImageKeys': {
            // P1-26: imageData 键派生唯一权威——注入层经 checkImageStorage 原始 URL 来取
            // _swMd5 键系 + 存在性。旧注入层 MD5 键与 SW 存储键错配，存在性检查恒 miss。
            var _rkPageKey = await _swMd5(params.pageUrl || '');
            var _rkImgKey = await _swMd5(params.imageUrl || '');
            if (!_rkPageKey || !_rkImgKey) { result = null; break; }
            var _rkRec = await db.getImageData(_rkPageKey, _rkImgKey);
            result = { exists: !!_rkRec, pageKey: _rkPageKey, imageKey: _rkImgKey };
            break;
          }
          case 'saveLocalThumbnail': {
            await db.saveLocalThumbnail(params.annId, params.pageKey, params.dataURL);
            // 修复 BUG-2：本地数据写入成功后，若当前等级具备图片上云权限（wpzl_isImageCloudUploadAllowed），
            // 标记 THUMBNAIL_PENDING（同一 SW 调用内顺序关联）。
            // 用纯 db.updateAnnotation（不经 dispatcher case 'updateAnnotation'），不触发 markDirty/requestSync——
            // 标注本身走正常 saveAnnotation→markDirty(0xFF) 推送（缩略图字段暂空），PENDING 仅用于 flush 扫描。
            // 无图片上云权限的等级（wpzl_isImageCloudUploadAllowed()=false）→ 不标 PENDING → 仅本地存储。
            if (typeof wpzl_isImageCloudUploadAllowed === 'function') {
              var _thumbAllowed = false;
              try { _thumbAllowed = await wpzl_isImageCloudUploadAllowed(); } catch (e) { /* ignore */ }
              if (_thumbAllowed) {
                // 一并持久化 _pageKey：_flushPendingThumbnails 读 ann._pageKey 作为上云 pageKey
                // （objectKey = u/{uid}/{pageKey}/{imageKey}.webp）。注释里原写「commitData fieldMap
                // 未收录 _pageKey」即此处补写——不写则 flush 取到 undefined→空串→/assets/upload 报
                // 「pageKey/imageKey 不能为空」。saveAnnotation 的 merge 会保留此字段，后续编辑不丢。
                // 重新框选截图 = 该标注的自然恢复路径：必须一并复位所有 THUMB_* 失败/终态标记，
                // 否则一个曾被判 THUMB_LOCAL_MISSING 的标注即使重新截图也永远不再补传。
                try {
                  await db.updateAnnotation(params.annId, {
                    THUMBNAIL_PENDING: true,
                    _pageKey: params.pageKey || '',
                    THUMB_RETRY_COUNT: 0,
                    THUMB_EXHAUSTED: false,
                    THUMB_LAST_ERROR: null,
                    THUMB_LOCAL_MISSING: false
                  });
                } catch (e) { console.warn('[thumb] mark PENDING failed:', e.message); }
                // P1-18c: 记入 thumb_pending_ids 清单（flush 靠它替代全表扫）。
                // P1-9（2026-10-05）：必须 await——fire-and-forget 时入队写与下面的 flush 并发，
                // flush 读到旧清单（无本 id）且 truncated=false 跳过补货 → 缩略图永久孤儿
                // （实例 g1791207636294l8uScjHFTv，同批后续截图因时序错开而全部正常）。
                if (typeof wpzlSyncEngine !== 'undefined' && typeof wpzlSyncEngine._noteThumbPending === 'function') {
                  try { await wpzlSyncEngine._noteThumbPending(params.annId); } catch (e) { console.warn('[thumb] note pending failed:', e && e.message); }
                }
                // 缩略图写入后立即触发一次后台上云（不等 connectivity-tick ~5min 周期）：
                // online 时秒级上云→markDirty+即时 push cloudUrl；offline 时由 connectivity-tick 兜底。
                // _thumbnailFlushActive 重入锁保证并发安全；异步触发不阻塞本次响应。
                // P1-9：flush 在入队 await 之后触发，读清单必然含本 id。
                if (typeof _flushPendingThumbnails === 'function') {
                  _flushPendingThumbnails().catch(function (e) { /* 静默 */ });
                }
              }
            }
            result = { ok: true };
            break;
          }
          case 'getLocalThumbnail': {
            var localThumb = await db.getLocalThumbnail(params.annId);
            result = { dataURL: localThumb };
            break;
          }
          case 'backfillThumbnailFromCloud': {
            // 本地优先原则：本地未命中的云端缩略图，由 SW 下载（绕过注入页 CORS）+ 回填 localThumbnails，
            // 返回 dataURL 供调用方显示。下次本地直接命中。失败返回 error（调用方降级签名直显）。
            try {
              if (typeof wpzl_getSignedAssetUrl !== 'function') {
                result = { error: 'asset-uploader not loaded' };
                break;
              }
              if (!params.objectKey) { result = { error: 'missing objectKey' }; break; }
              var _bkSigned = await wpzl_getSignedAssetUrl(params.objectKey);
              if (!_bkSigned) { result = { error: 'sign failed' }; break; }
              // E-P2-3: 30s 超时，签名 URL 挂起不再无限等待
              var _bkResp = await _wpzlFetchWithTimeout(_bkSigned, {}, 30000);
              if (!_bkResp.ok) { result = { error: 'fetch failed: ' + _bkResp.status }; break; }
              var _bkBlob = await _bkResp.blob();
              var _bkDataURL = await new Promise(function (resolve, reject) {
                var reader = new FileReader();
                reader.onloadend = function () { resolve(reader.result); };
                reader.onerror = function () { reject(reader.error); };
                reader.readAsDataURL(_bkBlob);
              });
              await db.saveLocalThumbnail(params.annId, params.pageKey || '', _bkDataURL);
              result = { dataURL: _bkDataURL };
            } catch (e) {
              result = { error: e.message };
            }
            break;
          }
          case 'signAsset': {
            // 注入层（control-panel.js）走 .do 桥，转调签名 URL
            if (typeof wpzl_getSignedAssetUrl !== 'function') {
              result = { error: 'asset-uploader not loaded' };
              break;
            }
            try {
              var signedUrl = await wpzl_getSignedAssetUrl(params.objectKey);
              result = { signedUrl: signedUrl };
            } catch (e) {
              result = { error: e.message };
            }
            break;
          }
          case 'checkImageReferences': {
            result = await db.checkImageReferences(params.webUri, params.imageUrl);
            break;
          }
          case 'getAllTags': {
            result = await db.getAllTags();
            break;
          }
          case 'getAllLocalThumbnails': {
            result = await db.getAllLocalThumbnails();
            break;
          }
          case 'saveTag': {
            result = await db.saveTag(params.name);
            break;
          }
          case 'searchByTag': {
            result = await db.searchByTag(params.tagName);
            break;
          }
          case 'savePageNote': {
            result = await db.savePageNote(params.url, params.noteData);
            // 标脏后触发同步（Pro 用户生效；非 Pro 仅存本地）
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'getPageNote': {
            // 返回完整 pages 记录（含 PAGE_NOTE / FAVORITE / FOLDER_ID 等同步字段）
            result = await db.getPageRecord(params.url);
            break;
          }
          case 'setFavorite': {
            result = await db.setFavorite(params.url, params.isFavorite);
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'getAllFolders': {
            result = await db.getAllFolders();
            // 自愈：folders 完全为空时补建默认目录。_ensureRootFolder 尊重用户删除标记（wpzl_df_del_*），
            // 不会复活已被用户主动删除的 root。覆盖 _finalizeAuth 静默切换分支历史遗漏 + 任何导致 folders
            // 为空的边缘路径（如手动清库、迁移异常），让 manager/popup 打开即自动恢复默认目录。
            if (!result || result.length === 0) {
              try { await _ensureRootFolder(); result = await db.getAllFolders(); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'putFolder': {
            result = await db.putFolder(params.folder);
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'softDeleteFolder': {
            // Pro/启用同步 → 软删（推送后硬删）；否则直接硬删（避免 tombstone 累积），与 deleteAnnotation 一致
            // 注意：必须等 init() 完成（最多 3s）后再判定 isEnabled()，避免 SW 重启窗口期
            // _syncEnabled=false 时误走硬删分支导致 tombstone 丢失、删除无法跨设备同步
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { await wpzlSyncEngine.waitForInit(3000); } catch (e) { /* ignore */ }
            }
            if (typeof wpzlSyncEngine !== 'undefined' && wpzlSyncEngine.isEnabled()) {
              result = await db.softDeleteFolder(params.folderId);
              wpzlSyncEngine.requestSync('normal');
            } else {
              result = await db.deleteFolder(params.folderId);
            }
            break;
          }
          case 'setPageFolderId': {
            result = await db.setPageFolderId(params.url, params.folderId);
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'setSortOrders': {
            // 目录树拖拽重排：批量写排序号（pages/documents/snapshots）
            result = await db.setSortOrders(params.updates);
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'renamePage': {
            // 自定义标题：customTitle 空串/null 表示清除自定义标题，回退到自动 title
            result = await db.setCustomTitle(params.url, params.customTitle);
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'getDocument': {
            result = await db.getDocument(params.docId);
            break;
          }
          case 'getAllDocuments': {
            result = await db.getAllDocuments();
            break;
          }
          case 'getServerBase': {
            // 返回同步/服务端 base（WPZL_SERVER_BASE）。供 manager 构造文档 webUri（manager 页无 server-api.js 上下文）。
            result = (typeof WPZL_SERVER_BASE !== 'undefined') ? WPZL_SERVER_BASE : '';
            break;
          }
          case 'getDailyMarkCount': {
            // V69: 当日已创建标注数（uid+本地日校验）。供 content.js 页面加载时写 meta.dataset.dailyMarkCount
            //（注入侧 feature-gate 每日限额门禁读）。失败返回 0（门禁未知不拦，服务端兜底）。
            try {
              var _dmcIdentity = await db.getUserIdentity();
              var _dmcUid = _dmcIdentity && (_dmcIdentity.userId || _dmcIdentity.authorId);
              result = { count: await wpzl_readDailyMarkCount(_dmcUid) };
            } catch (e) {
              result = { count: 0 };
            }
            break;
          }
          case 'getAccessToken': {
            // 供 manager 打开文档渲染页 /d/{docId} 用——DocumentController 以 token 鉴权（浏览器标签页
            // 导航无法带 Authorization 头）。manager 端用隐藏 form POST 把 token 放进表单体（不再进 URL）。
            // 过期则先 refresh；未登录/刷新失败返回空串（manager 退回 GET 打开，服务端返回 404「文档不
            // 存在或无权访问」，与无 token 现状一致）。
            try {
              var _gat = await _wpzlGetTokens();
              if (_gat && _wpzlIsTokenExpired(_gat) && _gat.refreshToken) {
                try { await _wpzlRefreshAccessToken(); _gat = await _wpzlGetTokens(); } catch (e) { /* ignore */ }
              }
              result = (_gat && _gat.accessToken) ? _gat.accessToken : '';
            } catch (e) { result = ''; }
            break;
          }
          case 'putDocument': {
            // doc = { docId, webUri, domain, urlMd5, title, bodyHtml, folderId }
            // urlMd5 由 SW 补算：manager 页未加载 md5.js（无 wpzl_md5），db.putDocument
            // 新建分支不会回填 urlMd5（会落空串），故在此用 SW 的 wpzl_md5(webUri) 补上。
            var _docParam = Object.assign({}, params.doc || {});
            if ((!_docParam.urlMd5 || _docParam.urlMd5 === '') && _docParam.webUri) {
              _docParam.urlMd5 = wpzl_md5(_docParam.webUri);
            }
            // D1：文档图片已内嵌进 body（data:image/...;base64），随 body 存 R2、随文档删除自动清理，
            // 不再需要按 data-image-key 做图片资产清理（旧 extractDocImageKeys/cleanupDocImages 路径已废弃）。
            result = await db.putDocument(_docParam);
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { wpzlSyncEngine.requestSync('normal'); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'getDocumentBody': {
            // P1-8 分仓后正文唯一读取口：本地 docBodies 命中直返（本地优先——含未同步的本地工作副本，
            // bodyDirty 文档本地比云端新）；未命中 → REST 回拉（DocumentApiController.getDocument，
            // owner JWT 鉴权 → 读 R2 → 读时消毒）并落 docBodies（云读回语义：不标 bodyDirty、
            // 复位下载重试——后续导出/二次打开不再走网络）。
            // P1-35: 失败返回 null（≠ 空文档 ''）——manager 据此显示"加载失败·点击重试"占位，
            // 而非把 R2 瞬时故障渲染成空文档。编辑器侧 null → toast + 仍以空 body 打开兜底。
            try {
              var _localBody = await db.getDocBodyHtml(params.docId);
              if (_localBody) { result = _localBody; break; }
              // localOnly（manager 详情「无 bodyObjectKey」分支用）：只探本地 docBodies，不做 REST
              // 回拉——未同步/本机文档的 body 只在本地；本地也无 → 返回 ''（空文档语义，≠ 失败
              // null），调用方据此渲染「空文档」占位而非把无云端 body 误报成加载失败。
              if (params.localOnly) { result = _localBody || ''; break; }
              var _docBodyResp = await _wpzlApiFetch('/api/v1/documents/' + encodeURIComponent(params.docId), { auth: true });
              var _fetchedBody = (_docBodyResp && _docBodyResp.data && _docBodyResp.data.bodyHtml) || '';
              if (_fetchedBody) {
                try { await db.saveDocumentBodyFromCloud(params.docId, _fetchedBody); } catch (e2) { /* 落库失败不影响返回 */ }
              }
              result = _fetchedBody;
            } catch (e) {
              console.warn('[getDocumentBody] failed:', e && e.message);
              result = null;
            }
            break;
          }
          case 'getSnapshotBody': {
            // P1-8：快照正文读取口。快照无 REST 单体 body 端点（查看走服务端渲染 /snap/{snapId}），
            // 本地 snapBodies 命中直返，未命中返回 ''（跨设备快照本就无本地 body，导出空——与分仓前行为一致）。
            try { result = await db.getSnapBodyHtml(params.snapId); }
            catch (e) { result = ''; }
            break;
          }
          case 'searchDocBodies': {
            // P1-8：文档正文搜索移 SW 侧——分仓后列表消息不携带 body，manager 搜索经此流式扫描
            // docBodies（bodyText 预计算；对无 bodyText 的旧记录回退现剥），返回命中 docId 集。
            // 快照不扫（与分仓前一致，manager 1956 注释：体可达 2MB 逐键扫描会卡顿）。
            result = await (async function () {
              var q = String((params && params.q) || '').toLowerCase();
              if (!q) return { docIds: [] };
              var hits = [];
              await new Promise(function (resolve) {
                var req;
                try { req = db._tx('docBodies', 'readonly').openCursor(); } catch (e) { resolve(); return; }
                req.onsuccess = function (ev) {
                  var cur = ev.target.result;
                  if (!cur) { resolve(); return; }
                  var r = cur.value;
                  if (r && r.docId) {
                    var text = (r.bodyText != null) ? r.bodyText : _wpzlHtmlToText(r.bodyHtml);
                    if (String(text).toLowerCase().indexOf(q) >= 0) {
                      hits.push(r.docId);
                      if (hits.length >= 500) { resolve(); return; }   // 有界：异常大库不爆消息
                    }
                  }
                  cur.continue();
                };
                req.onerror = function () { resolve(); };
              });
              return { docIds: hits };
            })();
            break;
          }
          case 'softDeleteDocument': {
            // Pro/启用同步 → 软删（推送后硬删）；否则直接硬删（避免 tombstone 累积），与 softDeleteFolder 一致
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { await wpzlSyncEngine.waitForInit(3000); } catch (e) { /* ignore */ }
            }
            // 图片清理：删文档前清理其所有图片（本地+云，走同页批注引用检查）
            await _cleanupDocImagesBeforeDelete(params.docId);
            if (typeof wpzlSyncEngine !== 'undefined' && wpzlSyncEngine.isEnabled()) {
              result = await db.softDeleteDocument(params.docId);
              wpzlSyncEngine.requestSync('normal');
            } else {
              result = await db.deleteDocument(params.docId);
            }
            break;
          }
          case 'deleteDocument': {
            await _cleanupDocImagesBeforeDelete(params.docId);
            result = await db.deleteDocument(params.docId);
            break;
          }
          case 'getSnapshot': {
            result = await db.getSnapshot(params.snapId);
            break;
          }
          case 'getAllSnapshots': {
            result = await db.getAllSnapshots();
            break;
          }
          case 'putSnapshot': {
            // snap = { snapId, webUri, domain, urlMd5, title, bodyHtml, sourceWebUri, sourceUrlMd5, folderId }
            // urlMd5 由 SW 补算：采集端（bundle）无 md5 上下文，新建分支会落空串，故在此补上。
            var _snapParam = Object.assign({}, params.snap || {});
            if ((!_snapParam.urlMd5 || _snapParam.urlMd5 === '') && _snapParam.webUri) {
              _snapParam.urlMd5 = wpzl_md5(_snapParam.webUri);
            }
            if ((!_snapParam.sourceUrlMd5 || _snapParam.sourceUrlMd5 === '') && _snapParam.sourceWebUri) {
              _snapParam.sourceUrlMd5 = wpzl_md5(_snapParam.sourceWebUri);
            }
            result = await db.putSnapshot(_snapParam);
            // 快照现已在侧栏独立列出（snapshotToPageLike），不再为「源页」补建 pages 记录——
            // 否则源页会与快照在侧栏重复出现。源页仅在用户真实访问/标注时由 _updatePageRecord 落库。
            if (typeof wpzlSyncEngine !== 'undefined') {
              // 快照采集：用 immediate 优先级推送上传，减少用户打开快照页时「尚未同步」的竞态窗口
              try { wpzlSyncEngine.requestSync('immediate'); } catch (e) { /* ignore */ }
            }
            break;
          }
          case 'softDeleteSnapshot': {
            if (typeof wpzlSyncEngine !== 'undefined') {
              try { await wpzlSyncEngine.waitForInit(3000); } catch (e) { /* ignore */ }
            }
            if (typeof wpzlSyncEngine !== 'undefined' && wpzlSyncEngine.isEnabled()) {
              result = await db.softDeleteSnapshot(params.snapId);
              wpzlSyncEngine.requestSync('normal');
            } else {
              result = await db.deleteSnapshot(params.snapId);
            }
            break;
          }
          case 'deleteSnapshot': {
            result = await db.deleteSnapshot(params.snapId);
            break;
          }
          case 'getLatestSnapshotBySource': {
            // manager「快照」按钮：按源网页 urlMd5 取最新快照（无则 null → manager 跳 live 页采集）
            result = await db.getLatestSnapshotBySource(params.sourceUrlMd5);
            break;
          }
          case 'getSnapshotsBySourceUrl': {
            // 详情页快照列表：按源页 url 返回全部快照（updatedAt 倒序）。
            // url 形态：普通页=webpath（host+path+search，无协议）；文档页=完整 URL（含协议）。
            // 统一在 SW 端剥协议再 md5，等价于 wpzl_normalizeWebpath(location) 的输出，天然兼容两种页面。
            var _gsSrcUrl = String((params && params.url) || '');
            var _gsNormUrl = _gsSrcUrl.replace(/^https?:\/\//, '');
            var _gsUrlMd5 = wpzl_md5(_gsNormUrl);
            try { result = await db.getSnapshotsBySource(_gsUrlMd5); }
            catch (e) { result = []; }
            break;
          }
          case 'openSnapPage': {
            // 用 chrome.tabs.create 打开快照批注页 /snap/{snapId}（MV3 SW 无法 form POST 进标签页；
            // window.open 在异步回调里会被 popup 拦截）。先 page-session 写 cookie 再开裸 URL。
            var _ospSnapId = params.snapId;
            if (!_ospSnapId) { result = { success: false, error: 'snapId required' }; break; }
            var _ospBase = (typeof WPZL_SERVER_BASE !== 'undefined') ? WPZL_SERVER_BASE : '';
            if (!_ospBase) { result = { success: false, error: 'server base missing' }; break; }
            _ospBase = _ospBase.replace(/\/+$/, '');
            var _ospToken = '';
            try {
              var _ospGat = await _wpzlGetTokens();
              if (_ospGat && _wpzlIsTokenExpired(_ospGat) && _ospGat.refreshToken) {
                try { await _wpzlRefreshAccessToken(); _ospGat = await _wpzlGetTokens(); } catch (e) { /* ignore */ }
              }
              _ospToken = (_ospGat && _ospGat.accessToken) ? _ospGat.accessToken : '';
            } catch (e) { _ospToken = ''; }
            // 用 access token 调 /api/v1/auth/page-session 写入页面会话 cookie（httpOnly, SameSite=Lax），
            // 再开裸 /snap/{snapId}——浏览器导航自动带 cookie，token 不再进 URL（历史/Referer/日志）。
            // fetch 失败不阻塞：仍开裸 URL，cookie 缺失时服务端 404 提示登录。绝不回退 ?token=。
            if (_ospToken) {
              try {
                await fetch(_ospBase + '/api/v1/auth/page-session', {
                  method: 'POST',
                  credentials: 'include',
                  headers: { 'Authorization': 'Bearer ' + _ospToken },
                  signal: AbortSignal.timeout(10000) // E-P2-3: 挂起不再阻塞后续开 tab
                });
              } catch (e) { /* ignore */ }
            }
            chrome.tabs.create({ url: _ospBase + '/snap/' + encodeURIComponent(_ospSnapId) });
            result = { success: true };
            break;
          }
          case 'migrateFoldersFromSettings': {
            // 导入旧备份后强制重跑 folder 迁移（force=true）
            result = await _migrateFoldersFromSettings(true);
            break;
          }
          case 'getPageSnapshot': {
            // url → source_url_md5 → snapshots store 最新一条（manager「快照」按钮：有则打开，无则采集）
            var _snapSrcUrlMd5 = wpzl_md5(params.url);
            try { result = await db.getLatestSnapshotBySource(_snapSrcUrlMd5); }
            catch (e) { result = null; }
            break;
          }
          case 'getPageUrlMd5': {
            // url → pages store URL_MD5（供 manager 按源页查快照等）
            result = await db.getPageUrlMd5(params.url);
            break;
          }
          case 'fetchImageAsBase64': {
            // D1：文档编辑器「将图片保存到文档」按钮 —— 把外链图 fetch 成 base64 内嵌进 body。
            // 合规：普通 GET，不伪造 Referer / 不绕防盗链（manifest 无 declarativeNetRequest）。
            // 403/CORS/网络错 → ok:false，上层提示并保留外链。
            var fiaUrl = params.imageUrl;
            if (!fiaUrl || !/^https?:\/\//i.test(fiaUrl)) { result = { ok: false, reason: 'invalid url' }; break; }
            try {
              // E-P2-3: 30s 超时，源站挂起不再无限等待
              var fiaResp = await _wpzlFetchWithTimeout(fiaUrl, {}, 30000);
              if (!fiaResp.ok) { result = { ok: false, reason: 'HTTP ' + fiaResp.status }; break; }
              var fiaBlob = await fiaResp.blob();
              var fiaCt = (fiaBlob.type || 'image/png').toLowerCase();
              if (fiaCt.indexOf('image/') !== 0) { result = { ok: false, reason: 'not image: ' + fiaCt }; break; }
              var fiaData = await new Promise(function (resolve, reject) {
                var fiaReader = new FileReader();
                fiaReader.onloadend = function () { resolve(fiaReader.result); };
                fiaReader.onerror = function () { reject(fiaReader.error); };
                fiaReader.readAsDataURL(fiaBlob);
              });
              result = { ok: true, dataUrl: fiaData, contentType: fiaCt };
            } catch (e) {
              result = { ok: false, reason: (e && e.message) || String(e) };
            }
            break;
          }
          case 'saveImageFromUrl': {
            // 从 URL 获取图片并保存到 imageData
            var imageUrl = params.imageUrl;
            var pageUrl = params.pageUrl || '';
            var pageKey = await _swMd5(pageUrl);
            var imageKey = await _swMd5(imageUrl);
            if (!pageKey || !imageKey) { result = null; break; }
            // F-1: 本 op 对页面 world 开放且不要求登录，result 不得回传 data（base64）——否则任意网页
            // 可借 SW 的 <all_urls> 权限读取任意跨源 URL 内容并回传页面（绕过 SOP 的 SSRF 通道）。
            // 合法调用方（image-storage 自动备份 / manager 缓存按钮）只判断成功与否，不消费 data（已核对全部调用点）。
            // 检查是否已存储
            var existing = await db.getImageData(pageKey, imageKey);
            if (existing) { result = { exists: true, pageKey: pageKey, imageKey: imageKey }; break; }
            // imageUrl 可能是 R2 objectKey（data:/blob: 锚点图上云后的 cloudUrl，形如 u/{uid}/{pageKey}/{imageKey}.webp）。
            // objectKey 不是合法 URL，直接 fetch 会 TypeError: Failed to fetch。
            // objectKey 图片已是云端图，本地无原始可下载源——此处的"保存到本地"语义为「缓存云端图到本地」，
            // 故先签名（wpzl_getSignedAssetUrl，走登录鉴权 + owner 校验的 /api/v1/assets/sign）再 fetch 签名 URL。
            // 复用 backfillThumbnailFromCloud / backfillImageDataFromUrl 的取图模式（签名 → fetch → blob）。
            var _isObjKey = imageUrl.indexOf('u/') === 0 && imageUrl.indexOf('.webp') > 0;
            var _fetchTarget = imageUrl;
            if (_isObjKey) {
              if (typeof wpzl_getSignedAssetUrl !== 'function') {
                throw new Error('asset-uploader not loaded');
              }
              _fetchTarget = await wpzl_getSignedAssetUrl(imageUrl);
              if (!_fetchTarget) throw new Error('sign failed');
            } else {
              // F-1: 仅接受 http(s) 且拒绝私网/本地目标（SW 可达 localhost/内网，页面自身不可达）
              var _imgUrl = null;
              try { _imgUrl = new URL(imageUrl); } catch (e) { _imgUrl = null; }
              if (!_imgUrl || (_imgUrl.protocol !== 'http:' && _imgUrl.protocol !== 'https:')) {
                throw new Error('image url scheme not allowed');
              }
              if (_wpzlIsPrivateNetworkHost(_imgUrl.hostname)) {
                throw new Error('image url target not allowed');
              }
            }
            // fetch 图片：普通 GET，不伪造 Referer / 不绕防盗链（manifest 无 declarativeNetRequest 权限）。
            // 防盗链图返回 403 → !ok → 抛错 → 上层 cascade（image-storage.js Method 3）走截图兜底，
            // 截"用户已合法看到并渲染"的视口。即：接受服务器的访问控制，不规避。
            // E-P2-3: 30s 超时，源站挂起不再无限等待。
            var imgResp = await _wpzlFetchWithTimeout(_fetchTarget, {}, 30000);
            if (!imgResp.ok) throw new Error('fetch image failed: ' + imgResp.status);
            var imgBlob = await imgResp.blob();
            // F-1: 响应必须是图片——Content-Type image/*，否则按魔数嗅探（部分图床回 octet-stream）。
            // 放行任意 Content-Type 等于把任意跨源文档 base64 化落库/外带。
            var _imgCt = (imgResp.headers.get('Content-Type') || '').split(';')[0].trim().toLowerCase();
            if (_imgCt.indexOf('image/') !== 0) {
              var _magic = new Uint8Array(await imgBlob.slice(0, 12).arrayBuffer());
              var _sniffOk =
                (_magic[0] === 0x89 && _magic[1] === 0x50 && _magic[2] === 0x4E && _magic[3] === 0x47) || // PNG
                (_magic[0] === 0xFF && _magic[1] === 0xD8 && _magic[2] === 0xFF) || // JPEG
                (_magic[0] === 0x47 && _magic[1] === 0x49 && _magic[2] === 0x46) || // GIF
                (_magic[0] === 0x42 && _magic[1] === 0x4D) || // BMP
                (_magic[0] === 0x52 && _magic[1] === 0x49 && _magic[2] === 0x46 && _magic[3] === 0x46 &&
                 _magic[8] === 0x57 && _magic[9] === 0x45 && _magic[10] === 0x42 && _magic[11] === 0x50); // WebP
              if (!_sniffOk) throw new Error('not an image response: ' + (_imgCt || 'unknown'));
            }
            // blob → base64
            var imgBase64 = await new Promise(function (resolve, reject) {
              var reader = new FileReader();
              reader.onloadend = function () { resolve(reader.result); };
              reader.onerror = function () { reject(reader.error); };
              reader.readAsDataURL(imgBlob);
            });
            // SVG 分支：服务端云上传魔数白名单必拒 SVG（D-12，如 xkw 试卷预览 svg 图）。
            // 入库前先栅格化为 PNG——成功则本地/上云均走 PNG；失败保留 SVG 仅本地（_svgLocalOnly），
            // 下方上传段置 exhausted 停止注定失败的重试。不触碰非 SVG 的既有路径。
            var _svgLocalOnly = false;
            if (_imgCt === 'image/svg+xml' || _imgCt === 'image/svg') {
              var _pngDataUrl = await _wpzlRasterizeSvgDataUrl(imgBase64);
              if (_pngDataUrl) {
                imgBase64 = _pngDataUrl;
                imgBlob = _wpzlDataUrlToBlob(_pngDataUrl);
              } else {
                _svgLocalOnly = true;
              }
            }
            var imgUid = '';
            try {
              var imgIdentity = await db.getUserIdentity();
              imgUid = imgIdentity && (imgIdentity.userId || imgIdentity.authorId) || '';
            } catch (e) { /* ignore */ }
            var record = {
              id: pageKey + '_' + imageKey,
              pageKey: pageKey,
              imageKey: imageKey,
              imageUrl: imageUrl,
              data: imgBase64,
              cloudUrl: null,
              contentHash: null,
              USER_ID: String(imgUid), // 决策 4：强制 USER_ID
              SYNC_STATUS: 'local',
              DIRTY_BITS: 0,
              timestamp: new Date().toISOString()
            };
            await (async function () {
              // P1-19/P1-17 连带：记录已存在（重复保存 / evicted 后重新保存）不得整记录 put
              // 打回 local/抹掉 cloudUrl——merge 更新 data 并复位 dataEvicted，保留同步元数据。
              var _ex2 = await db.getImageData(pageKey, imageKey);
              if (_ex2) {
                return db.mergeImageData(pageKey, imageKey, {
                  data: imgBase64,
                  imageUrl: imageUrl,
                  dataEvicted: false,
                  timestamp: _ex2.timestamp || new Date().toISOString()
                });
              }
              return db.saveImageData(record);
            })();
            // F-1: 只回传键与存在状态，data 留在 IDB
            result = { exists: true, pageKey: pageKey, imageKey: imageKey };
            // Pro 用户：异步上传 R2（积压超限则跳过，只存本地）。
            // SVG 栅格化失败的记录置 exhausted——服务端白名单必拒，不发起注定失败的上传。
            if (_svgLocalOnly) {
              await db.mergeImageData(pageKey, imageKey, {
                exhausted: true,
                lastError: WPZL_SVG_LOCAL_ONLY_ERROR
              });
            } else if (typeof wpzl_isImageCloudUploadAllowed === 'function' && typeof wpzl_uploadImage === 'function') {
              _tryUploadImageWithBacklogCheck(imgBlob, pageKey, imageKey, record);
            }
            break;
          }
          case 'saveImageFromBase64': {
            // 从 base64 数据保存（注入脚本 canvas 捕获后发送）
            var b64Data = params.data;
            var imgSrc = params.imageUrl;
            var pgUrl = params.pageUrl || '';
            var pgKey = await _swMd5(pgUrl);
            var imgKey = await _swMd5(imgSrc);
            if (!pgKey || !imgKey) { result = null; break; }
            // 检查是否已存储
            var ex = await db.getImageData(pgKey, imgKey);
            if (ex) {
              // P1-17: 已存在但 data 被容量治理清掉（dataEvicted）→ 回填新 data 并复位标记
              if (ex.dataEvicted || !ex.data) {
                result = await db.mergeImageData(pgKey, imgKey, {
                  data: b64Data,
                  imageUrl: imgSrc,
                  dataEvicted: false
                });
              } else {
                result = ex;
              }
              break;
            }
            var b64Uid = '';
            try {
              var b64Identity = await db.getUserIdentity();
              b64Uid = b64Identity && (b64Identity.userId || b64Identity.authorId) || '';
            } catch (e) { /* ignore */ }
            // SVG 分支：与 saveImageFromUrl 同策略——入库前栅格化为 PNG（服务端白名单必拒 SVG）；
            // 失败则保留 SVG 仅本地并置 exhausted，不发起注定失败的上传。
            var _svgLocalOnly2 = false;
            if (/^data:image\/svg\+xml/i.test(b64Data)) {
              var _pngDataUrl2 = await _wpzlRasterizeSvgDataUrl(b64Data);
              if (_pngDataUrl2) {
                b64Data = _pngDataUrl2;
              } else {
                _svgLocalOnly2 = true;
              }
            }
            var rec = {
              id: pgKey + '_' + imgKey,
              pageKey: pgKey,
              imageKey: imgKey,
              imageUrl: imgSrc,
              data: b64Data,
              cloudUrl: null,
              contentHash: null,
              USER_ID: String(b64Uid), // 决策 4：强制 USER_ID
              SYNC_STATUS: 'local',
              DIRTY_BITS: 0,
              timestamp: new Date().toISOString()
            };
            result = await db.saveImageData(rec);
            // Pro 用户：异步上传 R2（积压超限则跳过，只存本地）
            if (_svgLocalOnly2) {
              await db.mergeImageData(pgKey, imgKey, {
                exhausted: true,
                lastError: WPZL_SVG_LOCAL_ONLY_ERROR
              });
            } else if (typeof wpzl_isImageCloudUploadAllowed === 'function' && typeof wpzl_uploadImage === 'function') {
              // b64Data (dataURL) → blob（blob 类型取 data URL 自带 mime，服务端按魔数识别）
              var assetBlob2 = _wpzlDataUrlToBlob(b64Data);
              _tryUploadImageWithBacklogCheck(assetBlob2, pgKey, imgKey, rec);
            }
            break;
          }
          case 'updateImageDataField': {
            // 强制更新某条 imageData 记录的单个字段（绕过 saveImageFromUrl/Base64 的去重短路）
            // 用途：管理页 ② cloudUrl 路径拉 blob 后回填本地 data 字段（跨设备 pull 来的记录 data 为空）
            var uPageUrl = params.pageUrl || '';
            var uImgUrl = params.imageUrl || '';
            var uField = params.field;
            // 白名单：仅允许更新 data（防止误覆盖 cloudUrl/SYNC_STATUS 等同步元数据）
            if (uField !== 'data') { result = { success: false, error: 'field not allowed: ' + uField }; break; }
            var uPageKey = await _swMd5(uPageUrl);
            var uImgKey = await _swMd5(uImgUrl);
            if (!uPageKey || !uImgKey) { result = { success: false, error: 'invalid keys' }; break; }
            var uExisting = await db.getImageData(uPageKey, uImgKey);
            if (!uExisting) { result = { success: false, error: 'not_found' }; break; }
            uExisting[uField] = params.value;
            // 不改 SYNC_STATUS/DIRTY_BITS/cloudUrl——data 仅作本地显示缓存，同步元数据保持不变，
            // 避免触发不必要的 push 或 LWW 抖动（data 不上云，image_assets 表无此字段）
            await db.saveImageData(uExisting);
            result = { success: true };
            break;
          }
          case 'backfillImageDataFromUrl': {
            // 从原始 URL 抓取图片，绕过 saveImageFromUrl 去重，直接回填 data 字段
            // 用途：manager 分支 ② 优先用原始 URL 回填 IDB（避免走 cloudUrl、节省 R2 流量）
            // SW 端 fetch 不受 CORS 限制（host_permissions），manager 页面 fetch 才有 CORS 问题
            var bPageUrl = params.pageUrl || '';
            var bImgUrl = params.imageUrl || '';
            if (!bPageUrl || !bImgUrl) { result = { success: false, error: 'missing params' }; break; }
            var bPageKey = await _swMd5(bPageUrl);
            var bImgKey = await _swMd5(bImgUrl);
            if (!bPageKey || !bImgKey) { result = { success: false, error: 'invalid keys' }; break; }
            var bExisting = await db.getImageData(bPageKey, bImgKey);
            if (!bExisting) { result = { success: false, error: 'not_found' }; break; }
            // 幂等：已有 data 直接返回成功，避免重复抓取
            if (bExisting.data) { result = { success: true, alreadyHasData: true }; break; }
            // 带超时的 fetch（AbortController，默认 10s）
            var bTimeoutMs = parseInt(params.timeoutMs, 10) || 10000;
            var bController = new AbortController();
            var bTimer = setTimeout(function () { bController.abort(); }, bTimeoutMs);
            try {
              var bResp = await fetch(bImgUrl, { signal: bController.signal });
              if (!bResp.ok) throw new Error('HTTP ' + bResp.status);
              var bBlob = await bResp.blob();
              var bBase64 = await new Promise(function (resolve, reject) {
                var reader = new FileReader();
                reader.onloadend = function () { resolve(reader.result); };
                reader.onerror = function () { reject(reader.error); };
                reader.readAsDataURL(bBlob);
              });
              // 重新读最新记录（可能期间被其他路径更新过），仅写 data 字段
              // 不改 SYNC_STATUS/DIRTY_BITS/cloudUrl——同 updateImageDataField
              var bFresh = await db.getImageData(bPageKey, bImgKey);
              if (bFresh && !bFresh.data) {
                bFresh.data = bBase64;
                await db.saveImageData(bFresh);
              }
              result = { success: true };
            } catch (e) {
              result = { success: false, error: e && e.name === 'AbortError' ? ('timeout_' + bTimeoutMs + 'ms') : (e && e.message) };
            } finally {
              clearTimeout(bTimer);
            }
            break;
          }
          case 'getImageDataByUrl': {
            // 通过原始 URL 查询图片数据（SW 内部计算 hash）
            var gduPageUrl = params.pageUrl || '';
            var gduImgUrl = params.imageUrl || '';
            var gduPageKey = await _swMd5(gduPageUrl);
            var gduImgKey = await _swMd5(gduImgUrl);
            if (!gduPageKey || !gduImgKey) { result = null; break; }
            result = await db.getImageData(gduPageKey, gduImgKey);
            break;
          }
          case 'getImageDataBatch': {
            // 批量查询多个图片URL的本地存储状态
            var gdbPageUrl = params.pageUrl || '';
            var gdbUrls = params.imageUrls || [];
            var gdbPageKey = await _swMd5(gdbPageUrl);
            var gdbResults = {};
            for (var gdbI = 0; gdbI < gdbUrls.length; gdbI++) {
              var gdbUrl = gdbUrls[gdbI];
              var gdbImgKey = await _swMd5(gdbUrl);
              if (gdbPageKey && gdbImgKey) {
                var gdbRec = await db.getImageData(gdbPageKey, gdbImgKey);
                if (gdbRec) gdbResults[gdbUrl] = gdbRec;
              }
            }
            result = gdbResults;
            break;
          }
          case 'cleanupImageReferences': {
            // 删除标注后检查并清理无引用的图片数据
            var cwUri = params.webUri;
            var cImgUrl = params.imageUrl;
            var refResult = await db.checkImageReferences(cwUri, cImgUrl);
            if (refResult.count === 0) {
              // 该页面无其他标注引用此图片，删除图片数据
              // P1-13: 走墓碑语义（已上云→pending_deleted 上行传播；否则物理删）
              var cPageKey = await _swMd5(cwUri);
              var cImageKey = await _swMd5(cImgUrl);
              if (cPageKey && cImageKey) {
                var delRec = await db.getImageData(cPageKey, cImageKey);
                if (delRec) {
                  await _deleteImageDataWithTombstone(delRec);
                  result = { deleted: true };
                } else {
                  result = { deleted: false, reason: 'not found' };
                }
              } else {
                result = { deleted: false };
              }
            } else {
              result = { deleted: false, remainingReferences: refResult.count };
            }
            break;
          }
          case 'getSetting': {
            result = await db.getSetting(params.key);
            break;
          }
          case 'saveSetting': {
            result = await db.saveSetting(params.data);
            break;
          }
          case 'getUserIdentity': {
            result = await db.getUserIdentity();
            break;
          }
          case 'updateAuthorName': {
            result = await db.updateAuthorName(params.authorId, params.newName);
            break;
          }
          default:
            throw new Error('Unknown operation: ' + operation);
        }

        // P1-36: 写操作成功后广播数据变更（多 manager tab 失效重拉）。origin 取 sender.tab.id
        // （tab 宿主的扩展页才有；popup 发起时 undefined → 广播全体，接收侧自源过滤退化接受）。
        var _dcStores = _DB_WRITE_OP_STORES[operation];
        if (_dcStores) {
          try { _broadcastDataChanged(_dcStores, sender.tab ? sender.tab.id : null); } catch (e) { /* ignore */ }
        }

        sendResponse({ success: true, data: result });
      } catch (error) {
        console.error('Sagitnote DB error:', error);
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true; // 异步响应
  }
});
