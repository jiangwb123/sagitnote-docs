/* ============================================================
   Sagitnote - 共享主题加载器（每个扩展页面 <head> 同步引入）
   ------------------------------------------------------------
   - 启动读 chrome.storage.local['wpzl_theme']（默认 'auto'），
     写到 <html data-theme="...">。
   - 监听 chrome.storage.onChanged，跨页签实时换肤
     （设置页改皮肤后，所有打开的 manager/popup/settings/auth 立即生效）。
   - 'auto' 由 theme.css 的 @media (prefers-color-scheme) 纯 CSS 处理，
     无需 matchMedia 监听；切换系统主题即时生效、无 FOUC。
   <html> 默认带 data-theme="auto"，故 JS 未加载前已按系统正确着色。
   ============================================================ */
(function () {
  "use strict";
  var THEME_KEY = "wpzl_theme";
  var root = document.documentElement;

  function applyTheme(theme) {
    if (theme !== "light" && theme !== "dark" && theme !== "sepia") {
      theme = "auto";
    }
    root.setAttribute("data-theme", theme);
  }

  function init() {
    if (!chrome || !chrome.storage || !chrome.storage.local) {
      applyTheme("auto");
      return;
    }
    chrome.storage.local.get([THEME_KEY], function (res) {
      applyTheme(res && res[THEME_KEY]);
    });
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === "local" && changes[THEME_KEY]) {
        applyTheme(changes[THEME_KEY].newValue);
      }
    });
  }

  init();
})();
