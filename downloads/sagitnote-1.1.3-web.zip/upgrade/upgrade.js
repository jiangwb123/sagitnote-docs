// 升级 Pro 弹窗页（upgrade/upgrade.html，经 SW wpzl-open-upgrade 以 popup 窗口打开）。
// 布局：Hero（价值主张 + 当前套餐）→ 退款保障横幅 → 两栏（左：套餐卡 + 权益对比 / 右：结算摘要 + 单 CTA）→ 底栏。
// 数据全部经 SW 消息桥取自服务端：pro-status / payment-products / grade-list / payment-*。
// 到期叠加以服务端发放为准（PaymentService.grantIfCreated：在订则旧到期日 + 时长），本页仅做预览。
//
// 设计要点（勿随手改回多按钮）：整页只有右栏一个支付 CTA —— 套餐卡只承担"选择"，
// 于是 pendingOrderNo / payHold / payMaxExpiryAt 三种禁购门控只有一处生效点，不会出现
// 多按钮状态漂移。所有门控的服务端兜底仍是 40321 / 40322。
!function () {
  'use strict';

  // 登记升级面板所在 tabId：SW _wpzlOpenUpgradePanel 复用窗口用（免 "tabs" 权限的
  // 登记制，详见 SW _wpzlGetRegisteredTab 注释）。popup 窗口关闭由 SW onRemoved 除名。
  try {
    chrome.tabs.getCurrent(function (tab) {
      if (tab && tab.id != null) chrome.storage.session.set({ wpzl_upg_tab_id: tab.id });
    });
  } catch (e) { /* ignore */ }

  // ---- 状态 ----

  var state = {
    auth: null,          // auth-status 响应
    pro: null,           // pro-status 响应 / wpzl-pro-status-updated 广播
    products: null,      // payment-products 响应（数组）
    grades: null,        // grade-list 响应（数组）
    pendingOrderNo: null,// 轮询中的订单号（待支付态标记）
    pendingProductCode: null, // 待支付单对应的套餐 code（续付必须回到同一套餐，不能按当前选中项重下）
    creating: false,     // 下单请求在途（防重复点击；真正的跨窗口去重在 SW）
    payHold: null,       // payment-pay-hold 响应 {held,until,orderNo}；null=未持有/未知（UI fail-open，服务端硬拦）
    payMaxExpiryAt: null,// 下单累加到期日上限（pay-hold maxExpiryAt）；null=未知（fail-open，服务端 40322 硬拦）
    pollTimer: null,
    verifyTimer: null,   // 订单已 EXPIRED 后的低频复查定时器（晚到付款的自愈回显）
    loading: false,
    selectedCode: null,  // 当前选中套餐 code（默认取单位天数价格最低且未被有效期上限拦截的那个）
    cmpExpanded: false,  // 权益对比是否展开全部行
    lastLoadAt: 0        // 上次成功取到目录的时刻（window focus 静默重取的节流基准）
  };

  // ---- Helpers ----

  // chrome.i18n.getMessage 的短封装：键缺失时回退 en（default_locale），再退键名本身
  function getMessage(key, subs) {
    return chrome.i18n.getMessage(key, subs) || key;
  }

  function $(id) { return document.getElementById(id); }

  function applyI18n() {
    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      var msg = chrome.i18n.getMessage(el.getAttribute('data-i18n'));
      if (msg) el.textContent = msg;
    });
    document.querySelectorAll('[data-i18n-title]').forEach(function (el) {
      var msg = chrome.i18n.getMessage(el.getAttribute('data-i18n-title'));
      if (msg) el.title = msg;
    });
    document.querySelectorAll('[data-i18n-aria-label]').forEach(function (el) {
      var msg = chrome.i18n.getMessage(el.getAttribute('data-i18n-aria-label'));
      if (msg) el.setAttribute('aria-label', msg);
    });
    var lang = chrome.i18n.getUILanguage();
    if (lang) document.documentElement.lang = lang;
  }

  function showToast(msg, isError) {
    var el = $('upgToast');
    if (!el) return;
    var txt = el.querySelector('.js-toast-text');
    if (txt) txt.textContent = msg;
    el.classList.toggle('is-error', !!isError);
    el.style.display = '';
    clearTimeout(showToast._t);
    showToast._t = setTimeout(function () { el.style.display = 'none'; }, 3200);
  }

  function sendMsg(msg, cb) {
    chrome.runtime.sendMessage(msg, function (resp) {
      if (chrome.runtime.lastError) {
        cb({ success: false, error: chrome.runtime.lastError.message });
        return;
      }
      cb(resp || { success: false, error: 'no response' });
    });
  }

  function fmtDate(d) {
    try { return d.toLocaleDateString(); } catch (e) { return ''; }
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // Bug B（同步时区轴统一，同 manager.js parseStoredTime）：服务端 LocalDateTime 为 UTC，
  // ISO naive 串须按 UTC 解析再本地渲染；直接 new Date(naive) 会偏一个时区（日界附近差一天）。
  function parseStoredTime(ts) {
    if (!ts) return new Date(NaN);
    var s = String(ts).trim();
    // 绝对时间（末尾 Z 或显式 ±HH:MM / ±HHMM）→ 按原样解析
    if (/[zZ]$/.test(s) || /[+-]\d{2}:?\d{2}$/.test(s)) {
      if (!/[zZ]$/.test(s) && /[+-]\d{2}$/.test(s)) s = s.slice(0, -2) + ':' + s.slice(-2); // "+0800"→"+08:00"
      return new Date(s);
    }
    // 无时区 naive（空格或 T 分隔、可含毫秒尾）→ 视为 UTC
    var n = s.replace(/\.\d+$/, '').replace('T', ' ');
    if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/.test(n)) return new Date(NaN);
    return new Date(n.replace(' ', 'T') + 'Z');
  }

  // 服务端值约定：-1=无限（显式下发），0=不可用，正数=限额；
  // null/undefined=字段缺失——渲染「—」（未知），不得落进「∞ 无限」在购买页造成夸大
  function fmtLimitValue(v, unitKey) {
    if (v === null || v === undefined) {
      return { text: '—', cls: 'off' };
    }
    if (v === -1) {
      return { text: '∞ ' + getMessage('upgValUnlimited'), cls: 'unlimited' };
    }
    if (v === 0) {
      return { text: getMessage('upgValDisabled'), cls: 'disabled' };
    }
    return { text: Number(v).toLocaleString() + (unitKey ? ' ' + getMessage(unitKey) : ''), cls: '' };
  }

  // 布尔功能行（购买页语汇）：true → ✓（绿色，表示此套餐包含该功能）；false → 「不含」。
  // 不用「开/关」——那是设置页控件语汇，放在购买对比里读不出"套餐是否包含此功能"。
  function fmtBoolVal(b) {
    if (b === null || b === undefined) return { text: '—', cls: 'off' };
    return b ? { text: '✓', cls: 'on' } : { text: getMessage('upgValNotIncluded'), cls: 'off' };
  }

  // 云存储展示：≥1000MB 按 GB 折算（与官网「20GB」口径一致，避免 20,000 MB 这类难读值）；
  // -1/0 仍走 fmtLimitValue（∞ 无限 / 不可用）
  function fmtStorageValue(mb) {
    if (mb === null || mb === undefined || mb === -1 || mb === 0) return fmtLimitValue(mb);
    var n = Number(mb);
    if (n >= 1000) return { text: (n % 1000 === 0 ? n / 1000 : (n / 1000).toFixed(1)) + ' GB', cls: '' };
    return { text: n.toLocaleString() + ' ' + getMessage('upgUnitMb'), cls: '' };
  }

  // 每类标记行专用：limitPerPage=-1（服务端不单独设限）不渲染「∞ 无限」——
  // 上方「总标记数」「单页标注总数」两行才是真实上限，逐类 ∞ 会被误读为"该类标记数量无限"。
  // ✓ 仅表示该类型可用，实际数量受上述两行兜底（与网站定价卡/文档「不单独限量」口径一致）。
  function fmtTypeLimitValue(tl) {
    if (!tl || tl.enabled === false || tl.limitPerPage === 0) {
      return { text: getMessage('upgValDisabled'), cls: 'disabled' };
    }
    if (tl.limitPerPage === null || tl.limitPerPage === undefined || tl.limitPerPage === -1) {
      return { text: '✓', cls: 'on' };
    }
    return { text: Number(tl.limitPerPage).toLocaleString(), cls: '' };
  }

  // 导出格式：列表为空/缺失 → 不可用（与服务端口径一致）
  // 列宽有限会截断，故把完整列表同时写进 title（悬停可看全）
  function fmtFormatsValue(list) {
    if (!list || !list.length) return { text: getMessage('upgValDisabled'), cls: 'disabled' };
    return {
      text: getMessage('upgFormatsCount', [String(list.length), list.join(' / ')]),
      cls: '',
      title: list.join(' / ')
    };
  }

  // 产品名：优先服务端 nameKey 走 i18n，回落 name / code（与原 manager _mgrPayProductName 同口径）
  function productName(p) {
    var key = p.nameKey || '';
    var localized = key ? getMessage(key) : '';
    if (key && localized !== key) return localized;
    return p.name || p.code;
  }

  // ---- 金额 / 时长 / 折扣派生（纯前端，不新增服务端字段） ----

  function productDays(p) {
    var n = Number(p && p.durationDays);
    return isFinite(n) && n > 0 ? n : 0;
  }

  function productAmount(p) {
    var n = Number(p && p.amount);
    return isFinite(n) ? n : null;
  }

  // 单位天数价格：用于「折合每月」「省 X%」「默认选中」三处口径统一
  function perDayPrice(p) {
    var a = productAmount(p);
    var d = productDays(p);
    return (a !== null && d > 0) ? a / d : null;
  }

  function fullAmount(p) {
    if (!p) return '';
    return p.formattedAmount || ((p.amount != null ? p.amount : '') + ' ' + (p.currency || ''));
  }

  // 把服务端已格式化金额（如 "¥168.00" / "$29.00"）拆成「符号 + 数字 + 尾巴」三段，
  // 供大字号价格排版使用；拆不出来就整体当数字、符号留空（不猜货币、不硬编码符号）。
  // 大字号排版下 ".00" 是纯噪声，末尾全零小数位去掉（18.00→18、18.50→18.5，18.05 不动）。
  function splitAmount(p) {
    var fmt = String((p && p.formattedAmount) || '').trim();
    var m = fmt.match(/^([^\d]*?)([\d.,]+)\s*(.*)$/);
    if (!m) return { cur: '', num: fmt || String(p && p.amount != null ? p.amount : ''), tail: '' };
    var num = m[2].replace(/([.,])0+$/, '');
    return { cur: m[1].trim(), num: num, tail: m[3].trim() };
  }

  // 计价周期单位：≥350 天按「年」，27–31 天按「月」，其余按「天」
  function planUnitLabel(p) {
    var d = productDays(p);
    if (d >= 350) return getMessage('upgUnitYear');
    if (d >= 27 && d <= 31) return getMessage('upgUnitMonth');
    return d + ' ' + getMessage('upgDaysShort');
  }

  // 同比省钱比例：只在同一货币、且比最贵单位价便宜 ≥3% 时返回整数百分比，
  // 跨币种或差距过小时返回 null（宁可不显示，也不做跨币种误算/虚假折扣）。
  function savingPercent(p) {
    var list = (state.products || []).filter(function (x) {
      return String(x.currency || '') === String(p.currency || '');
    });
    if (list.length < 2) return null;
    var maxPerDay = 0;
    list.forEach(function (x) {
      var v = perDayPrice(x);
      if (v !== null && v > maxPerDay) maxPerDay = v;
    });
    var mine = perDayPrice(p);
    if (!mine || !maxPerDay || mine >= maxPerDay) return null;
    var pct = Math.round((1 - mine / maxPerDay) * 100);
    return pct >= 3 ? pct : null;
  }

  // 是否单位天数价格最低（用于「推荐」角标：同币种内唯一一项，多套餐时才标）
  function isBestValue(p) {
    var list = state.products || [];
    if (list.length < 2) return false;
    var mine = perDayPrice(p);
    if (mine === null) return false;
    var best = null;
    list.forEach(function (x) {
      if (String(x.currency || '') !== String(p.currency || '')) return;
      var v = perDayPrice(x);
      if (v !== null && (best === null || v < best)) best = v;
    });
    return best !== null && Math.abs(mine - best) < 1e-9;
  }

  // 「折合每月」：不足 60 天周期（月卡）折合每月等于原价，无信息量，返回 null 改显示计费说明
  function perMonthLabel(p) {
    if (productDays(p) < 60) return null;
    var perDay = perDayPrice(p);
    if (perDay === null) return null;
    var monthly = perDay * 30;
    var split = splitAmount(p);
    var num = monthly % 1 === 0 ? String(monthly) : monthly.toFixed(1);
    return (split.cur || '') + num;
  }

  // ---- 到期预览（对齐服务端 base = wasActive ? oldExpiry : now） ----

  function previewExpiry(pro, product) {
    var now = Date.now();
    var cur = pro && pro.expiresAt ? parseStoredTime(pro.expiresAt).getTime() : NaN;
    var active = !isNaN(cur) && cur > now;              // 在订：从旧到期日叠加
    var base = active ? cur : now;                       // 未订/已过期：立即生效
    var days = productDays(product);
    var newExpiry = new Date(base + days * 86400000);
    return { active: active, base: new Date(base), newExpiry: newExpiry };
  }

  // 有效期上限门控（与 40322 同口径，逐套餐计算）
  function horizonBlocked(p) {
    if (!state.payMaxExpiryAt || !p) return false;
    var max = parseStoredTime(state.payMaxExpiryAt).getTime();
    if (isNaN(max)) return false;
    return previewExpiry(state.pro, p).newExpiry.getTime() > max;
  }

  // ---- 选中项 ----

  function selectedProduct() {
    var list = state.products || [];
    if (!list.length) return null;
    var hit = null;
    list.forEach(function (p) { if (p.code === state.selectedCode) hit = p; });
    return hit;
  }

  // 默认选中：单位天数价格最低且未被有效期上限拦截的套餐；全部被拦截时退回第一个
  function pickDefaultCode() {
    var list = state.products || [];
    var best = null;
    var bestPerDay = Infinity;
    list.forEach(function (p) {
      if (horizonBlocked(p)) return;
      var v = perDayPrice(p);
      if (v === null) return;
      if (v < bestPerDay) { bestPerDay = v; best = p.code; }
    });
    if (best) return best;
    return list.length ? list[0].code : null;
  }

  // ---- 区域可见性 ----

  function setHidden(el, hidden) { if (el) el.hidden = !!hidden; }

  // Hero 右上角「当前套餐」卡（含刷新按钮）：数据未知/未登录时整块不显示，避免出现「—」空卡
  function setPlanCardVisible(visible) {
    setHidden(document.querySelector('.upg-plan-wrap'), !visible);
  }

  function showSkeleton() {
    setHidden($('upgLeft'), true);
    setHidden($('upgSide'), true);
    setHidden($('upgCenter'), true);
    setHidden($('upgSkelLeft'), false);
    setHidden($('upgSkelSide'), false);
    setPlanCardVisible(false);
  }

  function showMain() {
    setHidden($('upgLeft'), false);
    setHidden($('upgSide'), false);
    setHidden($('upgCenter'), true);
    setHidden($('upgSkelLeft'), true);
    setHidden($('upgSkelSide'), true);
    setPlanCardVisible(true);
  }

  // ---- 占位态（未登录 / 加载失败 / 联系客服） ----

  var ICON_LOCK = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>';
  var ICON_ALERT = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><line x1="12" y1="8" x2="12" y2="12.5"/><line x1="12" y1="16.5" x2="12.01" y2="16.5"/></svg>';
  var ICON_INFO = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><line x1="12" y1="11" x2="12" y2="16"/><line x1="12" y1="7.5" x2="12.01" y2="7.5"/></svg>';

  function renderCenter(cfg) {
    setHidden($('upgLeft'), true);
    setHidden($('upgSide'), true);
    setHidden($('upgSkelLeft'), true);
    setHidden($('upgSkelSide'), true);
    setHidden($('upgCenter'), false);
    setHidden($('upgHold'), !state.payHold);
    // 未登录时不显示当前套餐卡（无数据）；已登录但支付未开放/加载失败时保留
    setPlanCardVisible(!!(state.auth && state.auth.isLoggedIn));

    $('upgCenterIcon').innerHTML = cfg.icon || ICON_LOCK;
    $('upgCenterTitle').textContent = cfg.title || '';
    $('upgCenterMsg').textContent = cfg.msg || '';
    setHidden($('upgCenterList'), !cfg.list);
    var contactEl = $('upgCenterContact');
    contactEl.textContent = cfg.contact || '';
    setHidden(contactEl, !cfg.contact);

    var btn = $('upgCenterBtn');
    btn.textContent = cfg.btn || '';
    btn.classList.toggle('is-ghost', !!cfg.ghost);
    btn.onclick = cfg.onClick || null;
  }

  function renderLoading() {
    showSkeleton();
  }

  function renderLoggedOut() {
    renderCenter({
      icon: ICON_LOCK,
      title: getMessage('upgNotLoggedInTitle'),
      msg: getMessage('upgNotLoggedInMsg'),
      list: true,
      btn: getMessage('upgLoginBtn'),
      onClick: function () {
        // 登录页为独立标签页；登录成功后 wpzl_auth storage 变化触发本页自动刷新
        sendMsg({ type: 'wpzl-open-auth' }, function () { /* ignore */ });
      }
    });
  }

  function renderError(errMsg) {
    renderCenter({
      icon: ICON_ALERT,
      title: getMessage('upgLoadFailed'),
      msg: errMsg || '',
      btn: getMessage('upgRetry'),
      ghost: true,
      onClick: function () { refreshAll(true); }
    });
  }

  // 支付未启用（50300）/空目录 → 联系客服回落（联系信息经 upgrade-info）
  function renderContact() {
    var el;
    renderCenter({
      icon: ICON_INFO,
      title: getMessage('upgContactTitle'),
      msg: getMessage('upgContactHint'),
      btn: getMessage('upgRetry'),
      ghost: true,
      onClick: function () { refreshAll(true); }
    });
    el = $('upgCenterContact');
    sendMsg({ type: 'upgrade-info' }, function (resp) {
      if (el && resp.success && resp.data && resp.data.contact) {
        el.textContent = resp.data.contact;
        el.hidden = false;
      }
    });
  }

  // ---- 渲染：Hero 当前套餐 ----

  function renderStatusCard() {
    var pro = state.pro;
    var badge = document.querySelector('.js-plan-badge');
    var expiry = document.querySelector('.js-plan-expiry');
    if (!badge || !expiry) return;
    if (!pro) {
      badge.className = 'upg-plan-badge is-free js-plan-badge';
      badge.textContent = '—';
      expiry.textContent = '—';
      return;
    }
    var expired = !!pro.expiresAt && parseStoredTime(pro.expiresAt).getTime() <= Date.now();
    var badgeKey = expired ? 'userExpired' : (pro.isPro ? 'userPro' : 'upgFreePlan');
    badge.className = 'upg-plan-badge js-plan-badge' + (expired ? ' is-expired' : (pro.isPro ? '' : ' is-free'));
    badge.textContent = getMessage(badgeKey);
    expiry.textContent = pro.expiresAt
      ? getMessage(expired ? 'upgExpiryExpiredAt' : 'upgExpiryUntil', [fmtDate(parseStoredTime(pro.expiresAt))])
      : getMessage('upgNeverSubscribed');
  }

  // ---- 渲染：退款窗口持有横幅 ----

  function renderHold() {
    var el = $('upgHold');
    if (!el) return;
    if (!state.payHold) { setHidden(el, true); el.textContent = ''; return; }
    var untilStr = state.payHold.until ? fmtDate(parseStoredTime(state.payHold.until)) : '';
    el.innerHTML =
      '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15.5 14"/></svg>' +
      '<span>' + escapeHtml(getMessage('payHoldBanner', [untilStr])) + '</span>';
    setHidden(el, false);
  }

  // ---- 渲染：权益对比行定义 ----

  // perTypeLimits 的 key 与注入侧标注类型对应（line→自由线条，textAnnotation→文字，imageAnnotation→图片）
  var TYPE_KEYS = [
    ['highlight', 'filterHighlight'],
    ['arrow', 'filterArrow'],
    ['flag', 'filterFlag'],
    ['rect', 'filterRect'],
    ['pageRect', 'filterPageRect'],
    ['rectFrame', 'filterRectFrame'],
    ['elementMark', 'filterElementMark'],
    ['line', 'filterFreehand'],
    ['textAnnotation', 'filterText'],
    ['imageAnnotation', 'filterImgAnno']
  ];

  function gradeCfg(g) { return (g && g.gradeConfig) || null; }

  // 行定义：key=true 的 8 行是默认展示的关键项，其余折叠在「查看完整限额」里。
  // 列配额走 GradeSummaryResponse 独立列，逐类与功能开关走 gradeConfig（口径与原 limitRows 一致）。
  var ROW_SPEC = [
    { label: 'userPanelLimitMark', key: true, get: function (g) { return g.markLimit; }, fmt: fmtLimitValue },
    { label: 'userPanelLimitDoc', key: true, get: function (g) { return g.docLimit; }, fmt: fmtLimitValue },
    { label: 'userPanelLimitStorage', key: true, get: function (g) { return g.cloudStorageMb; }, fmt: fmtStorageValue },
    { label: 'upgFeatCloudSync', key: true, get: function (g) { var c = gradeCfg(g); return c && c.features ? c.features.cloudSync : null; }, fmt: fmtBoolVal },
    { label: 'upgFeatCollaboration', key: true, get: function (g) { var c = gradeCfg(g); return c && c.features ? c.features.collaboration : null; }, fmt: fmtBoolVal },
    { label: 'upgFeatImageCloud', key: true, get: function (g) { var c = gradeCfg(g); return c && c.features ? c.features.imageCloudUpload : null; }, fmt: fmtBoolVal },
    { label: 'userPanelLimitShareReply', key: true, get: function (g) { return g.shareReplyLimit; }, fmt: fmtLimitValue },
    { label: 'upgLimitExportFormats', key: true, get: function (g) { var c = gradeCfg(g); return c ? c.exportFormats : null; }, fmt: fmtFormatsValue },
    { label: 'upgLimitDocSize', key: false, get: function (g) { return g.docSizeLimit; }, fmt: function (v) { return fmtLimitValue(v, 'upgUnitChars'); } },
    { label: 'upgLimitSnapSize', key: false, get: function (g) { return g.snapSizeLimit; }, fmt: function (v) { return fmtLimitValue(v, 'upgUnitChars'); } },
    { label: 'upgLimitTotalPerPage', key: false, get: function (g) { var c = gradeCfg(g); return c ? c.totalLimitPerPage : null; }, fmt: fmtLimitValue }
  ];

  TYPE_KEYS.forEach(function (tk) {
    ROW_SPEC.push({
      label: tk[1],
      key: false,
      get: function (g) {
        var c = gradeCfg(g);
        var per = c && c.perTypeLimits;
        return per ? per[tk[0]] : null;
      },
      fmt: fmtTypeLimitValue
    });
  });

  // 当前档：优先 pro.gradeId 命中；否则回落 isDefault（免费档）；再否则空（渲染「—」）
  function currentGrade() {
    var list = state.grades || [];
    var pid = state.pro && state.pro.gradeId != null ? Number(state.pro.gradeId) : null;
    var byId = null;
    var byDefault = null;
    list.forEach(function (g) {
      if (pid !== null && Number(g.id) === pid) byId = g;
      if (g.isDefault) byDefault = g;
    });
    return byId || byDefault || null;
  }

  function targetGrade() {
    var p = selectedProduct();
    if (!p || p.gradeId == null) return null;
    var hit = null;
    (state.grades || []).forEach(function (g) { if (Number(g.id) === Number(p.gradeId)) hit = g; });
    return hit;
  }

  function clsClass(v, isTarget) {
    if (!v || !v.cls) return '';
    if (v.cls === 'on') return ' is-on';
    if (isTarget && v.cls === 'unlimited') return ' is-unlimited';
    return '';
  }

  function renderCompare() {
    var cur = currentGrade();
    var tgt = targetGrade();
    var p = selectedProduct();

    // 默认档（免费档）名称走本地化键，其余档用服务端下发的等级名（服务端只维护一份中文名）
    function gradeLabel(g) {
      if (!g) return getMessage('upgFreePlan');
      if (g.isDefault) return getMessage('upgFreePlan');
      return g.name || getMessage('upgFreePlan');
    }
    $('upgCmpCurHead').textContent = gradeLabel(cur);
    // 右列表头用「所购套餐名」而非等级名：月卡/年卡同属 Pro 档，用套餐名才能与卡片选中项对上
    $('upgCmpTgtHead').textContent = p ? productName(p) : '—';

    var wrap = $('upgCmpRows');
    var html = '';
    ROW_SPEC.forEach(function (row) {
      var curVal = cur ? row.fmt(row.get(cur)) : { text: '—', cls: 'off' };
      var tgtVal = tgt ? row.fmt(row.get(tgt)) : { text: '—', cls: 'off' };
      html +=
        '<div class="upg-cmp-row' + (row.key ? '' : ' is-extra') + '">' +
          '<span class="upg-cmp-label">' + escapeHtml(getMessage(row.label)) + '</span>' +
          '<span class="upg-cmp-cur' + clsClass(curVal, false) + '"' +
            (curVal.title ? ' title="' + escapeHtml(curVal.title) + '"' : '') + '>' +
            escapeHtml(curVal.text) + '</span>' +
          '<span class="upg-cmp-tgt' + clsClass(tgtVal, true) + '"' +
            (tgtVal.title ? ' title="' + escapeHtml(tgtVal.title) + '"' : '') + '>' +
            escapeHtml(tgtVal.text) + '</span>' +
        '</div>';
    });
    wrap.innerHTML = html;
    wrap.classList.toggle('is-expanded', !!state.cmpExpanded);

    var toggle = $('upgCmpToggle');
    toggle.classList.toggle('open', !!state.cmpExpanded);
    var label = toggle.querySelector('span');
    if (label) {
      label.setAttribute('data-i18n', state.cmpExpanded ? 'upgCompareCollapse' : 'upgCompareExpand');
      label.textContent = getMessage(state.cmpExpanded ? 'upgCompareCollapse' : 'upgCompareExpand');
    }
  }

  // ---- 渲染：套餐卡 ----

  function buildProductCard(product) {
    var isSelected = product.code === state.selectedCode;
    var blocked = horizonBlocked(product);
    var saving = savingPercent(product);
    var recommend = isBestValue(product);
    var split = splitAmount(product);
    var preview = previewExpiry(state.pro, product);
    var perMonth = perMonthLabel(product);
    var days = productDays(product);

    var card = document.createElement('button');
    card.type = 'button';
    card.className = 'upg-card' + (isSelected ? ' is-selected' : '') + (blocked ? ' is-blocked' : '');
    card.setAttribute('data-code', product.code);
    if (blocked) card.setAttribute('aria-disabled', 'true');

    var subText = perMonth
      ? getMessage('upgPerMonthEq', [perMonth])
      : (days >= 350 ? getMessage('upgBillingYearly') : getMessage('upgBillingMonthly'));

    var expText = preview.active
      ? getMessage('upgPreviewCalc', [fmtDate(preview.base), String(days), fmtDate(preview.newExpiry)])
      : getMessage('upgPreviewTitle') + ' · ' + fmtDate(preview.newExpiry);

    var html =
      (recommend ? '<span class="upg-card-flag">' + escapeHtml(getMessage('upgRecommended')) + '</span>' : '') +
      '<span class="upg-card-tick"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></span>' +
      '<span class="upg-card-name">' + escapeHtml(productName(product)) + '</span>' +
      '<span class="upg-card-days">' + escapeHtml(days + ' ' + getMessage('upgDaysShort')) + '</span>' +
      '<span class="upg-card-price">' +
        (split.cur ? '<span class="upg-card-cur">' + escapeHtml(split.cur) + '</span>' : '') +
        '<span class="upg-card-amt">' + escapeHtml(split.num) + '</span>' +
        '<span class="upg-card-per">/ ' + escapeHtml(planUnitLabel(product)) + '</span>' +
      '</span>' +
      '<span class="upg-card-sub">' +
        '<span class="upg-card-eq">' + escapeHtml(subText) + '</span>' +
        (saving ? '<span class="upg-card-save">' + escapeHtml(getMessage('upgSavePercent', [String(saving)])) + '</span>' : '') +
      '</span>' +
      '<span class="upg-card-exp">' +
        '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>' +
        '<span>' + escapeHtml(expText) + '</span>' +
      '</span>' +
      (blocked
        ? '<span class="upg-card-hint">' +
            '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>' +
            '<span>' + escapeHtml(getMessage('payHorizonHint', [fmtDate(parseStoredTime(state.payMaxExpiryAt))])) + '</span>' +
          '</span>'
        : '');

    card.innerHTML = html;
    card.addEventListener('click', function () { selectProduct(product); });
    return card;
  }

  function selectProduct(product) {
    if (!product) return;
    if (horizonBlocked(product)) {
      showToast(getMessage('payHorizonToast', [fmtDate(parseStoredTime(state.payMaxExpiryAt))]), true);
      return;
    }
    if (state.payHold) {
      showToast(getMessage('payHoldToast', [state.payHold.until ? fmtDate(parseStoredTime(state.payHold.until)) : '']), true);
      return;
    }
    if (state.pendingOrderNo) {
      showToast(getMessage('payOrderPendingBlocked'), true);
      return;
    }
    if (state.selectedCode === product.code) return;
    state.selectedCode = product.code;
    renderPlans();
    renderCompare();
    renderSummary();
  }

  function renderPlans() {
    var wrap = $('upgPlans');
    wrap.innerHTML = '';
    (state.products || []).forEach(function (p) { wrap.appendChild(buildProductCard(p)); });
  }

  // ---- 渲染：结算摘要 + 单一 CTA ----

  function renderSummary() {
    var p = selectedProduct();
    var badge = $('upgSumBadge');
    var cta = $('upgCta');

    if (!p) {
      badge.textContent = '—';
      $('upgSumPlan').textContent = '—';
      $('upgSumDays').textContent = '—';
      $('upgSumMode').textContent = '—';
      $('upgSumExpiry').textContent = '—';
      $('upgSumAmount').textContent = '—';
      $('upgCtaText').textContent = getMessage('payBuyNow');
      cta.disabled = true;
      return;
    }

    var preview = previewExpiry(state.pro, p);
    var days = productDays(p);

    badge.textContent = productName(p);
    $('upgSumPlan').textContent = productName(p);
    $('upgSumDays').textContent = days + ' ' + getMessage('upgDaysShort');
    $('upgSumMode').textContent = getMessage(preview.active ? 'upgModeStack' : 'upgModeImmediate');
    $('upgSumExpiry').textContent = fmtDate(preview.newExpiry);
    $('upgSumAmount').textContent = fullAmount(p);

    syncCta();
  }

  // 单 CTA 状态机：pending > hold > horizon 的优先级与禁用原因单一出口
  function syncCta() {
    var p = selectedProduct();
    var cta = $('upgCta');
    var txt = $('upgCtaText');
    var hint = $('upgCtaHint');
    var hintText = $('upgCtaHintText');
    if (!cta || !txt) return;

    var pending = !!state.pendingOrderNo;
    var creating = !!state.creating;
    var hold = !!state.payHold;
    var blocked = horizonBlocked(p);

    // 待支付 ≠ 不能点：第三方收银台的支付窗口可能先于本地订单有效期失效（微信付款单过期 /
    // "请通过商家重新创建订单"），此时必须让用户能重新拉起收银台。同 orderNo 复用在服务端完成
    // （>5 分钟会重签会话拿新链接）；在途请求由 creating + SW 在途去重拦住，不会重复建单。
    cta.classList.toggle('is-loading', creating);
    cta.disabled = !p || creating || hold || blocked;

    txt.textContent = creating
      ? getMessage('payOpening')
      : pending
        ? getMessage('upgCtaResume')
        : (p ? getMessage('upgCtaPay', [fullAmount(p)]) : getMessage('payBuyNow'));

    var hintMsg = '';
    if (hold) {
      hintMsg = getMessage('payHoldToast', [state.payHold.until ? fmtDate(parseStoredTime(state.payHold.until)) : '']);
    } else if (blocked) {
      hintMsg = getMessage('payHorizonToast', [fmtDate(parseStoredTime(state.payMaxExpiryAt))]);
    } else if (pending && !creating) {
      hintMsg = getMessage('payOrderPendingResume');
    }
    if (hintText) hintText.textContent = hintMsg;
    setHidden(hint, !hintMsg);
  }

  // ---- 权益对比展开/收起 ----

  function toggleCompare() {
    state.cmpExpanded = !state.cmpExpanded;
    $('upgCmpRows').classList.toggle('is-expanded', state.cmpExpanded);
    $('upgCmpToggle').classList.toggle('open', state.cmpExpanded);
    var label = $('upgCmpToggle').querySelector('span');
    if (label) label.textContent = getMessage(state.cmpExpanded ? 'upgCompareCollapse' : 'upgCompareExpand');
  }

  // ---- 购买 + 轮询（迁移 manager _mgrPayClick/_mgrPollPaymentStatus 语义） ----

  function setPendingUI() { syncCta(); }

  function clearPendingUI() {
    state.pendingOrderNo = null;
    state.pendingProductCode = null;
    state.creating = false;
    syncCta();
  }

  function stopPoll() {
    if (state.pollTimer) { clearTimeout(state.pollTimer); state.pollTimer = null; }
  }

  function stopVerify() {
    if (state.verifyTimer) { clearInterval(state.verifyTimer); state.verifyTimer = null; }
  }

  // ---- 跨窗口"进行中结账"标记（chrome.storage.session，所有升级面板共享）----
  // 升级面板是独立 popup 窗口，页面内 state.pendingOrderNo 各窗口互不可见；单靠"本页按钮禁用"
  // 拦不住另一个面板再下一单（2026-11-08 双收银台事故：同账户同时开出多个可付款窗口）。
  var PAY_CHECKOUT_KEY = 'wpzl_pay_checkout';
  var PAY_PENDING_TTL_MS = 45 * 60 * 1000; // 与 checkout 会话有效期对齐

  function readCheckoutState(cb) {
    try {
      chrome.storage.session.get([PAY_CHECKOUT_KEY], function (r) {
        cb((r && r[PAY_CHECKOUT_KEY]) || null);
      });
    } catch (e) { cb(null); }
  }

  function writeCheckoutState(st) {
    try {
      var o = {};
      o[PAY_CHECKOUT_KEY] = st;
      chrome.storage.session.set(o);
    } catch (e) { /* ignore */ }
  }

  function clearCheckoutState() {
    try { chrome.storage.session.remove(PAY_CHECKOUT_KEY); } catch (e) { /* ignore */ }
  }

  // 共享的"进行中结账"是否仍然算数：跟随服务端订单有效期（expiresAt），
  // 不再写死 45 分钟——服务端把 checkout-expire-seconds 调成多少，闸门就跟着多少。
  function checkoutAlive(shared) {
    if (!shared || !shared.at) return false;
    if (Date.now() - shared.at >= PAY_PENDING_TTL_MS) return false;
    if (shared.expiresAt) {
      var exp = parseStoredTime(shared.expiresAt);
      // 过期后留 30s 余量给轮询确认（轮询读到 EXPIRED 会主动清闸门）
      if (exp && Date.now() >= exp.getTime() + 30000) return false;
    }
    return true;
  }

  // 记录/刷新跨窗口结账标记。checkoutUrl 参与比对：续付时服务端可能已重签会话，
  // 客户端据此把旧收银台标签直接导航到新链接，而不是聚焦回那张"支付失败"的页面。
  function rememberCheckout(order, productCode, tabId) {
    writeCheckoutState({
      orderNo: order.orderNo,
      productCode: productCode,
      tabId: tabId,
      checkoutUrl: order.checkoutUrl || null,
      at: Date.now(),
      expiresAt: order.expiresAt || null // 跟随服务端订单有效期，闸门不再写死 45 分钟
    });
  }

  function openCheckout(order, productCode) {
    function createInNormalWindow() {
      function create(windowId) {
        var opts = { url: order.checkoutUrl };
        if (windowId != null) opts.windowId = windowId;
        try {
          chrome.tabs.create(opts, function (tab) {
            rememberCheckout(order, productCode, tab && tab.id != null ? tab.id : null);
          });
        } catch (e) { /* ignore */ }
      }
      // 收银台必须开在普通浏览器窗口：升级面板自身是 popup 窗口，tabs.create 默认把新标签开进
      // popup 内——用户一关面板就把收银台一起关掉，付款直接中断。
      try {
        chrome.windows.getLastFocused({ windowTypes: ['normal'] }, function (w) {
          create(w && w.id != null ? w.id : null);
        });
      } catch (e) { create(null); }
    }
    // SW 在途去重会把同一响应回给并发点击的多个面板：这里按 orderNo 再收敛一次，
    // 已有同单收银台标签就聚焦而不是再开一个（不重复扣款，但避免标签成对出现）。
    // 服务端判定旧会话已死时会关闭旧单并返回新 orderNo（2026-11-08）：此时也要复用那张
    // 标签并导航到新链接，否则用户会看到"已过期"的旧收银台 + 并排多出一个新标签。
    readCheckoutState(function (shared) {
      if (shared && shared.tabId != null &&
          (shared.orderNo === order.orderNo || !checkoutAlive(shared) ||
           shared.checkoutUrl !== order.checkoutUrl)) {
        focusCheckout(shared, order, function (alive) {
          if (alive) { rememberCheckout(order, productCode, shared.tabId); return; }
          createInNormalWindow();
        });
        return;
      }
      createInNormalWindow();
    });
  }

  // 接入别的面板已发起的结账：本窗口立刻显示"待支付"态 + 提示上一笔未结束，
  // 而不是看起来还可以再付一笔（打开第二个面板即生效，无需等用户点 CTA）。
  function adoptSharedPending() {
    if (state.pendingOrderNo) return;
    readCheckoutState(function (shared) {
      if (!checkoutAlive(shared)) return;
      if (state.pendingOrderNo) return;
      state.pendingOrderNo = shared.orderNo;
      state.pendingProductCode = shared.productCode || null;
      // 选中项对齐到待支付单的套餐：续付必须回到同一套餐（服务端复用按 productCode 匹配）。
      if (shared.productCode && state.products) {
        var hit = false;
        state.products.forEach(function (p) { if (p.code === shared.productCode) hit = true; });
        if (hit && state.selectedCode !== shared.productCode) state.selectedCode = shared.productCode;
      }
      setPendingUI();
      renderPlans();
      renderSummary();
      startPoll(shared.orderNo);
    });
  }

  // 聚焦已在的收银台标签；若续付已拿到新链接，则把原标签导航过去（旧页面往往已是"支付失败"）。
  // 标签已被用户关掉则回 false（调用方重新开一个，仍是同一 orderNo）。
  function focusCheckout(shared, order, cb) {
    if (shared.tabId == null) { cb(false); return; }
    try {
      chrome.tabs.get(shared.tabId, function (t) {
        if (chrome.runtime.lastError || !t || t.id == null) { cb(false); return; }
        var fresh = !!(order && order.checkoutUrl && shared.checkoutUrl !== order.checkoutUrl);
        try {
          chrome.tabs.update(t.id, fresh ? { url: order.checkoutUrl, active: true } : { active: true });
        } catch (e) { /* ignore */ }
        if (t.windowId != null) {
          try { chrome.windows.update(t.windowId, { focused: true }); } catch (e) { /* ignore */ }
        }
        cb(true);
      });
    } catch (e) { cb(false); }
  }

  function buy(product) {
    if (!product) return;
    if (state.payHold) { // 退款窗口持有期禁购（UI 状态可能过期，服务端 40321 兜底）
      showToast(getMessage('payHoldToast', [state.payHold.until ? fmtDate(parseStoredTime(state.payHold.until)) : '']), true);
      return;
    }
    if (horizonBlocked(product)) { // 有效期上限禁购（同上，服务端 40322 兜底）
      showToast(getMessage('payHorizonToast', [fmtDate(parseStoredTime(state.payMaxExpiryAt))]), true);
      return;
    }
    if (state.pendingOrderNo) {
      // 已有待支付单：不锁死购买入口。第三方收银台的支付单可能已先于本地订单过期/失败，
      // 这里走服务端复用（同 orderNo，>5 分钟会重签会话换新链接），让用户能立刻续付。
      requestOrder(state.pendingProductCode || product.code);
      return;
    }
    // 跨窗口闸门：另一面板已发起结账 → 接上同一订单继续付款。服务端复用同单：会话超时
    // （距上次拉起 >240s）会重拉全新收银台——所以 Pancake 页面显示"支付超时"后，用户点
    // 购买依然能拿到新的可付链接（同一 orderNo，不会重复扣款），绝不再建第二笔订单。
    readCheckoutState(function (shared) {
      if (checkoutAlive(shared)) {
        if (shared.productCode && shared.productCode !== product.code) {
          showToast(getMessage('payOrderPendingBlocked'), true);
          return;
        }
        state.pendingOrderNo = shared.orderNo;
        state.pendingProductCode = shared.productCode || product.code;
        setPendingUI();
        requestOrder(shared.productCode || product.code);
        return;
      }
      requestOrder(product.code);
    });
  }

  // 服务端权威下发"另一产品存在有效待付单"（P2：status=CREATED + pendingProductCode、无 checkoutUrl）。
  // 不直接开收银台（防"想买月卡却静默付了年卡"）：置待付态 + 选中项对齐 + 确认框引导先完成那笔；
  // 用户拒绝则保持「继续支付」入口。这也是浏览器重启后 storage.session 闸门丢失时的状态恢复路径
  // （待付信息由服务端兜底下发，不再只依赖本机会话存储）。
  function handlePendingOther(data) {
    state.pendingOrderNo = data.orderNo || null;
    state.pendingProductCode = data.pendingProductCode || null;
    var name = data.pendingProductName || '';
    if (state.pendingProductCode && state.products) {
      var hit = null;
      state.products.forEach(function (p) { if (p.code === state.pendingProductCode) hit = p; });
      if (hit) {
        name = productName(hit); // 目录内优先本地化名
        if (state.selectedCode !== hit.code) {
          state.selectedCode = hit.code;
          renderPlans();
          renderCompare();
        }
      }
    }
    setPendingUI(); // CTA 变「继续支付」+ 待付提示条
    renderSummary();
    if (state.pendingOrderNo) startPoll(state.pendingOrderNo);
    var until = data.expiresAt ? fmtDate(parseStoredTime(data.expiresAt)) : '';
    var ok = false;
    try {
      ok = window.confirm(getMessage('payPendingOtherBody', [name, until]));
    } catch (e) { /* confirm 不可用（极端环境）：退化为 toast，CTA 仍是「继续支付」 */ }
    if (ok && state.pendingProductCode) {
      requestOrder(state.pendingProductCode);
    } else {
      showToast(getMessage('payOrderPendingResume'), false);
    }
  }

  function requestOrder(productCode) {
    if (state.creating) return; // 在途请求未回：忽略重复点击（跨窗口由 SW 在途去重兜底）
    state.creating = true;
    stopVerify(); // 新单开跑：旧单的过期复查不再打扰（旧单如补发成功由服务端对账兜底）
    syncCta();
    sendMsg({ type: 'payment-create-order', productCode: productCode }, function (resp) {
      state.creating = false;
      // 复用待支付单时服务端发现远端已支付（漏 webhook 自愈）：按支付成功处理，不再发结账链接
      if (resp.success && resp.data && resp.data.status === 'PAID' && !resp.data.checkoutUrl) {
        clearPendingUI();
        clearCheckoutState();
        showToast(getMessage('paySuccess'), false);
        refreshHoldState(); // 刚支付成功即进入退款窗口持有期：立即禁购 + 出横幅
        sendMsg({ type: 'pro-status', forceRefresh: true }, function () { /* 广播链路自处理 */ });
        return;
      }
      // 跨产品待付拦截（P2）：服务端拒绝建新单、返回另一产品的待付单信息 → 引导先完成那笔
      if (resp.success && resp.data && resp.data.status === 'CREATED'
          && !resp.data.checkoutUrl && resp.data.pendingProductCode) {
        handlePendingOther(resp.data);
        return;
      }
      if (!(resp.success && resp.data && resp.data.checkoutUrl)) {
        var code = resp.serverCode || 0;
        // 临时性失败（R1）：远端状态确认中（50301，防双扣款有意拒绝）/ 支付服务暂不可用（50200）/
        // 下单限流（42910）/ 网络或 SW 故障（0）——保留待支付态不清（CTA 仍是「继续支付」，
        // 轮询继续跑），用户稍后重点即自动重试；文案走前端 i18n（服务端消息无多语言）。
        if (code === 50301) {
          showToast(getMessage('payStatusConfirmBusy'), true);
          return;
        }
        if (code === 50200 || code === 42910 || code === 0) {
          showToast(getMessage('payRetryLater'), true);
          return;
        }
        // 确定性失败：清待付态（40020 无效商品 / 50300 未启用 / 40321 40322 风控硬拦 / 其余未知）
        clearPendingUI();
        if (code === 50300) { renderContact(); return; }
        if (code === 40321 || code === 40322) {
          // 服务端门禁硬拦（本页 hold / maxExpiry 状态过期时兜底）
          showToast(resp.error || getMessage('payCreateFailed'), true);
          refreshHoldState();
          return;
        }
        showToast(resp.error || getMessage('payCreateFailed'), true);
        return;
      }
      var order = resp.data;
      state.pendingOrderNo = order.orderNo;
      state.pendingProductCode = productCode;
      openCheckout(order, productCode);
      showToast(getMessage('payWaitPayment'), false);
      setPendingUI();
      startPoll(order.orderNo);
    });
  }

  // 两阶段轮询：0-20 分钟 4s 快档；20 分钟后转 30s 慢档，一直查到订单过期 +60s 为止。
  // 这样支付页失效的那一刻，下一次轮询（≤30s）服务端就会把 CREATED 关成 EXPIRED——
  // 后台状态随即同步，不再依赖 sweeper 的周期（服务端 getOrderStatus 内置"轮询即关单"）。
  function startPoll(orderNo) {
    stopPoll();
    var startedAt = Date.now();
    var FAST_MS = 4000;
    var SLOW_MS = 30000;
    var FAST_WINDOW_MS = 20 * 60 * 1000;
    var EXPIRY_GRACE_MS = 60 * 1000; // 过期后再查 60s，然后交给 sweeper / 日对账兜底
    function schedule(delay) {
      state.pollTimer = setTimeout(function () { tick(); }, delay);
    }
    function tick() {
      sendMsg({ type: 'payment-order-status', orderNo: orderNo }, function (resp) {
        if (!(resp.success && resp.data)) { scheduleNext(null); return; }
        handle(resp.data);
      });
    }
    function handle(d) {
      // 旧单轮询的迟到响应必须丢弃（2026-11-08）：服务端关闭死会话旧单并换新单后，
      // 旧单会翻成 EXPIRED；若此处照常处理，会把刚建立的新单"待支付"态清掉并误报过期。
      // 注意不能调 stopPoll()——它的 timer 已属于新单的轮询，直接返回即可。
      if (state.pendingOrderNo && state.pendingOrderNo !== orderNo) return;
      var st = d.status;
      if (st === 'PAID') {
        stopPoll();
        clearPendingUI();
        clearCheckoutState(); // 结账完成：释放跨窗口闸门
        showToast(getMessage('paySuccess'), false);
        refreshHoldState(); // 刚支付成功即进入退款窗口持有期：立即禁购 + 出横幅
        // forceRefresh 触发 SW 广播 wpzl-pro-status-updated（本页 onMessage 接收热更）
        // + 升级后启用同步引擎。此处不再直接 refreshAll，避免 forceRefresh→广播→再 forceRefresh 死循环。
        sendMsg({ type: 'pro-status', forceRefresh: true }, function () { /* 广播链路自处理 */ });
        return;
      }
      if (st === 'EXPIRED') {
        stopPoll();
        clearPendingUI();
        clearCheckoutState(); // 会话已关：释放跨窗口闸门（后续可重新下单）
        showToast(getMessage('payExpired'), true);
        startExpiredVerify(orderNo);
        return;
      }
      if (st === 'CLOSED') {
        stopPoll();
        clearPendingUI();
        clearCheckoutState();
        showToast(getMessage('payExpired'), true);
        return;
      }
      scheduleNext(d);
    }
    function scheduleNext(d) {
      var elapsed = Date.now() - startedAt;
      if (elapsed <= FAST_WINDOW_MS) { schedule(FAST_MS); return; }
      var expMs = startedAt + 45 * 60 * 1000; // 服务端 expiresAt 缺失时的兜底
      if (d && d.expiresAt) {
        var t = parseStoredTime(d.expiresAt);
        if (t) expMs = t.getTime();
      }
      if (Date.now() > expMs + EXPIRY_GRACE_MS) {
        stopPoll();
        clearPendingUI();
        return;
      }
      schedule(SLOW_MS);
    }
    schedule(FAST_MS);
  }

  // 过期后低频复查（30s × 20 = 10 分钟）：本地会话过期 ≠ 一定没付款（付款可能落在
  // "本地已过期、远端仍可付"的窗口，webhook 也可能晚到）。服务端对 EXPIRED 单会主动查
  // Pancake 并允许补发；这里只负责把补发结果回显成"支付成功"，并解除重复下单的隐患。
  // 不占 pendingOrderNo、不禁用 CTA —— 用户仍可正常重新下单。
  function startExpiredVerify(orderNo) {
    stopVerify();
    var checks = 0;
    state.verifyTimer = setInterval(function () {
      if (++checks > 20) { stopVerify(); return; }
      sendMsg({ type: 'payment-order-status', orderNo: orderNo }, function (resp) {
        if (!(resp.success && resp.data) || resp.data.status !== 'PAID') return;
        stopVerify();
        clearCheckoutState();
        showToast(getMessage('paySuccess'), false);
        refreshHoldState();
        sendMsg({ type: 'pro-status', forceRefresh: true }, function () { /* 广播链路自处理 */ });
      });
    }, 30000);
  }

  // ---- 我的订单（订单/退款留在 manager，深链直达订单 modal） ----

  function openMyOrders() {
    // 复用/聚焦逻辑统一在 SW（登记制，免 "tabs" 权限；hash 深链由 SW 处理：
    // 已开 tab 仅改 hash（manager 的 hashchange 监听接住），未开则直达 #pay-orders）
    chrome.runtime.sendMessage({ type: 'wpzl-open-manager', hash: '#pay-orders' })
      .catch(function () { /* SW 不可用时静默 */ });
  }

  // ---- 退款窗口持有态单拉（支付成功/收到 40321 后重同步，无需整页刷新） ----

  function refreshHoldState() {
    sendMsg({ type: 'payment-pay-hold' }, function (r) {
      state.payHold = (r.success && r.data && r.data.held) ? r.data : null;
      state.payMaxExpiryAt = (r.success && r.data && r.data.maxExpiryAt) ? r.data.maxExpiryAt : null;
      renderHold();
      // 上限变化可能解除/新增逐卡门控：重绘卡片与 CTA
      renderPlans();
      renderSummary();
    });
  }

  // ---- 数据加载 ----

  // silent=true：窗口重新获得焦点时的静默重取（不转菊花、不动骨架），
  // 只把服务端当前目录/等级/持有态重新拉一遍 —— 弹窗复用逻辑会聚焦已开窗口，
  // 若服务端改价/改档，旧窗口不重取就会一直显示旧数据（2026-11-08 改价事故的观感来源）。
  function refreshAll(force, silent) {
    if (state.loading) return;
    state.loading = true;
    var refreshBtn = $('upgRefreshBtn');
    if (refreshBtn && !silent) refreshBtn.classList.add('spin');

    sendMsg({ type: 'auth-status' }, function (authResp) {
      state.auth = authResp.success ? authResp.data : null;
      if (!state.auth || !state.auth.isLoggedIn) {
        state.loading = false;
        if (refreshBtn) refreshBtn.classList.remove('spin');
        renderStatusCard();
        renderLoggedOut();
        return;
      }

      var pending = 4, proErr = null;
      var proData = null, products = null, grades = null, holdData = null;
      function done() {
        if (--pending > 0) return;
        state.loading = false;
        if (refreshBtn) refreshBtn.classList.remove('spin');
        // 静默重取（focus）拿不到目录时保留现有内容：网络抖动不该把正在看的购买页打成错误/客服占位态
        if (silent && (!products || !products.length)) return;
        state.pro = proData || state.pro;
        state.products = products;
        state.grades = grades;
        state.payHold = holdData && holdData.held ? holdData : null;
        state.payMaxExpiryAt = holdData && holdData.maxExpiryAt ? holdData.maxExpiryAt : null;
        state.lastLoadAt = Date.now();

        // 先刷新当前套餐徽章：占位态（未开放/加载失败）也需显示正确的套餐与到期日
        renderStatusCard();
        if (!proData && !products) { renderError((proErr && proErr.error) || ''); return; }
        if (!products || !products.length) {
          // 50300（支付未启用）或空目录 → 联系客服
          renderContact();
          return;
        }

        // 选中项校正：首次进入按「单位天数价格最低且未被上限拦截」自动选中；
        // 已选套餐消失（下架/目录变更）时同样重选
        var stillThere = false;
        (products || []).forEach(function (p) { if (p.code === state.selectedCode) stillThere = true; });
        if (!stillThere) state.selectedCode = pickDefaultCode();

        showMain();
        renderStatusCard();
        renderHold();
        renderPlans();
        renderCompare();
        renderSummary();
        adoptSharedPending(); // 别的面板已开收银台 → 本窗口同步进入待支付态（防第二笔）
      }
      sendMsg({ type: 'pro-status', forceRefresh: !!force }, function (r) {
        if (r.success) proData = r.data; else proErr = r;
        done();
      });
      sendMsg({ type: 'payment-products' }, function (r) {
        if (r.success) products = r.data;
        done();
      });
      sendMsg({ type: 'grade-list', forceRefresh: !!force }, function (r) {
        if (r.success) grades = r.data;
        done();
      });
      sendMsg({ type: 'payment-pay-hold' }, function (r) {
        if (r.success && r.data) holdData = r.data; // 失败按未持有渲染（fail-open），服务端 40321 才是硬门禁
        done();
      });
    });
  }

  // ---- 全局监听 ----

  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg && msg.type === 'wpzl-pro-status-updated') {
      // 广播只热更本地状态后重绘，绝不回发 forceRefresh（否则 forceRefresh→广播 死循环）
      state.pro = msg;
      if (state.products && state.products.length) {
        renderStatusCard();
        renderHold();
        renderCompare();   // 当前档可能变化 → 对比左列需重算
        renderSummary();   // 到期叠加基准变化 → 摘要与 CTA 文案需重算
      }
    }
  });

  // 登录态变化（auth.html 登录成功写 wpzl_auth）→ 自动刷新，无需手刷
  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === 'local' && changes.wpzl_auth) refreshAll(true);
  });

  // ---- init ----

  // 弹窗复用：SW 会聚焦已打开的升级窗口（不再新建）。窗口长时间开着时，服务端改价/改档/退款窗口变化
  // 都不会自动到达本页 —— 重新获得焦点时静默重取一次（60s 节流，占位态/首次加载不重复打扰）。
  var WPZL_REFETCH_MIN_MS = 60000;
  function maybeRefetch() {
    if (document.hidden) return;
    if (!state.products || !state.products.length) return; // 未登录/联系客服等占位态由用户手动刷新
    if (Date.now() - state.lastLoadAt < WPZL_REFETCH_MIN_MS) return;
    refreshAll(true, true);
  }
  window.addEventListener('focus', maybeRefetch);
  document.addEventListener('visibilitychange', maybeRefetch);

  applyI18n();
  renderLoading();
  $('upgRefreshBtn').addEventListener('click', function () { refreshAll(true); });
  $('upgOrdersBtn').addEventListener('click', openMyOrders);
  $('upgCmpToggle').addEventListener('click', toggleCompare);
  $('upgCta').addEventListener('click', function () { buy(selectedProduct()); });
  refreshAll(true);
}();
